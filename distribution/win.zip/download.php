<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de" dir="ltr">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="robots" content="noindex,nofollow" />
		<meta name="keywords" content="Kondom,Kondom,Entsperrwünsche,Geschützte Seiten,MediaWiki-Namensraum,Kondom" />
		<link rel="shortcut icon" href="/favicon.ico" />
		<link rel="search" type="application/opensearchdescription+xml" href="/w/opensearch_desc.php" title="Wikipedia (Deutsch)" />
		<link rel="copyright" href="http://www.gnu.org/copyleft/fdl.html" />
		<title>Quelltext betrachten - Wikipedia</title>
		<style type="text/css" media="screen,projection">/*<![CDATA[*/ @import "/skins-1.5/monobook/main.css?61"; /*]]>*/</style>
		<link rel="stylesheet" type="text/css" media="print" href="/skins-1.5/common/commonPrint.css?61" />
		<link rel="stylesheet" type="text/css" media="handheld" href="/skins-1.5/monobook/handheld.css?61" />
		<!--[if lt IE 5.5000]><style type="text/css">@import "/skins-1.5/monobook/IE50Fixes.css?61";</style><![endif]-->
		<!--[if IE 5.5000]><style type="text/css">@import "/skins-1.5/monobook/IE55Fixes.css?61";</style><![endif]-->
		<!--[if IE 6]><style type="text/css">@import "/skins-1.5/monobook/IE60Fixes.css?61";</style><![endif]-->
		<!--[if IE 7]><style type="text/css">@import "/skins-1.5/monobook/IE70Fixes.css?61";</style><![endif]-->
		<!--[if lt IE 7]><script type="text/javascript" src="/skins-1.5/common/IEFixes.js?61"></script>
		<meta http-equiv="imagetoolbar" content="no" /><![endif]-->
		
		<script type= "text/javascript">/*<![CDATA[*/
var skin = "monobook";
var stylepath = "/skins-1.5";
var wgArticlePath = "/wiki/$1";
var wgScriptPath = "/w";
var wgServer = "http://de.wikipedia.org";
var wgCanonicalNamespace = "";
var wgCanonicalSpecialPageName = false;
var wgNamespaceNumber = 0;
var wgPageName = "Kondom";
var wgTitle = "Kondom";
var wgArticleId = "9076";
var wgIsArticle = false;
var wgUserName = null;
var wgUserGroups = null;
var wgUserLanguage = "de";
var wgContentLanguage = "de";
var wgBreakFrames = false;
var wgCurRevisionId = "29639869";
/*]]>*/</script>
                
		<script type="text/javascript" src="/skins-1.5/common/wikibits.js?61"><!-- wikibits js --></script>
		<script type="text/javascript" src="/w/index.php?title=-&amp;action=raw&amp;gen=js"><!-- site js --></script>
		<style type="text/css">/*<![CDATA[*/
@import "/w/index.php?title=MediaWiki:Common.css&usemsgcache=yes&action=raw&ctype=text/css&smaxage=2678400";
@import "/w/index.php?title=MediaWiki:Monobook.css&usemsgcache=yes&action=raw&ctype=text/css&smaxage=2678400";
@import "/w/index.php?title=-&action=raw&gen=css&maxage=2678400";
/*]]>*/</style>
		<!-- Head Scripts -->
		<script type="text/javascript" src="/skins-1.5/common/ajax.js?61"></script>
	</head>
<body  class="mediawiki ns-0 ltr page-Kondom">
	<div id="globalWrapper">
		<div id="column-content">
	<div id="content">
		<a name="top" id="top"></a>
				<h1 class="firstHeading">Quelltext betrachten</h1>
		<div id="bodyContent">
			<h3 id="siteSub">aus Wikipedia, der freien Enzyklopädie</h3>
			<div id="contentSub">für <a href="/wiki/Kondom" title="Kondom">Kondom</a></div>
									<div id="jump-to-nav">Wechseln zu: <a href="#column-one">Navigation</a>, <a href="#searchInput">Suche</a></div>			<!-- start content -->
			<p>Diese Seite ist für das Bearbeiten gesperrt. Gründe für den Seitenschutz finden sich im <a href="http://de.wikipedia.org/w/index.php?title=Spezial:Log&amp;type=protect&amp;page=Kondom" class="external text" title="http://de.wikipedia.org/w/index.php?title=Spezial:Log&amp;type=protect&amp;page=Kondom" rel="nofollow">Seitenschutz-Logbuch</a>, auf der <a href="/wiki/Diskussion:Kondom" title="Diskussion:Kondom">Diskussionsseite</a> oder in den <a href="/wiki/Wikipedia:Gesch%C3%BCtzte_Seiten" title="Wikipedia:Geschützte Seiten">Regeln für geschützte Seiten</a>. Seiten im <a href="/wiki/Hilfe:MediaWiki-Namensraum" title="Hilfe:MediaWiki-Namensraum">MediaWiki-Namensraum</a> sind grundsätzlich nur von Administratoren bearbeitbar.
</p><p>Du kannst Änderungswünsche für diese Seite auf der zugehörigen Diskussionsseite vorschlagen. Wenn du meinst, dass der Bearbeitungsschutz aufgehoben werden sollte, kannst du dies auf <a href="/wiki/Wikipedia:Entsperrw%C3%BCnsche" title="Wikipedia:Entsperrwünsche">Wikipedia:Entsperrwünsche</a> erklären.
</p><p>Du kannst jedoch den Quelltext dieser Seite betrachten und kopieren:
</p>
<textarea name='wpTextbox1' id='wpTextbox1' cols='80' rows='25' readonly='readonly'>Ein '''Kondom''' (auch '''Präservativ'''; engl. ''Condom'') ist eine dünne Hülle aus [[Vulkanisation|vulkanisiertem]] [[Gummi]], die zur [[Empfängnisverhütung]] und zum Schutz gegen [[sexuell übertragbare Erkrankung]]en vor dem [[Geschlechtsverkehr]] über den [[Erektion|erigierten]] [[Penis]] des Mannes gestreift wird. 

== Geschichte ==
[[Image:Condom_with_manual_from_1813.jpg|thumb|Kondom aus Tierdarm mit Seidenbändern und lateinischer Gebrauchsanleitung von 1813]]
[[Bild:Condom 1900.jpg|thumb|Kondom aus tierischer Membran (um 1900)]]
Die ersten Kondome wurden aus gewebtem Stoff gefertigt. Sie waren nicht besonders wirksam bei der [[Empfängnisverhütung]]. Die ersten wirkungsvollen Kondome wurden aus Schafsdärmen oder anderen tierischen [[Membran]]en hergestellt und sind auch heutzutage noch erhältlich. Sie gelten als sinnlicher, da sie die Körperwärme besser übertragen, sind jedoch nicht so wirkungsvoll wie künstlich hergestellte Kondome bei der Verhütung von Schwangerschaften sowie [[sexuell übertragbare Krankheit|sexuell übertragbaren Krankheiten]] (beispielsweise [[AIDS]], [[Hepatitis C]]). Bereits [[Giacomo Casanova|Casanova]] benutzte solche Kondome, die im 18. Jahrhundert ''English Overcoats'' genannt wurden, um sich vor der gefürchteten [[Syphilis]] zu schützen. Über die Namensherkunft gibt es viele Theorien. Die verbreitetste ist, dass sie ihren Namen von Oberst Dr. Condom erhalten haben, der Hofarzt von [[Karl II. (England)|Charles II.]] war und Hammeldärme zur Empfängnis- und Infektionsverhütung empfohlen haben soll. Eine andere Variante bezieht sich auf die Kombination der Wortbestandteile &quot;con&quot; (ital., bzw. vom lat. &quot;cum&quot; abgeleitet, für &quot;mit&quot;) und &quot;doma&quot; (vom lat. &quot;domus&quot; für &quot;Haus&quot; oder &quot;Kuppel&quot;).

1839 machte [[Charles Goodyear]] eine bahnbrechende Erfindung: die [[Vulkanisierung]] von [[Kautschuk]]. Damit war es möglich, Gummi herzustellen, das wasserfest, wärme- und kältefest sowie bruchstabil war. 1855 stellte dieser das erste Gummi-Kondom her, das 1870 mit zwei Millimeter Dicke und vernahtet serienmäßig produziert wurde. 1912 entwickelte der Gummifabrikant [[Julius Fromm]] eine Methode nahtlose Kondome herzustellen, indem ein Glaskolben in eine Gummilösung eingetaucht wurde. Ab 1930 wurde [[Latex]] als Material benutzt. Diese Entwicklung von Latex-Kondomen war ein großer Schritt nach vorne in Bezug auf Wirksamkeit und Verfügbarkeit. Trotzdem war der Verkauf von Kondomen bis zur Mitte des 20. Jahrhunderts vielerorts verboten beziehungsweise nur zum medizinischen Gebrauch erlaubt. In [[Republik Irland|Irland]] galt eine solche Regelung sogar noch bis Anfang der 1990er Jahre.

Im Ersten Weltkrieg gehörten Kondome zur Standardausrüstung der Soldaten. Die deutsche, französische und britische Armee verteilten Kondome unter den Soldaten. Die US-Armee jedoch tat dies nicht, mit der Folge, dass die US-Soldaten viel häufiger unter Geschlechtskrankheiten litten als Angehörige anderer Armeen.

Die frühen Latex-Kondome waren alle prinzipiell recht ähnlich. Der einzige wesentliche Unterschied war bei einigen Kondomen das Fehlen des heute durchgängig üblichen [[Reservoir]]s zur Aufnahme der Samenflüssigkeit ([[Ejakulat]]). Eine frühe Entwicklung – die ''short cap'' – die nur über die [[Glans penis|Eichel]] des [[Penis]] gestreift wurde, scheiterte kläglich bei der Reduzierung von Schwangerschaften und Krankheiten.

In den nachfolgenden Jahrzehnten kamen die Hersteller mit einer großen Variation von Größen, Farben und Formen von Kondomen auf den Markt, einschließlich solcher, die stimulierende Eigenschaften haben sollten. Zusätzlich sind heute Kondome auf dem Markt, die zur zusätzlichen Sicherheit mit [[Spermizid]]en behandelt sind. Es gibt auch Geschmackskondome in den verschiedensten Richtungen, extra starke Kondome, zum Beispiel für den Gebrauch beim [[Analverkehr|Anal-Sex]], sowie Kondome mit [[Benzocain]], einem Lokalanästhetikum, für längerdauernden Sex. Mit dem Film ''Skin Deep'' wurden Kondome populär, die im Dunkeln leuchten.

Der &quot;[[Durex]] Local Report 2004&quot; ergab, dass in Deutschland 19&amp;nbsp;% der Frauen und 22&amp;nbsp;% der Männer beim Sex mit unbekanntem Partner kein Kondom verwenden. Bei den 21- bis 24-Jährigen verwendet hierbei sogar nur jeder vierte ein Kondom. Der &quot;Durex Global Sex Survey 2005&quot; ergab, dass in Deutschland schon 30&amp;nbsp;% der Bevölkerung auf Kondome verzichten, mit steigender Tendenz. Als Begründung der &quot;Kondomverweigerung&quot; wird oft die stark reduzierte Stimulation und im Zusammenhang damit geringere sexuelle Befriedigung angegeben, vor allem von Männern.

== Materialien ==
Kondome sind meist aus Naturkautschuk-Latex gefertigt. Mittlerweile sind auch Kondome aus [[Polyethylen]] (PE) und [[Polyurethan]] (PUR) auf dem Markt, deren Wirksamkeit mit Latex-Kondomen vergleichbar sein soll. Allerdings fehlen hier noch Testergebnisse und langjährige Erfahrungen. Für Menschen mit Latex-[[Allergie]] sind diese Kondome jedoch eine Alternative. Außerdem sind derartige Kondome auch zusammen mit fett- beziehungsweise ölhaltigen Gleitmitteln einsetzbar. Latex-Kondome werden durch fetthaltige Substanzen (z.B. [[Massageöl]]) porös und verlieren ihre Wirkung. Gleitgele auf Wasserbasis oder das ebenfalls kondomverträgliche [[Silikonöl]] haben dieses Problem nicht.

== Normierung ==
Kondome waren in Europa seit 1996 nach [[DIN]]&amp;nbsp;EN&amp;nbsp;600 normiert. Diese [[Norm]] regelte einerseits die Größe (mindestens 17 Zentimeter lang und 4,4&amp;ndash;5,6 Zentimeter breit), andererseits die Testverfahren, nach denen die Präservative auf ihre Haltbarkeit, Festigkeit und Dichtigkeit geprüft werden. Um zu prüfen, ob sie dicht sind, werden sie in eine [[Elektrolyt]]lösung getaucht. Leuchtet die Lampe an der Prüfstation auf, so fließt Strom durch das Kondom, das heißt es ist undicht und wird aussortiert. Beim Test auf Reißfestigkeit und Dehnungsfähigkeit muss ein Kondom eine Dehnung bis auf das Siebenfache seiner Normalgröße unbeschädigt überstehen. Einem Test der [[Stiftung Warentest]] aus dem Jahre 1999 zufolge erreichten allerdings drei von 29 getesteten Kondomen die Prüfziele nicht.

Seit 2002 gilt die internationale Norm EN&amp;nbsp;ISO&amp;nbsp;4074, abgestimmt zwischen [[CEN]] und [[International Organization for Standardization|ISO]], die unter anderem einen flexibleren Spielraum für Normierung der Größe einräumt. Das Kondom muss hiernach mindestens 16&amp;nbsp;cm lang sein und je nach Breite ein bestimmtes Mindestvolumen garantieren. Eine Beschränkung auf maximal 5,6&amp;nbsp;cm Breite besteht nicht mehr, der Hersteller muss lediglich eine Standardabweichung von +/&amp;minus;&amp;nbsp;2&amp;nbsp;mm gegenüber dem auf der Verpackung angegebenen Wert einhalten.
In Deutschland löst DIN&amp;nbsp;EN&amp;nbsp;ISO&amp;nbsp;4074 die Norm EN&amp;nbsp;600 ab. Kondome, deren Verpackung den Aufdruck „EN&amp;nbsp;600“ tragen, durften nur bis 2004 verkauft werden&lt;ref&gt;[http://www2.din.de/sixcms/detail.php?id=2824 Pressemitteilung des DIN]&lt;/ref&gt;. Fast alle auf dem europäischen Markt verfügbaren Kondome richten sich noch nach den maximalen und minimalen Größenangaben der DIN&amp;nbsp;EN&amp;nbsp;600 (Stand: November 2005), während erste Hersteller anfangen, ihre Produktlinien anzupassen, um der vom Konsumenten gewünschten Größenvielfalt Rechnung zu tragen.

== Qualitäts- und Gütesiegel ==
1981 wurde in Deutschland das erste Qualitätssiegel für Kondome erteilt: das DLF-[[Gütesiegel]] (DLF = '''D'''eutsche '''L'''atex-'''F'''orschungs- und Entwicklungsgemeinschaft). Die DLF ist ein Zusammenschluss von verschiedenen Herstellern. Um das Gütesiegel zu erhalten, wird am Kondom eine Reihe von Normprüfungen durchgeführt. Zusätzlich sind unabhängige Prüfungen von außen erforderlich.

Die Kondome werden in vier Prüfungen getestet:

#Dichtigkeitstest
#Aufblastest
#Dehnungstest
#Mikrobiologische Reinheit

In der Schweiz gibt es den „Verein Gütesiegel für Präservative“. Mit dem Gütesiegel wird garantiert, dass das Kondom der Euronorm für Präservative entspricht. Zusätzlich hat der Verein einen eigenen Kriterienkatalog. Jede Produktionseinheit wird von einem unabhängigen Labor getestet, bevor sie zum Verkauf freigegeben werden darf. Der Verein führt auch Stichproben in Verkaufsläden durch.

[[Bild:Kondom - abgerollt - hängend.jpg|thumb|100px|Kondom, ausgerollt]]
==Ausführungen==
Kondome sind individuellen Bedürfnissen entsprechend in verschiedenen Größen, Farben und für [[Oralverkehr]] auch in verschiedenen Geschmackssorten sowie mit besonderen der Luststeigerung dienenden Oberflächenstrukturen erhältlich.

==Alternativen==
Eine verhütende und zugleich vor Krankheitsübertragungen schützende Alternative zum Kondom ist seit neuerer Zeit das oft als „Kondom für die Frau“ bezeichnete so genannte [[Femidom]].

== Vor- und Nachteile sowie Risiken des Kondoms als Verhütungsmittel ==
=== Vorteile ===

* Bei richtiger Anwendung ist die Sicherheit sehr hoch. Mit einem [[Pearl-Index]] von 2&amp;ndash;14 sind Kondome allerdings deutlich weniger sicher als hormonelle Verhütungsmittel wie zum Beispiel [[Implanon]] mit einem Pearl-Index von 0,1. Ein hoher Unsicherheitsfaktor entsteht in erster Linie durch Fehlverhalten bei der Anwendung.
* Das Kondom ist das einzige Verhütungsmittel, das nicht nur eine Schwangerschaft, sondern auch eine Ansteckung mit [[sexuell übertragbare Erkrankung|sexuell übertragbaren Krankheiten]] (beispielsweise [[HIV]], [[Gonorrhoe]] und [[Hepatitis C]]) weitgehend verhindert.

=== Nachteile===
* Kondome können als unangenehm empfunden werden, da sie den Hautkontakt verhindern. In sexualwissenschaftlichen Studien geben viele Männer an, Kondome würden die Empfindungen verringern. Auch das Überziehen wird oft als Unterbrechung und Störfaktor im [[Sex|Liebesspiel]] angesehen. &lt;ref&gt; Fichtner, Jörg: ''Über Männer und Verhütung.'' Münster 2001. ISBN 3893257144 &lt;/ref&gt; Einige Sexualwissenschaftler sind jedoch der Ansicht, dass die Verringerung der Empfindungsfähigkeit und das Kondom als Störfaktor mehr psychisch durch das Wissen um das Kondom als physisch durch dieses selbst bedingt ist. &lt;ref&gt; Stoppard, Miriam: ''Sexualität und Partnerschaft''. Berlin 2002, ISBN 3-332-01011-5&lt;/ref&gt; &lt;ref&gt; Fichtner, Jörg: ''Wie Man(n) verhütet, so liebt Man[n)?''. In: Bundeszentrale für gesundheitliche Aufklärung (Hrsg.): ''Kontrazeption, Konzeption, Kinder oder keine''. Köln 1996 &lt;/ref&gt;
* Vereinzelt treten auch Fälle von Latex-[[Allergie]]n auf. Die meisten Menschen reagieren jedoch nur sensibel auf die Inhaltsstoffe der einen oder anderen Gleitbeschichtung, dabei können zwischen verschiedenen Marken große Unterschiede bestehen. Zusätzlich bieten manche Hersteller komplett unbeschichtete bzw. trockene Präservative für diesen Fall an. Einige Probleme lassen sich auch auf die spermizide Beschichtung zurückführen. 90% aller allergischen Reaktionen im [[Genitalien|Genitalbereich]] werden durch den Wirkstoff [[Nonoxynol-9]] ausgelöst &lt;ref&gt;[http://www.aids.ch/d/fragen/kondome.php#FAQ6 FAQ Aidshilfe Schweiz]&lt;/ref&gt;. Manchmal ist auch das [[Silikon]] schuld, welches in vielen [[Gleitmittel]]n enthalten ist. Für Latex-Allergiker gibt es auch latexfreie Kondome aus [[Polyurethan]]. Diese sind dünner, besonders gefühlsecht und geruchlos, allerdings auch deutlich teurer als Latex-Kondome (einziges Produkt auf dem deutschen Markt: Durex Avanti).
* Der starke Latex-Geruch wird von vielen Menschen als unangenehm empfunden.

=== Risiken === 
In der Praxis führen Fehler in der Handhabung immer wieder zu ungewollten Schwangerschaften. 
* Schon das Berühren der weiblichen [[Geschlechtsteil]]e mit der (ungewaschenen) Hand, mit welcher das Kondom abgezogen wurde, kann zu einer Schwangerschaft führen
* Bevor das Kondom übergestreift wird, kann es bereits zu unbemerkten Austritt von Sperma kommen, was auch hier zu dem Risiko führt, wenn Körperteile die Vagina berühren, die mit dem Penis in Berührung kommen, bevor das Kondom übergestreift worden ist. Das gleiche gilt für das Überstreifen des Kondoms. Wird im Laufe des [[Vorspiel (Sexualität)|Vorspiels]], das meist aus Spielarten des [[Petting]]s besteht, vor der Benutzung des Kondoms der Penis im Bereich der Eichel berührt, so besteht die Gefahr, dass einzelne Spermien beim Überziehen auf die Oberfläche des Kondoms gelangen und so den Weg in den Scheide finden. Das dadurch entstehende Risiko wird durch spermizid beschichtete Kondome gesenkt.
* Nichtvollständiges Abrollen oder ein Abrollen, das ungleichmäßig erfolgt und damit das Kondom nicht weit genug hin zur Peniswurzel bringt, kann zu einem Ablösen des Kondoms vom Penis während des Geschlechtsaktes führen.
* Wird das Reservoir für das Sperma am oberen Ende beim Abrollen nicht zusammen gedrückt, gelangt Luft hinein oder es wird zu weit über die Eichel gezogen, was zum Platzen führen kann.
* Lange Fingernägel können das Kondom beim Abrollen oder beim Aufreißen der Packung beschädigen. Diese Gefahr besteht auch, wenn während dem Sex die Geschlechtsteile der Frau zusätzlich mit den Fingern stimuliert werden. 
* Beim Einsatz ölhaltiger Gleitmittel wie [[Bodylotion]], [[Massageöl]], [[Babyöl]], [[Vaseline]], [[Butter]] oder bestimmte Spermiziden wie [[Vagina|Scheiden]]-[[Suppositorium|Zäpfchen]] (Suppositorien) und einiger [[Homöopathie|homöopathischer Behandlungen]] kann die Latexstruktur Schaden nehmen, wenn sie nicht für den Einsatz mit Kondomen freigeben sind. Angaben dazu befinden sich meist auf der Verpackung oder dem Beipackzettel. Das Kondom verliert unter solchen Umständen innerhalb von weniger als fünf Minuten seine Dehnbarkeit und, auch wenn das Kondom manchmal nicht reißt oder sichtbare Beschädigungen aufweist, wird es doch durchlässig, beispielsweise für Viren. Wasserhaltige und silikonhaltige Gleitmittel oder Gleitmittel auf Dimeticone-Basis haben solche Risiken nicht.
* Falsch aufbewahrte oder nach Verstreichen des [[Verfalldatum]]s verwendete Kondome können Beschädigungen aufweisen, oft auch unsichtbar, die Viren oder Samen durchlassen. Schädliche Einflüsse sind vor allem [[Sonneneinstrahlung]], [[Hitze]], [[Kälte]] sowie [[mechanische Beanspruchung]], die vor allem bei der Aufbewahrung im [[Automobil|Auto]], [[Portemonnaie]] oder in der [[Hosentasche]] auftreten. 
* Die Verwendung eines (im Verhältnis zur Penisgröße) zu kleinen Kondoms kann Schmerzen oder  Durchblutungsprobleme verursachen. &lt;ref&gt; Fichtner, Jörg, ''Über Männer und Verhütung''. Münster, 2001. ISBN 3893257144 &lt;/ref&gt; Zudem besteht eine erhöhte Reißgefahr. Ein zu großes Kondom rutscht leicht ab vom Penis, wodurch Sperma in die Scheide gelangen kann und kein Schutz mehr besteht. Maßgeblich für die richtige Kondomgröße ist nicht dessen Länge, sondern eine zum Penisumfang passende Breite.

===Automatenkondome bergen besondere Risiken===
Sind die Automaten im Freien aufgestellt, kann aufgrund der Temperaturschwankungen das Material Schaden nehmen und beim Geschlechtsverkehr reißen oder platzen. Es ist auch gut möglich, dass das Mindesthaltbarkeitsdatum abgelaufen ist, da manche Kondomautomaten selten kontrolliert und neu befüllt werden.

== Krebserregende Nitrosamine in Kondomen ==
[[Nitrosamine]] gehören zu den am stärksten krebserregenden Stoffen überhaupt. Auch wenn ein linearer Zusammenhang zwischen aufgenommener Menge und krebserregender Wirkung besteht, können Nitrosamine schon in kleinsten Dosen kanzerogen wirken. Die Bestimmung eines kritischen Grenzwertes ist jedoch problematisch. Nitrosamine können bei der Herstellung von Gummiprodukten im Vulkanisierungsprozess entstehen. Anders als bei vielen anderen Produkten existiert hinsichtlich der Belastung von Kondomen bisher keine gesetzliche Regelung. Eine eingeschränkte Vergleichsmöglichkeit besteht in Bezug auf Babyschnuller, für die eine gesetzliche Höchstgrenze schon seit längerem festgelegt wurde.

Die Auseinandersetzung um die Einschätzung der von Kondomen ausgehenden Gefahr wird derzeit kontrovers geführt. In einer Studie des Chemischen und Veterinäruntersuchungsamtes Stuttgart wurden in 29 von 32 untersuchten Kondomen N-[[Nitrosamine]] nachgewiesen &lt;ref&gt;http://www.cvuas.de/pdf/druck_nitros_kondome2004.pdf&lt;/ref&gt;. Gemäß dieser Studie beträgt die aufgenommene Menge an N-Nitrosaminen bei einmaliger täglicher Kondombenutzung bis zu das Dreifache der täglich über die Nahrung aufgenommenen Menge. Zu deutlich abweichenden Ergebnissen gelangt die Stiftung Warentest &lt;ref&gt;vgl. test 8/2004, S. 88-92 und [http://www.stiftung-warentest.de/online/gesundheit_kosmetik/test/1193915/1193915/1194643.html]&lt;/ref&gt;. Ihr zufolge ist die Belastung an Nitrosaminen in Kondomen erheblich geringer, meist unter dem Höchstwert für Babyschnuller. Das Bundesinstitut für Arzneimittel und Medizinprodukte weist auf eine Studie hin, derzufolge die Nitrosaminbelastung bei der Benutzung eines Kondomes etwa ein bis drei Tausendstel der täglichen Belastung durch die Nahrung beträgt. Deshalb kann nicht behauptet werden, dass die Verwendung von Kondomen für den Anwender zu einem erhöhten Risiko hinsichtlich der Nitrosaminbelastung führt &lt;ref&gt;http://www.bfarm.de/nn_424526/DE/Medizinprodukte/riskinfo/wissauf/kondome__Nitrosamine__280704.html&lt;/ref&gt;. Auch eine weitere Studie kommt zu dem Ergebnis, dass die Nitrosaminbelastung durch Kondome so gering ist, dass das damit verbundene gesundheitliche Risiko sehr gering ist &lt;ref&gt;http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&amp;db=pubmed&amp;dopt=Abstract&amp;list_uids=11759152&lt;/ref&gt;.

==Weitere Nebenwirkungen== 

Kondome, die mit dem Spermizid Nonoxynol-9 beschichtet sind, können die Empfänglichkeit für HIV und andere sexuell übertragbare Krankheiten erhöhen. In diesem Zusammenhang spricht sich die U.S-Amerikanische [[Food and Drug Administration|FDA]] für einen Warnhinweis auf Kondomverpackungen aus.&lt;ref&gt;[http://www.fda.gov/bbs/topics/ANSWERS/2003/ANS01191.html FDA proposes new warning for over-the-counter contraceptive drugs containing Nonoxynol-9]&lt;/ref&gt;

== Die römisch-katholische Kirche und das Kondom ==
Im Gegensatz zur Haltung der meisten protestantischen Kirchen ist nach der offiziellen Lehrmeinung der [[Römisch-katholische Kirche|römisch-katholischen Kirche]] (Humanae vitae) der Gebrauch von Kondomen (wie auch der [[Anti-Baby-Pille]]) als Verhütungsmittel abzulehnen, da er wegen der künstlichen Verhinderung einer Kindszeugung nicht der [[Menschenwürde|Würde des Menschen]] entspräche. Als Möglichkeit verantworteter Elternschaft wird einzig die [[natürliche Familienplanung]], z.&amp;nbsp;B. nach [[Knaus-Ogino-Verhütungsmethode|Knaus-Ogino]] oder die [[Symptothermale Methode]] mit einem [[Pearl-Index]] von 0,3-2,5, akzeptiert. 

Vor allem in [[Europa]] und den [[USA]] wurde das Kondomverbot kritisiert, das Papst [[Johannes Paul II.]] auch in den vom HI-Virus geplagten [[Afrika|afrikanischen]] Ländern ausgerufen hat. Als die spanische [[Bischofskonferenz]] öffentlich bekannt gab, dass sie unter Umständen das Kondom als Mittel im Kampf gegen [[AIDS]] als geringeres Übel akzeptiere, wurde sie vom [[Vatikan]] zurechtgewiesen und zog die Aussage innerhalb von 24 Stunden zurück. Die neue Stellungnahme lautete: &quot;Der Gebrauch von Kondomen verstößt gegen die Moral&quot;.

Unter Papst [[Benedikt XVI.]] sprach sich Kardinal Baragàn für eine Ausnahme des grundsätzlichen Kondomverbots aus, falls in einer Ehe ein Ehepartner HIV-infiziert ist.&lt;ref&gt;dpa: [http://www.tagesspiegel.de/politik/archiv/24.04.2006/2487972.asp Vatikan will Aids-Kranken Kondome erlauben]. ''Der Tagesspiegel'' (24.04.2006)&lt;/ref&gt; Papst [[Johannes Paul II.]] vertrat auch für solche Fälle als einzig moralisch vertretbare Möglichkeit die Enthaltsamkeit. 

[[Bild:Mondos.jpg|thumb|Mondos „feucht“ aus der DDR. (3 Stück 2,00 [[Mark der DDR|Mark]])]]
Die römisch-katholische Kirche hat mit Bezug auf die Versagerquote des Kondoms auch darauf hingewiesen, dass das Kondom keinen hundertprozentigen Schutz gegen [[HIV]] bieten kann, was auch zutrifft. Berichte, dass die Struktur des Kondoms überhaupt keinen Schutz vor Viren bieten könne, sind jedoch falsch.&lt;ref name=&quot;Carey1992&quot;&gt;{{cite journal 
| author=Carey, RF et al
| title=Effectiveness of latex condoms as a barrier to human immunodeficiency virus-sized particles under conditions of simulated use
| journal=Sexually transmitted diseases
| year=1992 
| pages=230-234 
| volume=19 
| issue=4
| id={{PMID |1411838}}
}}&lt;/ref&gt;
&lt;ref name=&quot;Das2001&quot;&gt;{{cite journal 
| author=Das, B et al
| title=Virus transmission through compromised synthetic barriers: part II--influence of pore geometry.
| journal=Journal of biochemical engineering
| year=2001
| pages=513-518 
| volume=123 
| issue=5
| id={{PMID |11601738}}
}}&lt;/ref&gt;
&lt;ref name=&quot;Kettering1993&quot;&gt;{{cite journal 
| author=Kettering, J. 
| title=Efficacy of thermoplastic elastomer and latex condoms as viral barriers.
| journal=Contraception
| year=1993
| pages=559-567 
| volume=47
| issue=6
| id={{PMID | 8392926}}
}}&lt;/ref&gt;

Der Vorwurf, die katholische Kirche sei Schuld an den hohen Infektions-Raten in Afrika, wird in der öffentlichen Diskussion vor allem implizit, aber auch explizit, immer wieder erhoben. Kardinal [[Alfonso López Trujillo|Trujillo]] führt andererseits in seiner Abhandlung an, dass katholisch geprägte Länder ([[Philippinen]]) geringere AIDS-Quoten hätten als nicht katholische Nachbarländer ([[Thailand]]) mit freizügigerer [[Sexualmoral]].

In den [[Presse (Medien)|Medien]] wird 2006 bekannt, dass der Vatikan an einer Prüfung zur Lockerung des Kondomverbots arbeitet. &lt;ref&gt; [http://www.tagesschau.de/aktuell/meldungen/0,1185,OID6120034_TYP6_THE_NAV_REF1_BAB,00.html Meldung der Tagesschau: Lockerung des Kondomverbots] &lt;/ref&gt; &lt;ref&gt; [http://www.stern.de/wissenschaft/medizin/:Aidspr%E4vention-Kurswechsel-Vatikan/577014.html Meldung des Stern:Lockerung des Kondomverbots] &lt;/ref&gt;

== Sonstiges ==
* In Deutschland werden etwa 180 Millionen Kondome pro Jahr verbraucht, das macht 342 Stück pro Minute&amp;nbsp;– aber nur etwa 2,5 pro geschlechtsreifem Bundesbürger und Jahr.
* Im volkstümlichen Sprachgebrauch existieren für Kondome zahlreiche Synonyme, unter anderem „Pariser“, „Verhüterli“, „Lümmeltüte“, „Präser(l)“, „Gummi“, „Nahkampfsocke“, „Fromms“, „Londoner“, „Überzieher“, „Tüte“, &quot;Rammelbeutel&quot;.
* In der [[Deutsche Demokratische Republik|DDR]] waren Kondome im Allgemeinen unter der Bezeichnung &quot;Mondos&quot; oder umgangssprachlich als „Gummi-Fuffzscher“ (Fünfziger) erhältlich. Berühmt war hierfür der diskrete Versand von H. Kästners Familienunternehmen aus Dresden, der bis zu 2 Mio. Kondome pro Jahr versandte.
* Die Preise für Kondome hängen sehr stark von der gekauften Menge ab. 1000er-Packs wechseln schon für 150 Euro den Besitzer, während im Einzelhandel 24 Stück für 12 Euro verbreitet sind.

== Literatur ==
* Marianne Ursula Bauer: ''Die Frommser-Saga: alles über Kondome von A bis Z''. Neuer Sachsenverlag, Leipzig 1991, ISBN 3910164285
* Deutsches Institut für Gütesicherung und Kennzeichnung: ''Kondome. Gütesicherung RAL-RG 203''. Beuth, Berlin ³1996. 
* Caspar Frei: ''Viva Kondom, alles über Kondome, woher sie kommen, wozu man sie braucht, wem sie nützen''. Olms, Zürich 1993, ISBN 3283002630
* Ian Harvey: ''Kondome quer durchs Curriculum''. Verlag an der Ruhr, Mülheim an der Ruhr 1995, ISBN 3860721917
* Mavis Jukes: ''Küsse, Kerls, Kondome. Was Mädchen wissen wollen''. Droemer Knaur, München 1998, ISBN 342682129X
* Claudia Klier: ''Kondome, na sicher! Eine Broschüre über Empfängnisverhütung und Schutz vor Ansteckung''. Maudrich, Wien - München 1990.  ISBN 3-85175-531-6

== Weblinks ==
{{Commons|Category:Condoms|Kondome}}
{{Wiktionary|Kondom}}
{{Wikibooks|Sexualität/ Sexualhygiene|Benutzung von Kondomen}}
* [http://www.netdoktor.at/Sex_Partnerschaft/fakta/kondome.shtml Wissenswertes über Kondome]
* [http://www.testberichte.de/produktindex/produktindex_1860.html Zusammenfassung aktueller Kondom-Tests (Testberichte.de)] 
* [http://www.dr-winter-team.de/beide/norm.htm Die verflixte Norm] - Infos über kleine und große Kondome (mit einem Trick, wie auch zu kleine Kondome drübergehen)
* [http://www.profamilia.de/article/show/910.html Informationen zum Kondom bei pro familia]

==Quellen==
&lt;references /&gt;

[[Kategorie:Verhütungsmittel]]
[[Kategorie:Wort des Jahres]]

[[br:Stevell]]
[[ca:Preservatiu]]
[[cs:Kondom]]
[[da:Kondom]]
[[el:Προφυλακτικό]]
[[en:Condom]]
[[eo:Kondomo]]
[[es:Preservativo]]
[[fa:کاندوم]]
[[fi:Kondomi]]
[[fr:Préservatif]]
[[he:קונדום]]
[[hi:कंडोम]]
[[id:Kondom]]
[[it:Profilattico]]
[[ja:コンドーム]]
[[ko:콘돔]]
[[ln:Ekopekisa]]
[[lt:Prezervatyvas]]
[[mk:Кондом]]
[[ms:Kondom]]
[[nl:Condoom]]
[[no:Kondom]]
[[pl:Prezerwatywa]]
[[pt:Preservativo]]
[[ru:Презерватив]]
[[simple:Condom]]
[[sv:Kondom]]
[[tr:Prezervatif]]
[[vi:Bao cao su]]
[[zh:避孕套]]
[[zh-min-nan:Sak-khuh]]
</textarea><div class="mw-templatesUsedExplanation"><p>Folgende <a href="/wiki/Hilfe:Vorlagen" title="Hilfe:Vorlagen">Vorlagen</a> werden von diesem Artikel verwendet:
</p></div><ul><li><a href="/wiki/Vorlage:Booland" title="Vorlage:Booland">Vorlage:Booland</a> </li><li><a href="/wiki/Vorlage:Cite_journal" title="Vorlage:Cite journal">Vorlage:Cite journal</a> </li><li><a href="/wiki/Vorlage:Commons" title="Vorlage:Commons">Vorlage:Commons</a> (schreibgeschützt für unangemeldete und neue Benutzer)</li><li><a href="/wiki/Vorlage:Datum" title="Vorlage:Datum">Vorlage:Datum</a> (schreibgeschützt für unangemeldete und neue Benutzer)</li><li><a href="/wiki/Vorlage:Ggf" title="Vorlage:Ggf">Vorlage:Ggf</a> </li><li><a href="/wiki/Vorlage:PMID" title="Vorlage:PMID">Vorlage:PMID</a> </li><li><a href="/wiki/Vorlage:Wikibooks" title="Vorlage:Wikibooks">Vorlage:Wikibooks</a> (schreibgeschützt für unangemeldete und neue Benutzer)</li><li><a href="/wiki/Vorlage:Wiktionary" title="Vorlage:Wiktionary">Vorlage:Wiktionary</a> (schreibgeschützt für unangemeldete und neue Benutzer)</li></ul>
<p>Zurück zur Seite <a href="/wiki/Hauptseite" title="Hauptseite">Hauptseite</a>.</p>
<div class="printfooter">
Von „<a href="http://de.wikipedia.org/wiki/Kondom">http://de.wikipedia.org/wiki/Kondom</a>“</div>
						<!-- end content -->
			<div class="visualClear"></div>
		</div>
	</div>
		</div>
		<div id="column-one">
	<div id="p-cactions" class="portlet">
		<h5>Diese Seite</h5>
		<div class="pBody">
			<ul>
					 <li id="ca-nstab-main" class="selected"><a href="/wiki/Kondom" title="Seiteninhalt anzeigen [c]" accesskey="c">Artikel</a></li>
					 <li id="ca-talk"><a href="/wiki/Diskussion:Kondom" title="Diskussion zum Seiteninhalt [t]" accesskey="t">Diskussion</a></li>
					 <li id="ca-viewsource" class="selected"><a href="/w/index.php?title=Kondom&amp;action=edit" title="Diese Seite ist geschützt. Der Quelltext kann angesehen werden. [e]" accesskey="e">Quelltext betrachten</a></li>
					 <li id="ca-history"><a href="/w/index.php?title=Kondom&amp;action=history" title="Frühere Versionen dieser Seite [h]" accesskey="h">Versionen/Autoren</a></li>
				</ul>
		</div>
	</div>
	<div class="portlet" id="p-personal">
		<h5>Persönliche Werkzeuge</h5>
		<div class="pBody">
			<ul>
				<li id="pt-login"><a href="/w/index.php?title=Spezial:Anmelden&amp;returnto=Kondom" title="Sich einzuloggen wird zwar gerne gesehen, ist aber keine Pflicht. [o]" accesskey="o">Anmelden</a></li>
			</ul>
		</div>
	</div>
	<div class="portlet" id="p-logo">
		<a style="background-image: url(http://upload.wikimedia.org/wikipedia/de/b/bc/Wiki.png);" href="/wiki/Hauptseite" title="Hauptseite anzeigen [z]" accesskey="z"></a>
	</div>
	<script type="text/javascript"> if (window.isMSIE55) fixalpha(); </script>
		<div class='portlet' id='p-navigation'>
		<h5>Navigation</h5>
		<div class='pBody'>
			<ul>
				<li id="n-mainpage"><a href="/wiki/Hauptseite" title="Hauptseite anzeigen [z]" accesskey="z">Hauptseite</a></li>
				<li id="n-aboutsite"><a href="/wiki/Wikipedia:%C3%9Cber_Wikipedia">Über Wikipedia</a></li>
				<li id="n-topics"><a href="/wiki/Portal:Wikipedia_nach_Themen">Themenportale</a></li>
				<li id="n-alphindex"><a href="/wiki/Spezial:Alle_Seiten">Von A bis Z</a></li>
				<li id="n-randompage"><a href="/wiki/Spezial:Zuf%C3%A4llige_Seite" title="Zufällige Seite [x]" accesskey="x">Zufälliger Artikel</a></li>
			</ul>
		</div>
	</div>
		<div class='portlet' id='p-Mitmachen'>
		<h5>Mitmachen</h5>
		<div class='pBody'>
			<ul>
				<li id="n-help"><a href="/wiki/Wikipedia:Hilfe" title="Hilfeseite anzeigen">Hilfe</a></li>
				<li id="n-portal"><a href="/wiki/Wikipedia:Autorenportal" title="Über das Portal, was Sie tun können, wo was zu finden ist">Autorenportal</a></li>
				<li id="n-recentchanges"><a href="/wiki/Spezial:Letzte_%C3%84nderungen" title="Liste der letzten Änderungen in Wikipedia. [r]" accesskey="r">Letzte Änderungen</a></li>
				<li id="n-sitesupport"><a href="http://wikimediafoundation.org/wiki/Spenden" title="Unterstützen Sie uns">Spenden</a></li>
			</ul>
		</div>
	</div>
		<div id="p-search" class="portlet">
		<h5><label for="searchInput">Suche</label></h5>
		<div id="searchBody" class="pBody">
			<form action="/wiki/Spezial:Suche" id="searchform"><div>
				<input id="searchInput" name="search" type="text" title="Durchsuche die Wikipedia [f]" accesskey="f" value="" />
				<input type='submit' name="go" class="searchButton" id="searchGoButton"	value="Artikel" />&nbsp;
				<input type='submit' name="fulltext" class="searchButton" id="mw-searchButton" value="Volltext" />
			</div></form>
		</div>
	</div>
	<div class="portlet" id="p-tb">
		<h5>Werkzeuge</h5>
		<div class="pBody">
			<ul>
				<li id="t-whatlinkshere"><a href="/wiki/Spezial:Verweisliste/Kondom" title="Liste aller Seiten, die hierher zeigen [j]" accesskey="j">Links auf diese Seite</a></li>
				<li id="t-recentchangeslinked"><a href="/wiki/Spezial:%C3%84nderungen_an_verlinkten_Seiten/Kondom" title="Letzte Änderungen an Seiten, die von hier verlinkt sind [k]" accesskey="k">Änderungen an verlinkten Seiten</a></li>
<li id="t-upload"><a href="/wiki/Spezial:Hochladen" title="Dateien hochladen [u]" accesskey="u">Hochladen</a></li>
<li id="t-specialpages"><a href="/wiki/Spezial:Spezialseiten" title="Liste aller Spezialseiten [q]" accesskey="q">Spezialseiten</a></li>
			</ul>
		</div>
	</div>
		</div><!-- end of the left (by default at least) column -->
			<div class="visualClear"></div>
			<div id="footer">
				<div id="f-poweredbyico"><a href="http://www.mediawiki.org/"><img src="/skins-1.5/common/images/poweredby_mediawiki_88x31.png" alt="Powered by MediaWiki" /></a></div>
				<div id="f-copyrightico"><a href="http://wikimediafoundation.org/"><img src="/images/wikimedia-button.png" border="0" alt="Wikimedia Foundation"/></a></div>
			<ul id="f-list">
				<li id="privacy"><a href="/wiki/Wikipedia:Datenschutz" title="Wikipedia:Datenschutz">Datenschutz</a></li>
				<li id="about"><a href="/wiki/Wikipedia:%C3%9Cber_Wikipedia" title="Wikipedia:Über Wikipedia">Über Wikipedia</a></li>
				<li id="disclaimer"><a href="/wiki/Wikipedia:Impressum" title="Wikipedia:Impressum">Impressum</a></li>
			</ul>
		</div>
		
	
		<script type="text/javascript">if (window.runOnloadHook) runOnloadHook();</script>
</div>
<!-- Served by srv111 in 0.111 secs. --></body></html>
