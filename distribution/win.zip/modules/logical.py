#-------------------------------------------------->
# JEliza Module
#
#-> name: Logical
#-> compatible: 2.3
#-> author: JEliza Team
#-> copyright: Tobias Schulz
#-> date: 05.2007
#-------------------------------------------------->

# librarys to import
import random

# main part

def answer_logical_frage_ohne_fragewort(frage, orig_fra):
    dbs = DBSentence()
    dbs.copy_tupel(cpp_toDBSentence(frage))

    if len(dbs.verb) < 1:
        log("- Kein Verb gefunden in: \"" + frage + "\" (frage_ohne_fragewort)")
        return ""

    orig_dbs = DBSentence()
    orig_dbs.copy(dbs)

    dbs.subject = ohne_muell(dbs.subject).lower()
    dbs.object = ohne_muell(dbs.object).lower()
    dbs.verb = ohne_muell(dbs.verb).lower()

    meinungen = []
    s = ""

    x = 0
    a = 0
    maxprio = 0
    for orig in db:
        sent = DBSentence()
        sent.copy(orig)

        procent = 70 / float(len(db)) * float(a)
        apply_procent(procent)
        a = a + 1

        sent.subject = ohne_muell(sent.subject).lower()
        sent.object = ohne_muell(sent.object).lower()
        sent.verb = ohne_muell(sent.verb).lower()

        if not is_similar(dbs.verb, sent.verb):
            continue

        if ((is_similar(dbs.subject, sent.subject) and not is_similar(dbs.object, sent.object))
                or (not is_similar(dbs.subject, sent.subject) and is_similar(dbs.object, sent.object))):
            if orig.priority > maxprio:
                meinungen = []
            if orig.priority >= maxprio:
                maxprio = orig.priority

                meinungen.append("Nein, " + orig.subject + " " + orig.verb + " aber " + orig.object + ".")
                meinungen.append("Nein, aber " + orig.subject + " " + orig.verb + " " + orig.object + ".")
                meinungen.append("Nein, " + orig.subject + " " + orig.verb + " " + orig.object + ".")
                meinungen.append("Nein, aber ich glaube, " + orig.subject + " " + orig.verb + " " + orig.object + "!")

            continue

        if (is_similar(dbs.subject, sent.subject) and is_similar(dbs.object, sent.object)):
            if orig.priority > maxprio:
                meinungen = []
            if orig.priority >= maxprio:
                maxprio = orig.priority

                meinungen = []
                meinungen.append("Ja.")
                meinungen.append("Klar.")
                meinungen.append("Logisch.")
                meinungen.append("Ja!")

            break

    if len(meinungen) < 1:
        meinungen.append("Nein.")
        meinungen.append("Nein, das " + orig_dbs.verb + " " + orig_dbs.subject + " nicht!")

    for meinung in meinungen:
        log("- Meinung: " + meinung)


    random.shuffle(meinungen)
    return meinungen[0]

def answer_logical_frage_was_wer_wie_wo_wann(frage, orig_fra):
    dbs = DBSentence()
    dbs.copy_tupel(cpp_toDBSentence(frage))

    if len(dbs.verb) < 1:
        log("- Kein Verb gefunden in: \"" + frage + "\" (frage_ohne_fragewort)")
        return ""

    orig_dbs = DBSentence()
    orig_dbs.copy(dbs)

    dbs.subject = ohne_muell(dbs.subject).lower()
    dbs.object = ohne_muell(dbs.object).lower()
    dbs.verb = ohne_muell(dbs.verb).lower()

    meinungen = []
    s = ""

    x = 0
    a = 0
    maxprio = 0
    for orig in db:
        sent = DBSentence()
        sent.copy(orig)

        procent = 70 / float(len(db)) * float(a)
        apply_procent(procent)
        a = a + 1

        sent.subject = ohne_muell(sent.subject).lower()
        sent.object = ohne_muell(sent.object).lower()
        sent.verb = ohne_muell(sent.verb).lower()

        if not is_similar(dbs.verb, sent.verb):
            continue

        if orig.priority > 50:
            log("orig.priority > 50 (" + str(orig.priority) + "): " + orig.subject + " " + orig.verb + " " + orig.object + ".")

        if is_similar(dbs.object, sent.subject):
            if orig.priority > maxprio:
                meinungen = []
            if orig.priority >= maxprio:
                maxprio = orig.priority

#                meinungen.append(sent.object + ".")
                meinungen.append(orig.subject + " " + orig.verb + " " + orig.object + ".")

            continue

        if is_similar(dbs.object, sent.object):
            if orig.priority > maxprio:
                meinungen = []
            if orig.priority >= maxprio:
                maxprio = orig.priority

#                meinungen.append(sent.subject + ".")
                meinungen.append(orig.subject + " " + orig.verb + " " + orig.object + ".")

            continue

    if len(meinungen) < 1:
        meinungen.append("Hmm. Keine Ahnung.")
        meinungen.append("Ich weiss nicht.")
        meinungen.append("Darueber hab ich mir noch nie Gedanken gemacht.")

    for meinung in meinungen:
        log("- Meinung: " + meinung)


    random.shuffle(meinungen)
    return meinungen[0]


def answer_logical(frage, orig_fra):
    frage = frage.strip()
    log("- Suche nach einer logischen Antwort auf \"" + frage + "\"" + " bzw. " + orig_fra)

    if (contains(orig_fra, "?")
            and not contains(orig_fra, "was")
            and not contains(orig_fra, "wer")
            and not contains(orig_fra, "wie")
            and not contains(orig_fra, "wo")
            and not contains(orig_fra, "wann")
            and not contains(orig_fra, "warum")
            and not contains(orig_fra, "wieso")
            and not contains(orig_fra, "weshalb")):
        return answer_logical_frage_ohne_fragewort(frage, orig_fra)
    if contains(orig_fra, "?"):
        return answer_logical_frage_was_wer_wie_wo_wann(frage, orig_fra)

    dbs = DBSentence()
    dbs.copy_tupel(cpp_toDBSentence(frage))
    if len(dbs.verb) < 1:
        log("- Kein Verb gefunden in: \"" + frage + "\"")
        return ""

    dbs.subject = ohne_muell(dbs.subject).lower()
    dbs.object = ohne_muell(dbs.object).lower()
    dbs.verb = ohne_muell(dbs.verb).lower()

    log("- Verb ist " + dbs.verb)

    orig_fra_lower = orig_fra.lower()
#    if contains(orig_fra_lower, "bin") or contains(orig_fra_lower, "bist"):
#        log("Satz enthaelt 'bin' oder 'bist'"
#        return ""

    if len(dbs.subject) < 1 or len(dbs.object) < 1 or len(dbs.verb) < 1:
        log("- Unvollstaendiger Satzteil in: \"" + frage + "\"")

#        if (not contains(orig_fra_lower, "bin") and not contains(orig_fra_lower, "bist")
#                    and not contains(orig_fra_lower, "ich") and not contains(orig_fra_lower, "du")
#                    and not contains(orig_fra_lower, "mir") and not contains(orig_fra_lower, "dir")
#                    and not contains(orig_fra_lower, "mich") and not contains(orig_fra_lower, "dich")):
#            yesno = ["Ja.", "Nein! Natuerlich nicht!", "Nein!"]
#
#            random.shuffle(yesno)
#            return yesno[0]
        return ""

    meinungen = []
    s = ""

    x = 0
    a = 0
    maxprio = 0
    for orig in db:
        sent = DBSentence()
        sent.copy(orig)

        procent = 70 / float(len(db)) * float(a)
        apply_procent(procent)
        a = a + 1

        if len(sent.genSentences(True)[0]) > 70:
            continue

        if (len(sent.subject) < 1 or len(sent.object) < 1) or len(sent.verb) < 1:
            continue

        sent.subject = ohne_muell(sent.subject).lower()
        sent.object = ohne_muell(sent.object).lower()
        sent.verb = ohne_muell(sent.verb).lower()

        if len(sent.subject) < 1 or len(sent.object) < 1 or len(sent.verb) < 1:
            continue

        if (not is_similar(dbs.subject, sent.subject) and not is_similar(dbs.object, sent.object)
                and not is_similar(dbs.subject, sent.object) and not is_similar(dbs.object, sent.subject)):
            continue

        if not is_similar(dbs.verb, sent.verb):
            continue

        if orig.priority > maxprio:
            meinungen = []
        if orig.priority >= maxprio:
            maxprio = orig.priority

            meinungen.append("Ich dachte immer, " + orig.subject + " " + orig.verb + " " + orig.object + "??")
            meinungen.append(orig.verb + " " + orig.subject + " nicht " + orig.object + "?")
            meinungen.append("Nein, " + orig.subject + " " + orig.verb + " " + orig.object + ".")
            meinungen.append(orig.subject + " " + orig.verb + " doch " + orig.object + ", oder?")
            meinungen.append(orig.subject + " " + orig.verb + " doch " + orig.object + ", nicht wahr?")
            meinungen.append("Ich ging immer davon aus, dass " + orig.subject + " " + orig.object + " " + orig.verb + "!")
            meinungen.append(orig.subject + " " + orig.verb + " " + orig.object + "! Stimmt das etwa nicht?")
            meinungen.append(orig.subject + " " + orig.verb + " " + orig.object + "! Das stimmt doch, oder?")
            meinungen.append(orig.verb + " " + orig.subject + " wirklich " + orig.object + "?")
            meinungen.append("Ich weiss nur, dass " + orig.subject + " " + orig.object + " " + orig.verb + ".")
            meinungen.append("Meine Berechnungen ergaben, dass " + orig.subject + " " + orig.object + " " + orig.verb + "!!")
            meinungen.append("Kann durchaus sein.")
            meinungen.append("Das glaube ich nicht.")

    for meinung in meinungen:
        log("- Meinung: " + meinung)

    if len(meinungen) < 1:
        log("Keine logischen Meinungen")
        return ""

    random.shuffle(meinungen)
    return meinungen[0]


frage = JELIZA_QUESTION
frage = frage.strip()
orig_frage = JELIZA_QUESTION_ORIGINAL
orig_frage = orig_frage.strip()

logical_ans = answer_logical(frage, orig_frage)
if len(logical_ans) > 2:
    log("- Logische Antwort gefunden: " + logical_ans)

    fp = open("temp/answer.tmp", "w")
    fp.write(logical_ans)
    fp.close()

else:
    log("- Keine logische Antwort gefunden, suche eine unlogische")
    fp = open("temp/answer.tmp", "w")
    fp.close()
