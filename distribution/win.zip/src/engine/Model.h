#ifndef __Model_
#define __Model_

#include <fstream>
#include <vector>
using namespace std;
#include "Defs.h"
#include "Swap.h"
#include "Tree.h"
#include "Dictionary.h"

class Model {

public:

	
	
	
	
	
	
	
	Model() { new_model( ORDER, "" ); }
	Model( BYTE1 order ) { new_model( order, "" ); };
	Model( BYTE1 order, const string &newName ) { new_model( order, newName ); };
	Model( const string &newName ) { new_model( ORDER, newName ); };

private:
	
	
	
	
	
	
	
	void new_model( BYTE1 order, const string &newName );

public:

	
	
	
	
	
	
	void free();

	
	
	
	
	
	
	~Model() { free(); };

	
	
	
	
	
	
	
	void update_model( BYTE2 symbol );

	
	
	
	
	
	
	
	
	void update_context( BYTE2 symbol );

	
	
	
	
	
	
	
	void initialize_context();

	
	
	
	
	
	
	
	void learn( Dictionary *phrase );

	
	
	
	
	
	
	
	int train( istream &in );

	
	
	
	
	
	
	
	bool save_model( const string &fileName );
	bool save_model( ostream &out ) const;

	
	
	
	
	
	
	
	bool load_model( const string &fileName );
	bool load_model( istream &in );

	
	
	
	
	
	
	
	string generate_reply( Dictionary *phrase );

	
	
	
	
	
	
	
	Dictionary *make_greeting();

	
	
	
	
	
	
	
	Dictionary *make_keywords( Dictionary *phrase );

	
	
	
	
	
	void add_key( Dictionary *keys, const string &theWord );

	
	
	
	
	
	
	
	void add_aux( Dictionary *keys, const string &theWord );

	
	
	
	
	
	
	
	Dictionary *reply( Dictionary *keys );

	
	
	
	
	
	
	
	float evaluate_reply( Dictionary *keys, Dictionary *words );

	
	
	
	
	
	
	
	BYTE2 babble( Dictionary *keys, Dictionary *words, bool &usedKey );

	
	
	
	
	
	
	
	BYTE2 seed( Dictionary *keys );

	
	
	
	
	
	
	
	
	
	int load_personality( const string &personalityPath );

	
	
	
	
	
	
	
	inline Dictionary *getAux() { return( myAux ); };
	inline Dictionary *getGreets() { return( myGreets ); };
	inline Dictionary *getBan() { return( myBan ); };
	inline Swap *getSwap() { return( mySwap ); };

	
	
	
	
	
	
	
	
	
	
	
	
	
	void setAux( Dictionary *newAux );
	void setGreets( Dictionary *newGreets );
	void setBan( Dictionary *newBan );
	void setSwap( Swap *newSwap );

protected:

	
	string myName;

	
	BYTE1 myOrder;

	
	Tree *myForward;

	
	Tree *myBackward;

	
	
	vector<Tree*> myContext;

	
	Dictionary *myVocabulary;

	
	Dictionary *myAux;

	
	Dictionary *myGreets;

	
	Dictionary *myBan;

	
	string myVocabOutputFile;
	string myConversationLogFile;
	string myErrorLogFile;
	string myBrainFile;

	
	Swap *mySwap;

}; 

#endif 
