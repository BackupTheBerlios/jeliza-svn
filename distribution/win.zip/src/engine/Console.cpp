#include "Console.h"

Console::Console() {
}

string Console::commandArgs( const string &wholeCommand ) const {
	BYTE1 i;
	BYTE1 cmdSize = (BYTE1)wholeCommand.size();
	if( cmdSize == 0 || wholeCommand[0] != '#' ) {
		return( string("") );
	}
	for( i = 1; i < cmdSize; ++i ) {
		if( wholeCommand[i] == ' ' || wholeCommand[i] == '\t' ) {
			break;
		}
	}
	for( ; i < cmdSize; ++i ) {
		if( wholeCommand[i] != ' ' && wholeCommand[i] != '\t' ) {
			break;
		}
	}
	return( wholeCommand.substr( i, cmdSize - i ) );
}

void Console::main_loop() {
	string buffer, user_input, al_reply;
	Model *al = new Model();
	al->load_personality( "" );
	Dictionary *input_words = NULL;
	bool typingDelay = false;

	input_words = al->make_greeting();
	al_reply = al->generate_reply( input_words );
	Funcs::middle(al_reply);
	cout << "MegaHAL: " << al_reply << endl << endl;

	while( true ) {
		if( input_words != NULL ) {
			delete input_words;
			input_words = NULL;
		}
		user_input = "";
		cout << "> ";
		getline( cin, buffer );
		while( buffer.size() != 0 ) {
			user_input.append( buffer );
			cout << "+ ";
			getline( cin, buffer );
			if( buffer.size() != 0 ) {
				buffer.insert( 0, " " );
			}
		}
		input_words = new Dictionary( user_input );
		if( input_words->size() == 0 ) {
			cout << "MegaHAL doesn't respond well to the silent treatment.\n\n";
			continue;
		}
		if( input_words->entry(0)[0] == '#' ) {
			buffer = input_words->entry(1);
			delete input_words; input_words = NULL;
			cout << "command: " << buffer << endl;
			Funcs::upper(buffer);
			if( buffer == "EXIT" || buffer == "ABORT" ) {
				break;
			}
			else if( buffer == "QUIT" ) {
				al->save_model( "" );
				break;
			}
			else if( buffer == "SAVE" ) {
				al->save_model( commandArgs( user_input ) );
			}
			else if( buffer == "BRAIN" ) {
				buffer = commandArgs( user_input );
				cout << "Attempting to open personality " << buffer << "." << endl;
				
				
				Model *newal = new Model(buffer);
				if( ! newal->load_personality( buffer ) ) {
					delete al; al = NULL;
					al = newal;
				}
				else {
					cout << "#BRAIN command failure!" << endl;
					delete newal; newal = NULL;
				}
				input_words = al->make_greeting();
				al_reply = al->generate_reply( input_words );
				Funcs::middle(al_reply);
				cout << "MegaHAL: " << al_reply << endl << endl;
			}
			else if( buffer == "BRAWN" ) {
				buffer = commandArgs( user_input );
				cout << "Attempting to open only the brain file in " << buffer << "." << endl;
				
				
				Model *newal = new Model(buffer);
				newal->setAux( NULL );
				newal->setGreets( NULL );
				newal->setBan( NULL );
				newal->setSwap( NULL );
				if( ! newal->load_personality( buffer ) ) {
					newal->setAux( al->getAux() );
					newal->setGreets( al->getGreets() );
					newal->setBan( al->getBan() );
					newal->setSwap( al->getSwap() );
					delete al; al = NULL;
					al = newal;
				}
				else {
					cout << "#BRAWN command failure!" << endl;
					delete newal; newal = NULL;
				}
				input_words = al->make_greeting();
				al_reply = al->generate_reply( input_words );
				Funcs::middle(al_reply);
				cout << "MegaHAL: " << al_reply << endl << endl;
			}
			else if( buffer == "DELAY" ) {
				typingDelay = ! typingDelay;
				cout << "MegaHAL: TYPING DELAY IS NOW " << ( typingDelay ? "ON" : "OFF" ) << ".\n";
			}
			else {
				cout << endl
<< "#QUIT   : quits the program and saves MegaHAL's brain." << endl
<< "#EXIT   : exits the program *without* saving MegaHAL's brain." << endl
<< "#SAVE   : saves the current MegaHAL brain." << endl
<< "#BRAIN  : loads an entire personality from the specified directory." << endl
<< "#BRAWN  : loads a megahal.brn file or megahal.trn file from the specified" << endl
<< "          directory. Uses the currently loaded AUX/BAN/GRT/SWP databases." << endl
<< "#DELAY  : toggles MegaHAL's typing delay (off by default)." << endl
<< "#HELP   : displays this message." << endl << endl;
			}
			continue;
		}
		Funcs::upper( user_input );
		al->learn( input_words );
		al_reply = al->generate_reply( input_words );
		Funcs::middle(al_reply);
		cout << endl << "MegaHAL: " << al_reply << endl << endl;
	}
	cout << endl << "Goodbye." << endl;
	if( input_words != NULL ) {
		delete input_words;
		input_words = NULL;
	}
	if( al != NULL ) {
		delete al;
		al = NULL;
	}
}
