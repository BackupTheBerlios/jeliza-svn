#include "Tree.h"


Tree::Tree() {
	mySymbol = 0;
	myUsage = 0;
	myCount = 0;
	myBranch = 0;
	myChildren.resize( 0 );
#ifdef TREE_MAINTAINS_COUNTER
	numberOfPointersToMe = new BYTE4(0);
#endif
} 



void Tree::free() {
	for( BYTE2 i = 0; i < myBranch; ++i ) {
		if( myChildren[i] != NULL ) {
			delete myChildren[i];
		}
	}
	mySymbol = 0;
	myUsage = 0;
	myCount = 0;
	myBranch = 0;
	myChildren.resize( 0 );
}


Tree *Tree::add_symbol(BYTE2 symbol) {
	Tree *node = NULL;

	/*
	 *		Search for the symbol in the subtree of the tree node.
	 */
	node = find_symbol_add(symbol);

	/*
	 *		Increment the symbol counts
	 */
	if( node->myCount < 65535 ) {
		node->myCount += 1;
		myUsage += 1;
	}

	return(node);
}



Tree *Tree::find_symbol(BYTE2 symbol) const
{
	BYTE2 i;
	Tree *found = NULL;
	bool found_symbol = false;

	/*
	 *		Perform a binary search for the symbol.
	 */
	i = search_node( symbol, &found_symbol );
	if( found_symbol == true ) {
		found = myChildren[i];
	}
	return(found);
}



Tree *Tree::find_symbol_add(BYTE2 symbol)
{
	BYTE2 i;
	Tree *found = NULL;
	bool found_symbol = false;

	/*
	 *		Perform a binary search for the symbol.  If the symbol isn't found,
	 *		attach a new sub-node to the tree node so that it remains sorted.
	 */
	i = search_node(symbol, &found_symbol);
	if( found_symbol == true ) {
		found = myChildren[i];
	}
	else {
		found = new Tree();
		found->mySymbol = symbol;
		add_child(found, i);
	}

	return(found);
}


void Tree::add_child(Tree *node, BYTE2 position)
{
	myChildren.insert(myChildren.begin() + position, node);
	myBranch += 1;
}




BYTE2 Tree::search_node(BYTE2 symbol, bool *found_symbol) const {
	BYTE2 position;
	BYTE2 min;
	BYTE2 max;
	BYTE2 middle;
	int compar;

	/*
	 *		Handle the special case where the subtree is empty.
	 */
	if( myBranch == 0 ) {
		position = 0;
		*found_symbol = false;
		return position;
	}

	/*
	 *		Perform a binary search on the subtree.
	 */
	min = 0;
	max = myBranch - 1;
	while( true ) {
		middle = (min + max) / 2;
		compar = symbol - myChildren[middle]->mySymbol;
		if( compar == 0 ) {
				position = middle;
				*found_symbol = true;
				return position;
		} else if( compar > 0 ) {
			if( max == middle ) {
				position = middle + 1;
				*found_symbol = false;
				return position;
			}
			min = middle + 1;
		} else {
			if( min == middle ) {
				position = middle;
				*found_symbol = false;
				return position;
			}
			max = middle - 1;
		}
	}
}


void Tree::save_tree(ostream &out) const {
	out.write( (char*)&mySymbol, sizeof( BYTE2 ) );
	out.write( (char*)&myUsage,  sizeof( BYTE4 ) );
	out.write( (char*)&myCount,  sizeof( BYTE2 ) );
	out.write( (char*)&myBranch, sizeof( BYTE2 ) );

	for( BYTE2 i = 0; i < myBranch; ++i ) {
		myChildren[i]->save_tree( out );
	}
}


void Tree::print_tree( ostream &out ) const {
	out <<	mySymbol << " "
		 <<	myUsage << " "
		 <<	myCount << " "
		 << myBranch << "\n";
	for( BYTE2 i = 0; i < myBranch; ++i ) {
		myChildren[i]->print_tree( out );
	}
}


void Tree::load_tree(istream &in) {
	free();
	in.read( (char*)&mySymbol, sizeof( BYTE2 ) );
	in.read( (char*)&myUsage,  sizeof( BYTE4 ) );
	in.read( (char*)&myCount,  sizeof( BYTE2 ) );
	in.read( (char*)&myBranch, sizeof( BYTE2 ) );

	if( myBranch == 0 ) { return; }

	myChildren.resize( myBranch );

	for( BYTE2 i = 0; i < myBranch; ++i ) {
		myChildren[i] = new Tree();
		myChildren[i]->load_tree( in );
	}
}
