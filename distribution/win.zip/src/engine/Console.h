#ifndef __Console_
#define __Console_

#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
#include "Defs.h"
#include "Swap.h"
#include "Tree.h"
#include "Dictionary.h"
#include "Model.h"

class Console {

public:

	Console();

	string commandArgs( const string &wholeCommand ) const;

	void main_loop();

}; 

#endif 
