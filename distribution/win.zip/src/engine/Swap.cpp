#include "Swap.h"


const string Swap::errorString("<ERROR>");


Swap::Swap() {
	mySize = 0;
	myTo.resize( 0, "" );
	myFrom.resize( 0, "" );
	numberOfPointersToMe = new BYTE4(0);
}


void Swap::add_swap( const string &newFrom, const string &newTo ) {
	myFrom.push_back( newFrom );
	myTo.push_back( newTo );
	++mySize;
}





int Swap::initialize_swap( const string &fileName ) {
	ifstream infile;
	char buffer[2048]; 
	string bufstr, tostr, fromstr;
	BYTE2 pos;
	infile.open(fileName.c_str(), ios::in);
	if( ! infile ) {
		return( 1 );	
	}
	while( infile.getline( buffer, 4096 ) ) {
		if( buffer[0] == '#' ) { continue; }
		bufstr = buffer;
		pos = (BYTE2)bufstr.find_first_of( "\t ", 0 );
		fromstr = bufstr.substr( 0, pos++ );
		while( ! isalnum( bufstr[pos] ) ) {
			++pos;
		}
		tostr = bufstr.substr( pos, bufstr.size() - pos );
		add_swap( fromstr, tostr );
	}
	infile.close();
	return( 0 );
}


void Swap::print_swap() {
	cout << "SWAP:\n";
	for( size_t i = 0; i < myFrom.size(); ++i ) {
		cout << "/" << myFrom[i] << "->" << myTo[i] << "/"<< endl;
	}
	cout << endl;
}


