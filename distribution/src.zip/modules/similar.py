#-------------------------------------------------->
# JEliza Module
#
#-> name: Similar
#-> compatible: 2.3
#-> author: JEliza Team
#-> copyright: Tobias Schulz
#-> date: 05.2007
#-------------------------------------------------->

# librarys to import
import random
import time

# main part

frage = JELIZA_QUESTION_CLEAN

frage = frage.strip()
replies = []
reply = ""
last_sent = DBSentence()
best = 0

woerter = frage.split(" ")
woerter_new = []


old_words = []
for word in woerter:
    woerter_new.append(word)
    old_words.append(word)
    if len(old_words) > 1:
        woerter_new.append(old_words[-2] + " " + old_words[-1])
    if len(old_words) > 2:
        woerter_new.append(old_words[-3] + " " + old_words[-2] + " " + old_words[-1])



log("- " + str(len(db)) + " moegliche Antworten, waehle eine aus...")

a = 0
for db_sent in db:
    sentence = db_sent.genSentences(True)[0]
    sentence = sentence.strip()
    orig_sentence = sentence
    sentence = db_sent.all_ohne_muell
#    log(sentence
#    log(orig_sentence

#    sys.stdout.write(".")

#    if reply == sentence:
#        log("reply == sentence"
#        continue

    woerter2 = sentence.split(" ")
    woerter2_new = []


    old_words = []
    for word in woerter2:
        woerter2_new.append(word)
        old_words.append(word)
        if len(old_words) > 1:
            woerter2_new.append(old_words[-2] + " " + old_words[-1])
        if len(old_words) > 2:
            woerter2_new.append(old_words[-3] + " " + old_words[-2] + " " + old_words[-1])



    last = ""

    for word2 in woerter2_new:
        word2 = word2.lower()

        points = 0

        for word in woerter_new:
            word = word.lower()

            comp = compare(word, word2)
            points += comp
            if comp > 400:
                points += max(len(word), len(word2)) * max(len(word), len(word2)) * 10
                log("")
#                log(">400: " + word + " : " + word2)

        points /= float(len(woerter_new)) # * float(len(woerter2_new))
        points *= float(db_sent.priority) / 50.0

        if points > best:
            log(" " + str(points) + "\t\t" + frage + " | " + sentence + " __  " + word2)
            best = points
            reply = sentence
            replies = db_sent.genSentences(True);
            #last_sent = db_sent;

    procent = 70 / float(len(db)) * float(a)
    sys.stdout.write(str(procent))
    sys.stdout.write(" ")
    sys.stdout.flush()
    apply_procent(procent)
    a = a + 1

answer = ""

apply_procent(99)

if len(replies) > 0:
    random.shuffle(replies)
    answer = replies[0]

    log("- Eine passende Antwort wurde gefunden, und zwar: \"" + answer + "\"")

else:
    answer = "Erzähl mir mehr darüber!"
    log("- Die Datenbank ist leer, irgendwas stimmt da nicht. Antwort: \"" + answer + "\"")

fp = open("temp/answer.tmp", "w")
fp.write(answer)
fp.close()
