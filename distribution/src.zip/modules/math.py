#-------------------------------------------------->
# JEliza Module
#
#-> name: Math
#-> compatible: 2.3
#-> author: JEliza Team
#-> copyright: Tobias Schulz
#-> date: 05.2007
#-------------------------------------------------->

# librarys to import
import random

# main part



