# -*- coding: utf-8 -*-

#-------------------------------------------------->
# JEliza Util functions for modules
#
#-> module: _util
#-> compatible: 2.3
#-> author: JEliza Team
#-> copyright: Tobias Schulz
#-> date: 05.2007
#-------------------------------------------------->

# imports
import string
import time
from jelizacpp import *

# help functions

def ohne_muell(frage2):
  frage = frage2 + ""
  frage = frage.replace("?","")
  frage = frage.replace(".","")
  frage = frage.replace(",","")
  frage = frage.replace("","")
  frage = frage.replace("+"," ztrgftredrefd ")
  frage = frage.replace("ztrgftredrefd","+")
  frage = frage.replace("-"," ztrgftredrefd ")
  frage = frage.replace("ztrgftredrefd","-")
  frage = frage.replace("*"," ztrgftredrefd ")
  frage = frage.replace("ztrgftredrefd","*")
  frage = frage.replace("/"," ztrgftredrefd ")
  frage = frage.replace("ztrgftredrefd","/")
  frage = frage.replace("  "," ")
  frage = " " + frage + " "

  unuseful_words = []
  unuseful_words.append("der")
  unuseful_words.append("die")
  unuseful_words.append("das")
  unuseful_words.append("dem")
  unuseful_words.append("des")
  unuseful_words.append("dessen")
  unuseful_words.append("was")
  unuseful_words.append("wer")
  unuseful_words.append("wie")
  unuseful_words.append("wo")
  unuseful_words.append("wann")
  unuseful_words.append("von")
  unuseful_words.append("vom")
  unuseful_words.append("in")
  unuseful_words.append("auf")
  unuseful_words.append("unter")
  unuseful_words.append("neben")
  unuseful_words.append("zwischen")
  unuseful_words.append("denn")
  unuseful_words.append("bloß")
  unuseful_words.append("bloss")
  unuseful_words.append("stimmts")
  unuseful_words.append("stimmt's")
  unuseful_words.append("hmm")
  unuseful_words.append("hm")
  unuseful_words.append("hmmm")
  unuseful_words.append("hmmmm")
  unuseful_words.append("sonst")
  unuseful_words.append("ansonsten")
  unuseful_words.append("noch")

  unuseful_words.append("fast")
  unuseful_words.append("bald")
  unuseful_words.append("sehr")
  unuseful_words.append("na")
  unuseful_words.append("bisschen")
  unuseful_words.append("bischen")
  unuseful_words.append("hald")
  unuseful_words.append("halt")
  unuseful_words.append("eben")
  unuseful_words.append("oder")
  unuseful_words.append("und")

  unuseful_words.append("of")
  unuseful_words.append("from")
  unuseful_words.append("by")
  unuseful_words.append("between")
  unuseful_words.append("what")
  unuseful_words.append("when")

  unuseful_words.append("ein")
  unuseful_words.append("eine")
  unuseful_words.append("einer")
  unuseful_words.append("eines")
  unuseful_words.append("einem")

  unuseful_words.append("fr")
  unuseful_words.append("für")
  unuseful_words.append("fuer")

  for unuseful_word in unuseful_words:
    unuseful_word = " " + unuseful_word + " "

    better_frage = frage.replace(unuseful_word, " ")

    if len(better_frage.strip()) > 0:
      frage = better_frage

  return frage.strip()

def compare_one (s1_2, s2_2):
    x = -1
    acc = 0.0
    accBest = 0.0

    s1_size = len(s1_2)
    s2_size = len(s2_2)

    s1 = ""
    s2 = ""
    s1 += s1_2
    s2 += s2_2
    if s1_size > s2_size:
        s2 += " " * (s1_size - s2_size)
    elif s2_size > s1_size:
        s1 += " " * (s2_size - s1_size)

    while x + 1 < s1_size and x + 1 < s2_size:
        accBest = accBest + 5

        x = x + 1

        if s1[x] == s2[x]:
            acc = acc + 5
            continue


        y = x + 1
        if y < s2_size and s1[x] == s2[y] and s1_size > 3:
            acc = acc + 3
            continue
        y = x + 2
        if y < s2_size and s1[x] == s2[y] and s1_size > 3:
            acc = acc + 2
            continue
#        y = x + 3
#        if y < s2_size and s1[x] == s2[y] and s1_size > 4:
#            acc = acc + 1
#            continue


        y = x - 1
        if y >= 0 and y < s2_size and s1[x] == s2[y] and s1_size > 3:
            acc = acc + 3
            continue
        y = x - 2
        if y >= 0 and y < s2_size and s1[x] == s2[y] and s1_size > 3:
            acc = acc + 2
            continue
#        y = x - 3
#        if y >= 0 and y < s2_size and s1[x] == s2[y] and s1_size > 4:
#            acc = acc + 1
#            continue


#    if s1_size == s2_size:
#        acc = acc + 1
#        accBest = accBest + 1

    if s1 == s2:
        return 500.0

#    tmp = float(max(s1_size, s2_size))
#    tmp /= float(min(s1_size, s2_size))

#    acc /= float(tmp)
#    acc *= float(3)
#    acc /= float(4.0)

    res = 0.0
    if accBest > 0 and acc > 0:
        res = 500.0 / float(accBest) * float(acc)
        res = res / (float(max(s1_size, s2_size)) / float(min(s1_size, s2_size)))

#    if res > 100:
#        res = 100.0

#    log(res, "==", s1, "|", s2

    return res

def compare (s1, s2):
    return (compare_one(s1, s2) + compare_one(s2, s1)) / 2

def contains (s1, s2):
    return (string.find(s1, s2) > -1)

def is_similar(s1_2, s2_2):
    s1 = s1_2 + ""
    s2 = s2_2 + ""

    if s1 == s2:
        return True

    s1 = s1.lower()
    s1 = s1.strip()
    s1 = s1.replace("_", " ")

    s2 = s2.lower()
    s2 = s2.strip()
    s2 = s2.replace("_", " ")

    if len(s1) < 1 and len(s2) > 0:
        return False

    if len(s2) < 1 and len(s1) > 0:
        return False

    if s1 == s2:
        return True
    if contains(s1, s2):
        return True
    if contains(s2, s1):
        return True

    return False

def apply_procent(procent):
    fp_pc = open("temp/procent", "w")
    fp_pc.write(str(procent))
    fp_pc.flush()
    fp_pc.close()
    cpp_update_prozent()
    time.sleep(0.005)



