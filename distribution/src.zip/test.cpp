#include <iostream>
#include <fstream>
#include <string>
#include <map>

#include <string>
#include <list>

#include <time.h>
#include <vector>

#include "src/jeliza/socketload.cpp"
#include "src/jeliza/util.cpp"

string wikipedia (string wort) {
    string url = "http://de.wikipedia.org/w/index.php?title=" + wort + "&action=edit";
    cout << "Url: \"" << url << "\"" << endl;
    download(url);

    ifstream ifstr("download.php");
    string all;
    string temp;
    while (ifstr) {
		getline(ifstr, temp);
//		temp = Util::strip(temp);

		all += temp;
		all += "\n";
    }

    vector<string> lines;
    Util::split(all, string("\n"), lines);

    bool inRichtigemBereich = false;
    bool inKlammer = false;
    string satz = "";
    for (int x = 0; x < lines.size(); x++) {
        string line = lines[x];
        line = Util::strip(line);

        if (Util::contains(line, "REDIRECT")) {
            continue;
        }

        if (Util::contains(line, "cols='80'")) {
//            cout << "inRichtigemBereich = true; " << line << endl;
            inRichtigemBereich = true;
            line = line.substr(line.find(">") + 1, line.size() - line.find(">") - 1);
        }

        if (inRichtigemBereich && !inKlammer && Util::contains(line, string("{{"))) {
//            cout << "inKlammer = true; " << line << endl;
            inKlammer = true;
        }

        if (inRichtigemBereich && !inKlammer && line.size() > 0) {
//            cout << "cout << satz << endl; " << line << endl;
            satz = "";

            line = Util::replace(line, string("'"), string(""));

            bool inKlammer = false;
            for (int y = 0; y < line.size(); y++) {
                char ch = line[y];

                if (ch == '(') {
                    inKlammer = true;
                }

                if (!inKlammer) {
                    satz += ch;
                }

                if (ch == ')') {
                    inKlammer = false;
                }
            }

            inKlammer = false;
            string tempStr = "";
            string satz2 = satz + " ";
            satz = "";
            for (int y = 0; y < satz2.size(); y++) {
                char ch = satz2[y];

                if (ch == '[' && satz2[y+1] == '[') {
                    inKlammer = true;
                    y++;
                }

                if (!inKlammer) {
                    satz += ch;
                }

                if (ch == '|') {
                    tempStr = "";
                }

                if (inKlammer && ch != '|' && ch != '[' && ch != ']') {
                    tempStr += ch;
                }

                if (ch == ']' && satz2[y+1] == ']') {
                    inKlammer = false;
                    satz += tempStr;
                    tempStr = "";
                    y++;
                }
            }

            satz = "-" + Util::replace(satz, string("  "), string(" ")) + "-";
            satz = Util::replace(satz, string("."), string("ekdnkecolesl"));
            satz = Util::replace(satz, string("ekdnkecolesl"), string("-.-"));

            vector<string> temp;
            Util::split(satz, string("."), temp);

//            cout << temp[0] << endl;

            if (temp[0].size() < 15 || Util::contains(temp[0], string("bzw-"))) {
                satz = Util::strip(temp[0]) + ". " + Util::strip(temp[1]) + ".";
            } else {
                satz = Util::strip(temp[0]) + ".";
            }

            satz = Util::replace(satz, string("-"), string(""));
            satz = Util::replace(satz, string("  "), string(" "));

            break;
        }

        if (inRichtigemBereich && inKlammer && Util::contains(line, string("}}"))) {
//            cout << "inKlammer = false; " << line << endl;
            inKlammer = false;
        }
    }

    return satz;
}

string search_in_wikipedia(string wort) {
    string wort = wort;
    wort = Util::strip(wort);
    wort = Util::toLower(wort);
    string orig_wort = wort;
    string firstchar = string(Util::toUpper(wort.substr(0, 1)));
    wort = wort.substr(1, wort.size());
    wort = firstchar + wort;
    wort = Util::strip(wort);
    cout << "- Wort zum Nachschlagen: " << wort << endl;

    string satz;

    satz = wikipedia(wort);
    if (satz.size() < 1) {
        satz = wikipedia(orig_wort);
        if (satz.size() < 1) {
            satz = wikipedia(Util::toUpper(orig_wort));
        }
    }
    return satz;
}

int main (int argc, char** argv) {
    string wort = argv[1];
    cout << "- Wort zum Nachschlagen: " << wort << endl;

    string satz;

    satz = search_in_wikipedia(wort);
    cout << satz << endl;

    return 0;
}
