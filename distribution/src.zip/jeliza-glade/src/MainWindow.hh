// generated 2007/3/10 15:04:38 CET by tobias@donald.(none)
// using glademm V2.6.0
//
// newer (non customized) versions of this file go to MainWindow.hh_new

// you might replace
//    class foo : public foo_glade { ... };
// by
//    typedef foo_glade foo;
// if you didn't make any modifications to the widget

#ifndef _MAINWINDOW_HH
#  include "MainWindow_glade.hh"
#  define _MAINWINDOW_HH
class MainWindow : public MainWindow_glade
{  
        
        void on_new_activate();
        void on_open_activate();
        void on_save_activate();
        void on_close_activate();
        void on_cut_activate();
        void on_copy_activate();
        void on_paste_activate();
        void on_delete_activate();
        void on_einstellungen_activate();
        void on_info_activate();
};
#endif
