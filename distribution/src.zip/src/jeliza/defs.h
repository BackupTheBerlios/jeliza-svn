#ifndef JELIZA_DEFS_H
#define JELIZA_DEFS_H 1


#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <queue>
#include <sstream>

#include <string>
#include <list>

#include <time.h>
#include <vector>
#include <unistd.h>
#include <getopt.h>

#ifndef JELIZA_VERSION
#define JELIZA_VERSION "2.2 beta"
#endif

#include "jeliza.h"


#endif
