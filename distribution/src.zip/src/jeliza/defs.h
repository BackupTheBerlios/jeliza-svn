#ifndef JELIZA_DEFS_H
#define JELIZA_DEFS_H 1

#include <Python.h>

#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <queue>
#include <sstream>

#include <string>
#include <list>

#include <time.h>
#include <vector>
#include <unistd.h>
#include <getopt.h>

#include <algorithm>

#include <sys/time.h>

#include <stdlib.h>

#ifdef linux
//#include <process.h>
#define CLEAR_CMD "clear"
#else
#ifdef __linux__
//#include <process.h>
#define CLEAR_CMD "clear"
#else
//#include <conio.h>
#define CLEAR_CMD "cls"s
#endif
#endif

#ifndef JELIZA_DEC_VERSION
#define JELIZA_DEC_VERSION 2.3
#endif

#ifndef JELIZA_FULL_VERSION
#define JELIZA_FULL_VERSION "2.3 beta"
#endif

#include <utility>
using namespace std::rel_ops;

#include "jeliza-namespace.h"


#endif
