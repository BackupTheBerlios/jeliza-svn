#ifndef JELIZA_H
#define JELIZA_H 1

#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <queue>
#include <sstream>

#include <string>
#include <list>

#include <time.h>
#include <vector>
#include <unistd.h>
#include <getopt.h>

#include <utility>


/*
 * This is part of jeliza::JEliza 2.0.
 * Copyright 2006 by Tobias Schulz
 * WWW: http://jeliza.ch.to/
 *
 * JEliza is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later
 * version.
 *
 * JEliza is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU GPL
 * along with JEliza (file "gpl.txt") ; if not, write
 * to the Free Software Foundation, Inc., 51 Franklin St,
 * Fifth Floor, Boston, MA  02110-1301  USA
 *
 */



using namespace std;
using namespace std::rel_ops;

namespace jeliza {

class Sentence {
public:
    auto_ptr<string> m_sent;

    explicit Sentence (string sent)
    : m_sent(new string(sent))
    {
    }
    Sentence (const Sentence& sent)
    : m_sent(new string((*(sent.m_sent))))
    {
    }
    explicit Sentence (const char* sent)
    : m_sent(new string(sent))
    {
    }

    Sentence& operator= (const Sentence& sent);
//    Sentence& operator= (string sent);
    char& operator[] (int index);
    bool operator== (Sentence);
    bool operator== (string);
    bool operator== (const char*);

    Sentence ()
    : m_sent(new string(""))
    {
    }

    string get ();
    string get () const;
    string& ref ();
    string ref () const;
    Sentence& set(const string&);
    Sentence& set(const Sentence&);
    Sentence& set(const char*);
//    operator string();
    unsigned int size();
    unsigned int length();
    int find(string s);
    int find(const char s);
    Sentence substr(int x, int y);
    Sentence toASCII();
    void lower();
    void upper();
    Sentence get_lower();
    Sentence get_upper();
    Sentence replace(const Sentence, const Sentence);
    Sentence replace(const Sentence, const string);
    Sentence replace(const string, const string);
    Sentence replace_first(const Sentence, const Sentence);
    Sentence replace_first(const Sentence, const string);
    Sentence replace_first(const string, const string);
    Sentence replace_nocase(const Sentence, const Sentence);
    bool contains (const Sentence rep);
    bool contains (const char*);
    bool startswith (const Sentence rep);
    bool startswith (const char*);
    void strip();
    Sentence get_strip();
    bool equal (Sentence s2);
    bool equal (string s2);
    bool equal (const char* s2);
};

class DBSentence {
public:
    Sentence subject;
    Sentence verb;
    Sentence object;
    Sentence prefix;
    Sentence suffix;
    Sentence feeling;
    Sentence category;
    unsigned int priority;

    DBSentence ()
    : subject(string("")), verb(string("")), object(string("")), prefix(string("")), suffix(string("")),
      feeling(string("normal")), category("normal"), priority(50)
    {
    }

    DBSentence& operator= (const DBSentence& sent);

    void print();
    Sentence toXML();
    void toXMLPrint();
    Sentence printPart (string str, string temp, string wert);
    void strip();
    vector<Sentence> genSentences(bool);
    vector<Sentence> genSentences_all(bool);
};

typedef vector<jeliza::Sentence> answers;
typedef vector<jeliza::DBSentence> DB;

/*class JElizaData {
public:
	auto_ptr<jeliza::DB> m_sents;
	bool m_initOk;
	bool m_destructorOk;

	JElizaData()
	: m_sents(new jeliza::DB()),
	  m_initOk(true),
	  m_destructorOk(false)
	{
	}

	~JElizaData()
	{
		abbau();
	}

	void abbau() {
		m_initOk = false;
		m_destructorOk = true;
	}
};*/

/*
 * The jeliza::JElizaImpl class
 *
 * JEliza is a conversation simulator.
 */
class JElizaImpl {
public:
//	static JElizaData m_jd;

	JElizaImpl()
	{
	}

	~JElizaImpl()
	{
	}

	void learn (Sentence);
	void learn (answers);
	void init ();
	Sentence ask (Sentence frage);
	jeliza::Sentence getGreeting ();
};

class JElizaManager {
public:
    Sentence m_antwort;
    JElizaImpl m_jel;

    JElizaManager()
    : m_antwort("")
    { }

    string greet();

    JElizaImpl& operator* ();

    JElizaManager& operator>> (string&);
};


unsigned int isQuestion (Sentence);
Sentence ohne_muell (Sentence);
answers split_spo (Sentence, vector<string>);
void saveDB(string, jeliza::DB);
DBSentence toDBSentence (Sentence, vector<string>);

extern unsigned int FRAGE_FRAGEWORT;
extern unsigned int KEINE_FRAGE;
extern unsigned int FRAGE_YES_NO;

bool hat_gleichen_wortstamm(Sentence, Sentence, Sentence, Sentence, Sentence, Sentence);
bool is_similar(Sentence, Sentence);
bool is_similar(string, string);

DB* parseJDB (string file);

void generatePythonDBFile();


typedef int Wortart;
typedef pair<Sentence, Wortart> worddef;

extern int VOK;
extern int KONS;
extern int VERB;
extern int NOMEN;
extern int ADJ;
extern int PREP;
extern int PP;
extern int ART;
extern auto_ptr<vector<jeliza::answers> > Wortart_Database;


Wortart bestimmeWortart(Sentence, bool, vector<jeliza::answers>&);
void init_jeliza();
Sentence ermittle_wortstamm(Sentence);
Sentence entferne_prefixe(Sentence);

void update_prozent();

}

extern const string vokale;
extern const string konsonanten;
extern const jeliza::Sentence prefixe;


extern PyMethodDef jelizacpp_methods[6];
PyObject* jelizacpp_toDBSentence(PyObject *self, PyObject *args);
PyObject* jelizacpp_hat_gleichen_wortstamm(PyObject* self, PyObject* args);
PyObject* jelizacpp_update_prozent(PyObject *self, PyObject *args);
PyObject* jelizacpp_log(PyObject *self, PyObject *args);
PyObject* jelizacpp_search_in_wikipedia_with_newlines(PyObject *self, PyObject *args);


jeliza::Sentence& operator+ (jeliza::Sentence, jeliza::Sentence);
jeliza::Sentence& operator+ (jeliza::Sentence, string);
jeliza::Sentence& operator+ (jeliza::Sentence, const char*);
jeliza::Sentence operator+ (string, jeliza::Sentence);
jeliza::Sentence& operator+ (const char*, jeliza::Sentence);
//string& operator+ (string, string&);
//jeliza::Sentence& operator+= (jeliza::Sentence&, jeliza::Sentence&);
jeliza::Sentence& operator+= (jeliza::Sentence&, const jeliza::Sentence);
jeliza::Sentence& operator+= (jeliza::Sentence&, string);
jeliza::Sentence& operator+= (jeliza::Sentence&, const char*);
jeliza::answers& operator<< (jeliza::answers&, const jeliza::answers&);
jeliza::answers& operator<< (jeliza::answers&, int*);
//string& operator+= (string, string&);
//ofstream& operator<<(ofstream&, jeliza::Sentence);
//ostream& operator<<(ostream&, jeliza::Sentence);

/*
 * Die << und >> Operatoren
 */
jeliza::JElizaManager& operator<< (jeliza::JElizaManager&, string);
jeliza::JElizaManager& operator<< (jeliza::JElizaManager&, jeliza::answers);




namespace verbs {
vector<string> getVerbs();
}

namespace jeliza {
}

namespace Util {
    void split (jeliza::Sentence&, string, jeliza::answers&);
    void SplitString (jeliza::Sentence, jeliza::Sentence, jeliza::answers&, bool);
    string toLower (string text);
    string toUpper (string text);
    string toLower_const (const string text);
/*    void trim(string& str);
    string strip (string text);*/
    string replace (string in, const string rep, const string wit);
    string replace_save (string in, const string rep, const string wit);
	string replace_nocase (string& in, string rep, const string wit);
	bool contains (string in, string rep);
	string tausche (string str, string s1, string s2);
	jeliza::Sentence umwandlung (jeliza::Sentence str);
    int max (int a, int b);
    int min (int a, int b);
}




class StringCompare {
	long double points;
	int x;
	long double acc;
	long double accBest;
	int y;
	int s1_size;
	int s2_size;
	long double res;

public:
	StringCompare ()
	: points(0.0)
	{
	}

	void compare (string s1, string s2);
	long double getPoints();
	long double compare_one (string s1, string s2);
};

/*
 * Die Downloadfunktion aus socketload.cpp
 */
string download (string);
string download_with_pbar (string);

jeliza::Sentence search_in_wikipedia (jeliza::Sentence);
jeliza::Sentence search_in_wikipedia_with_newlines (jeliza::Sentence);

extern double* JELIZA_PROGRESS;

extern void jeliza_pulse();


jeliza::answers wikipedia (jeliza::Sentence, int, bool, bool);
jeliza::answers wikipedia_article (jeliza::Sentence, int, bool, bool);
jeliza::answers search_in_wikipedia_acticle (jeliza::Sentence);

extern jeliza::answers wikipedia_words;
void log(string);

class Logger {
public:

};

Logger& operator<< (Logger, string);
extern jeliza::Sentence log_all;
extern ofstream clogger;
extern bool offline_mode;
extern bool www_surf_mode;
extern jeliza::Sentence allWikiWords;

extern auto_ptr<jeliza::DB> jeliza_db;

#endif
