#ifndef JELIZA_MOD_QUES_EMPTY
#define JELIZA_MOD_QUES_EMPTY 1
/*
 * This is part of JEliza 2.0.
 * Copyright 2006 by Tobias Schulz
 * WWW: http://jeliza.ch.to/
 *
 * JEliza is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later
 * version.
 *
 * JEliza is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU GPL
 * along with JEliza (file "gpl.txt") ; if not, write
 * to the Free Software Foundation, Inc., 51 Franklin St,
 * Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include "defs.h"

using namespace jdb;


class ModQues_Empty {
public:
    JEliza& m_jel;
    DB& m_db;

    ModQues_Empty (JEliza& jel, DB& db)
    : m_jel(jel), m_db(db)
    {
        cout << ":: Modul 'Empty' gestartet !!" << endl;
    }

    Answer get (string frage) {
        if (frage.size() == 0) {
            cout << "- Leere Frage!" << endl;
            return Answer("Hmmm.");
        }
        (*JELIZA_PROGRESS) = 8;
        return Answer("");
    }
};


#endif
