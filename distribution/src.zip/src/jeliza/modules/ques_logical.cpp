#ifndef JELIZA_MOD_QUES_LOGICAL
#define JELIZA_MOD_QUES_LOGICAL 1
/*
 * This is part of jeliza::JEliza 2.0.
 * Copyright 2006 by Tobias Schulz
 * WWW: http://jeliza.ch.to/
 *
 * JEliza is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later
 * version.
 *
 * JEliza is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU GPL
 * along with JEliza (file "gpl.txt") ; if not, write
 * to the Free Software Foundation, Inc., 51 Franklin St,
 * Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include "defs.h"


class ModQues_Logical {
public:
    jeliza::JElizaImpl& m_jel;
    jeliza::DB* m_db;

    ModQues_Logical (jeliza::JElizaImpl& jel, jeliza::DB* db)
    : m_jel(jel), m_db(db)
    {
        clogger << ":: Modul 'Logical' gestartet !!" << endl;
        log(":: Modul 'Logical' gestartet !!");
    }

    jeliza::Sentence Sentence_logical(jeliza::Sentence frage, jeliza::Sentence orig_fra) {
        frage.strip();
        clogger << "- Suche nach einer logischen Antwort auf \"" << frage.ref() << "\"" << endl;

        jeliza::DBSentence dbs = jeliza::toDBSentence (frage, verbs::getVerbs());
        if (dbs.verb.size() < 1) {
            clogger << "- Kein Verb gefunden in: \"" << frage.ref() << "\"" << endl;
            clogger << dbs.toXML().ref() << endl;
            return (jeliza::Sentence(""));
        }

        dbs.subject.set(jeliza::ohne_muell(dbs.subject));
        dbs.subject.lower();
        dbs.object.set(jeliza::ohne_muell(dbs.object));
        dbs.object.lower();

        dbs.verb.set(jeliza::ohne_muell(dbs.verb));
        dbs.verb.lower();

        clogger << "- Verb ist " << dbs.verb.ref() << endl;

        jeliza::Sentence orig_fra_lower;
        (orig_fra_lower.set(orig_fra)).lower();
        if (orig_fra_lower.contains("bin") || orig_fra_lower.contains("bist")
//                || orig_fra_lower.contains("ich") || orig_fra_lower.contains("du")
//                || orig_fra_lower.contains("mir") || orig_fra_lower.contains("dir")
//                || orig_fra_lower.contains("mich") || orig_fra_lower.contains("dich")) {
            ){
            return jeliza::Sentence();
        }

        if (dbs.subject.size() < 1 || dbs.object.size() < 1 || dbs.verb.size() < 1) {
            clogger << "- Unvollstaendiger Satzteil in: \"" << frage.ref() << "\"" << endl;

            if ((!orig_fra_lower.contains("bin") && !orig_fra_lower.contains("bist")
                    && !orig_fra_lower.contains("ich") && !orig_fra_lower.contains("du")
                    && !orig_fra_lower.contains("mir") && !orig_fra_lower.contains("dir")
                    && !orig_fra_lower.contains("mich") && !orig_fra_lower.contains("dich"))
                    || orig_fra_lower.contains("mal") || true) {
                jeliza::answers yesno;
                yesno.push_back(jeliza::Sentence("Ja."));
                yesno.push_back(jeliza::Sentence("Nein! Natuerlich nicht!"));
                yesno.push_back(jeliza::Sentence("Nein!"));

                srand((unsigned) time(NULL));
                int random = rand() % yesno.size();
                jeliza::Sentence sentence = jeliza::Sentence(yesno[random]);
                return sentence;
            }
            return jeliza::Sentence();
        }

        jeliza::answers meinungen;

        jeliza::Sentence s;
        for (jeliza::DB::iterator it = m_db->begin(); it != m_db->end(); it++) {
            jeliza::DBSentence orig = *it;
            jeliza::DBSentence sent = *it;

            if (sent.genSentences(true)[0].size() > 70) {
                continue;
            }

            if ((sent.subject.size() < 1 || sent.object.size() < 1) || sent.verb.size() < 1) {
                continue;
            }

            sent.subject.set(jeliza::ohne_muell(sent.subject));
            sent.subject.lower();
            sent.object.set(jeliza::ohne_muell(sent.object));
            sent.object.lower();

            sent.verb.set(jeliza::ohne_muell(sent.verb));
            sent.verb.lower();

            if (sent.subject.size() < 1 || sent.object.size() < 1 || sent.verb.size() < 1) {
                continue;
            }

            if (!jeliza::is_similar(dbs.subject, sent.subject) && !jeliza::is_similar(dbs.object, sent.object)
                    && !jeliza::is_similar(dbs.subject, sent.object) && !jeliza::is_similar(dbs.object, sent.subject)) {
                continue;
            }

            if (!jeliza::is_similar(dbs.verb, sent.verb)) {
                continue;
            }

            meinungen.push_back(jeliza::Sentence("Ich dachte immer, " + orig.subject + " " + orig.verb + " " + orig.object + "??"));
            meinungen.push_back(jeliza::Sentence(orig.verb + " " + orig.subject + " nicht " + orig.object + "?"));
            meinungen.push_back(jeliza::Sentence("Nein, " + orig.subject + " " + orig.verb + " " + orig.object + "."));
            meinungen.push_back(jeliza::Sentence(orig.subject + " " + orig.verb + " doch " + orig.object + ", oder?"));
            meinungen.push_back(jeliza::Sentence(orig.subject + " " + orig.verb + " doch " + orig.object + ", nicht wahr?"));
            meinungen.push_back(jeliza::Sentence("Ich ging immer davon aus, dass " + orig.subject + " " + orig.object + " " + orig.verb + "!"));
            meinungen.push_back(jeliza::Sentence(orig.subject + " " + orig.verb + " " + orig.object + "! Stimmt das etwa nicht?"));
            meinungen.push_back(jeliza::Sentence(orig.subject + " " + orig.verb + " " + orig.object + "! Das stimmt doch, oder?"));
            meinungen.push_back(jeliza::Sentence(orig.verb + " " + orig.subject + " wirklich " + orig.object + "?"));
            meinungen.push_back(jeliza::Sentence("Ich weiss nur, dass " + orig.subject + " " + orig.object + " " + orig.verb + "."));
            meinungen.push_back(jeliza::Sentence("Meine Berechnungen ergaben, dass " + orig.subject + " " + orig.object + " " + orig.verb + "!!"));
            meinungen.push_back(jeliza::Sentence("Kann durchaus sein."));
            meinungen.push_back(jeliza::Sentence("Das glaube ich nicht."));
        }

        for (unsigned int x = 0; x < meinungen.size(); x++) {
            clogger << "- Meinung: " << meinungen[x].ref() << endl;
        }

        if (meinungen.size() < 1) {
            return jeliza::Sentence("");
        }

        srand((unsigned) time(NULL));
        int random = rand() % meinungen.size();
        jeliza::Sentence sentence = jeliza::Sentence(meinungen[random]);
        return sentence;
    }

    jeliza::Sentence Sentence_logical_question_type_1 (jeliza::Sentence frage, jeliza::Sentence orig_fra) {
        frage.strip();
        clogger << "- Suche nach einer logischen Antwort auf die Frage \"" << frage.ref() << "\"" << endl;

        jeliza::DBSentence dbs = jeliza::toDBSentence (frage, verbs::getVerbs());
        jeliza::DBSentence dbs_orig = jeliza::toDBSentence (orig_fra, verbs::getVerbs());
        if (dbs_orig.verb.size() < 1) {
            clogger << "- Kein Verb gefunden in: \"" << frage.ref() << "\"" << endl;
            clogger << dbs.toXML().ref() << endl;
            return jeliza::Sentence("");
        }

        dbs.subject.set(jeliza::ohne_muell(dbs.subject));
        dbs.subject.lower();
        dbs.object.set(jeliza::ohne_muell(dbs.object));
        dbs.object.lower();

        dbs.verb.set(jeliza::ohne_muell(dbs.verb));
        dbs.verb.lower();

        jeliza::Sentence orig_fra_lower;
        (orig_fra_lower.set(orig_fra)).lower();
        if (orig_fra_lower.contains("bin") || orig_fra_lower.contains("bist")) {
            return jeliza::Sentence("");
        }

        jeliza::Sentence dbs_orig_verb_lower;
        (dbs_orig_verb_lower.set(dbs_orig.verb)).lower();
        clogger << dbs.object.size() << " " << (!dbs_orig_verb_lower.contains("bin"));
        clogger << " " << (orig_fra_lower.contains("was")) << " " << (orig_fra_lower.contains("wer")) << endl;

        if (dbs.object.size() > 0 && !dbs_orig_verb_lower.contains("bin")
                && (orig_fra_lower.contains("was") || orig_fra_lower.contains("wer"))) {
            jeliza::Sentence definition(search_in_wikipedia_with_newlines(dbs.object));
            if (definition.size() > 2) {
                m_jel.learn(definition);
                return jeliza::Sentence(definition);
            }
        }

        if (dbs.prefix.size() > 0 && dbs.prefix.get_lower().contains("kenne ich")) {
            jeliza::Sentence p;
            (p = dbs.prefix).replace_nocase(jeliza::Sentence("kenne"), jeliza::Sentence(""));
            p.replace_nocase(jeliza::Sentence("kennst"), jeliza::Sentence(""));
            p.replace_nocase(jeliza::Sentence("ich"), jeliza::Sentence(""));
            p.strip();
            jeliza::Sentence definition = search_in_wikipedia_with_newlines(p);
            if (definition.size() > 2) {
                m_jel.learn(definition);
                return jeliza::Sentence(definition);
            }
        }

        if (dbs.object.size() > 0 && dbs.object.get_lower().contains("ich")
                && (dbs.verb.get_lower().contains("kenn"))) {
            jeliza::Sentence p;
            (p = dbs.object).replace_nocase(jeliza::Sentence("kenne"), jeliza::Sentence(""));
            p.replace_nocase(jeliza::Sentence("kennst"), jeliza::Sentence(""));
            p.replace_nocase(jeliza::Sentence("ich"), jeliza::Sentence(""));
            p.strip();
            jeliza::Sentence definition(search_in_wikipedia_with_newlines(p));
            if (definition.size() > 2) {
                m_jel.learn(definition);
                return jeliza::Sentence(definition);
            }
        }

        clogger << "- Verb ist " << dbs.verb.ref() << endl;

        dbs.print();
        dbs_orig.print();

        // (*JELIZA_PROGRESS) = 46;
        jeliza_pulse();

        if (dbs_orig.subject.size() < 1 || dbs_orig.object.size() < 1 || dbs_orig.verb.size() < 1) {
            clogger << "- Unvollstaendiger Satzteil in: \"" << frage.ref() << "\"" << endl;
            return jeliza::Sentence("");
        }

        jeliza::answers meinungen;

        jeliza::Sentence s;
        int ssize = m_db->size();
        int x = 0;
        for (jeliza::DB::iterator it = m_db->begin(); it != m_db->end(); it++) {
            jeliza::DBSentence orig = *it;
            jeliza::DBSentence sent = *it;

            x++;

            // (*JELIZA_PROGRESS) += 8.0 / ssize * x;
            jeliza_pulse();

            if (sent.genSentences(true)[0].size() > 60) {
                continue;
            }

            if (sent.subject.size() < 1 || sent.object.size() < 1 || sent.verb.size() < 1) {
                continue;
            }

            sent.subject.set(jeliza::ohne_muell(sent.subject));
            sent.subject.lower();
            sent.object.set(jeliza::ohne_muell(sent.object));
            sent.object.lower();

            sent.verb.set(jeliza::ohne_muell(sent.verb));
            sent.verb.lower();

            if (sent.subject.size() < 1 || sent.object.size() < 1 || sent.verb.size() < 1) {
                continue;
            }

            clogger << sent.genSentences(true)[0].get() << endl;

            if (!jeliza::is_similar(dbs.subject, sent.subject) && !jeliza::is_similar(dbs.object, sent.object)
                    && !jeliza::is_similar(dbs.subject, sent.object) && !jeliza::is_similar(dbs.object, sent.subject)) {
                continue;
            }

            if (!jeliza::is_similar(dbs.verb, sent.verb)) {
                continue;
            }

            jeliza::answers anss = orig.genSentences(true);
            for (jeliza::answers::iterator it = anss.begin(); it != anss.end(); it++) {
                meinungen.push_back(*it);
            }
        }

        for (unsigned int x = 0; x < meinungen.size(); x++) {
            clogger << "- Meinung: " << meinungen[x].ref() << endl;
        }

        if (meinungen.size() < 1) {
            return jeliza::Sentence("");
        }

        srand((unsigned) time(NULL));
        int random = rand() % meinungen.size();
        jeliza::Sentence sentence;
        sentence.set(jeliza::Sentence(meinungen[random]));
        return sentence;
    }


    jeliza::Sentence get (jeliza::Sentence frage, jeliza::Sentence orig_fra) {
        if (jeliza::isQuestion(orig_fra) != 0) {
            clogger << "- \"" << frage.ref() << "\" bzw. \"" << orig_fra.ref() << "\" ist eine Frage!!" << endl;

            if (jeliza::isQuestion(orig_fra) == 1) {
                clogger << "- \"" << frage.ref() << "\" bzw. \"" << orig_fra.ref() << "\" ist eine Frage mit Typ 1 !!" << endl;
                log("- \"" + frage.ref() + "\" bzw. \"" + orig_fra.ref() + "\" ist eine Frage mit Typ 1 !!");

                jeliza::Sentence logical_ans = Sentence_logical_question_type_1(frage, orig_fra);
                if (logical_ans.get().size() > 2) {

                    clogger << "- Logische Antwort gefunden: " << logical_ans.ref() << endl;
                    return logical_ans;
                }
            }

            clogger << "- \"" << frage.ref() << "\" bzw. \"" << orig_fra.ref() << "\" ist eine Frage mit Typ 2 !!" << endl;
            log("- \"" + frage.ref() + "\" bzw. \"" + orig_fra.ref() + "\" ist eine Frage mit Typ 2 !!");
        }

        jeliza::Sentence logical_ans = Sentence_logical(frage, orig_fra);
        if (logical_ans.ref().size() > 2) {
            clogger << "- Logische Antwort gefunden: " << logical_ans.ref() << endl;
            log("- Logische Antwort gefunden: " + logical_ans.ref());

            return logical_ans;
        }

        clogger << "- Keine logische Antwort gefunden, suche eine unlogische..." << endl;
        log("- Keine logische Antwort gefunden, suche eine unlogische...");
        return jeliza::Sentence("");
    }
};


#endif



