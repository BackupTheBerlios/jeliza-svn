#ifndef JELIZA_MOD_QUES_LOGICAL
#define JELIZA_MOD_QUES_LOGICAL 1
/*
 * This is part of JEliza 2.0.
 * Copyright 2006 by Tobias Schulz
 * WWW: http://jeliza.ch.to/
 *
 * JEliza is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later
 * version.
 *
 * JEliza is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU GPL
 * along with JEliza (file "gpl.txt") ; if not, write
 * to the Free Software Foundation, Inc., 51 Franklin St,
 * Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include "defs.h"

using namespace jdb;


class ModQues_Logical {
public:
    JEliza& m_jel;
    DB& m_db;

    ModQues_Logical (JEliza& jel, DB& db)
    : m_jel(jel), m_db(db)
    {
        cout << ":: Modul 'Logical' gestartet !!" << endl;
    }

    Answer get (string frage, string orig_fra) {
        if (m_jel.isQuestion(orig_fra) != 0) {
            cout << "- \"" << frage << "\" bzw. \"" << orig_fra << "\" ist eine Frage!!" << endl;

            if (m_jel.isQuestion(orig_fra) == 1) {
                cout << "- \"" << frage << "\" bzw. \"" << orig_fra << "\" ist eine Frage mit Typ 1 !!" << endl;

                (*JELIZA_PROGRESS) = 25;

                Answer logical_ans = m_jel.answer_logical_question_type_1(frage, orig_fra);
                if (logical_ans.m_ans.size() > 2) {

                    (*JELIZA_PROGRESS) = 55;

                    cout << "- Logische Antwort gefunden: " << logical_ans.m_ans << endl;
                    return logical_ans;
                }
            }

            cout << "- \"" << frage << "\" bzw. \"" << orig_fra << "\" ist eine Frage mit Typ 2 !!" << endl;
        }
        (*JELIZA_PROGRESS) = 30;
        Answer logical_ans = m_jel.answer_logical(frage, orig_fra);
        if (logical_ans.m_ans.size() > 2) {
            cout << "- Logische Antwort gefunden: " << logical_ans.m_ans << endl;

            (*JELIZA_PROGRESS) = 55;
            return logical_ans;
        }

        (*JELIZA_PROGRESS) = 55;
        cout << "- Keine logische Antwort gefunden, suche eine unlogische..." << endl;
        return Answer("");
    }
};


#endif


