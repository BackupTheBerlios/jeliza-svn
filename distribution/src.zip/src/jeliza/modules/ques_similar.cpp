#ifndef JELIZA_MOD_QUES_SIMILAR
#define JELIZA_MOD_QUES_SIMILAR 1
/*
 * This is part of jeliza::JEliza 2.0.
 * Copyright 2006 by Tobias Schulz
 * WWW: http://jeliza.ch.to/
 *
 * JEliza is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later
 * version.
 *
 * JEliza is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU GPL
 * along with JEliza (file "gpl.txt") ; if not, write
 * to the Free Software Foundation, Inc., 51 Franklin St,
 * Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include "defs.h"


class ModQues_Similar {
public:
    jeliza::JElizaImpl& m_jel;
    jeliza::DB* m_db;

    ModQues_Similar (jeliza::JElizaImpl& jel, jeliza::DB* db)
    : m_jel(jel), m_db(db)
    {
        clogger << ":: Modul 'Similar' gestartet !!" << endl;
        log(":: Modul 'Similar' gestartet !!");
        cout << "m_db->size(): " << m_db->size() << endl;
    }

    jeliza::Sentence get (jeliza::Sentence frage) {
        (frage.set(jeliza::ohne_muell(frage))).strip();

        jeliza::answers replies;
        jeliza::Sentence reply;
        jeliza::DBSentence last_sent;
        long double best = 0;

        jeliza::answers woerter;
        Util::split(frage, " ", woerter);

        jeliza::answers woerter_new;

        for (unsigned int x = 0; x < woerter.size(); x++) {
            if (x < 1) {
                woerter_new.push_back(jeliza::Sentence(woerter[x]));
            } else if (x < 2) {
                woerter_new.push_back(jeliza::Sentence(woerter[x-1] + " " + woerter[x]));
            } else {
                woerter_new.push_back(jeliza::Sentence(woerter[x-2] + " " + woerter[x-1] + " " + woerter[x]));
            }
        }

        for (unsigned int x = 0; x < woerter.size(); x++) {
            woerter_new.push_back(woerter[x]);
        }

        clogger << "- " << m_db->size() << " moegliche Antworten, waehle eine aus..." << endl;
        stringstream sst;
        jeliza::Sentence u;
        sst << m_db->size();
        sst >> u.ref();
        log("- " + u.ref() + " moegliche Antworten, waehle eine aus...");

        for (jeliza::DB::iterator it = m_db->begin(); it != m_db->end(); it++) {
            jeliza::Sentence sentence = it->genSentences(true)[0];

            sentence.strip();
            jeliza::Sentence orig_sentence = sentence;
            sentence.set(jeliza::ohne_muell(sentence));
            if (sentence.size() < 1) {
                clogger << "sentence.size() < 1" << endl;
                continue;
            }
            if (reply == sentence) {
                clogger << "reply == sentence" << endl;
                continue;
            }
            clogger << "ok";

            jeliza::answers woerter2;
            Util::split(sentence, " ", woerter2);

            jeliza::answers woerter2_new;

            for (unsigned int x = 0; x < woerter2.size(); x++) {
                if (x < 1) {
                    woerter2_new.push_back(jeliza::Sentence(woerter2[x]));
                } else if (x < 2) {
                    woerter2_new.push_back(jeliza::Sentence(woerter2[x-1] + " " + woerter2[x]));
                } else {
                    woerter2_new.push_back(jeliza::Sentence(woerter2[x-2] + " " + woerter2[x-1] + " " + woerter2[x]));
                }
            }
            for (unsigned int x = 0; x < woerter2.size(); x++) {
                woerter2_new.push_back(woerter2[x]);
            }

            jeliza::Sentence last;

            long double points2 = 0;

            StringCompare sc;
            for (unsigned int a = 0; a < woerter2_new.size(); a++) {
                jeliza::Sentence wort2 = woerter2_new[a];
                wort2.lower();

                for (unsigned int y = 0; y < woerter_new.size(); y++) {
                    jeliza::Sentence wort = woerter_new[y];
                    wort.lower();

                    sc.compare(wort.ref(), wort2.ref());
                    points2 += sc.getPoints();
                }

            }
            points2 = points2 / (woerter_new.size() * woerter2_new.size());
            points2 *= (static_cast<long double>(it->priority) / 100);


            if (points2 > best) {
                clogger << "  " << points2 << "\t\t" << frage.ref() << " | " << sentence.ref() << endl;
                best = points2; // points2 / 100 * 98
                reply = sentence;
                replies << NULL << it->genSentences(true);
                last_sent = *it;
            }
        }

        jeliza::Sentence answer;

        if (replies.size() > 0) {
            srand((unsigned) time(NULL));
            int random = rand() % replies.size();
            answer.set(replies[random]);

            clogger << "- Eine passende Antwort wurde gefunden, und zwar: \"" << answer.ref() << "\"" << endl;
            log("- Eine passende Antwort wurde gefunden, und zwar: \"" + answer.ref() + "\"");
        }
        else {
            answer.set("Erzähl mir mehr darüber!");
            clogger << "- Die Datenbank ist leer, irgendwas stimmt da nicht. Antwort: \"" << answer.ref() << "\"" << endl;
            log("- Die Datenbank ist leer, irgendwas stimmt da nicht.");
        }

        clogger << endl;

        return answer;
    }
};


#endif



