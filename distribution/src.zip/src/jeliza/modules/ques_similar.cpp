#ifndef JELIZA_MOD_QUES_SIMILAR
#define JELIZA_MOD_QUES_SIMILAR 1
/*
 * This is part of JEliza 2.0.
 * Copyright 2006 by Tobias Schulz
 * WWW: http://jeliza.ch.to/
 *
 * JEliza is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later
 * version.
 *
 * JEliza is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU GPL
 * along with JEliza (file "gpl.txt") ; if not, write
 * to the Free Software Foundation, Inc., 51 Franklin St,
 * Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include "defs.h"

using namespace jdb;


class ModQues_Similar {
public:
    JEliza& m_jel;
    DB& m_db;

    ModQues_Similar (JEliza& jel, DB& db)
    : m_jel(jel), m_db(db)
    {
        cout << ":: Modul 'Similar' gestartet !!" << endl;
    }

    Answer get (string frage) {
        frage = Util::strip(m_jel.ohne_muell(frage));

        answers replies;
        string reply;
        DBSentence last_sent;
        long double best = 0;

        answers woerter;
        Util::split(frage, string(" "), woerter);

        answers woerter_new;

        for (unsigned int x = 0; x < woerter.size(); x++) {
            if (x == 0) {
                woerter_new.push_back(woerter[x]);
            } else if (x+1 >= woerter.size()) {
                woerter_new.push_back(woerter[x]);
            } else {
                woerter_new.push_back(woerter[x-1] + " " + woerter[x]);
            }
        }

        cout << "- " << m_db.size() << " moegliche Antworten, waehle eine aus..." << endl;

        for (DB::iterator it = m_db.begin(); it != m_db.end(); it++) {
            string sentence = it->genSentences(true)[0];
            sentence = Util::strip(m_jel.ohne_muell(sentence));
            if (sentence.size() < 1) {
                continue;
            }
            if (reply == sentence) {
                continue;
            }

            vector<string> woerter2;
            Util::split(sentence, " ", woerter2);

            answers woerter2_new;

            for (unsigned int x = 0; x < woerter2.size(); x++) {
                if (x == 0) {
                    woerter2_new.push_back(woerter2[x]);
                } else if (x+1 >= woerter.size()) {
                    woerter2_new.push_back(woerter2[x]);
                } else {
                    woerter2_new.push_back(woerter2[x-1] + " " + woerter2[x]);
                }
            }


            string last = "";

            long double points2 = 0;

            for (unsigned int a = 0; a < woerter2_new.size(); a++) {
                string wort2 = woerter2_new[a];
                wort2 = Util::toLower(wort2);

                for (unsigned int y = 0; y < woerter_new.size(); y++) {
                    string wort = woerter_new[y];
                    wort = Util::toLower(wort);

                    StringCompare sc(wort, wort2);
                    points2 += sc.getPoints();
                }

            }
            points2 = points2 / (woerter_new.size() * woerter2_new.size());
            points2 *= (static_cast<long double>(it->priority) / 100);


            if (points2 > best) {
                cout << "  " << points2 << "\t\t" << frage << " | " << sentence << endl;
                best = points2; // points2 / 100 * 98
                reply = sentence;
                replies = it->genSentences(true);
                last_sent = *it;
            }
        }

        string answer;

        if (replies.size() > 0) {
            srand((unsigned) time(NULL));
            int random = rand() % replies.size();
            answer = replies[random];

            cout << "- Eine passende Antwort wurde gefunden, und zwar: \"" << answer << "\"" << endl;
        }
        else {
            answer = "Erzähl mir mehr darüber!";
            cout << "- Die Datenbank ist leer, irgendwas stimmt da nicht. Antwort: \"" << answer << "\"" << endl;
        }

        cout << endl;

        return Answer(answer);
    }
};


#endif



