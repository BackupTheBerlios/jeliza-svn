#ifndef JELIZA_MOD_QUES_MATH
#define JELIZA_MOD_QUES_MATH 1
/*
 * This is part of jeliza::JEliza 2.0.
 * Copyright 2006 by Tobias Schulz
 * WWW: http://jeliza.ch.to/
 *
 * JEliza is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later
 * version.
 *
 * JEliza is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU GPL
 * along with JEliza (file "gpl.txt") ; if not, write
 * to the Free Software Foundation, Inc., 51 Franklin St,
 * Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include "defs.h"


double rechne(jeliza::Sentence s) {
	jeliza::answers ss;
	s.strip();
	Util::split(s, " ", ss);

	vector<jeliza::Sentence> digits;
	digits.push_back(jeliza::Sentence("0"));
	digits.push_back(jeliza::Sentence("1"));
	digits.push_back(jeliza::Sentence("2"));
	digits.push_back(jeliza::Sentence("3"));
	digits.push_back(jeliza::Sentence("4"));
	digits.push_back(jeliza::Sentence("5"));
	digits.push_back(jeliza::Sentence("6"));
	digits.push_back(jeliza::Sentence("7"));
	digits.push_back(jeliza::Sentence("8"));
	digits.push_back(jeliza::Sentence("9"));
	digits.push_back(jeliza::Sentence(","));
	digits.push_back(jeliza::Sentence("."));

	double u = 0;
	double* base = &u;

	jeliza::Sentence zeichen;

	for (unsigned int x = 0; x < ss.size(); x++) {
		jeliza::Sentence sym = ss[x];
		jeliza::Sentence temp = sym;

		for (unsigned int y = 0; y < digits.size(); y++) {
			temp.replace(digits[y], jeliza::Sentence(""));
		}

		clogger << "sym " << sym.ref() << "  temp.size() " << temp.size() << "  temp " << temp.ref();

		if (temp.size() == 0) {
			stringstream sst;
			double integer;

			sst << sym.ref();
			sst >> integer;

//				if (base == NULL) {
			if (zeichen.size() == 0) {
				double v = integer + 0;
				base = &v;
			} else {
				clogger << "  zeichen.size() " << zeichen.size() << "  integer " << integer << "  base " << *base;
				if (zeichen == "+") {
					*base += integer;
				}
				if (zeichen == "-") {
					*base -= integer;
				}
				if (zeichen == "*") {
					*base *= integer;
				}
				if (zeichen == "/") {
					*base /= integer;
				}
				clogger << "  zeichen.size() " << zeichen.size() << "  integer " << integer << "  base " << *base;
			}
//				}
		} else {
			if (sym.contains(jeliza::Sentence("+"))) {
				zeichen.set("+");
			}
			else if (sym.contains(jeliza::Sentence("-"))) {
				zeichen.set("-");
			}
			else if (sym.contains(jeliza::Sentence("*"))) {
				zeichen.set("*");
			}
			else if (sym.contains(jeliza::Sentence("/"))) {
				zeichen.set("/");
			}
			else {
				throw jeliza::Sentence("KeineRechnung");
			}
		}

		clogger << endl;
	}

	return *base;
}


class ModQues_Math {
public:
    jeliza::JElizaImpl& m_jel;
    jeliza::DB* m_db;

    ModQues_Math (jeliza::JElizaImpl& jel, jeliza::DB* db)
    : m_jel(jel), m_db(db)
    {
        clogger << ":: Modul 'Math' gestartet !!" << endl;
        log(":: Modul 'Math' gestartet !!");
    }

    jeliza::Sentence get (jeliza::Sentence frage) {
        // Ist es eine Rechenaufgabe?
        try {
            stringstream sst;
            jeliza::Sentence str;

            jeliza::Sentence divNull = jeliza::Sentence("/ 0");
            if (frage.contains(divNull)) {
                clogger << "- Division durch Null!" << endl;
                return jeliza::Sentence("Tut mir leid, aber durch 0 kann ich nicht teilen!");
            }

            sst << rechne(jeliza::Sentence(frage));
            sst >> str.ref();

            clogger << "- Es war eine Rechenaufgabe!" << endl;
            log("- Es war eine Rechenaufgabe!");
            clogger << "- " << frage.ref() << " = " << str.ref() << endl;
            log("- " + frage.ref() + " = " + str.ref());
            return jeliza::Sentence(str);
        } catch (const jeliza::Sentence) {
            clogger << "- Es war keine Rechenaufgabe!" << endl;
            log("- Es war keine Rechenaufgabe!");
        }
        return jeliza::Sentence("");
    }
};


#endif

