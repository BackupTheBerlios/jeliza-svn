#ifndef JELIZA_MOD_QUES_MATH
#define JELIZA_MOD_QUES_MATH 1
/*
 * This is part of JEliza 2.0.
 * Copyright 2006 by Tobias Schulz
 * WWW: http://jeliza.ch.to/
 *
 * JEliza is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later
 * version.
 *
 * JEliza is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU GPL
 * along with JEliza (file "gpl.txt") ; if not, write
 * to the Free Software Foundation, Inc., 51 Franklin St,
 * Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include "defs.h"

using namespace jdb;


class ModQues_Math {
public:
    JEliza& m_jel;
    DB& m_db;

    ModQues_Math (JEliza& jel, DB& db)
    : m_jel(jel), m_db(db)
    {
        clogger << ":: Modul 'Math' gestartet !!" << endl;
        log(":: Modul 'Math' gestartet !!");
    }

    Answer get (string frage) {
        // Ist es eine Rechenaufgabe?
        try {
            stringstream sst;
            string str;

            string divNull = string("/ 0");
            if (Util::contains(frage, divNull)) {
                clogger << "- Division durch Null!" << endl;
                return Answer("Tut mir leid, aber durch 0 kann ich nicht teilen!");
            }

            sst << m_jel.rechne(frage);
            sst >> str;

            clogger << "- Es war eine Rechenaufgabe!" << endl;
            log("- Es war eine Rechenaufgabe!");
            clogger << "- " << frage << " = " << str << endl;
            log("- " + frage + " = " + str);
            return Answer(str);
        } catch (const string) {
            clogger << "- Es war keine Rechenaufgabe!" << endl;
            log("- Es war keine Rechenaufgabe!");
        }
        return Answer("");
    }
};


#endif

