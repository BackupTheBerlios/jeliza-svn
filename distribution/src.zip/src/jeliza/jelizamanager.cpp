#ifndef JELIZA_MANAGER
#define JELIZA_MANAGER 1

/*
 * This is part of jeliza::JEliza 2.0.
 * Copyright 2006 by Tobias Schulz
 * WWW: http://jeliza.ch.to/
 *
 * JEliza is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later
 * version.
 *
 * JEliza is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU GPL
 * along with JEliza (file "gpl.txt") ; if not, write
 * to the Free Software Foundation, Inc., 51 Franklin St,
 * Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include "defs.h"

using namespace std;

/*
 * Die << und >> Operatoren
 */
jeliza::JElizaManager& operator<< (jeliza::JElizaManager& jel, string fra) {
    clogger << "jeliza::JElizaManager& operator<< (jeliza::JElizaManager& jel, string fra);" << endl;
    jel.m_antwort.set(jel.m_jel.ask(jeliza::Sentence(fra)));
    jel.m_jel.learn(jeliza::Sentence(fra));
    clogger << "end jeliza::JElizaManager& operator<< (jeliza::JElizaManager& jel, string fra);" << endl;

    return jel;
}
jeliza::JElizaManager& operator<< (jeliza::JElizaManager& jel, jeliza::answers ans) {
    clogger << "jeliza::JElizaManager& operator<< (jeliza::JElizaManager& jel, jeliza::answers ans);" << endl;
    jel.m_jel.init();
    jel.m_jel.learn(ans);
    jel.m_jel.init();
    clogger << "end jeliza::JElizaManager& operator<< (jeliza::JElizaManager& jel, jeliza::answers ans);" << endl;

    return jel;
}
jeliza::JElizaManager& jeliza::JElizaManager::operator>> (string& ans) {
    clogger << "jeliza::JElizaManager& jeliza::JElizaManager::operator>> (string& ans);" << endl;
    ans = m_antwort.ref();
    clogger << "end jeliza::JElizaManager& jeliza::JElizaManager::operator>> (string& ans);" << endl;

    return (*this);
}

jeliza::JElizaImpl& jeliza::JElizaManager::operator* () {
    return m_jel;
}

string jeliza::JElizaManager::greet () {
    return m_jel.getGreeting().ref();
}


#endif

