#ifndef JELIZA_MANAGER
#define JELIZA_MANAGER 1
/*
 * This is part of JEliza 2.0.
 * Copyright 2006 by Tobias Schulz
 * WWW: http://jeliza.ch.to/
 *
 * JEliza is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later
 * version.
 *
 * JEliza is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU GPL
 * along with JEliza (file "gpl.txt") ; if not, write
 * to the Free Software Foundation, Inc., 51 Franklin St,
 * Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include "defs.h"

using namespace std;
using namespace jdb;

/*
 * Die << und >> Operatoren
 */
JElizaManager& operator<< (JElizaManager& jel, string fra) {
    jel.m_jel.vorbereite();
    jel.m_jel << Question(fra);
    jel.m_jel << LearnableSentence(fra);
    jel.m_jel.vorbereite();

    return jel;
}
JElizaManager& operator<< (JElizaManager& jel, answers ans) {
    jel.m_jel.vorbereite();
    jel.m_jel.saveSentence(ans);
    jel.m_jel.vorbereite();

    return jel;
}
JElizaManager& JElizaManager::operator>> (string& ans) {
    m_jel >> ans;

    return *this;
}

JEliza& JElizaManager::operator* () {
    return m_jel;
}

string JElizaManager::greet () {
    return m_jel.getGreeting();
}


#endif
