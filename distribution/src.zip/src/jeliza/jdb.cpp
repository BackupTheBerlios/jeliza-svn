#ifndef JELIZA_Jjeliza::DB
#define JELIZA_Jjeliza::DB 1

/*
 * This is part of jeliza::JEliza 2.0.
 * Copyright 2006 by Tobias Schulz
 * WWW: http://jeliza.ch.to/
 *
 * JEliza is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later
 * version.
 *
 * JEliza is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU GPL
 * along with JEliza (file "gpl.txt") ; if not, write
 * to the Free Software Foundation, Inc., 51 Franklin St,
 * Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include "defs.h"

namespace jdb {

string toASCIIreally_2(string all) {
	string ascii(" \n\r!\"#$%&'()*+,-./0123456789:;<=>?    @ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_    `abcdefghijklmnopqrstuvwxyz{|}~");
//	string ascii = ;

	string allAscii = "";
    char array[2];
	array[1] = '\0';
	string y;
	for (unsigned int x = 0; x < all.size(); x++) {
		array[0] = all[x];
		y = array;
		if (Util::contains(ascii, y)) {
			allAscii += y;
		}
	}

	return allAscii;
}

string toASCII_2_2(string all) {
	all = Util::replace(all, "Ã¼", "ue");
	all = Util::replace(all, "Ã", "ss");
	all = Util::replace(all, "Ã¤", "ae");
	all = Util::replace(all, "ü", "ue");
	all = Util::replace(all, "ß", "ss");
	all = Util::replace(all, "ä", "ae");
	all = Util::replace(all, "ö", "oe");
	all = Util::replace(all, "Ü", "Ue");
	all = Util::replace(all, "Ä", "Ae");
	all = Util::replace(all, "Ö", "Oe");
	all = Util::replace(all, "Ã¢ÂÂ", "\"");
	all = Util::replace(all, "Ã¢ÂÂ", "\"");
	all = Util::replace(all, "&lt;/br&gt;", " ");

    all = toASCIIreally_2(all);

	return all;
}


void jeliza::DBSentence::print() {
    clogger << "Subject:   " << subject << endl;
    clogger << "Verb:      " << verb << endl;
    clogger << "Object:    " << object << endl;
    clogger << "Prefix:    " << prefix << endl;
    clogger << "Suffix:    " << suffix << endl;
    clogger << "Feeling:   " << feeling << endl;
    clogger << "Priority:  " << priority << endl;
    clogger << "Category:  " << category << endl;
    clogger << endl;
}




}

#endif
