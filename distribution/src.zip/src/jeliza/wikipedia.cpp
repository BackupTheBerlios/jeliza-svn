#ifndef JELIZA_WIKIPEDIA
#define JELIZA_WIKIPEDIA 1
/*
 * This is part of JEliza 2.0.
 * Copyright 2006 by Tobias Schulz
 * WWW: http://jeliza.ch.to/
 *
 * JEliza is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later
 * version.
 *
 * JEliza is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU GPL
 * along with JEliza (file "gpl.txt") ; if not, write
 * to the Free Software Foundation, Inc., 51 Franklin St,
 * Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include "defs.h"

using namespace std;
using namespace jdb;

bool offline_mode = false;
bool www_surf_mode = true;

jdb::answers wikipedia_words;

string ohneEckKlammer (string satz, bool withPipeInBrackets) {
    int inKlammer2 = 0;
    string tempStr = "";
    string satz2 = satz + " ";
    satz = "";
    bool schon_gesucht = false;
    for (int y = 0; y < satz2.size(); y++) {
        char ch = satz2[y];

        if (ch == '[' && satz2[y+1] == '[') {
            inKlammer2++;
            y++;
        }

        if (inKlammer2 == 0) {
            satz += ch;
        }

        if (ch == '|') {
            wikipedia_words.push_back(tempStr);
            schon_gesucht = true;
            tempStr = "";
        }

        if (inKlammer2 > 0 && ch != '|' && ch != '[' && ch != ']') {
            tempStr += ch;
        }

        if (ch == ']' && satz2[y+1] == ']') {
            if (!schon_gesucht) {
                wikipedia_words.push_back(tempStr);
            }
            inKlammer2--;
            if (withPipeInBrackets) {
                satz += tempStr;
            }
            tempStr = "";
            y++;
            schon_gesucht = false;
        }
    }

    return Util::strip(satz);
}

answers wikipedia (string wort, int count, bool rec = false, bool with_newlines = false) {
    wort = Util::replace(wort, string(" "), string("_"));

    log("- Suche in der deutschen Wikipedia nach: " + wort);

    string url = "http://de.wikipedia.org/w/index.php?title=" + wort + "&action=edit";
    clogger << "Url: \"" << url << "\"" << endl;
    download(url);

    ifstream ifstr("download.php");
    string all;
    string temp;
    while (ifstr) {
		getline(ifstr, temp);
//		temp = Util::strip(temp);

		all += toASCII_2(temp);
		all += "\n";
    }

    vector<string> lines;
    Util::split(all, string("\n"), lines);

    answers saetze;

    bool inRichtigemBereich = false;
    bool liste = false;
    int listenIndex = 0;
    int inKlammer = 0;
    string satz = "";
    for (int x = 0; x < lines.size(); x++) {
        string line = lines[x];
        line = Util::strip(line);

        clogger << inKlammer << " " << line << endl;

        if (Util::contains(line, "cols='80'")) {
//            clogger << "inRichtigemBereich = true; " << line << endl;
            inRichtigemBereich = true;
            vector<string> uuu;
            Util::split(line, string(">"), uuu);
            if (uuu.size() > 1) {
                line = uuu[1];
            } else {
                line = uuu[0];
            }
            line = Util::strip(line);
        }

        string sline = "-" + line + "-";
        string ssline = "-----" + line + "-----";

        if (inRichtigemBereich) {
            clogger << inKlammer << " " << line << endl;
        }

        if (inRichtigemBereich && Util::contains(ssline, "textarea")) {
            break;
        }

        if (Util::contains(ssline, "----[[")) {
            continue;
        }

        if (inRichtigemBereich && liste && line.size() > 1) {
            if (Util::contains(line, "*")) {
                listenIndex++;
                stringstream sst;
                sst << listenIndex;
                string j;
                sst >> j;
                satz += "*_____*";
                satz += "\n";
                satz += j;
                satz += ". ";
                line = Util::strip(ohneEckKlammer(line.substr(2, line.size() - 2), true));
                satz += line;
            }
            continue;
        }

        if (inRichtigemBereich && Util::contains(line, string("{{"))) {
            inKlammer++;
        }

        if (inRichtigemBereich && Util::contains(line, string("{|"))) {
            inKlammer++;
        }

        if (inRichtigemBereich && inKlammer == 0 && line.size() > 0 && !liste) {
//            clogger << "clogger << satz << endl; " << line << endl;
            satz = "";

            line = Util::replace(line, string("'"), string(""));

            int inKlammer2 = 0;
            for (int y = 0; y < line.size(); y++) {
                char ch = line[y];

                if (ch == '(') {
                    inKlammer2++;
                }

                if (inKlammer2 == 0) {
                    satz += ch;
                }

                if (ch == ')') {
                    inKlammer2--;
                }
            }

            line = satz;
            satz = "";
            inKlammer2 = 0;
            for (int y = 0; y < line.size(); y++) {
                char ch = line[y];

                if (ch == '<') {
                    inKlammer2++;
                }

                if (inKlammer2 == 0) {
                    satz += ch;
                }

                if (ch == '>') {
                    inKlammer2--;
                }
            }

            satz = ohneEckKlammer(satz, true);

            line = satz;
            satz = "";
            inKlammer2 = 0;
            for (int y = 0; y < line.size(); y++) {
                char ch = line[y];

                if (ch == '[') {
                    inKlammer2++;
                }

                if (inKlammer2 == 0) {
                    satz += ch;
                }

                if (ch == ']') {
                    inKlammer2--;
                }
            }

            satz = "-" + Util::replace(satz, string("  "), string(" ")) + "-";
            satz = Util::replace(satz, string("."), string("ekdnkecolesl"));
            satz = Util::replace(satz, string("ekdnkecolesl"), string("-.-"));
            if (Util::contains(satz, "-</textarea>")) {
                satz = "";
                break;
            }

            string satzlower = Util::toLower(satz);
            if (Util::contains(satzlower, "redirect") && rec) {
                satz = Util::replace_nocase(satz, string("redirect"), string(""));
                satz = Util::replace_nocase(satz, string("#"), string(""));
                satz = Util::strip(satz);
                satz = Util::replace(satz, string("-"), string(""));
                satz = Util::replace(satz, string("  "), string(" "));
                satz = Util::strip(satz);
                return wikipedia(satz, count, true, with_newlines);
            }
            else if (Util::contains(satzlower, "redirect") && !rec) {
                return answers();
            }

            vector<string> temp;
            Util::split(satz, string("."), temp);

            vector<string> temp2;
            Util::split(satz, string(" "), temp2);

//            clogger << temp[0] << endl;

/*            if (!with_newlines) {
                clogger << "with_newlines == false " << line << " | " << satz << endl;

                if ((temp[0].size() < 15 || Util::contains(temp[0], string("bzw-"))) && temp.size() > 1) {
                    satz = Util::strip(temp[0]) + ". " + Util::strip(temp[1]) + ".";
                } else if (temp[0].size() < 12) {
                    satz = "";
                } else if (temp2.size() < 7) {
                    satz = "";
                } else if (Util::contains(satz, string(":"))) {
                    satz = "";
                } else {
                    satz = Util::strip(temp[0]) + ".";
                }
                satz = Util::replace(satz, string("-"), string(""));
                satz = Util::replace(satz, string("  "), string(" "));

                break;
            }
            else {*/
            clogger << liste << "with_newlines == true " << line << " | " << satz << endl;

            if (Util::contains(satz, string(":")) || temp[0].size() < 12 || temp2.size() < 7) {
                satz = satz;
                satz = Util::replace(satz, string("-"), string(""));
                satz = Util::replace(satz, string("  "), string(" "));

                liste = true;
            } else if ((temp[0].size() < 15 || Util::contains(temp[0], string("bzw-"))) && temp.size() > 1) {
                satz = Util::strip(temp[0]) + ". " + Util::strip(temp[1]) + ".";
                satz = Util::replace(satz, string("-"), string(""));
                satz = Util::replace(satz, string("  "), string(" "));

                saetze.push_back(satz);
                satz = "";
                if (saetze.size() >= count) {
                    break;
                }
            } else {
                satz = Util::strip(temp[0]) + ".";
                satz = Util::replace(satz, string("-"), string(""));
                satz = Util::replace(satz, string("  "), string(" "));

                saetze.push_back(satz);
                satz = "";
                if (saetze.size() >= count) {
                    break;
                }
            }
//            }

        }

        if (inRichtigemBereich && inKlammer > 0 && Util::contains(line, string("}}"))) {
            inKlammer--;
        }

        if (inRichtigemBereich && inKlammer > 0 && Util::contains(line, string("|}"))) {
            inKlammer--;
        }

        if (inRichtigemBereich) {
            clogger << inKlammer << " " << line << endl;
        }

//        if (inRichtigemBereich) {
//           if (inRichtigemBereich && Util::contains(sline, string("]]-"))) {
//                inKlammer--;
//            }
//        }
    }

    if (liste) {
        saetze.push_back(satz);
        satz = "";
    }

    (*JELIZA_PROGRESS) += 4;

    answers saetze2;
    for (answers::iterator it = saetze.begin(); it != saetze.end(); it++) {
        clogger << *it << endl;
        if (!Util::contains(*it, "cols")) {
            saetze2.push_back(Util::replace(*it, string("*_____*"), string("")));
        }
    }

    if (saetze2.size() > 0) {
        wikipedia_words.push_back(wort);
    }

    return saetze2;
}

answers wikipedia_article (string wort, int count, bool rec = false, bool with_newlines = false) {
    wort = Util::replace(wort, string(" "), string("_"));

    log("- Suche in der deutschen Wikipedia dem Thema: " + wort);
    log("  um mehr Informationen zu finden...");

    string url = "http://de.wikipedia.org/w/index.php?title=" + wort + "&action=edit";
    clogger << "Url: \"" << url << "\"" << endl;
    download(url);

    ifstream ifstr("download.php");
    string all;
    string temp;
    while (ifstr) {
		getline(ifstr, temp);
//		temp = Util::strip(temp);

		all += toASCII_2(temp);
		all += "\n";
    }

    vector<string> lines;
    Util::split(all, string("\n"), lines);

    answers saetze;

    bool inRichtigemBereich = false;
    bool liste = false;
    int listenIndex = 0;
    int inKlammer = 0;
    string satz = "";
    for (int x = 0; x < lines.size(); x++) {
        string line = lines[x];
        line = Util::strip(line);

        clogger << inKlammer << " " << line << endl;

        if (Util::contains(line, "cols='80'")) {
//            clogger << "inRichtigemBereich = true; " << line << endl;
            inRichtigemBereich = true;
            vector<string> uuu;
            Util::split(line, string(">"), uuu);
            if (uuu.size() > 1) {
                line = uuu[1];
            } else {
                line = uuu[0];
            }
            line = Util::strip(line);
        }

        string sline = "-" + line + "-";
        string ssline = "-----" + line + "-----";

        if (inRichtigemBereich) {
            clogger << inKlammer << " " << line << endl;
        }

        if (inRichtigemBereich && Util::contains(ssline, "textarea")) {
            break;
        }

        if (Util::contains(ssline, "----[[")) {
            continue;
        }

        if (Util::contains(ssline, "=")) {
            continue;
        }

        if (inRichtigemBereich && line.size() > 1) {
            if (Util::contains(line, "*")) {
                continue;
            }
        }

        if (inRichtigemBereich && Util::contains(line, string("{{"))) {
            inKlammer++;
        }

        if (inRichtigemBereich && Util::contains(line, string("{|"))) {
            inKlammer++;
        }

        if (inRichtigemBereich && inKlammer == 0 && line.size() > 0 && !liste) {
//            clogger << "clogger << satz << endl; " << line << endl;
            satz = "";

            line = Util::replace(line, string("'"), string(""));

            int inKlammer2 = 0;
            for (int y = 0; y < line.size(); y++) {
                char ch = line[y];

                if (ch == '(') {
                    inKlammer2++;
                }

                if (inKlammer2 == 0) {
                    satz += ch;
                }

                if (ch == ')') {
                    inKlammer2--;
                }
            }

            line = satz;
            satz = "";
            inKlammer2 = 0;
            for (int y = 0; y < line.size(); y++) {
                char ch = line[y];

                if (ch == '<') {
                    inKlammer2++;
                }

                if (inKlammer2 == 0) {
                    satz += ch;
                }

                if (ch == '>') {
                    inKlammer2--;
                }
            }

            satz = ohneEckKlammer(satz, true);

            line = satz;
            satz = "";
            inKlammer2 = 0;
            for (int y = 0; y < line.size(); y++) {
                char ch = line[y];

                if (ch == '[') {
                    inKlammer2++;
                }

                if (inKlammer2 == 0) {
                    satz += ch;
                }

                if (ch == ']') {
                    inKlammer2--;
                }
            }

            satz = "-" + Util::replace(satz, string("  "), string(" ")) + "-";
            satz = Util::replace(satz, string("."), string("ekdnkecolesl"));
            satz = Util::replace(satz, string("ekdnkecolesl"), string("-.-"));
            if (Util::contains(satz, "-</textarea>")) {
                satz = "";
                break;
            }

            string satzlower = Util::toLower(satz);
            if (Util::contains(satzlower, "#redirect") && rec) {
                satz = Util::replace_nocase(satz, string("#redirect"), string(""));
                satz = Util::strip(satz);
                satz = Util::replace(satz, string("-"), string(""));
                satz = Util::replace(satz, string("  "), string(" "));
                satz = Util::strip(satz);
                return wikipedia_article(satz, count, true, with_newlines);
            }
            else if (Util::contains(satzlower, "#redirect") && !rec) {
                return answers();
            }

            vector<string> temp;
            Util::split(satz, string("."), temp);

            vector<string> temp2;
            Util::split(satz, string(" "), temp2);

            clogger << liste << "with_newlines == true " << line << " | " << satz << endl;

            if (Util::contains(satz, string(":")) || temp[0].size() < 12 || temp2.size() < 7) {
            } else if ((temp[0].size() < 15 || Util::contains(temp[0], string("bzw-"))) && temp.size() > 1) {
                satz = satz;
                satz = Util::replace(satz, string("-"), string(""));
                satz = Util::replace(satz, string("  "), string(" "));

                saetze.push_back(satz);
                satz = "";
            } else {
                satz = satz;
                satz = Util::replace(satz, string("-"), string(""));
                satz = Util::replace(satz, string("  "), string(" "));

                saetze.push_back(satz);
                satz = "";
            }
//            }

        }

        if (inRichtigemBereich && inKlammer > 0 && Util::contains(line, string("}}"))) {
            inKlammer--;
        }

        if (inRichtigemBereich && inKlammer > 0 && Util::contains(line, string("|}"))) {
            inKlammer--;
        }

        if (inRichtigemBereich) {
            clogger << inKlammer << " " << line << endl;
        }
    }

    if (liste) {
        saetze.push_back(satz);
        satz = "";
    }

    (*JELIZA_PROGRESS) += 4;

    answers saetze2;
    for (answers::iterator it = saetze.begin(); it != saetze.end(); it++) {
        clogger << *it << endl;
        if (!Util::contains(*it, "cols")) {
            saetze2.push_back(Util::replace(*it, string("*_____*"), string("")));
        }
    }

    return saetze2;
}



string search_in_wikipedia_with_newlines(string wort) {
    if (offline_mode) {
        return "";
    }

    wort = Util::strip(wort);
    wort = Util::toLower(wort);
    string orig_wort = wort;
    string firstchar = string(Util::toUpper(wort.substr(0, 1)));
    wort = wort.substr(1, wort.size());
    wort = firstchar + wort;
    wort = Util::strip(wort);

    answers satz;

    if (wort.size() < 1) {
        return "";
    }

    clogger << "- Wort zum Nachschlagen: " << wort << endl;
    satz = wikipedia(wort, 1, true, true);
    if (satz.size() < 1) {
        clogger << "- Wort zum Nachschlagen: " << orig_wort << endl;
        satz = wikipedia(orig_wort, 1, true, true);
        if (satz.size() < 1) {
            clogger << "- Wort zum Nachschlagen: " << Util::toUpper(orig_wort) << endl;
            satz = wikipedia(Util::toUpper(orig_wort), 1, true, true);
        }
    }

    string rsatz = "";
    if (satz.size() > 0) {
        rsatz = satz[0];
    }

    rsatz = Util::replace(rsatz, string("&"), string(""));
    rsatz = Util::replace(rsatz, string("amp;"), string("&"));
    rsatz = Util::replace(rsatz, string("nbsp;"), string("&"));

    (*JELIZA_PROGRESS) += 2;

    rsatz = Util::strip(rsatz);

    return rsatz;
}


answers search_in_wikipedia_acticle(string wort) {
    if (offline_mode) {
        return answers();
    }

    wort = Util::strip(wort);
    wort = Util::toLower(wort);
    string orig_wort = wort;
    string firstchar = string(Util::toUpper(wort.substr(0, 1)));
    wort = wort.substr(1, wort.size());
    wort = firstchar + wort;
    wort = Util::strip(wort);

    answers satz;

    if (wort.size() < 1) {
        return answers();
    }

    clogger << "- Wort zum Nachschlagen: " << wort << endl;
    satz = wikipedia_article(wort, 4000, true, true);
    if (satz.size() < 1) {
        clogger << "- Wort zum Nachschlagen: " << orig_wort << endl;
        satz = wikipedia_article(orig_wort, 4000, true, true);
        if (satz.size() < 1) {
            clogger << "- Wort zum Nachschlagen: " << Util::toUpper(orig_wort) << endl;
            satz = wikipedia_article(Util::toUpper(orig_wort), 4000, true, true);
        }
    }

    answers rsatz;

    for (int x = 0; x < satz.size(); x++) {
        //satz[x] = Util::toLower(satz[x]);

        answers y;
        Util::split(satz[x], string("."), y);

        for (int z = 0; z < y.size(); z++) {
            if (y[z].size() > 0
                    && !Util::contains(y[z], "|")
                    && !Util::contains(y[z], "*")
                    && !Util::contains(y[z], "?")) {

                y[z] = Util::replace(y[z], string("&"), string(""));
                y[z] = Util::replace(y[z], string("amp;"), string("&"));
                y[z] = Util::replace(y[z], string("nbsp;"), string("&"));

                if (y[z].size() < 55) {
                    continue;
                }

                rsatz.push_back(Util::strip(y[z]));
            }
        }
        x++;
    }

    return rsatz;
}

answers search_in_wikipedia_random() {
    string wort = "http://de.wikipedia.org/wiki/Spezial:Zuf%C3%A4llige_Seite";

    answers satz;

    if (wort.size() < 1) {
        return answers();
    }

    if (offline_mode) {
        return answers();
    }

    clogger << "- Wort zum Nachschlagen: " << wort << endl;
    satz = wikipedia_article(wort, 4000, true, true);

    answers rsatz;

    for (int x = 0; x < satz.size(); x++) {
        answers y;
        Util::split(satz[x], string("."), y);

        for (int z = 0; z < y.size(); z++) {
            y[z] = Util::replace(y[z], string("&"), string(""));
            y[z] = Util::replace(y[z], string("amp;"), string("&"));
            y[z] = Util::replace(y[z], string("nbsp;"), string("&"));

            if (y[z].size() < 40) {
                continue;
            }

            rsatz.push_back(Util::strip(y[z]));
        }
        x++;
    }

    return rsatz;
}





#endif
