#ifndef JELIZA_WIKIPEDIA
#define JELIZA_WIKIPEDIA 1
/*
 * This is part of jeliza::JEliza 2.0.
 * Copyright 2006 by Tobias Schulz
 * WWW: http://jeliza.ch.to/
 *
 * JEliza is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later
 * version.
 *
 * JEliza is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU GPL
 * along with JEliza (file "gpl.txt") ; if not, write
 * to the Free Software Foundation, Inc., 51 Franklin St,
 * Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include "defs.h"

using namespace std;

bool offline_mode = false;
bool www_surf_mode = true;

jeliza::answers wikipedia_words;
jeliza::Sentence allWikiWords;


jeliza::Sentence addNeuWikiWord (jeliza::Sentence tempStr) {
    if (!((jeliza::Sentence("+" + allWikiWords + "+")).contains(tempStr))) {
        wikipedia_words.push_back(tempStr);
        allWikiWords += "+";
        allWikiWords += tempStr;
        allWikiWords += "+";
    }
}

jeliza::Sentence ohneEckKlammer (jeliza::Sentence satz, bool withPipeInBrackets, jeliza::Sentence currentWort = jeliza::Sentence()) {
    satz.set(satz.toASCII());
    int inKlammer2 = 0;
    jeliza::Sentence tempStr;
    jeliza::Sentence satz2 = satz + " ";
    satz.set("");
    bool schon_gesucht = false;
    int y = 0;
    while (y < (signed) satz2.size()) {
        char t1[2];
        t1[0] = satz2[y];
        t1[1] = '\0';
        jeliza::Sentence ch(t1);
        jeliza::Sentence nch("");
        if (y + 1 < (signed) satz2.size()) {
            char t2[2];
            t2[0] = satz2[y+1];
            t2[1] = '\0';
            nch.set(t2);
        }

        if (ch == "[" && nch == "[") {
            inKlammer2++;
            y++;
        }

        if (inKlammer2 == 0) {
            satz += ch;
        }

        if (ch == "|") {
            jeliza::Sentence tempStrLower = tempStr;
            tempStrLower.lower();
            if (!allWikiWords.contains(jeliza::Sentence("+" + tempStrLower + "+")) // fix lower!!!
                    && !is_similar(currentWort, tempStr)) {
                wikipedia_words.push_back(tempStr);
                allWikiWords += "+";
                allWikiWords += tempStrLower;
                allWikiWords += "+";
            }

            schon_gesucht = true;
            tempStr.set("");
        }

        // cout << 5 << flush;
        if (inKlammer2 > 0 && ch.ref() != string("|") && ch.ref() != string("[") && ch.ref() != string("]")) {
            tempStr += ch;
        }

        // cout << 6 << flush;
        if (ch == string("]") && nch == string("]")) {
            // cout << 6.5 << flush;
            if (!schon_gesucht) {
                // cout << 6.7 << tempStr << flush;
                jeliza::Sentence tempStrLower = tempStr;
                tempStrLower.lower();
                if (!allWikiWords.contains("+" + tempStrLower + "+")) {
                    wikipedia_words.push_back(tempStr);
                    allWikiWords += "+";
                    allWikiWords += tempStrLower;
                    allWikiWords += "+";
                }
                // cout << 6.9 << flush;
            }
            // cout << 8 << flush;
            inKlammer2--;
            // cout << 9 << flush;
            if (withPipeInBrackets) {
                // cout << 10 << flush;
                satz += tempStr;
                // cout << 11 << flush;
            }
            // cout << 12 << flush;
            tempStr.set("");
            // cout << 13 << flush;
            y++;
            schon_gesucht = false;
        }
        // cout << 7 << endl << flush;

        y++;
        // cout << "2. " << y << " " << satz2.size() << "  ch " << ch << "#" << endl;
    }

    satz.strip();
    return (satz);
}

jeliza::answers wikipedia (jeliza::Sentence wort, int count, bool rec = false, bool with_newlines = false) {
    wort.replace(jeliza::Sentence(" "), jeliza::Sentence("_"));

    log("- Suche in der deutschen Wikipedia nach: " + wort.ref());

    jeliza::Sentence url = "http://de.wikipedia.org/w/index.php?title=" + wort + "&action=edit";
    clogger << "Url: \"" << url.ref() << "\"" << endl;
    download(url.ref());

    ifstream ifstr("download.php");
    jeliza::Sentence all;
    jeliza::Sentence temp;
    while (ifstr) {
		getline(ifstr, temp.ref());
//		temp = Util::strip(temp);

		all += temp.toASCII();
		all += "\n";
    }

    jeliza::answers lines;
    Util::split(all, string("\n"), lines);

    jeliza::answers saetze;

    bool inRichtigemBereich = false;
    bool liste = false;
    int listenIndex = 0;
    int inKlammer = 0;
    jeliza::Sentence satz;
    for (int x = 0; x < lines.size(); x++) {
        jeliza::Sentence line = lines[x];
        line.strip();

        clogger << inKlammer << " " << line.ref() << endl;

        if (line.contains("cols='80'")) {
//            clogger << "inRichtigemBereich = true; " << line << endl;
            inRichtigemBereich = true;
            jeliza::answers uuu;
            Util::split(line, string(">"), uuu);
            if (uuu.size() > 1) {
                line = uuu[1];
            } else {
                line = uuu[0];
            }
            line.strip();
        }

        jeliza::Sentence sline = "-" + line + "-";
        jeliza::Sentence ssline = "-----" + line + "-----";

        if (inRichtigemBereich) {
            clogger << inKlammer << " " << line.ref() << endl;
        }

        if (inRichtigemBereich && ssline.contains("textarea")) {
            break;
        }

        if (ssline.contains("----[[")) {
            continue;
        }

        if (inRichtigemBereich && liste && line.size() > 1) {
            if (line.contains("*")) {
                listenIndex++;
                stringstream sst;
                sst << listenIndex;
                jeliza::Sentence j;
                sst >> j.ref();
                satz += "*_____*";
                satz += "\n";
                satz += j;
                satz += ". ";
                (line.set(ohneEckKlammer(line.substr(2, line.size() - 2), true, wort))).strip();
                satz += line;
            }
            continue;
        }

        if (inRichtigemBereich && line.contains(jeliza::Sentence("{{"))) {
            inKlammer++;
        }

        if (inRichtigemBereich && line.contains(jeliza::Sentence("{|"))) {
            inKlammer++;
        }

        if (inRichtigemBereich && inKlammer == 0 && line.size() > 0 && !liste) {
//            clogger << "clogger << satz << endl; " << line << endl;
            satz.set("");

            line.replace(jeliza::Sentence("'"), jeliza::Sentence(""));

            int inKlammer2 = 0;
            for (int y = 0; y < line.size(); y++) {
                char ch = line[y];

                if (ch == '(') {
                    inKlammer2++;
                }

                if (inKlammer2 == 0) {
                    satz.ref() += ch;
                }

                if (ch == ')') {
                    inKlammer2--;
                }
            }

            line = satz;
            satz.set("");
            inKlammer2 = 0;
            for (int y = 0; y < line.size(); y++) {
                char ch = line[y];

                if (ch == '<') {
                    inKlammer2++;
                }

                if (inKlammer2 == 0) {
                    satz.ref() += ch;
                }

                if (ch == '>') {
                    inKlammer2--;
                }
            }

            satz.set(ohneEckKlammer(satz, true, wort));

            line.set(satz);
            satz.set("");
            inKlammer2 = 0;
            for (int y = 0; y < line.size(); y++) {
                char ch = line[y];

                if (ch == '[') {
                    inKlammer2++;
                }

                if (inKlammer2 == 0) {
                    satz.ref() += ch;
                }

                if (ch == ']') {
                    inKlammer2--;
                }
            }

            satz.set("-" + satz.replace(jeliza::Sentence("  "), jeliza::Sentence(" ")) + "-");
            satz.replace(jeliza::Sentence("."), jeliza::Sentence("ekdnkecolesl"));
            satz.replace(jeliza::Sentence("ekdnkecolesl"), jeliza::Sentence("-.-"));
            if (satz.contains("-</textarea>")) {
                satz.set("");
                break;
            }

            jeliza::Sentence satzlower;
            (satzlower.set(satz)).lower();
            if (satzlower.contains("redirect") && rec) {
                satz.replace_nocase(jeliza::Sentence("redirect"), jeliza::Sentence(""));
                satz.replace_nocase(jeliza::Sentence("#"), jeliza::Sentence(""));
                satz.strip();
                satz.replace(jeliza::Sentence("-"), jeliza::Sentence(""));
                satz.replace(jeliza::Sentence("  "), jeliza::Sentence(" "));
                satz.strip();
                return (wikipedia(satz, count, true, with_newlines));
            }
            else if (satzlower.contains("redirect") && !rec) {
                return (jeliza::answers());
            }

            jeliza::answers temp;
            Util::split(satz, string("."), temp);

            jeliza::answers temp2;
            Util::split(satz, string(" "), temp2);


            clogger << liste << "with_newlines == true " << line.ref() << " | " << satz.ref() << endl;

            if (satz.contains(jeliza::Sentence(":")) || temp[0].size() < 12 || temp2.size() < 7) {
                satz = satz;
                satz.replace(jeliza::Sentence("-"), jeliza::Sentence(""));
                satz.replace(jeliza::Sentence("  "), jeliza::Sentence(" "));

                liste = true;
            } else if ((temp[0].size() < 15 || temp[0].contains(jeliza::Sentence("bzw-"))) && temp.size() > 1) {
                satz = temp[0].get_strip() + ". " + temp[1].get_strip() + ".";
                satz.replace(jeliza::Sentence("-"), jeliza::Sentence(""));
                satz.replace(jeliza::Sentence("  "), jeliza::Sentence(" "));

                saetze.push_back(satz);
                satz.set("");
                if (saetze.size() >= count) {
                    break;
                }
            } else {
                satz = temp[0].get_strip() + ".";
                satz.replace(jeliza::Sentence("-"), jeliza::Sentence(""));
                satz.replace(jeliza::Sentence("  "), jeliza::Sentence(" "));

                saetze.push_back(satz);
                satz.set("");
                if (saetze.size() >= count) {
                    break;
                }
            }
        }

        if (inRichtigemBereich && inKlammer > 0 && line.contains(jeliza::Sentence("}}"))) {
            inKlammer--;
        }

        if (inRichtigemBereich && inKlammer > 0 && line.contains(jeliza::Sentence("|}"))) {
            inKlammer--;
        }

        if (inRichtigemBereich) {
            clogger << inKlammer << " " << line.ref() << endl;
        }
    }

    if (liste) {
        saetze.push_back(satz);
        satz.set("");
    }

    jeliza::answers saetze2;
    for (jeliza::answers::iterator it = saetze.begin(); it != saetze.end(); it++) {
        it->set(it->toASCII());
        clogger << it->ref() << endl;
        if (!it->contains("cols")) {
            saetze2.push_back(it->replace(jeliza::Sentence("*_____*"), jeliza::Sentence("")));
        }
    }

    if (saetze2.size() > 0) {
        jeliza::Sentence wordLower;
        (wordLower = wort).lower();
        if (!allWikiWords.contains("+" + wordLower + "+")) {
            wikipedia_words.push_back(wort);
            allWikiWords += "+";
            allWikiWords += wordLower;
            allWikiWords += "+";
        }
    }

    return saetze2;
}

jeliza::answers wikipedia_article (jeliza::Sentence wort, int count, bool rec = false, bool with_newlines = false) {
    wort.replace(jeliza::Sentence(" "), jeliza::Sentence("_"));

    log("- Suche in der deutschen Wikipedia dem Thema: " + wort.ref());
    log("  um mehr Informationen zu finden...");

    jeliza::Sentence url = "http://de.wikipedia.org/w/index.php?title=" + wort + "&action=edit";
    clogger << "Url: \"" << url.ref() << "\"" << endl;
    download(url.ref());

    ifstream ifstr("download.php");
    jeliza::Sentence all;
    jeliza::Sentence temp;
    while (ifstr) {
		getline(ifstr, temp.ref());
//		temp = Util::strip(temp);

		all += temp.toASCII();
		all += "\n";
    }

    jeliza::answers lines;
    Util::split(all, string("\n"), lines);

    jeliza::answers saetze;

    bool inRichtigemBereich = false;
    bool liste = false;
    int listenIndex = 0;
    int inKlammer = 0;
    jeliza::Sentence satz;
    for (int x = 0; x < lines.size(); x++) {
        jeliza::Sentence line = lines[x];
        line.strip();

        clogger << inKlammer << " " << line.ref() << endl;

        if (line.contains("cols='80'")) {
//            clogger << "inRichtigemBereich = true; " << line << endl;
            inRichtigemBereich = true;
            jeliza::answers uuu;
            Util::split(line, string(">"), uuu);
            if (uuu.size() > 1) {
                line = uuu[1];
            } else {
                line = uuu[0];
            }
            line.strip();
        }

        jeliza::Sentence sline = "-" + line + "-";
        jeliza::Sentence ssline = "-----" + line + "-----";

        if (inRichtigemBereich) {
            clogger << inKlammer << " " << line.ref() << endl;
        }

        if (inRichtigemBereich && ssline.contains("textarea")) {
            break;
        }

        if (ssline.contains("----[[")) {
            continue;
        }

        if (ssline.contains("=")) {
            continue;
        }

        if (inRichtigemBereich && line.size() > 1) {
            if (line.contains("*")) {
                continue;
            }
        }

        if (inRichtigemBereich && line.contains(jeliza::Sentence("{{"))) {
            inKlammer++;
        }

        if (inRichtigemBereich && line.contains(jeliza::Sentence("{|"))) {
            inKlammer++;
        }

        if (inRichtigemBereich && inKlammer == 0 && line.size() > 0 && !liste) {
//            clogger << "clogger << satz << endl; " << line << endl;
            satz.set("");

            line.replace(jeliza::Sentence("'"), jeliza::Sentence(""));

            int inKlammer2 = 0;
            for (int y = 0; y < line.size(); y++) {
                char ch = line[y];

                if (ch == '(') {
                    inKlammer2++;
                }

                if (inKlammer2 == 0) {
                    satz.ref() += ch;
                }

                if (ch == ')') {
                    inKlammer2--;
                }
            }

            line.set(satz);
            satz.set("");
            inKlammer2 = 0;
            for (int y = 0; y < line.size(); y++) {
                char ch = line[y];

                if (ch == '<') {
                    inKlammer2++;
                }

                if (inKlammer2 == 0) {
                    satz.ref() += ch;
                }

                if (ch == '>') {
                    inKlammer2--;
                }
            }

            satz.set(ohneEckKlammer(satz, true, wort));

            line.set(satz);
            satz.set("");
            inKlammer2 = 0;
            for (int y = 0; y < line.size(); y++) {
                char ch = line[y];

                if (ch == '[') {
                    inKlammer2++;
                }

                if (inKlammer2 == 0) {
                    satz.ref() += ch;
                }

                if (ch == ']') {
                    inKlammer2--;
                }
            }

            satz.set("-" + satz.replace(jeliza::Sentence("  "), jeliza::Sentence(" ")) + "-");
            satz.replace(jeliza::Sentence("."), jeliza::Sentence("ekdnkecolesl"));
            satz.replace(jeliza::Sentence("ekdnkecolesl"), jeliza::Sentence("-.-"));
            if (satz.contains("-</textarea>")) {
                satz.set("");
                break;
            }

            jeliza::Sentence satzlower;
            (satzlower.set(satz)).lower();
            if (satzlower.contains("#redirect") && rec) {
                satz.replace_nocase(jeliza::Sentence("#redirect"), jeliza::Sentence(""));
                satz.strip();
                satz.replace(jeliza::Sentence("-"), jeliza::Sentence(""));
                satz.replace(jeliza::Sentence("  "), jeliza::Sentence(" "));
                satz.strip();
                return (wikipedia_article(satz, count, true, with_newlines));
            }
            else if (satzlower.contains("#redirect") && !rec) {
                return (jeliza::answers());
            }

            vector<jeliza::Sentence> temp;
            Util::split(satz, string("."), temp);

            vector<jeliza::Sentence> temp2;
            Util::split(satz, string(" "), temp2);

            clogger << liste << "with_newlines == true " << line.ref() << " | " << satz.ref() << endl;

            if (satz.contains(jeliza::Sentence(":")) || temp[0].size() < 12 || temp2.size() < 7) {
            } else if ((temp[0].size() < 15 || temp[0].contains(jeliza::Sentence("bzw-"))) && temp.size() > 1) {
                satz.replace(jeliza::Sentence("-"), jeliza::Sentence(""));
                satz.replace(jeliza::Sentence("  "), jeliza::Sentence(" "));

                saetze.push_back(satz);
                satz.set("");
            } else {
                satz.replace(jeliza::Sentence("-"), jeliza::Sentence(""));
                satz.replace(jeliza::Sentence("  "), jeliza::Sentence(" "));

                saetze.push_back(satz);
                satz.set("");
            }
        }

        if (inRichtigemBereich && inKlammer > 0 && line.contains(jeliza::Sentence("}}"))) {
            inKlammer--;
        }

        if (inRichtigemBereich && inKlammer > 0 && line.contains(jeliza::Sentence("|}"))) {
            inKlammer--;
        }

        if (inRichtigemBereich) {
            clogger << inKlammer << " " << line.ref() << endl;
        }
    }

    if (liste) {
        saetze.push_back(satz);
        satz.set("");
    }

    jeliza::answers saetze2;
    for (jeliza::answers::iterator it = saetze.begin(); it != saetze.end(); it++) {
        clogger << it->ref() << endl;
        if (!it->contains("cols")) {
            saetze2.push_back(it->replace(jeliza::Sentence("*_____*"), jeliza::Sentence("")));
        }
    }

    return saetze2;
}



jeliza::Sentence search_in_wikipedia_with_newlines(jeliza::Sentence wort) {
    if (offline_mode) {
        return jeliza::Sentence();
    }

    wort.strip();
    wort.lower();
    jeliza::Sentence orig_wort = wort;
    jeliza::Sentence firstchar;
    (firstchar.set(wort.substr(0, 1))).upper();
    wort.set(wort.substr(1, wort.size()));
    wort.set(firstchar + wort);
    wort.strip();

    jeliza::answers satz;

    if (wort.size() < 1) {
        return jeliza::Sentence();
    }

    clogger << "- Wort zum Nachschlagen: " << wort.ref() << endl;
    satz << NULL << wikipedia(wort, 1, true, true);
    if (satz.size() < 1) {
        clogger << "- Wort zum Nachschlagen: " << orig_wort.ref() << endl;
        satz << NULL << wikipedia(orig_wort, 1, true, true);
        if (satz.size() < 1) {
            clogger << "- Wort zum Nachschlagen: " << orig_wort.get_upper().ref() << endl;
            satz << NULL << wikipedia(orig_wort.get_upper(), 1, true, true);
        }
    }

    jeliza::Sentence rsatz;
    if (satz.size() > 0) {
        rsatz = satz[0];
    }

    rsatz.replace(jeliza::Sentence("&"), jeliza::Sentence(""));
    rsatz.replace(jeliza::Sentence("amp;"), jeliza::Sentence("&"));
    rsatz.replace(jeliza::Sentence("nbsp;"), jeliza::Sentence("&"));

    rsatz.strip();

    return rsatz;
}


jeliza::answers search_in_wikipedia_acticle(jeliza::Sentence wort) {
    if (offline_mode) {
        return jeliza::answers();
    }

    wort.strip();
    wort.lower();
    jeliza::Sentence orig_wort = wort;
    jeliza::Sentence firstchar;
    (firstchar.set(wort.substr(0, 1))).upper();
    wort.set(wort.substr(1, wort.size()));
    wort.set(firstchar + wort);
    wort.strip();

    jeliza::answers satz;

    if (wort.size() < 1) {
        return jeliza::answers();
    }

    clogger << "- Wort zum Nachschlagen: " << wort.ref() << endl;
    satz << NULL << wikipedia_article(wort, 4000, true, true);
    if (satz.size() < 1) {
        clogger << "- Wort zum Nachschlagen: " << orig_wort.ref() << endl;
        satz << NULL << wikipedia_article(orig_wort, 4000, true, true);
        if (satz.size() < 1) {
            clogger << "- Wort zum Nachschlagen: " << orig_wort.get_upper().ref() << endl;
            satz << NULL << wikipedia_article(orig_wort.get_upper(), 4000, true, true);
        }
    }

    jeliza::answers rsatz;

    for (int x = 0; x < satz.size(); x++) {
        jeliza::answers y;
        Util::split(satz[x], string("."), y);

        for (int z = 0; z < y.size(); z++) {
            if (y[z].size() > 0
                    && !y[z].contains("|")
                    && !y[z].contains("*")
                    && !y[z].contains("?")) {

                y[z].replace(jeliza::Sentence("&"), jeliza::Sentence(""));
                y[z].replace(jeliza::Sentence("amp;"), jeliza::Sentence("&"));
                y[z].replace(jeliza::Sentence("nbsp;"), jeliza::Sentence("&"));

                if (y[z].size() < 55) {
                    continue;
                }

                rsatz.push_back(y[z].get_strip());
            }
        }
        x++;
    }

    return rsatz;
}
/*
answers search_in_wikipedia_random() {
    jeliza::Sentence wort = "http://de.wikipedia.org/wiki/Spezial:Zuf%C3%A4llige_Seite";

    answers satz;

    if (wort.size() < 1) {
        return answers();
    }

    if (offline_mode) {
        return answers();
    }

    clogger << "- Wort zum Nachschlagen: " << wort << endl;
    satz = wikipedia_article(wort, 4000, true, true);

    answers rsatz;

    for (int x = 0; x < satz.size(); x++) {
        answers y;
        Util::split(satz[x], jeliza::Sentence("."), y);

        for (int z = 0; z < y.size(); z++) {
            y[z] = Util::replace(y[z], jeliza::Sentence("&"), jeliza::Sentence(""));
            y[z] = Util::replace(y[z], jeliza::Sentence("amp;"), jeliza::Sentence("&"));
            y[z] = Util::replace(y[z], jeliza::Sentence("nbsp;"), jeliza::Sentence("&"));

            if (y[z].size() < 40) {
                continue;
            }

            rsatz.push_back(Util::strip(y[z]));
        }
        x++;
    }

    return rsatz;
}
*/




#endif
