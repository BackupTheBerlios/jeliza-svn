#ifndef JELIZA
#define JELIZA 1

/*
 * This is part of jeliza::JEliza 2.0.
 * Copyright 2006 by Tobias Schulz
 * WWW: http://jeliza.ch.to/
 *
 * JEliza is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later
 * version.
 *
 * JEliza is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU GPL
 * along with JEliza (file "gpl.txt") ; if not, write
 * to the Free Software Foundation, Inc., 51 Franklin St,
 * Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include "defs.h"

using namespace std;

#include "modules/ques_empty.cpp"
#include "modules/ques_logical.cpp"
#include "modules/ques_math.cpp"
#include "modules/ques_similar.cpp"


Logger& operator<< (Logger lg, jeliza::Sentence str) {
    clogger << "Logger& operator<<" << endl;
    clogger << "" << endl;
    log(str.ref());
    return (lg);
}

/*ofstream& operator<<(ofstream& o, jeliza::Sentence s) {
    o << s.ref();
    return (o);
}

ostream& operator<<(ostream& o, jeliza::Sentence s) {
    o << s.ref();
    return (o);
}*/

int jeliza::VOK = 0;
int jeliza::KONS = 1;
int jeliza::VERB = 5;
int jeliza::NOMEN = 6;
int jeliza::ADJ = 7;
int jeliza::PREP = 8;
int jeliza::PP = 9;
int jeliza::ART = 10;

ofstream clogger("jeliza.log");
auto_ptr<vector<jeliza::answers> > jeliza::Wortart_Database;

void jeliza::init_jeliza() {
    Wortart_Database.reset(new vector<jeliza::answers>());
    ifstream iDic("wsh/dic.wsh");
    jeliza::Sentence str;
    while (iDic) {
        getline(iDic, str.ref());
        jeliza::answers vec;

        Util::split(str, string(";"), vec);
        if (vec.size() == 4) {
            vec[0].lower();
//            vec.push_back(jeliza::ermittle_wortstamm(vec[1]));
            vec[2].strip();
            jeliza::Wortart_Database->push_back(vec);
        }
        /*else if (vec.size() == 1) {
            vec[0].lower();
            vec.push_back(jeliza::Sentence("verb"));
            vec.push_back(ermittle_wortstamm(vec[1]));
            jeliza::Wortart_Database->push_back(vec);
        }*/
    }

    Py_Initialize();
    PyImport_AddModule("jelizacpp");
    Py_InitModule("jelizacpp", jelizacpp_methods);
}


jeliza::Sentence jeliza::DBSentence::toXML() {
    clogger << "toXML()" << endl;
    jeliza::Sentence temp;

    stringstream sst;
    sst << priority;
    jeliza::Sentence tempprio;
    sst >> tempprio.ref();

    jeliza::Sentence all;

    all += " <fact>\n";
    all += this->printPart (string("prefix>   "), temp.ref(), prefix.ref());
    all += this->printPart (string("subject>  "), temp.ref(), subject.ref());
    all += this->printPart (string("verb>     "), temp.ref(), verb.ref());
    all += this->printPart (string("object>   "), temp.ref(), object.ref());
    all += this->printPart (string("suffix>   "), temp.ref(), suffix.ref());
    all += this->printPart (string("feeling>  "), temp.ref(), feeling.ref());
    all += this->printPart (string("priority> "), temp.ref(), tempprio.ref());
    all += this->printPart (string("category> "), temp.ref(), category.ref());
    all += " </fact>\n\n";

    return all;
}

void jeliza::DBSentence::toXMLPrint() {
    clogger << "toXMLPrint()" << endl;
    jeliza::Sentence temp;

    stringstream sst;
    sst << priority;
    jeliza::Sentence tempprio;
    sst >> tempprio.ref();

    clogger << " <fact>" << endl;
    printPart (string("prefix>   "), temp.ref(), prefix.ref());
    printPart (string("subject>  "), temp.ref(), subject.ref());
    printPart (string("verb>     "), temp.ref(), verb.ref());
    printPart (string("object>   "), temp.ref(), object.ref());
    printPart (string("suffix>   "), temp.ref(), suffix.ref());
    printPart (string("feeling>  "), temp.ref(), feeling.ref());
    printPart (string("priority> "), temp.ref(), tempprio.ref());
    printPart (string("category> "), temp.ref(), category.ref());

    clogger << " </fact>" << endl;
    clogger << endl;
}

jeliza::Sentence jeliza::DBSentence::printPart (string str, string temp, string wert) {
    clogger << "printPart()" << endl;
//    clogger << "  <" << str << wert << "  " << "</" << str << endl;

    temp = Util::replace(temp, string("\n"), string("\\n"));
    temp = Util::replace(temp, string("\r"), string(""));

    return Sentence("  <" + str + wert + "  " + "</" + str + "\n");
}

void jeliza::DBSentence::print() {
    clogger << "print()" << endl;
    clogger << "Subject:   " << subject.ref() << endl;
    clogger << "Verb:      " << verb.ref() << endl;
    clogger << "Object:    " << object.ref() << endl;
    clogger << "Prefix:    " << prefix.ref() << endl;
    clogger << "Suffix:    " << suffix.ref() << endl;
    clogger << "Feeling:   " << feeling.ref() << endl;
    clogger << "Priority:  " << priority << endl;
    clogger << "Category:  " << category.ref() << endl;
    clogger << endl;
}

void jeliza::DBSentence::strip() {
    clogger << "DBSentence::strip()" << endl;
    prefix.strip();
    subject.strip();
    verb.strip();
    object.strip();
    suffix.strip();
    feeling.strip();
    category.strip();

    prefix.replace(string("\\n"), string("\n"));
    subject.replace(string("\\n"), string("\n"));
    verb.replace(string("\\n"), string("\n"));;
    object.replace(string("\\n"), string("\n"));
    suffix.replace(string("\\n"), string("\n"));
    feeling.replace(string("\\n"), string("\n"));
    category.replace(string("\\n"), string("\n"));
}

jeliza::answers jeliza::DBSentence::genSentences(bool withFix = false) {
    clogger << "genSentences" << endl;
    strip();

    jeliza::answers ans;

    if (subject.size() > 2 && verb.size() > 2 && object.size() > 1) {
        ans.push_back(jeliza::Sentence(subject + " " + verb + " " + object));
    } else if (withFix) {
        ans.push_back(jeliza::Sentence(prefix + " " + subject + " " + verb + " " + object + " " + suffix));
    }
    jeliza::Sentence temp;
    (temp = prefix + " " + subject + " " + verb + " " + object).strip();
    if (temp.size() > 1) {
        ans.push_back(temp);
    }
    (temp = subject + " " + verb + " " + object + " " + suffix).strip();
    if (temp.size() > 1) {
        ans.push_back(temp);
    }

    ans.push_back(jeliza::Sentence(prefix + " " + subject + " " + verb + " " + object + " " + suffix));

    return ans;
}

jeliza::answers jeliza::DBSentence::genSentences_all(bool withFix = false) {
    clogger << "genSentences_all" << endl;
    strip();

    jeliza::answers ans;

    ans.push_back(jeliza::Sentence(prefix + " " + subject + " " + verb + " " + object + " " + suffix));

    return ans;
}

auto_ptr<jeliza::DB> jeliza_db;
jeliza::Sentence log_all;
jeliza::JElizaImpl jel;

unsigned int jeliza::isQuestion (jeliza::Sentence ques) {
    clogger << "isQuestion" << endl;
    ques.lower();
    if (ques.contains(jeliza::Sentence("was"))) {
        return 1;
    }
    if (ques.contains(jeliza::Sentence("wie"))) {
        return 1;
    }
    if (ques.contains(jeliza::Sentence("wer"))) {
        return 1;
    }
    if (ques.contains(jeliza::Sentence("wie"))) {
        return 1;
    }
    if (ques.contains(jeliza::Sentence("wo"))) {
        return 1;
    }
    if (ques.contains(jeliza::Sentence("wann"))) {
        return 1;
    }
    if (ques.contains(jeliza::Sentence("warum"))) {
        return 1;
    }
    if (ques.contains(jeliza::Sentence("wieso"))) {
        return 1;
    }
    if (ques.contains(jeliza::Sentence("weshalb"))) {
        return 1;
    }

    if (ques.contains(jeliza::Sentence("kennst du")) && ques.contains(jeliza::Sentence("?"))) {
        return 1;
    }

    if (ques.contains(jeliza::Sentence("kenne du")) && ques.contains(jeliza::Sentence("?"))) {
        return 1;
    }

    if (ques.contains(jeliza::Sentence("?"))) {
        return 2;
    }

    return 0;
}

namespace jeliza {
    unsigned int FRAGE_FRAGEWORT = 1;
    unsigned int KEINE_FRAGE = 0;
    unsigned int FRAGE_YES_NO = 2;
}

jeliza::DBSentence& jeliza::DBSentence::operator= (const jeliza::DBSentence& sent) {
    subject.set(sent.subject);
    verb.set(sent.verb);
    object.set(sent.object);
    prefix.set(sent.prefix);
    suffix.set(sent.suffix);
    feeling.set(sent.feeling);
    category.set(sent.category);
    priority = sent.priority;
    return (*this);
}

jeliza::DB* jeliza::parseJDB (string file) {
    clogger << "parseJDB" << endl;
    ifstream i(file.c_str());

    jeliza::Sentence buffer;
    jeliza::Sentence all;
    while (i) {
        getline (i, buffer.ref());

        if (buffer.contains("<?xml")) {
            continue;
        }

        all += buffer;
        all += "\n";
//        clogger << all << "\t";
    }

    jeliza::answers lines;
    Util::split(all, string("\n\r<>"), lines);

    clogger << lines.size() << endl;

    jeliza::DB* sents = new jeliza::DB();

    for (jeliza::answers::iterator it = lines.begin(); it != lines.end(); it++) {
//        clogger << (*it) << "\t";
        it->strip();
//        clogger << ",";
    }
    clogger << endl;

    clogger << lines.size() << endl;

    jeliza::DBSentence act_sent;
    jeliza::Sentence line;
    for (jeliza::answers::iterator it = lines.begin(); it != lines.end(); it++) {
        line.ref() = it->ref();

        if (line.equal("priority")) {
            stringstream sst;
            sst << (*(it + 1)).ref();
            int t;
            sst >> t;
            act_sent.priority = t;
            it += 2;
        }

        else if (line.equal("subject")) {
            act_sent.subject.ref() = (it + 1)->get();

            it += 2;
        }

        else if (line.equal("verb")) {
            act_sent.verb.ref() = (it + 1)->get();
            it += 2;
        }

        else if (line.equal("object")) {
            act_sent.object.ref() = (it + 1)->get();
            it += 2;
        }

        else if (line.equal("feeling")) {
            act_sent.feeling.ref() = (it + 1)->get();
            it += 2;
        }

        else if (line.equal("prefix")) {
            act_sent.prefix.ref() = (it + 1)->get();
            it += 2;
        }

        else if (line.equal("suffix")) {
            act_sent.suffix.ref() = (it + 1)->get();
            it += 2;
        }

        else if (line.equal("category")) {
            act_sent.category.ref() = (it + 1)->get();
            it += 2;
        }

        else if (line.equal("/fact")) {
            act_sent.strip();
            if (jeliza::isQuestion(act_sent.genSentences_all(true)[0]) == 0) {
                sents->push_back(act_sent);
            }
            act_sent = jeliza::DBSentence();
            clogger << ".";
        }
    }
    clogger << endl << endl;

    return (sents);
}

jeliza::DBSentence jeliza::toDBSentence (jeliza::Sentence buffer, vector<string> verbs) {
    clogger << "toDBSentence" << endl;
    buffer.replace(jeliza::Sentence("\n"), jeliza::Sentence("\\n"));
    jeliza::answers parts = jeliza::split_spo(buffer, verbs);

    jeliza::DBSentence act_sent;

    if (parts.size() == 4) {
        clogger << "parts.size() > 1 " << parts[0].ref() << "|"  << parts[1].ref() << "|"  << parts[2].ref() << "|"  << parts[2].ref() << endl;
        jeliza::Sentence prefix;
        clogger << "1";
        if (parts[0].contains(",")) {
            clogger << "2";
            int n = parts[0].find(",");
            clogger << "3";
            prefix.set(parts[0].substr(0, n));
            clogger << "4";
            parts[0].set(parts[0].substr(n+1, parts[0].size()));
        }
        clogger << "5";
        jeliza::Sentence suffix;
        if (parts[3].contains(",")) {
            clogger << "6";
            int n = parts[3].find(",");
            clogger << "7";
            suffix.set(parts[3].substr(n+1, parts[3].size()));
            clogger << "8";
            parts[3].set(parts[3].substr(0, n));
        }
        clogger << "9";
        act_sent.subject.set(parts[0]);
        act_sent.subject.strip();
        act_sent.verb.set(parts[1]);
        act_sent.verb.strip();
        act_sent.object.set(parts[3]);
        act_sent.object.strip();
        act_sent.prefix.set(prefix);
        act_sent.prefix.strip();
        act_sent.suffix.set(suffix);
        act_sent.suffix.strip();
    }
    else {
        clogger << "parts.size() == 0" << endl;
        jeliza::Sentence prefix(buffer);
        jeliza::Sentence suffix;
        if (buffer.contains(",")) {
            int n = buffer.find(",");
            prefix.set(buffer.substr(0, n));
            suffix.set(buffer.substr(n+1, buffer.size()));
        }
        act_sent.prefix.set(prefix);
        act_sent.prefix.strip();
        act_sent.suffix.set(suffix);
        act_sent.suffix.strip();
    }
    return act_sent;
}


void jeliza::saveDB(string file, jeliza::DB db) {
    clogger << "saveDB()" << endl;
    ofstream o(file.c_str());

    vector<string> verbs = verbs::getVerbs();
	jeliza::Sentence buffer;

    o << "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" << endl << endl << "<jdb>" << endl;

    o << " <feelings>" << endl
      << "  <feeling>happy</happy>" << endl
      << "  <feeling>angry</angry>" << endl
      << "  <feeling>bored</bored>" << endl
      << "  <feeling>scared</scared>" << endl
      << "  <feeling>curiously</curiously>" << endl
      << "  <feeling>normal</normal>" << endl
      << " </feelings>" << endl
      << endl;


    for (jeliza::DB::iterator it = db.begin(); it != db.end(); it++) {
        o << (*it).toXML().toASCII().ref() << endl;
    }

    o << "</jdb>" << endl;
}


jeliza::Sentence jeliza::ohne_muell(jeliza::Sentence frage2) {
    clogger << "ohne_muell" << endl;
    string frage = frage2.get();
	frage = Util::replace(frage, string("?"), string(""));
	frage = Util::replace(frage, string("!"), string(""));
	frage = Util::replace(frage, string("."), string(""));
	frage = Util::replace(frage, string(","), string(""));
	frage = Util::replace(frage, string(";"), string(""));
	frage = Util::replace(frage, string("+"), string(" ztrgftredrefd "));
	frage = Util::replace(frage, string("ztrgftredrefd"), string("+"));
	frage = Util::replace(frage, string("*"), string(" ztrgftredrefd "));
	frage = Util::replace(frage, string("ztrgftredrefd"), string("*"));
	frage = Util::replace(frage, string("/"), string(" ztrgftredrefd "));
	frage = Util::replace(frage, string("ztrgftredrefd"), string("/"));
	frage = Util::replace(frage, string("  "), string(" "));
	frage = " " + frage + " ";

	vector<string> unuseful_words;
	unuseful_words.push_back("der");
	unuseful_words.push_back("die");
	unuseful_words.push_back("das");
	unuseful_words.push_back("dem");
	unuseful_words.push_back("des");
	unuseful_words.push_back("dessen");
	unuseful_words.push_back("was");
	unuseful_words.push_back("wer");
	unuseful_words.push_back("wie");
	unuseful_words.push_back("wo");
	unuseful_words.push_back("wann");
	unuseful_words.push_back("von");
	unuseful_words.push_back("vom");
	unuseful_words.push_back("in");
	unuseful_words.push_back("auf");
	unuseful_words.push_back("unter");
	unuseful_words.push_back("neben");
	unuseful_words.push_back("zwischen");
	unuseful_words.push_back("denn");
	unuseful_words.push_back("bloß");
	unuseful_words.push_back("bloss");
	unuseful_words.push_back("stimmts");
	unuseful_words.push_back("stimmt's");
	unuseful_words.push_back("hmm");
	unuseful_words.push_back("hm");
	unuseful_words.push_back("hmmm");
	unuseful_words.push_back("hmmmm");
	unuseful_words.push_back("sonst");
	unuseful_words.push_back("ansonsten");
	unuseful_words.push_back("noch");

	unuseful_words.push_back("fast");
	unuseful_words.push_back("bald");
	unuseful_words.push_back("sehr");
	unuseful_words.push_back("na");
	unuseful_words.push_back("bisschen");
	unuseful_words.push_back("bischen");
	unuseful_words.push_back("hald");
	unuseful_words.push_back("halt");
	unuseful_words.push_back("eben");
	unuseful_words.push_back("oder");
	unuseful_words.push_back("und");

	unuseful_words.push_back("of");
	unuseful_words.push_back("from");
	unuseful_words.push_back("by");
	unuseful_words.push_back("between");
	unuseful_words.push_back("what");
	unuseful_words.push_back("when");

	unuseful_words.push_back("ein");
	unuseful_words.push_back("eine");
	unuseful_words.push_back("einer");
	unuseful_words.push_back("eines");
	unuseful_words.push_back("einem");

	unuseful_words.push_back("fr");
	unuseful_words.push_back("für");
	unuseful_words.push_back("fuer");

	for (unsigned int x = 0; x < unuseful_words.size(); x++) {
		string unuseful_word = " " + unuseful_words[x] + " ";

		string better_frage = Util::replace(frage, unuseful_word, string(" "));
//		clogger << better_frage << endl;

		if (jeliza::Sentence(better_frage).get_strip().size() > 0) {
			frage = better_frage;
		}
	}

	return jeliza::Sentence(frage).get_strip();
}

bool is_in (string all, char ch) {
    string::iterator iter = find(all.begin(), all.end(), ch);

    if (iter == all.end()) {
        return false;
    }
    return true;
}

const string vokale("aeiouAEIOU");
const string konsonanten("bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ");
const jeliza::Sentence prefixe("ab an auf aus be bei dar ein er ent ge miss hin nach nieder ueber ber um unter ver vor weg zer zu");

jeliza::Sentence jeliza::entferne_prefixe(jeliza::Sentence s1) {
    jeliza::answers v_prefixe;
    jeliza::Sentence prefixe_tmp(prefixe);
    Util::split(prefixe_tmp, string(" "), v_prefixe);

    for (int x = 0; x < 3; x++) {
        for (int y = 0; y < v_prefixe.size(); y++) {
            if (s1.startswith(v_prefixe[y])) {
                cout << s1.ref() << endl;
                s1.replace_first(v_prefixe[y], "");
                cout << s1.ref() << endl;
            }
        }
    }

    return s1;
}

jeliza::Sentence jeliza::ermittle_wortstamm(jeliza::Sentence s1) {
    jeliza::Sentence stamm;

    jeliza::Sentence orig_s1(s1);
    s1 = jeliza::entferne_prefixe(s1);

    int i = 0;
    if (is_in(konsonanten, s1[0])) {
        while (is_in(konsonanten, s1[i])) {
            stamm.ref() += s1[i];
            i++;
        }
    }
    while (is_in(vokale, s1[i])) {
        stamm.ref() += s1[i];
        i++;
    }
    while ((s1.size() - i > 2 || s1.size() < 4 || s1[i] == s1[i-1]) && is_in(konsonanten, s1[i])) {
        stamm.ref() += s1[i];
        i++;
    }

    cout << "Wortstamm von " << orig_s1.ref() << " ist " << stamm.ref() << "." << endl;

    return stamm;
}

bool jeliza::hat_gleichen_wortstamm(jeliza::Sentence s1, jeliza::Sentence s2, jeliza::Sentence stamm1, jeliza::Sentence stamm2,
        jeliza::Sentence prefixe_entfernt1, jeliza::Sentence prefixe_entfernt2) {
    if (s1 == s2) {
        return true;
    }

    if (s1 == stamm1) {
        return false;
    }
    if (s2 == stamm2) {
        return false;
    }

    int size_s1 = prefixe_entfernt1.size();
    int size_s2 = prefixe_entfernt2.size();

    if (Util::max(size_s1, size_s2) - Util::min(size_s1, size_s2) > 4) {
        return false;
    }

    if (stamm1 == stamm2) {
        return true;
    }

    s1.strip();
    s1.replace("_", " ");

    s2.strip();
    s2.replace("_", " ");

    if (s1.size() < 1 && s2.size() > 0) {
        return false;
    }
    if (s2.size() < 1 && s1.size() > 0) {
        return false;
    }

    if (s1 == s2) {
        return true;
    }

    bool valid_s1 = s1.get_lower() == s1;
    bool valid_s2 = s2.get_lower() == s2;
    if (valid_s1 != valid_s2) {
        return false;
    }

    if (s1.size() > 18) {
        return false;
    }
    if (s2.size() > 18) {
        return false;
    }

    return false;
}
bool jeliza::is_similar(jeliza::Sentence s1, jeliza::Sentence s2) {
    clogger << "is_similar()" << endl;
    if (s1 == s2) {
        return true;
    }

    s1.lower();
    s1.strip();
    s1.replace("_", " ");

    s2.lower();
    s2.strip();
    s2.replace("_", " ");

    if (s1.size() < 1 && s2.size() > 0) {
        return false;
    }
    if (s2.size() < 1 && s1.size() > 0) {
        return false;
    }

    if (s1 == s2) {
        return true;
    }
    if (s1.contains(s2)) {
        return true;
    }
    if (s2.contains(s1)) {
        return true;
    }
    return false;
}

jeliza::Sentence jeliza::JElizaImpl::getGreeting () {
    clogger << "getGreeting()" << endl;
    init();

    jeliza::answers greetings;
    for (jeliza::DB::iterator it = jeliza_db->begin(); it != jeliza_db->end(); it++) {
        if (it->category.contains("greeting")) {
            greetings.push_back(it->genSentences(true)[0]);
        }
    }

    jeliza::Sentence answer;
    if (greetings.size() > 0) {
        srand((unsigned) time(NULL));
        int random = rand() % greetings.size();
        answer = greetings[random];
    }
	return answer;
}

jeliza::Wortart jeliza::bestimmeWortart(jeliza::Sentence word2, bool atBeginningOfSentence, vector<jeliza::answers>& vDic) {
    string word = word2.ref();

    string str;
    string word_low = word2.get_lower().ref();

    string word_substrd = word.substr(0, word.size() - 3);

    jeliza::Sentence stamm_word = ermittle_wortstamm(word2);
    jeliza::Sentence prefixe_entfernt_word = jeliza::entferne_prefixe(word2);

    for (unsigned int x = 0; x < vDic.size(); x++) {
        jeliza::answers& vec = vDic[x];

        jeliza::Sentence& stamm_vec1 = vec[2];
        jeliza::Sentence& prefixe_entfernt = vec[3];

        if (vec.size() == 4) {
            if (jeliza::hat_gleichen_wortstamm(vec[1], jeliza::Sentence(word), stamm_vec1,
                    stamm_word, prefixe_entfernt, prefixe_entfernt_word)) {
                cout << "Word found in DB: " << stamm_word.ref() << " or " << word << " or " << vec[1].ref() << endl;

                if (vec[0] == "verb") {
                    return VERB;
                }
                if (vec[0] == "vt") {
                    return VERB;
                }
                if (vec[0] == "vi") {
                    return VERB;
                }
                if (vec[0] == "n") {
                    return NOMEN;
                }
                if (vec[0] == "f,m") {
                    return NOMEN;
                }
                if (vec[0] == "f,n") {
                    return NOMEN;
                }
                if (vec[0] == "f,n,m") {
                    return NOMEN;
                }
                if (vec[0] == "f,m,n") {
                    return NOMEN;
                }
                if (vec[0] == "m,f") {
                    return NOMEN;
                }
                if (vec[0] == "m,n") {
                    return NOMEN;
                }
                if (vec[0] == "m,f,n") {
                    return NOMEN;
                }
                if (vec[0] == "m,n,f") {
                    return NOMEN;
                }
                if (vec[0] == "m,") {
                    return NOMEN;
                }
                if (vec[0] == "f,") {
                    return NOMEN;
                }
                if (vec[0] == "n,") {
                    return NOMEN;
                }
                if (vec[0] == "n,pl") {
                    return NOMEN;
                }

                if (vec[0] == "adj") {
                    return ADJ;
                }
                if (vec[0] == "adv") {
                    return ADJ;
                }
                if (vec[0] == "pron") {
                    return PP;
                }
                if (vec[0] == "ppron") {
                    return NOMEN;
                }

                break;
            }
        }
    }

    cout << "not found in DB: " << word_substrd << " or " << word << endl;

    // Artikel
    ifstream iArts("wsh/arts.wsh");
    vector<string> vArts;
    while (iArts) {
        iArts >> str;
        vArts.push_back(str);
    }

    if (find(vArts.begin(), vArts.end(), word_low) != vArts.end()) {
        return ART;
    }

    // Pronomen
    ifstream iPP("wsh/pp.wsh");
    vector<string> vPP;
    while (iPP) {
        iPP >> str;
        vPP.push_back(str);
    }

    if (find(vPP.begin(), vPP.end(), word_low) != vPP.end()) {
        return PP;
    }

    // Praepositionen
    ifstream iPreps("wsh/preps.wsh");
    vector<string> vPreps;
    while (iPreps) {
        iPreps >> str;
        vPreps.push_back(str);
    }

    if (find(vPreps.begin(), vPreps.end(), word_low) != vPreps.end()) {
        return PREP;
    }


    // Nomen (1)
    ifstream iNomen("wsh/nomends.wsh");
    vector<string> vNomen;
    while (iNomen) {
        iNomen >> str;
        vNomen.push_back(str);
    }

    if (find(vNomen.begin(), vNomen.end(), word) != vNomen.end()) {
        return NOMEN;
    }

    if (toupper(word[0]) == word[0] && !atBeginningOfSentence) {
        return NOMEN;
    }

    // Adjektiv
    ifstream iAdj("wsh/adj.wsh");
    vector<string> vAdj;
    while (iAdj) {
        iAdj >> str;
        vAdj.push_back(str);
    }

    if (find(vAdj.begin(), vAdj.end(), word_low) != vAdj.end()) {
        return ADJ;
    }

    ifstream iAdjends("wsh/adjends.wsh");
    vector<string> vAdjends;
    while (iAdjends) {
        iAdjends >> str;
        vAdjends.push_back(str);
    }

    for (unsigned int x = 0; x < vAdjends.size(); x++) {
        if (word_low.size() > 4 && jeliza::Sentence(word_low).contains(jeliza::Sentence(vAdjends[x]))) {
            return ADJ;
        }
    }

    // Verb
    /*ifstream iVerbends("wsh/verbends.wsh");
    vector<string> vVerbends;
    while (iVerbends) {
        iVerbends >> str;
        vVerbends.push_back(str);
    }

    for (unsigned int x = 0; x < vVerbends.size(); x++) {
        if (word_low.size() > 4 && jeliza::Sentence(word_low).contains(jeliza::Sentence(vVerbends[x]))) {
            return VERB;
        }
    }*/

    ifstream iVerbs("wsh/verbs.wsh");
    vector<string> vVerbs;
    while (iVerbs) {
        iVerbs >> str;
        vVerbs.push_back(str);
    }

    if (find(vVerbs.begin(), vVerbs.end(), word_low) != vVerbs.end()) {
        return VERB;
    }


    // Nomen (2)
    if (toupper(word[0]) == word[0] && atBeginningOfSentence && word.size() > 3) {
        return NOMEN;
    }

    return 0;
}

jeliza::worddef* next_word_if(vector<jeliza::worddef>& woerter, jeliza::Wortart soll_wa, unsigned int index) {
    for (unsigned int x = index; x < woerter.size(); x++) {
        if (woerter[x].second == soll_wa) {
            return (&woerter[x]);
        }
    }
    return NULL;
}
int next_word_index_if(vector<jeliza::worddef>& woerter, jeliza::Wortart soll_wa, unsigned int index) {
    for (unsigned int x = index; x < woerter.size(); x++) {
        if (woerter[x].second == soll_wa) {
            return x;
        }
    }
    return -1;
}

/*
 * Trennt einen Satz in Subjekt, Verb und Objekt auf
 */
jeliza::answers jeliza::split_spo (jeliza::Sentence s, vector<string> verbs) {
    /*
    clogger << "split_spo" << endl;
	jeliza::answers woerter;
	Util::split(s, " ", woerter);

	if (woerter.size() < 2) {
	    return (jeliza::answers());
	}

//	ifstream in("verbs.txt");

	jeliza::Sentence verb;
	jeliza::Sentence verb2;
	long double bestVerb = 0;
	long double points2 = 0;
	long double points3 = 0;
	StringCompare sc;
	jeliza::answers constructed_verbs(verbs.size());
	for (unsigned int x = 0; x < verbs.size(); x++) {
		jeliza::Sentence buffer(verbs[x]);
		constructed_verbs[x] = buffer;
		if (buffer.size() > 1) {
		    jeliza::Sentence buffer_lower;
		    buffer_lower.set(buffer);
		    buffer_lower.lower();
			points2 = 0;
			points3 = 0;
			jeliza::Sentence tempverb;
			jeliza::Sentence tempverb2;
			for (unsigned int g = 0; g < woerter.size(); g++) {
				jeliza::Sentence wort = woerter[g];
				jeliza::Sentence wort_lower;
				wort_lower.set(wort);
				wort_lower.lower();
				sc.compare(wort.ref(), buffer.ref());
				points2 += sc.getPoints();

				if (sc.getPoints() > bestVerb) {
                    bestVerb = sc.getPoints();
                    verb.set(wort);
                    verb2.set(buffer);

                    if (bestVerb > 75) {
                        break;
                    }
				}
			}
		}
	}

	if (verb.size() < 2) {
	    for (unsigned int g = 0; g < woerter.size(); g++) {
            jeliza::Sentence wort = woerter[g];
            jeliza::Sentence wort_lower;
            wort_lower.set(wort);
            wort_lower.lower();

            jeliza::Wortart wa = jeliza::bestimmeWortart(wort, (g == 0 ? true : false), &constructed_verbs);
            if (wa == jeliza::VERB) {
                verb.set(wort);
                verb2.set(wort);
                break;
            }
	    }
    }

	if (verb.size() > 1 && verb == verb.get_lower()) { // && bestVerb > 40
		jeliza::answers k;
		Util::SplitString(s, verb, k, false);

		if (k.size() < 2) {
		    k.push_back(jeliza::Sentence());
		}

		k[0].strip();
		k[1].strip();
		s.strip();
		verb.strip();
		verb2.strip();

		k[0].replace("  ", " ");
		k[1].replace("  ", " ");
		s.replace("  ", " ");
		verb.replace("  ", " ");

		if (k[0].size() > 1 && k[1].size() > 1) {
		    jeliza::answers ret;
		    ret.push_back(k[0]);
		    ret.push_back(verb);
		    ret.push_back(verb2);
		    ret.push_back(k[1]);
		    return ret;
		}
		else if (k[0].size() > 1) {
		    jeliza::answers ret;
		    ret.push_back(k[0]);
		    ret.push_back(verb);
		    ret.push_back(verb2);
		    ret.push_back(jeliza::Sentence(""));
		    return ret;
		}
		else if (k[1].size() > 1) {
		    jeliza::answers ret;
		    ret.push_back(jeliza::Sentence(""));
		    ret.push_back(verb);
		    ret.push_back(verb2);
		    ret.push_back(k[1]);
		    return ret;
		}
	}
	jeliza::answers ret;
	return ret;
	*/



    string temp = "                                         ";

    {
        jeliza::Sentence satz;
        satz.set(s);

        jeliza::answers words;
        Util::split(satz, " .()/-:,;!?\n\r", words);

        vector<worddef> woerter;

        cout << "Bestimme..." << endl;
        for (unsigned int x = 0; x < words.size(); x++) {
            jeliza::Sentence word = words[x];
            Wortart wa = bestimmeWortart(word, (x == 0 ? true : false), *jeliza::Wortart_Database);
            woerter.push_back(worddef(word, wa));
        }

        for (unsigned int x = 0; x < woerter.size(); x++) {
            Wortart wa = woerter[x].second;
            jeliza::Sentence word = woerter[x].first;

            if (wa == NOMEN) {
            }
            if (wa == VERB) {
                if (((signed) (x))-1 > -1 && x+1 < woerter.size()) {
                    Wortart wa_m1 = woerter[x-1].second;
                    Wortart wa_p1 = woerter[x+1].second;
//                    Wortart wa_p2 = woerter[x+1].second;

//                    if (wa_m1 == ART && (wa_p1 == NOMEN || wa_p1 == ADJ)) {
//                        woerter[x].second = ADJ;
//                    }
                    if (wa_m1 == VERB && (wa_p1 == NOMEN || wa_p1 == ADJ || wa_p1 == PP)) {
                        woerter[x].second = ADJ;
                    }
                }
            }
            if (wa == ADJ) {
            }
            if (wa == PP) {
            }
            if (wa == PREP) {
            }
            if (wa == ART) {
            }
        }

        for (unsigned int x = 0; x < woerter.size(); x++) {
            Wortart wa = woerter[x].second;
            jeliza::Sentence word = woerter[x].first;

            cout << word.ref() << temp.substr(0, temp.size() - word.size());
            if (wa == NOMEN) {
                cout << "Nomen";
            }
            if (wa == VERB) {
                cout << "Verb";
            }
            if (wa == ADJ) {
                cout << "Adjektiv/Adverb";
            }
            if (wa == PP) {
                cout << "Pronomen";
            }
            if (wa == PREP) {
                cout << "Praeposition";
            }
            if (wa == ART) {
                cout << "Artikel";
            }

            cout << endl;
        }
        cout << endl;

        for (unsigned int x = 0; x < woerter.size();) {
            int num = x+1;
            Wortart wa = woerter[x].second;
            jeliza::Sentence word = woerter[x].first;

            if (wa == ART) {
                worddef* searched = next_word_if(woerter, NOMEN, x);
                if (searched == NULL) {
                    cout << "no noun found (wa == ART)" << endl;
                    x++;
                    continue;
                } else {
                    x = next_word_index_if(woerter, NOMEN, x) + 1;

                    cout << " Einheit: " << endl
                         << "----------" << endl;
                    for (unsigned int y = num-1; y < x; y++) {
                        cout << woerter[y].first.ref() << " (";
                        Wortart waa = woerter[y].second;

                        if (waa == NOMEN) {
                            cout << "Nomen";
                        }
                        if (waa == VERB) {
                            cout << "Verb";
                        }
                        if (waa == ADJ) {
                            cout << "Adjektiv";
                        }
                        if (waa == PP) {
                            cout << "Pronomen";
                        }
                        if (waa == PREP) {
                            cout << "Praeposition";
                        }
                        if (waa == ART) {
                            cout << "Artikel";
                        }

                        cout << ")" << endl;
                    }
                    cout << endl;
                    continue;
                }
            }

            x++;
        }
        cout << endl;

        jeliza::Sentence subj;
        jeliza::Sentence prae;
        jeliza::Sentence obj;
        bool sub_war_schon = false;
        for (unsigned int x = 0; x < woerter.size(); x++) {
            jeliza::Sentence word = woerter[x].first;
            Wortart wa = woerter[x].second;

            if (wa == VERB) {
                cout << "Prädikat: " << word.ref() << endl;
                prae += word + " ";
            }
            else if (x < next_word_index_if(woerter, VERB, 0) || !sub_war_schon) {
                cout << "Subjekt:  " << word.ref() << endl;
                if (wa == NOMEN) {
                    sub_war_schon = true;
                }
                subj += word + " ";
            }
            else if ((x > next_word_index_if(woerter, VERB, 0) && subj.get_strip().size() > 2) || sub_war_schon) {
                cout << "Objekt:   " << word.ref() << endl;
                obj += word + " ";
            }
            else {
                cout << "Prädikat: " << word.ref() << endl;
                prae += word + " ";
            }
        }
        subj.strip();
        prae.strip();
        obj.strip();

        cout << endl;

        jeliza::answers ret;
        ret.push_back(subj);
        ret.push_back(prae);
        ret.push_back(prae);
        ret.push_back(obj);
        return ret;
    }
    return jeliza::answers();
}

/*
 * Liest alle Subjekt-Verb bzw. Verb-Objekt Paare ein
 */
void jeliza::JElizaImpl::init () {
    clogger << "init()" << endl;
	clogger << endl << "- Vorbereite..." << endl;
	clogger << "- Lade Datenbank ins RAM... " << endl;

    jeliza_db.reset(jeliza::parseJDB("jeliza-standard.xml"));

	clogger << "- Datenbank erfolgreich geladen!" << endl;
	clogger << "- Vorbereitung abgeschlossen!" << endl << endl;
}

/*
 * Lernt einen Satz, dh. formt ihn um (ich->du) und ruft savejeliza::Sentence() auf
 */
void jeliza::JElizaImpl::learn (jeliza::answers anss) {
    clogger << "learn() (answers)" << endl;
	vector<string> verbs = verbs::getVerbs();
	init();

    for (jeliza::answers::iterator it = anss.begin(); it != anss.end(); it++) {
        if (isQuestion(*it) != 0) {
            continue;
        }

        it->set(Util::umwandlung(*it));

        jeliza::answers temp;
        Util::split(*it, string(" "), temp);

        if (temp.size() < 3) {
            cerr << "- Satz hat zu wenig Woerter (< 10): " << it->ref() << endl;
            return;
        }

        jeliza::DBSentence dbs = jeliza::toDBSentence (*it, verbs);

        jeliza_db->push_back(dbs);
    }
    jeliza::saveDB("jeliza-standard.xml", *jeliza_db);
}
/*
 * Lernt einen Satz, dh. formt ihn um (ich->du) und ruft savejeliza::Sentence() auf
 */
void jeliza::JElizaImpl::learn (jeliza::Sentence fra) {
    clogger << "learn() (Sentence)" << endl;
	jeliza::answers anss;
	anss.push_back(fra);
	learn(anss);
}

PyObject* jelizacpp_update_prozent(PyObject *self, PyObject *args) {
    jeliza::update_prozent();

    return Py_BuildValue("b", true);
}

PyMethodDef jelizacpp_methods[] = {
    {"cpp_toDBSentence",  jelizacpp_toDBSentence, METH_VARARGS, "Converts a sentence to a 'dbsentence'."},
    {"cpp_hat_gleichen_wortstamm",  jelizacpp_hat_gleichen_wortstamm, METH_VARARGS, "Compares the 'Wortstamm' of two words."},
    {"cpp_update_prozent",  jelizacpp_update_prozent, METH_VARARGS, "Updates the procent label in the main window."},
    {"log",  jelizacpp_log, METH_VARARGS, "Replacemen for print which prints the string in the log window, too."},
    {"cpp_www_wikipedia_de",  jelizacpp_search_in_wikipedia_with_newlines, METH_VARARGS, "Searches in Wikipedia."},
//    search_in_wikipedia_with_newlines
    {NULL, NULL, 0, NULL}        /* Sentinel */
};

PyObject* jelizacpp_search_in_wikipedia_with_newlines(PyObject *self, PyObject *args) {
    const char *command;

    if (!PyArg_ParseTuple(args, "s", &command))
        return NULL;

    jeliza::Sentence def = search_in_wikipedia_with_newlines(jeliza::Sentence(command));
    log("Result:" + def.ref());

    return Py_BuildValue("s", def.ref().c_str());
}

PyObject* jelizacpp_toDBSentence(PyObject *self, PyObject *args) {
    const char *command;
    vector<string> verbs = verbs::getVerbs();

    if (!PyArg_ParseTuple(args, "s", &command))
        return NULL;

    jeliza::DBSentence dbs = jeliza::toDBSentence(jeliza::Sentence(string(command)), verbs);

    return Py_BuildValue("(sssssssi)", dbs.subject.get().c_str(), dbs.verb.get().c_str(),
            dbs.object.get().c_str(), dbs.prefix.get().c_str(), dbs.suffix.get().c_str(),
            dbs.feeling.get().c_str(), dbs.category.get().c_str(), dbs.priority);
}

PyObject* jelizacpp_log(PyObject *self, PyObject *args) {
    const char *command;

    if (!PyArg_ParseTuple(args, "s", &command))
        return NULL;

    log(string(command));
    cout << command << endl;

    return Py_BuildValue("s", command);
}

PyObject* jelizacpp_hat_gleichen_wortstamm(PyObject* self, PyObject* args) {
    const char *s1;
    const char *s2;

    if (!PyArg_ParseTuple(args, "ss", &s1, &s2))
        return NULL;

    jeliza::Sentence stamm1 = ermittle_wortstamm(jeliza::Sentence(s1));
    jeliza::Sentence stamm2 = ermittle_wortstamm(jeliza::Sentence(s2));

    jeliza::Sentence prefixe_entfernt1 = jeliza::entferne_prefixe(jeliza::Sentence(s1));
    jeliza::Sentence prefixe_entfernt2 = jeliza::entferne_prefixe(jeliza::Sentence(s2));

    bool hat_gleichen_stamm = jeliza::hat_gleichen_wortstamm(jeliza::Sentence(s1), jeliza::Sentence(s2),
            stamm1, stamm2, prefixe_entfernt1, prefixe_entfernt2);

    return Py_BuildValue("(b)", hat_gleichen_stamm);
}

double aktuelle_prozent = 0;
void prozent_plus(double p) {
    aktuelle_prozent += p;

    ofstream oo("temp/procent");
    oo << aktuelle_prozent;
    oo.close();
    jeliza::update_prozent();
}

void jeliza::generatePythonDBFile() {
    ofstream o2("temp/__init__.py");
    o2 << "import pyjdb" << endl;
    o2.close();


    ofstream o("temp/pyjdb.py");

    o << "from modules.utilities import *" << endl
      << endl
      << "class DBSentence:" << endl
      << "  subject = \"\"" << endl
      << "  verb = \"\"" << endl
      << "  object = \"\"" << endl
      << "  prefix = \"\"" << endl
      << "  suffix = \"\"" << endl
      << "  feeling = \"\"" << endl
      << "  category = \"\"" << endl
      << "  priority = \"\"" << endl
      << "  all_ohne_muell = \"\"" << endl
      << endl
      << "  def copy_tupel(self, tup):" << endl
      << "    self.subject = tup[0].strip()" << endl
      << "    self.verb = tup[1].strip()" << endl
      << "    self.object = tup[2].strip()" << endl
      << "    self.prefix = tup[3].strip()" << endl
      << "    self.suffix = tup[4].strip()" << endl
      << "    self.feeling = tup[5].strip()" << endl
      << "    self.category = tup[6].strip()" << endl
      << "    self.priority = tup[7]" << endl
      << "    self.all_ohne_muell = ohne_muell(self.genSentences(True)[0]).strip()" << endl
      << "  def copy(self, src):" << endl
      << "    self.subject = \"\" + src.subject.strip()" << endl
      << "    self.verb = \"\" + src.verb.strip()" << endl
      << "    self.object = \"\" + src.object.strip()" << endl
      << "    self.prefix = \"\" + src.prefix.strip()" << endl
      << "    self.suffix = \"\" + src.suffix.strip()" << endl
      << "    self.feeling = \"\" + src.feeling.strip()" << endl
      << "    self.category = \"\" + src.category.strip()" << endl
      << "    self.priority = src.priority + 0" << endl
      << "    self.all_ohne_muell = ohne_muell(src.genSentences(True)[0] + \"\").strip()" << endl
      << "  def strip(self):" << endl
      << "    self.subject = self.subject.strip()" << endl
      << "    self.verb = self.verb.strip()" << endl
      << "    self.object = self.object.strip()" << endl
      << "    self.prefix = self.prefix.strip()" << endl
      << "    self.suffix = self.suffix.strip()" << endl
      << "    self.feeling = self.feeling.strip()" << endl
      << "    self.category = self.category.strip()" << endl
      << "    self.all_ohne_muell = self.all_ohne_muell.strip()" << endl
      << endl
      << "  def genSentences(self, withFix):" << endl
      << "    self.strip()" << endl
      << "    ans = []" << endl
//      << "    if len(self.subject) > 2 and len(self.verb) > 2 and len(self.object) > 1:" << endl
//      << "      ans.append(self.subject + ' ' + self.verb + ' ' + self.object)" << endl
//      << "    elif withFix:" << endl
      << "    ans.append(self.prefix + ' ' + self.subject + ' ' + self.verb + ' ' + self.object + ' ' + self.suffix)" << endl
      << "    temp = self.prefix + ' ' + self.subject + ' ' + self.verb + ' ' + self.object" << endl
      << "    temp = temp.strip()" << endl
      << "    if len(temp) > 1:" << endl
      << "      ans.append(temp)" << endl
      << "    temp = self.subject + ' ' + self.verb + ' ' + self.object + ' ' + self.suffix" << endl
      << "    temp = temp.strip()" << endl
      << "    if len(temp) > 1:" << endl
      << "      ans.append(temp)" << endl
      << "    ans.append((self.prefix + ' ' + self.subject + ' ' + self.verb + ' ' + self.object + ' ' + self.suffix).strip())" << endl
      << "    return ans" << endl
      << endl;

    o << "db = []" << endl;

    int x = 0;
    for (jeliza::DB::iterator it = jeliza_db->begin(); it != jeliza_db->end(); it++) {
        it->strip();
        o << endl
          << "tempdbsent" << x << " = DBSentence()" << endl
          << "tempdbsent" << x << ".subject        = '" << it->subject.replace(string("'"), string("\"")).ref() << "'" << endl
          << "tempdbsent" << x << ".verb           = '" << it->verb.replace(string("'"), string("\"")).ref() << "'" << endl
          << "tempdbsent" << x << ".object         = '" << it->object.replace(string("'"), string("\"")).ref() << "'" << endl
          << "tempdbsent" << x << ".prefix         = '" << it->prefix.replace(string("'"), string("\"")).ref() << "'" << endl
          << "tempdbsent" << x << ".suffix         = '" << it->suffix.replace(string("'"), string("\"")).ref() << "'" << endl
          << "tempdbsent" << x << ".feeling        = '" << it->feeling.replace(string("'"), string("\"")).ref() << "'" << endl
          << "tempdbsent" << x << ".category       = '" << it->category.replace(string("'"), string("\"")).ref() << "'" << endl
          << "tempdbsent" << x << ".priority       = " << it->priority << "" << endl
          << "tempdbsent" << x << ".all_ohne_muell = '" << jeliza::ohne_muell(it->genSentences_all(true)[0]).replace(string("'"), string("\"")).ref() << "'" << endl
          << "db.append(tempdbsent" << x << ")" << endl
          << endl;
        x++;
    }


    o << endl;

    o << endl << endl;

//    jeliza_db
}

jeliza::Sentence use_module(jeliza::Sentence frage, string module) {
    prozent_plus(1);
    jeliza::Sentence orig_fra = frage;
    frage.set(Util::umwandlung(frage));

    log("Bitte warten... Untersuche Modul...");
    jeliza::Sentence module_zusammenfassung;
    module_zusammenfassung += "+----------------------------------------------+\n";
    module_zusammenfassung += "| JEliza Module activated                      |\n";
    module_zusammenfassung += "+----------------------------------------------+\n";
    ifstream i2(("modules/" + module + ".py").c_str());
    string temp =             "                        ";
    int may_be_incompatible = true;
    string author = "JEliza Team";
    int b = 0;
    while (i2 && b < 30) {
        b++;
        jeliza::Sentence x;
        getline(i2, x.ref());
        if (x.contains("#-> ")) {
            x.replace("#-> ", "");
            jeliza::answers pai;
            Util::split(x, string(":"), pai);
            if (pai.size() == 2) {
                module_zusammenfassung += pai[0] + ":" + temp.substr(0, temp.size() - pai[0].size()) + pai[1] + "\n";
                if (pai[0].get_strip().contains("ompatibl")) {
                    stringstream sst;
                    double cv;
                    sst << pai[1].ref();
                    sst >> cv;
                    if (cv == JELIZA_DEC_VERSION) {
                        may_be_incompatible = false;
                    }
                }
                if (pai[0].get_strip().contains("autho")) {
                    author = pai[1].get_strip().ref();
                }
            } else {
                cout << endl
                     << "Invalid Module!" << endl
                     << "Line: " << "#-> " << x.ref() << endl;
            }
        }
    }
    i2.close();

    prozent_plus(1);
    ofstream o("temp/answer.tmp");
    o << "Mein Gehirn funktioniert nicht richtig. Es ist ein Fehler im Modul '" << module << "' aufgetreten. "
      << "Bitte kontaktieren Sie meine Programmierer, in dem Sie eine Mail an jeliza@gmx.net schicken oder "
      << "unter http://das-kiforum.de.vu/ ein neues Thema erstellen. Bitte senden sie auch folgenden Fehlerbericht mit:\n\n";
    o << "There is a fatal bug in module " << module << " (jeliza version " << JELIZA_DEC_VERSION << " or " << JELIZA_FULL_VERSION << ")!" << endl;
    o << module_zusammenfassung.ref() << endl;
    o.close();

    jeliza::Sentence ans;

    log("Bitte warten... Konfiguriere Modul...");
    clogger << endl << module_zusammenfassung.ref() << ":: Modul '" << module << "' gestartet !!" << endl;
    log("\n");
    log(module_zusammenfassung.ref());
    log(":: Modul '" + module + "' gestartet !!");
//    system(CLEAR_CMD);
    cout << "\033[2J\033[0;0H\033[0H";
    cout << module_zusammenfassung.ref() << endl;
    cout << ":: Modul '" + module + "' gestartet !!" << endl
         << endl
         << endl;

    string line;

    ifstream i3(("modules/" + module + ".py").c_str());
    ofstream o3(("modules/" + module + "_tmp.py").c_str());
    o3 << "# -*- coding: utf-8 -*-" << endl;
    o3 << "import sys" << endl;
    o3 << "print sys.path" << endl;
    o3 << "sys.path = [ \"./\", \"./jelizapy/Lib/\", \"./jelizapy/lib-dynload\"]" << endl;
    o3 << "print sys.path" << endl;
    o3 << "import sys" << endl;
    ifstream i4("temp/pyjdb.py");
    while (i4) {
        getline(i4, line);
        o3 << line << endl;
    }
    o3 << "JELIZA_QUESTION = '" << frage.replace(string("'"), string("\"")).ref() << "'" << endl;
    o3 << "JELIZA_QUESTION_CLEAN = '" << jeliza::ohne_muell(frage).replace(string("'"), string("\"")).ref() << "'" << endl;
    o3 << "JELIZA_QUESTION_ORIGINAL = '" << orig_fra.replace(string("'"), string("\"")).ref() << "'" << endl;
    o3 << "JELIZA_QUESTION_CLEAN_ORIGINAL = '" << jeliza::ohne_muell(orig_fra).replace(string("'"), string("\"")).ref() << "'" << endl;
//    o3 << "from temp.pyjdb import *" << endl;
    o3 << "from modules.utilities import *" << endl;
    o3 << "from jelizacpp import *" << endl;
    o3 << "apply_procent(0.0)" << endl;
    o3 << endl;
    while (i3) {
        getline(i3, line);
        o3 << line << endl;
    }
    o3.close();
    i3.close();

    prozent_plus(1);
    log("Bitte warten... Starte Modul...");
    if (may_be_incompatible) {
        cout << "Das Modul '" << module << "' ist leider nicht kompatibel zu dieser Version von JEliza!" << endl;
        clogger << "Das Modul '" << module << "' ist leider nicht kompatibel zu dieser Version von JEliza!" << endl;
        log("Das Modul '" + module + "' ist leider nicht kompatibel zu dieser Version von JEliza!");

        ofstream o("temp/answer.tmp");
        o << "Das Modul " << module << "ist leider nicht kompatibel zu meiner Version. ";
        o << "Bitte melden Sie sich bei \"" << author << "\" und/oder bei per Mail bei <jeliza@gmx.net>.";
        o << "Bitte senden sie auch folgenden Fehlerbericht mit:\n\n";
        o << "Module " << module << " is incompatibel to jeliza version " << JELIZA_DEC_VERSION << " or " << JELIZA_FULL_VERSION << "!" << endl;
        o << module_zusammenfassung.ref() << endl;
        o.close();

    }
    else {
//        FILE* fp = fopen(("modules/" + module + ".ptmp").c_str(),"r");
//        PyRun_SimpleFile(fp, ("modules/" + module + ".ptmp").c_str());
        PyRun_SimpleString(("execfile(\"" + ("modules/" + module + "_tmp.py") + "\")").c_str());
    }

    ifstream i("temp/answer.tmp");
    while (i) {
        string ss;
        getline (i, ss);
        ans += ss;
        ans += "\n";
    }
    ans.strip();



    return ans;
}

/*
 * Antwortet auf eine Frage
 */
jeliza::Sentence jeliza::JElizaImpl::ask(jeliza::Sentence frage) {
    aktuelle_prozent = 0;
	clogger << "- Suche eine passende Antwort: " << endl;
    prozent_plus(1);

    log("Bitte warten... Konfiguriere Modul... Konfiguriere Datenbank");
    jeliza::generatePythonDBFile();

    prozent_plus(1);

    jeliza::Sentence ans;

    log("Bitte warten... Initialisiere Modul...");

	if (ans.size() < 2) {
        ans = use_module(frage, "logical");
	}

    prozent_plus(2);
    log("Bitte warten... Initialisiere Modul...");

	if (ans.size() < 2) {
	    ans = use_module(frage, "similar");
	}

//    Py_Finalize();

/*    // Modul Empty
    ModQues_Empty mod_empty(*this, &(*jeliza_db));
    ans.set(mod_empty.get(frage));
    if (ans.ref().size() > 0) {
        return ans;
    }


    // Modul Logical
    ModQues_Logical mod_logical(*this, &(*jeliza_db));
    ans.set(mod_logical.get(frage, orig_fra));
    if (ans.ref().size() > 0) {
        return ans;
    }

    //init();

    // Modul Similar
    ModQues_Similar mod_similar(*this, &(*jeliza_db));
    ans.set(mod_similar.get(frage));*/





    return (ans);
}




#endif
