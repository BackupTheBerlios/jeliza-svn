#ifndef JELIZA_SENTENCE
#define JELIZA_SENTENCE 1

/*
 * This is part of jeliza::JEliza 2.0.
 * Copyright 2006 by Tobias Schulz
 * WWW: http://jeliza.ch.to/
 *
 * JEliza is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later
 * version.
 *
 * JEliza is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU GPL
 * along with JEliza (file "gpl.txt") ; if not, write
 * to the Free Software Foundation, Inc., 51 Franklin St,
 * Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include "defs.h"

using namespace std;


string jeliza::Sentence::get() {
    return *m_sent;
}

string jeliza::Sentence::get() const {
    return *m_sent;
}

string& jeliza::Sentence::ref() {
    return *m_sent;
}

string jeliza::Sentence::ref() const {
    return *m_sent;
}

jeliza::Sentence& jeliza::Sentence::set(const string& str) {
    m_sent.reset(new string(str.c_str()));
    return (*this);
}
jeliza::Sentence& jeliza::Sentence::set(const Sentence& str) {
    m_sent.reset(new string(str.get().c_str()));
    return (*this);
}
jeliza::Sentence& jeliza::Sentence::set(const char* str) {
    m_sent.reset(new string(str));
    return (*this);
}

unsigned int jeliza::Sentence::size() {
    return (m_sent->size());
}

unsigned int jeliza::Sentence::length() {
    return (size());
}

int jeliza::Sentence::find(string s) {
    return (ref().find(s));
}
int jeliza::Sentence::find(const char s) {
    return (ref().find(s));
}
jeliza::Sentence jeliza::Sentence::substr(int x, int y) {
    Sentence ret = *this;
    ret.ref() = ret.ref().substr(x, y);
    return ret;
}

char& jeliza::Sentence::operator[] (int index) {
    if (index < 0) {
        index = ref().size() - index;
    }
    return (ref()[index]);
}

void jeliza::Sentence::lower() {
    for (string::size_type x = 0; x < ref().size(); x++) {
		ref()[x] = tolower(ref()[x]);
	}
}
void jeliza::Sentence::upper() {
    for (string::size_type x = 0; x < ref().size(); x++) {
		ref()[x] = toupper(ref()[x]);
	}
}

jeliza::Sentence jeliza::Sentence::get_lower() {
    jeliza::Sentence ret = *this;
    ret.lower();
    return (ret);
}
jeliza::Sentence jeliza::Sentence::get_upper() {
    jeliza::Sentence ret = *this;
    ret.upper();
    return (ret);
}

jeliza::Sentence jeliza::Sentence::get_strip() {
    jeliza::Sentence ret = *this;
    ret.strip();
    return (ret);
}

jeliza::Sentence jeliza::Sentence::replace(const jeliza::Sentence rep, const jeliza::Sentence wit) {
	int pos;
	while (true) {
		pos = ref().find(rep.get());
		if (pos == -1) {
			break;
		} else {
			ref().erase(pos, rep.get().size());
			ref().insert(pos, wit.get());
		}
	}
	return (*this);
}
jeliza::Sentence jeliza::Sentence::replace(const jeliza::Sentence rep, const string wit) {
    return (replace (rep, jeliza::Sentence(wit)));
}
jeliza::Sentence jeliza::Sentence::replace(const string rep, const string wit) {
    return (replace (jeliza::Sentence(rep), jeliza::Sentence(wit)));
}
jeliza::Sentence jeliza::Sentence::replace_nocase(const jeliza::Sentence rep, const jeliza::Sentence wit) {
	int pos;
	while (true) {
	    jeliza::Sentence low;
        (low.set(get())).lower();
		pos = low.find(rep.get());
		if (pos == -1) {
			break;
		} else {
			ref().erase(pos, rep.get().size());
			ref().insert(pos, wit.get());
		}
	}
	return (*this);
}
jeliza::Sentence jeliza::Sentence::replace_first(const jeliza::Sentence rep, const jeliza::Sentence wit) {
	int pos;
    pos = ref().find(rep.get());
    if (pos != -1) {
        ref().erase(pos, rep.get().size());
        ref().insert(pos, wit.get());
	}
	return (*this);
}
jeliza::Sentence jeliza::Sentence::replace_first(const jeliza::Sentence rep, const string wit) {
    return (replace_first (rep, jeliza::Sentence(wit)));
}
jeliza::Sentence jeliza::Sentence::replace_first(const string rep, const string wit) {
    return (replace_first (jeliza::Sentence(rep), jeliza::Sentence(wit)));
}
bool jeliza::Sentence::contains (const jeliza::Sentence rep) {
    int pos = ref().find(rep.get());
    if (pos == -1) {
		return 0;
	}
	return 1;
}
bool jeliza::Sentence::contains (const char* rep) {
    int pos = ref().find(string(rep));
    if (pos == -1) {
		return 0;
	}
	return 1;
}

bool jeliza::Sentence::startswith (const jeliza::Sentence rep) {
    int pos = ref().find(rep.get());
    if (pos == 0) {
		return true;
	}
	return false;
}
bool jeliza::Sentence::startswith (const char* rep) {
    int pos = ref().find(string(rep));
    if (pos == 0) {
		return true;
	}
	return false;
}
void jeliza::Sentence::strip() {
    for (int y = 0; y < 2; y++) {
        if (m_sent->length()) {
            while (m_sent->length() > 0) {
                if ((*m_sent)[0] != ' ' && (*m_sent)[0] != '\n' && (*m_sent)[0] != '\r') {
                    break;
                }
                m_sent->erase(0, 1);
            }

            /*const string temp = *m_sent;
            for (int x = temp.size() - 1; x >= 0; x--) {
                (*m_sent)[temp.size()-1-x] = temp[x];
            }*/

            reverse(m_sent->begin(), m_sent->end());
        }
    }
}

jeliza::Sentence jeliza::Sentence::toASCII() {
    Sentence ret = *this;
    string& all = ret.ref();

    all = Util::replace(all, "Ã¼", "ue");
	all = Util::replace(all, "Ã", "ss");
	all = Util::replace(all, "Ã¤", "ae");
	all = Util::replace(all, "ü", "ue");
	all = Util::replace(all, "ß", "ss");
	all = Util::replace(all, "ä", "ae");
	all = Util::replace(all, "ö", "oe");
	all = Util::replace(all, "Ü", "Ue");
	all = Util::replace(all, "Ä", "Ae");
	all = Util::replace(all, "Ö", "Oe");
	all = Util::replace(all, "Ã¢ÂÂ", "\"");
	all = Util::replace(all, "Ã¢ÂÂ", "\"");
	all = Util::replace(all, "&lt;/br&gt;", " ");

	string ascii(" \n\r!\"#$%&'()*+,-./0123456789:;<=>?    @ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_    `abcdefghijklmnopqrstuvwxyz{|}~");

	string allAscii = "";
	for (int x = 0; x < all.size(); x++) {
		char array[2];
		array[0] = all[x];
		array[1] = '\0';
		string y(array);
		if (Util::contains(ascii, y)) {
			allAscii += y;
		}
	}
    ret.set(allAscii);

	return (ret);
}

jeliza::Sentence& operator+ (jeliza::Sentence s1, jeliza::Sentence s2) {
    (*s1.m_sent) += s2.ref();
    return s1;
}
jeliza::Sentence& operator+ (jeliza::Sentence s1, string s2) {
    (*s1.m_sent) += s2;
    return s1;
}
jeliza::Sentence& operator+ (jeliza::Sentence s1, const char* s2) {
    (*s1.m_sent) += s2;
    return s1;
}
jeliza::Sentence operator+ (string s2, jeliza::Sentence s1) {
    jeliza::Sentence temp(s2);
    temp += s1;
    return temp;
}
jeliza::Sentence& operator+ (const char* s2, jeliza::Sentence s1) {
    (*s1.m_sent) = string(s2) + (*s1.m_sent);
    return s1;
}


jeliza::Sentence& operator+= (jeliza::Sentence& s1, const jeliza::Sentence s2) {
    (*s1.m_sent) += (*s2.m_sent);
    return s1;
}
jeliza::Sentence& operator+= (jeliza::Sentence& s1, string s2) {
    (*s1.m_sent) += s2;
    return s1;
}
jeliza::Sentence& operator+= (jeliza::Sentence& s1, const char* s2) {
    (*s1.m_sent) += s2;
    return s1;
}

/*jeliza::Sentence& jeliza::Sentence::operator= (string sent) {
    set (sent);
    return (*this);
}*/
/*jeliza::Sentence& jeliza::Sentence::operator= (const char* sent) {
    set (string(sent));
    return (*this);
}*/
jeliza::Sentence& jeliza::Sentence::operator= (const jeliza::Sentence& sent) {
    set (sent);
    return (*this);
}

bool jeliza::Sentence::operator== (jeliza::Sentence s2) {
    return (equal(s2));
}
bool jeliza::Sentence::operator== (string s2) {
    return (equal(s2));
}
bool jeliza::Sentence::operator== (const char* s2) {
    return (equal(s2));
}

bool jeliza::Sentence::equal (Sentence s2) {
    return ((*m_sent) == s2.ref());
}
bool jeliza::Sentence::equal (string s2) {
    return ((*m_sent) == s2);
}
bool jeliza::Sentence::equal (const char* s2) {
    return ((*m_sent) == string(s2));
}


jeliza::answers& operator<< (jeliza::answers& a1, const jeliza::answers& a2) {
    for (int x = 0; x < a2.size(); x++) {
        a1.push_back(a2[x]);
    }
    return a1;
}
jeliza::answers& operator<< (jeliza::answers& a1, int*) {
    a1.erase(a1.begin(), a1.end());
    return a1;
}




#endif
