#ifndef __TREE_
#define __TREE_

#include <vector>
#include <iostream>
#include <fstream>
using namespace std;
#include "Defs.h"



class Tree {
public:
    Tree();
    void free();

    ~Tree() {
        free();
#ifdef TREE_MAINTAINS_COUNTER
        delete numberOfPointersToMe; numberOfPointersToMe = NULL;
#endif
    }

    Tree *add_symbol( BYTE2 symbol );
    void add_child(Tree *node, BYTE2 position);
    Tree *find_symbol( BYTE2 findit ) const;
    Tree *find_symbol_add( BYTE2 findit );
    BYTE2 search_node( BYTE2 findit, bool *found_symbol ) const;
    void load_tree( istream &in );
    void save_tree( ostream &out ) const;
    void print_tree( ostream &out ) const;

    inline BYTE2 symbol() const { return mySymbol; }
    inline BYTE4 usage() const { return myUsage; }
    inline BYTE2 count() const { return myCount; }
    inline BYTE2 branch() const { return myBranch; }
    inline Tree *child( BYTE2 pos ) const { return( pos < myBranch ? myChildren[pos] : NULL );  }

#ifdef TREE_MAINTAINS_COUNTER
public:

    BYTE4 *numberOfPointersToMe;
#endif



private:


BYTE2 mySymbol;


BYTE4 myUsage;


BYTE2 myCount;


BYTE2 myBranch;
vector< Tree* > myChildren;

};

#endif
