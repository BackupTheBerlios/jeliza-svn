#include "Dictionary.h"


const string Dictionary::errorString("<ERROR>");



Dictionary::Dictionary() {
	mySize = 0;
	myWords.resize(0,"");
	myIndex.resize(0,0);
	myIndexed = true;
	numberOfPointersToMe = new BYTE4(0);
}



Dictionary::Dictionary( const string &inphrase ) {
	mySize = 0;
	myWords.resize(0,"");
	myIndex.resize(0,0);
	myIndexed = true;
	numberOfPointersToMe = new BYTE4(0);
	size_t offset = 0;
	string phrase( inphrase );
	/*
	 *		If the string is empty then do nothing, for it contains no words.
	 */
	if( phrase.size() == 0 ) { return; }

	/*
	 *		Loop forever.
	 */
	while( true ) {
		/*
		 *		If the current character is of the same type as the previous
		 *		character, then include it in the word.  Otherwise, terminate
		 *		the current word.
		 */
		if( Funcs::boundary(phrase, offset) ) {
			/*
			 *		Add the word to the dictionary
			 */
			push_word( phrase.substr(0,offset) );

			if( offset == phrase.size() ) { break; }
			phrase = phrase.substr( offset, phrase.size() - offset );
			offset = 0;
		} else {
			++offset;
		}
	}

	/*
	 *		If the last word isn't punctuation, then add punctuation.
	 */
	if(isalnum(myWords[mySize-1][0])) {
		push_word(".");
	}
	else if( phrase.find_first_of( "!?.", 0 ) == basic_string<char>::npos ) {
		myWords[mySize-1] = ".";
	}

   return;
}


Dictionary &Dictionary::operator=( const Dictionary &other ) {
	myWords.resize( 0 );
	mySize = 0;
	myIndexed = true;
	for( BYTE2 i = 0; i < other.mySize; ++i ) {
		add_word( other.myWords[i] );
	}
	return *this;
}



void Dictionary::free() {
	myWords.resize( 0 );
	mySize = 0;
	myIndexed = true;
}



BYTE2 Dictionary::push_word( const string &newWord ) {
	if( myIndexed && mySize == 2 ) {
		mySize = 0;
		myWords.resize( 0 );
		myIndex.resize( 0 );
	}
	myIndexed = false;
	myWords.push_back( newWord );
	Funcs::upper( myWords[mySize]);
	myIndex.push_back( 0 );
	++mySize;
	return( mySize - 1 );
}



BYTE2 Dictionary::insert_word( BYTE2 pos, const string &newWord ) {
	if( myIndexed && mySize == 2 ) {
		mySize = 0;
		myWords.resize( 0 );
		myIndex.resize( 0 );
	}
	myIndexed = false;
	pos = pos < mySize ? pos : mySize;
	myWords.insert( myWords.begin() + pos, newWord );
	Funcs::upper( myWords[pos]);
	myIndex.push_back( 0 );
	++mySize;
	return( pos );
}




BYTE2 Dictionary::add_word( const string &newWord ) {
	if( myIndexed == false ) { return( push_word( newWord ) ); }

	BYTE2 position;
	bool found;
	/*
	 *		If the word's already in the dictionary, there is no need to add it
	 */
	position = search( newWord, &found );
	if( found==true ) { return( myIndex[position] ); }
	/*
	 *		Increase the number of words in the dictionary
	 */
	myWords.push_back( newWord );
	Funcs::upper( myWords[mySize] );
	myIndex.insert( myIndex.begin() + position, mySize );
	++mySize;
	return( myIndex[position] );
}







BYTE2 Dictionary::search( const string &thisWord, bool *find) const {
	if( myIndexed == false ) { return( unindexed_search( thisWord, find ) ); }
	*find = false;
	BYTE2 min;
	BYTE2 max;
	BYTE2 middle;
	int compar;
	/*
	 *		If the dictionary is empty, then obviously the word won't be found
	 */
	if( mySize == 0 ) {
		return( 0 );
	}
	/*
	 *		Initialize the lower and upper bounds of the search
	 */
	min = 0;
	max = mySize - 1;
	/*
	 *		Search repeatedly, halving the search space each time, until either
	 *		the entry is found, or the search space becomes empty
	 */
	while( true ) {
		/*
		 *		See whether the middle element of the search space is greater
		 *		than, equal to, or less than the element being searched for.
		 */
		middle = ( min + max ) / 2;
		compar = Funcs::wordcmp( thisWord, myWords[myIndex[middle]] );
		
		

		/*
		 *		If it is equal then we have found the element.  Otherwise we
		 *		can halve the search space accordingly.
		 */
		if( compar == 0 ) {
			*find = true;
			return( middle );
		}
		else if( compar > 0 ) {
			if( max == middle ) {
				return( middle + 1 );
			}
			min = middle + 1;
		} else {
			if( min == middle ) {
				return( middle );
			}
			max = middle - 1;
		}
	}
}


/*
 *		Function:	Find_Word
 *
 *		Purpose:		Return the symbol corresponding to the word specified.
 *						We assume that the word with index zero is equal to a
 *						NULL word, indicating an error condition.
 */
BYTE2 Dictionary::find_word( const string &thisWord ) const {
	BYTE2 position;
	bool found;
	position = search( thisWord, &found );
	return( found == true ? myIndex[position] : 0 );
}


bool Dictionary::word_exists( const string &thisWord ) const {
	bool found;
	search( thisWord, &found );
	return found;
}



BYTE2 Dictionary::unindexed_search( const string &thisWord, bool *find ) const {
	if( myIndexed == true ) { return( search( thisWord, find ) ); }
	*find = false;
	for( BYTE2 i = 0; i < mySize; ++i ) {
		if( Funcs::wordcmp( myWords[i], thisWord ) == 0 ) {
			*find = true;
			return( i );
		}
	}
	return( 0 );
}


/*
 *		Function:	similar
 *
 *		Purpose:		Return TRUE or FALSE depending on whether the dictionaries
 *						are the same or not.
 */
bool Dictionary::similar( const Dictionary &other ) const {
	if( mySize != other.mySize ) return(false);
	for( BYTE2 i = 0; i < mySize; ++i ) {
		if( Funcs::wordcmp( myWords[i], other.myWords[i] ) != 0 ) {
			return(false);
		}
	}
	return(true);
}


/*
 *		Function:	Make_Output
 *
 *		Purpose:		Generate a string from the dictionary of reply words.
 */
string Dictionary::make_output() const {
	string output;
	if( mySize == 0 ) {
		output = "I am utterly speechless!";
		return(output);
	}
	for( BYTE2 i = 0; i < mySize; ++i ) {
		output.append( myWords[i] );
	}
	return(output);
}


/*
 *		Function:	Save_Dictionary
 *
 *		Purpose:		Save a dictionary to the specified file.
 */
void Dictionary::save_dictionary( ostream &out ) const {
	BYTE4 saveSize = (BYTE4)mySize;
	BYTE1 myWordSize;
	out.write( (char*)&saveSize, sizeof( BYTE4 ) );
	for( BYTE2 i = 0; i < mySize; ++i ) {
		myWordSize = (BYTE1)myWords[i].size();
		out.write( (char*)&(myWordSize), sizeof( BYTE1 ) );
		out << myWords[i];
	}
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	Load_Dictionary
 *
 *		Purpose:		Load a dictionary from the specified file.
 */
void Dictionary::load_dictionary( istream &in ) {
	free();
	BYTE4 newSize;
	BYTE1 newWordSize;
	char tc[2048];
	string bufstr;
	in.read( (char*)&newSize,  sizeof( BYTE4 ) );
	for( BYTE2 i = 0; i < newSize; ++i ) {
		in.read( (char*)&(newWordSize), sizeof( BYTE1 ) );
		in.read( tc, sizeof( char ) * newWordSize );
		tc[newWordSize] = '\0';
		bufstr = tc;
		add_word( bufstr );
	}
}


/*
 *		Function:	Initialize_List
 *
 *		Purpose:		Read a dictionary from a file.
 */
int Dictionary::initialize_list( const string &fileName ) {
	ifstream infile;
	char buffer[2048]; 
	string bufstr;
	BYTE2 pos;
	infile.open(fileName.c_str(), ios::in);
	if( ! infile ) {
		return( 1 );	
	}
	while( infile.getline( buffer, 4096 ) ) {
		if( buffer[0] == '#' ) { continue; }
		bufstr = buffer;
		pos = (BYTE2)bufstr.find_first_of( "\t #\n", 0 );
		bufstr = bufstr.substr( 0, pos );
		add_word( bufstr );
	}
	infile.close();
	return( 0 );
}


/*
 *		Function:	Show_Dictionary
 *
 *		Purpose:		Display the dictionary for training purposes.
 */
int Dictionary::show_dictionary( const string &filename ) const {
	ofstream outfile;
	outfile.open(filename.c_str(), ios::out);
	if( ! outfile ) {
		return( 1 );	
	}
	for( BYTE2 i = 0; i < mySize; ++i ) {
		outfile << i << ":" << myWords[i] << "\t\t:" << myIndex[i] << endl;
	}
	outfile.close();
	return( 0 );
}


void Dictionary::print_dictionary() const {
	cout << "\n\n/";
	for( BYTE2 i = 0; i < mySize; ++i ) {
		cout << myWords[i] << "/";
	}
	cout << "\n";
}
