#ifndef __SWAP_
#define __SWAP_

#include <string>
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
#include "Defs.h"

class Swap {

public:
	Swap();

	~Swap() { delete numberOfPointersToMe; numberOfPointersToMe = NULL; };

	void add_swap( const string &newFrom, const string &newTo );

	int initialize_swap( const string &fileName );

	void print_swap();

	BYTE2 size() const { return( mySize ); };

	const string &from( BYTE2 pos ) const { return( pos < mySize ? myFrom[pos] : Swap::errorString ); };

	const string &to( BYTE2 pos ) const { return( pos < mySize ? myTo[pos] : Swap::errorString ); };


public:

BYTE4 *numberOfPointersToMe;

protected:


	BYTE2 mySize;


	static const string errorString;


	vector<string> myFrom;


	vector<string> myTo;

};

#endif
