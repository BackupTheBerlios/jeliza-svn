#ifdef WIN32
	#pragma once
	#define WIN32_LEAN_AND_MEAN		
	#include <stdio.h>
	#include <tchar.h>
#else
	#include <stdio.h>
#endif

#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include "Defs.h"
#include "Swap.h"
#include "Tree.h"
#include "Dictionary.h"
#include "Model.h"
#include "Console.h"




/*===========================================================================*/
