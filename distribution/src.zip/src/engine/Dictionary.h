#ifndef __DICTIONARY_
#define __DICTIONARY_

#include <vector>
#include <iostream>
#include <fstream>
using namespace std;
#include "Defs.h"
#include "Funcs.h"

class Dictionary {


public:

	
	
	
	
	
	
	
	Dictionary();

	
	
	
	
	
	
	
	Dictionary( const Dictionary &other )
			{ numberOfPointersToMe = new BYTE4(0); operator=( other ); };

	
	
	
	
	
	
	
	
	Dictionary( const string &phrase );

	~Dictionary() { delete numberOfPointersToMe; numberOfPointersToMe = NULL; };

	
	
	
	
	
	
	
	void free();

	
	
	
	
	
	
	
	
	BYTE2 push_word( const string &newWord );

	
	
	
	
	
	
	
	
	BYTE2 insert_word( BYTE2 pos, const string &newWord );

	
	
	
	
	
	
	
	
	
	BYTE2 add_word( const string &newWord );

	
	
	
	
	
	
	
	Dictionary &operator=( const Dictionary &other );

	
	
	
	
	
	
	
	inline bool dissimilar( const Dictionary &other ) const { return( ! similar(other) ); };

	
	
	
	
	
	
	
	bool similar( const Dictionary &other ) const;

	
	
	
	
	
	
	
	
	
	
	
	BYTE2 find_word( const string &thisWord ) const;

	
	
	
	
	
	
	
	bool word_exists( const string &thisWord ) const;

	
	
	
	
	
	
	
	
	
	BYTE2 unindexed_search( const string &thisWord, bool *find ) const;

	
	
	
	
	
	
	
	
	
	BYTE2 search( const string &thisWord, bool *foundit ) const;

	
	
	
	
	
	
	
	string make_output() const;

	
	
	
	
	
	
	
	int show_dictionary( const string &fileName ) const;

	
	
	
	
	
	
	
	void print_dictionary() const;

	
	
	
	
	
	
	
	void save_dictionary( ostream &out ) const;

	
	
	
	
	
	
	
	void load_dictionary( istream &in );

	
	
	
	
	
	
	
	
	int initialize_list( const string &fileName );

	
	
	
	
	
	
	
	inline BYTE2 size() const { return( mySize ); };
	inline const string &operator[]( BYTE2 pos ) const { return( pos < mySize ? myWords[pos] : Dictionary::errorString ); };
	inline const string &entry( BYTE2 pos ) const { return( this->operator[](pos) ); };
	inline const string &atIndex( BYTE2 pos ) const { return( pos < mySize ? myWords[myIndex[pos]] : Dictionary::errorString ); };


public:
	
BYTE4 *numberOfPointersToMe;

private:

	
	
	bool myIndexed;

	
	BYTE2 mySize;

	
	const static string errorString;

	
	vector<string> myWords;

	
	vector<BYTE2> myIndex;

}; 

#endif
