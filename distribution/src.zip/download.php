<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de" dir="ltr">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="robots" content="noindex,nofollow" />
		<meta name="keywords" content="Leipzig,Leipzig,Leipzig,Lizenzbestimmungen,Quellenangaben,Urheberrechte beachten,Leipzig,Liste der IPA-Zeichen,Sonderzeichen" />
		<link rel="shortcut icon" href="/favicon.ico" />
		<link rel="search" type="application/opensearchdescription+xml" href="/w/opensearch_desc.php" title="Wikipedia (Deutsch)" />
		<link rel="copyright" href="http://www.gnu.org/copyleft/fdl.html" />
		<title>Bearbeiten von Leipzig - Wikipedia</title>
		<style type="text/css" media="screen,projection">/*<![CDATA[*/ @import "/skins-1.5/monobook/main.css?61"; /*]]>*/</style>
		<link rel="stylesheet" type="text/css" media="print" href="/skins-1.5/common/commonPrint.css?61" />
		<link rel="stylesheet" type="text/css" media="handheld" href="/skins-1.5/monobook/handheld.css?61" />
		<!--[if lt IE 5.5000]><style type="text/css">@import "/skins-1.5/monobook/IE50Fixes.css?61";</style><![endif]-->
		<!--[if IE 5.5000]><style type="text/css">@import "/skins-1.5/monobook/IE55Fixes.css?61";</style><![endif]-->
		<!--[if IE 6]><style type="text/css">@import "/skins-1.5/monobook/IE60Fixes.css?61";</style><![endif]-->
		<!--[if IE 7]><style type="text/css">@import "/skins-1.5/monobook/IE70Fixes.css?61";</style><![endif]-->
		<!--[if lt IE 7]><script type="text/javascript" src="/skins-1.5/common/IEFixes.js?61"></script>
		<meta http-equiv="imagetoolbar" content="no" /><![endif]-->
		
		<script type= "text/javascript">/*<![CDATA[*/
var skin = "monobook";
var stylepath = "/skins-1.5";
var wgArticlePath = "/wiki/$1";
var wgScriptPath = "/w";
var wgServer = "http://de.wikipedia.org";
var wgCanonicalNamespace = "";
var wgCanonicalSpecialPageName = false;
var wgNamespaceNumber = 0;
var wgPageName = "Leipzig";
var wgTitle = "Leipzig";
var wgArticleId = "2996";
var wgIsArticle = false;
var wgUserName = null;
var wgUserGroups = null;
var wgUserLanguage = "de";
var wgContentLanguage = "de";
var wgBreakFrames = false;
var wgCurRevisionId = "30249034";
/*]]>*/</script>
                
		<script type="text/javascript" src="/skins-1.5/common/wikibits.js?61"><!-- wikibits js --></script>
		<script type="text/javascript" src="/w/index.php?title=-&amp;action=raw&amp;gen=js"><!-- site js --></script>
		<style type="text/css">/*<![CDATA[*/
@import "/w/index.php?title=MediaWiki:Common.css&usemsgcache=yes&action=raw&ctype=text/css&smaxage=2678400";
@import "/w/index.php?title=MediaWiki:Monobook.css&usemsgcache=yes&action=raw&ctype=text/css&smaxage=2678400";
@import "/w/index.php?title=-&action=raw&gen=css&maxage=2678400";
/*]]>*/</style>
		<!-- Head Scripts -->
		<script type="text/javascript" src="/skins-1.5/common/ajax.js?61"></script>
	</head>
<body  class="mediawiki ns-0 ltr page-Leipzig">
	<div id="globalWrapper">
		<div id="column-content">
	<div id="content">
		<a name="top" id="top"></a>
				<h1 class="firstHeading">Bearbeiten von Leipzig</h1>
		<div id="bodyContent">
			<h3 id="siteSub">aus Wikipedia, der freien Enzyklopädie</h3>
			<div id="contentSub"></div>
									<div id="jump-to-nav">Wechseln zu: <a href="#column-one">Navigation</a>, <a href="#searchInput">Suche</a></div>			<!-- start content -->
			<p>Du bearbeitest den Artikel unangemeldet. Statt eines Benutzernamens wird deine aktuelle IP-Adresse in der Versionsgeschichte aufgezeichnet.
</p><p>Diese Seite ist 116 kB groß.
</p><div id="wikiPreview"></div><div id='toolbar'>
<script type='text/javascript'>
/*<![CDATA[*/
addButton('/skins-1.5/common/images/button_bold.png','Fetter Text','\'\'\'','\'\'\'','Fetter Text','mw-editbutton-bold');
addButton('/skins-1.5/common/images/button_italic.png','Kursiver Text','\'\'','\'\'','Kursiver Text','mw-editbutton-italic');
addButton('/skins-1.5/common/images/button_link.png','Interner Link','[[',']]','Link-Text','mw-editbutton-link');
addButton('/skins-1.5/common/images/button_extlink.png','Externer Link (http:// beachten)','[',']','http://www.beispiel.de Link-Text','mw-editbutton-extlink');
addButton('/skins-1.5/common/images/button_headline.png','Überschrift','\n== ',' ==\n','Überschrift','mw-editbutton-headline');
addButton('/skins-1.5/common/images/button_image.png','Bildverweis','[[Bild:',']]','Beispiel.jpg','mw-editbutton-image');
addButton('/skins-1.5/common/images/button_media.png','Mediendatei-Verweis','[[Media:',']]','Beispiel.ogg','mw-editbutton-media');
addButton('/skins-1.5/common/images/button_math.png','Mathematische Formel (LaTeX)','<math>','<\/math>','Formel hier einfügen','mw-editbutton-math');
addButton('/skins-1.5/common/images/button_nowiki.png','Unformatierter Text','<nowiki>','<\/nowiki>','Unformatierten Text hier einfügen','mw-editbutton-nowiki');
addButton('/skins-1.5/common/images/button_sig.png','Deine Signatur mit Zeitstempel','--~~~~','','','mw-editbutton-signature');
addButton('/skins-1.5/common/images/button_hr.png','Horizontale Linie (sparsam verwenden)','\n----\n','','','mw-editbutton-hr');
/*]]>*/
</script>
</div>
<form id="editform" name="editform" method="post" action="/w/index.php?title=Leipzig&amp;action=submit" enctype="multipart/form-data">
<input type='hidden' value="" name="wpSection" />
<input type='hidden' value="20070408140126" name="wpStarttime" />

<input type='hidden' value="20070408125104" name="wpEdittime" />

<input type='hidden' value="" name="wpScrolltop" id="wpScrolltop" />



<textarea tabindex='1' accesskey="," name="wpTextbox1" id="wpTextbox1" rows='25'
cols='80' >{{Dieser Artikel|befasst sich mit der deutschen Großstadt Leipzig, andere Bedeutungen unter [[Leipzig (Begriffsklärung)]].}}

{| cellpadding=&quot;2&quot; style=&quot;float: right; width: 307px; background: #e3e3e3; margin-left: 1em; border-spacing: 1px;&quot;
! Wappen
! Karte
|- style=&quot;background: #ffffff; text-align: center;&quot;
| style=&quot;width: 100px;&quot; | [[Bild:Stadtwappen Leipzig.svg|140px|Stadtwappen von Leipzig]]
| style=&quot;width: 145px;&quot; | [[Bild:Lage der kreisfreien Stadt Leipzig in Deutschland.png|140px|Lage der kreisfreien Stadt Leipzig in Deutschland]]
|-
! colspan=&quot;2&quot; | Leitspruch
|- style=&quot;background: #ffffff; text-align: center;&quot;
| colspan=&quot;2&quot; | Leipzig kommt! (1992–2002)
|-
|- style=&quot;background: #ffffff; text-align: center;&quot;
| colspan=&quot;2&quot; | Leipziger Freiheit (seit 2003)
|-
|-
! colspan=&quot;2&quot; | Basisdaten
|- bgcolor=&quot;#FFFFFF&quot;
| [[Bundesland (Deutschland)|Bundesland]]: || [[Sachsen]]
|- bgcolor=&quot;#FFFFFF&quot;
| [[Regierungsbezirk]]: || [[Regierungsbezirk Leipzig|Leipzig]]
|- bgcolor=&quot;#FFFFFF&quot;
| [[Kreisfreie Stadt|Kreis]]: || Leipzig, Stadt
|- bgcolor=&quot;#FFFFFF&quot;
| [[Fläche]]: || 297,60 [[Quadratkilometer|km²]]
|- bgcolor=&quot;#FFFFFF&quot;
| [[Einwohner]]: || 506.372 ''&lt;small&gt;(November 2006)&lt;/small&gt;'' &lt;ref&gt;[http://www.statistik.sachsen.de/21/02_02/02_02_05_tabelle.asp Statistisches Landesamt]&lt;/ref&gt;
|- bgcolor=&quot;#FFFFFF&quot;
| [[Bevölkerungsdichte]]: || 1715 Einwohner je km²
|- bgcolor=&quot;#FFFFFF&quot;
| [[Ausländeranteil]]: || 6,3 %
|- bgcolor=&quot;#FFFFFF&quot;
&lt;!-- ARBEITSLOSENQUOTE: Zur Aktualisierung folgendes Webangebot nutzen: http://www.pub.arbeitsamt.de/hst/services/statistik/000000/html/start/karten/aloq_kreis.html --&gt;
| [[Arbeitslosenquote]]: || 17,7 % ''&lt;small&gt;(März 2007)&lt;/small&gt;'' &lt;ref&gt;[http://www.pub.arbeitsamt.de/hst/services/statistik/000000/html/start/karten/aloq_kreis_387.html Arbeitsagentur]&lt;/ref&gt;
|- bgcolor=&quot;#FFFFFF&quot;
| [[Geographische Koordinaten|Geographische Lage]]: || {{Koordinate Text Artikel|51_20_N_12_23_E_type:city(504971)_region:DE-SN|51°&amp;nbsp;20'&amp;nbsp;N, 12°&amp;nbsp;23'&amp;nbsp;O}}
|- bgcolor=&quot;#FFFFFF&quot;
| [[Höhe]]: || {{Höhe|113|DE-NN|link=true}}
|- bgcolor=&quot;#FFFFFF&quot;
| [[Postleitzahl]]en: || 04003–04357 (''alt:'' 70xx)
|- bgcolor=&quot;#FFFFFF&quot;
| [[Telefonvorwahl|Vorwahl]]: || 0341
|- bgcolor=&quot;#FFFFFF&quot;
| [[Kraftfahrzeugkennzeichen|Kfz-Kennzeichen]]: || L
|- bgcolor=&quot;#FFFFFF&quot;
| [[Amtlicher Gemeindeschlüssel|Gemeindeschlüssel]]: || 14 3 65 000
|- bgcolor=&quot;#FFFFFF&quot;
| [[UN/LOCODE]]: || &lt;tt&gt;DE LEJ&lt;/tt&gt;
|- bgcolor=&quot;#FFFFFF&quot;
| Stadtgliederung: || 10 [[Stadtbezirk]]e&lt;br /&gt;mit 63 [[Ortsteil]]en
|- bgcolor=&quot;#FFFFFF&quot;
| Adresse der&lt;br /&gt;Stadtverwaltung: || Neues Rathaus&lt;br /&gt;Martin-Luther-Ring 4-6&lt;br /&gt;04109 Leipzig
|- bgcolor=&quot;#FFFFFF&quot;
| Offizielle [[Website]]: || [http://www.leipzig.de/ leipzig.de]
|- bgcolor=&quot;#FFFFFF&quot;
|-
! colspan=&quot;2&quot; | Politik
|- bgcolor=&quot;#FFFFFF&quot;
| [[Oberbürgermeister]]: || [[Burkhard Jung]] ([[Sozialdemokratische Partei Deutschlands|SPD]])
|}

[[Bild:Battle_Of_The_Nations-Monument.jpg|thumb|300px|right|Leipziger Wahrzeichen: [[Völkerschlachtdenkmal]]]]

{{Audio|Leipzig.ogg|'''Leipzig'''}} ist eine [[kreisfreie Stadt]] im Nordwesten [[Sachsen]]s. Mit mehr als einer halben Million Einwohner ist sie mit Stand November 2006 knapp vor [[Dresden]] die bevölkerungsreichste [[Stadt]] Sachsens und der [[Neue Bundesländer|fünf neuen Bundesländer]]. 

Nach Verleihung des Stadtrechts und der Marktprivilege im Jahre [[1165]] entwickelte sich Leipzig während der [[Deutsche Ostsiedlung|Deutschen Ostsiedlung]] schnell zu einem Handelszentrum. Die Einwohnerzahl überschritt etwa 1870 die Grenze von 100.000, wodurch Leipzig [[Großstadt]] wurde. Es gehört zu den sechs [[Oberzentrum|Oberzentren]] Sachsens und ist Sitz des [[Regierungsbezirk Leipzig|Regierungsbezirks Leipzig]].

Leipzigs Tradition als bedeutender [[Leipziger Messe|Messestandort]] in Mitteleuropa und die älteste [[Messe]] der Welt gehen auf das Jahr 1190 zurück.

Neben [[Frankfurt am Main]] ist die Stadt ein historisches Zentrum des [[Buchdruck]]s und -[[Buchhandel|handels]]. Außerdem befinden sich in Leipzig eine der ältesten [[Universität Leipzig|Universitäten]] sowie die älteste [[Handelshochschule Leipzig|Handels-]] und [[Hochschule für Musik und Theater „Felix Mendelssohn Bartholdy“ Leipzig|Musikhochschule]] Deutschlands.  

Leipzig ist ein Kern des [[Ballungsraum Leipzig-Halle|Ballungsraums Leipzig-Halle]] und damit Teil der [[Metropolregion Sachsendreieck]]. Die Stadt ist ein bedeutender Verkehrsknotenpunkt und bildet einen der wirtschaftsstärksten Räume der [[Neue Bundesländer|neuen Bundesländer]].

== Geographie ==
=== Geographische Lage ===
Leipzig liegt im Zentrum der [[Leipziger Tieflandsbucht]], einem Teil der [[Norddeutsches Tiefland|Norddeutschen Tiefebene]]. Im Osten grenzt daran das nördliche Elbland und im Südosten und Süden das Mittelsächsische Hügelland an. Im westlichen [[Thüringen]] und [[Sachsen-Anhalt]] geht die Tieflandsbucht durch das Tal der [[Saale]] in die [[Saale-Unstrut-Region]] über.

In der Nähe liegende Großstädte sind [[Halle (Saale)|Halle]] (etwa 30 km nordwestlich), [[Chemnitz]] (etwa 70 km südlich), [[Dresden]] (etwa 100 km südöstlich), [[Erfurt]] (etwa 100 km südwestlich), [[Magdeburg]] (etwa 100 km nordwestlich) und [[Berlin]] (etwa 145 km nördlich). Leipzig liegt fast im Schwerpunkt der drei benachbarten Landeshauptstädte Dresden, Magdeburg und Erfurt. 

Durch die Stadt fließt die [[Weiße Elster]], in die hier die [[Pleiße]] und die [[Parthe]] münden. Aus der Weißen Elster entspringt im Stadtgebiet mit der [[Luppe (Fluss)|Luppe]] ein zweiter Flusslauf. Mit Leipzig wird aber vor allem die Pleiße in Verbindung gebracht, da sie unmittelbar am Stadtzentrum vorbeifließt. 

Die höchsten Erhebungen Leipzigs sind der [[Monarchenhügel]] (159 m), der künstlich aufgeschüttete [[Fockeberg]] (153 m) sowie der knapp außerhalb der Stadtgrenze liegende [[Galgenberg]] (163 m).

=== Natur und Umwelt ===
[[Bild:Leipzig pleissemuehlencanar.jpg|thumb|Freilegen des Pleißenmühlgrabens (Jan. 2007)]]
[[Bild:Cospudenersee-leipzig.jpg|thumb|[[Cospudener See]]]]
Entlang der Flüsse zieht sich ein ausgedehntes [[Leipziger Auenwald|Auwald]]gebiet mitten durch die Stadt. Es gilt als größtes innerstädtisches, zusammenhängendes Waldgebiet dieser Art in Europa. Da sich unter Leipzig und seinem Umland bedeutende [[Braunkohle]]lagerstätten befinden, wurde bereits in den 1930er Jahren mit dem industriellen Abbau dieses Rohstoffes in [[Tagebau]]weise begonnen. Durch den [[Bergbau]], der sich während der [[Deutsche Demokratische Republik|DDR]]-Zeit immer weiter ausbreitete (Braunkohle war der Hauptenergieträger), wurden südlich von Leipzig Teile des Auwaldes zerstört. Zahlreiche Hochwasserschutzmaßnahmen, unter anderem der Bau des [[Elsterbecken]]s und die Verlegung natürlicher Flussläufe sowie mit dem Kohleabbau verbundene Absenkungen des Grundwasserspiegels führten zu Störungen des hochspezialisierten Ökosystems, das ursprünglich als natürliches Überflutungsgebiet diente. 

In den 1950er Jahren wurden der Pleißenmühlgraben und ein Teil des Elstermühlgrabens – im Mittelalter für den Betrieb von Mühlen teilweise künstlich angelegte Nebenarme der beiden Flüsse – wegen der Verschmutzung durch Industrieabwässer aus der Braunkohleverarbeitung südlich von Leipzig verrohrt und teilweise auch zugeschüttet, sodass Leipzig seinen Charakter als Flussstadt teilweise verlor. Die Einleitung der hochgiftigen Abwässer führte dazu, dass die Flüsse biologisch tot waren. Seit den 1990er Jahren werden beide Flussläufe nach und nach wieder freigelegt.

Neben der Gewässerverunreinigung brachte die Braunkohlebefeuerung veralteter Industrieanlagen und Kraftwerke, die teilweise noch dem Vorkriegsstandard entsprachen, sowie häuslicher Ofenheizungen eine sehr starke [[Luftverschmutzung]] mit sich. Die [[schwefel]]- und [[phenol]]reiche Luft und der damit einhergehende [[Saurer Regen|saure Regen]] griff Teile der Bausubstanz, v.&amp;nbsp;a. die aus [[Sandstein]], an. In den 1970er und 1980er Jahren galt Leipzig als eine der mit Umweltgiften am meisten belasteten Großstädte Europas. [[Pseudokrupp]] war eine der häufigsten Kinderkrankheiten. 

Nach der [[Wende (DDR)|Wende]] führte die Stilllegung der Altindustrie und die Modernisierung von Kraftwerken und häuslichen Heizungsanlagen sehr schnell zu erheblich verbesserten Wasser- und Luftverhältnissen und einer sichtbaren Gesundung der Tier- und Pflanzenwelt. Leipzig zählt heute mit seinen zahlreichen Stadtparks, wie beispielsweise dem zentrumsnahen Clara-Zetkin-Park und dem [[Rosental (Leipzig)|Rosental]], vielen neu geschaffenen Anlagen in den Wohngebieten sowie den traditionellen [[Kleingarten|Schrebergarten]]vereinen – die von [[Daniel Gottlob Moritz Schreber|Schreber]] initiierte Kleingartenbewegung hat in Leipzig ihren Ursprung – mit einem Grünflächenanteil von etwa 50&amp;nbsp;% und einem Waldanteil von etwa 7&amp;nbsp;% zu den grünsten Städten Deutschlands. 

Anfang der 1990er Jahre wurde auch der Braunkohleabbau gestoppt und mit der [[Rekultivierung]] der [[Tagebaurestloch|Tagebaurestlöcher]] und der [[Renaturierung]] des Umfeldes begonnen. Inzwischen sind aus den gefluteten Tagebauen mehrere Seen mit sehr guter Wasserqualität entstanden. Weitere Tagebaue befinden sich noch in der Flutung. Der [[Cospudener See]] liegt dem Leipziger Stadtzentrum am nächsten und dient bereits als sehr gut erschlossenes Naherholungsgebiet. Der so entstehende großflächige Erholungsraum wird als „[[Leipziger Neuseenland]]“ auch touristisch vermarktet. Um Natur und Landschaft der Region gemeinsam mit den umliegenden Kommunen und Landkreisen zu entwickeln und erlebbar zu machen, ist Leipzig seit 1996 Mitglied im [[Grüner Ring Leipzig|Grünen Ring Leipzig]].

=== Stadtgliederung und Nachbargemeinden ===
Leipzig besteht aus zehn [[Stadtbezirk]]en mit 63 [[Ortsteil]]en, siehe [[Liste der Ortsteile Leipzigs]] für die politische Gliederung und [[Liste der Stadtteile Leipzigs]] für die historisch gewachsene Struktur.

Die nachfolgenden [[Gemeinde]]n grenzen an die Stadt Leipzig. Sie werden im [[Uhrzeigersinn]] beginnend im Osten genannt:

* im [[Muldentalkreis]] (MTL): [[Borsdorf]], Stadt [[Brandis]] und Stadt [[Naunhof]]
* im [[Landkreis Leipziger Land]] (L): [[Großpösna]], Stadt [[Markkleeberg]], Stadt [[Zwenkau]], [[Kitzen]] und Stadt [[Markranstädt]]
* im [[Landkreis Delitzsch]] (DZ): Stadt [[Schkeuditz]], [[Rackwitz]], [[Krostitz]], [[Jesewitz]] und Stadt [[Taucha]]

=== Klima ===
[[Bild:Klimadiagramm-Leipzig-Deutschland-metrisch-deutsch.png|thumb|Klimadiagramm von Leipzig&lt;ref&gt;Geoklima 2.1&lt;/ref&gt;]]
Leipzig liegt in der [[Gemäßigte Zone|kühlgemäßigten]] [[Klimazone]]. Die durchschnittliche Jahrestemperatur beträgt 8,4&amp;nbsp;°C und die mittlere jährliche Niederschlagsmenge 556,8 mm (Mittel 1972–2001). Die mittlere Frostdauer beträgt 79 Tage. &lt;ref name=&quot;Klimastat&quot;/&gt;

Leipzig liegt im [[Regenschatten]] des [[Harz (Mittelgebirge)|Harz]]es und noch vor den Regenstaulagen am [[Erzgebirge]]. Der meiste Niederschlag fällt in den Sommermonaten Juni bis August mit einem Spitzenwert von 72&amp;nbsp;mm im Juli. Im Februar fällt der geringste Niederschlag mit 27&amp;nbsp;mm, in den anderen Wintermonaten liegt er etwa bei 30&amp;nbsp;mm. Aufgrund des unterschiedlichen Ausmaßes des Regenschattens des Harzes unterscheiden sich auch die Niederschlagsmengen innerhalb des Stadtgebietes. Am trockensten ist der Norden Leipzigs, der meiste Niederschlag fällt im Südraum der Stadt, wobei die Jahresdifferenz etwa 100 mm beträgt. &lt;ref&gt;[http://www.leipzig.de/de/buerger/freizeit/leipzig/stadtwald/wissen/02998.shtml leipzig.de- Klima]&lt;/ref&gt;

Der heißeste Tag war der 9. August 1992 mit 38,8&amp;nbsp;°C, der kälteste der 14. Januar 1987 mit −24,1&amp;nbsp;°C.&lt;ref name=&quot;Klimastat&quot;&gt;[http://www.uni-leipzig.de/~meteo/KLIMASTATISTIK/ Klimastatistik der Uni Leipzig]&lt;/ref&gt;
&lt;br style=&quot;clear:both&quot;&gt;

=== Nach Leipzig benannte Ortschaften ===
In der [[Kanada|kanadischen]] Provinz [[Saskatchewan (Provinz)|Saskatchewan]] gibt es eine Kleinstadt namens Leipzig.

Ferner befinden sich mehrere nach Leipzig benannte Ortschaften in den [[Vereinigte Staaten|USA]]. So tragen zwei Orte, in [[Delaware]] (203 Einwohner; Stand: 2000) und in [[Ohio]] (2.236 Einwohner; Stand: 2000), den der englischen Aussprache angepassten Namen ''Leipsic''. In [[North Dakota]] liegt zudem das im Jahre 1901 von [[Russlanddeutsche|Russlanddeutschen]] gegründete ''New Leipzig'', welches heute 326 Einwohner zählt.

== Geschichte ==
[[Bild:Leipzig 1632 Theatrum Europaeum.jpg|thumb|200px|Leipzig zur Belagerung durch [[Heinrich von Holk]] im Jahr 1632]]
''Hauptartikel:'' [[Geschichte der Stadt Leipzig]]
[[Bild:Leipzig Nikolaikirche 18 Jh.jpg|thumb|200px|Nikolaikirchhof und alte Nikolaischule im 18. Jahrhundert]]
[[Bild:Leipzig Marktplatz Messe um 1800.jpg|thumb|200px|Messe auf dem Markt (um 1800)]]

Etwa 900 n. Chr. wurde an beiden Ufern der [[Parthe]] eine [[Slawen|slawische]] Siedlung angelegt, wie Grabungen von Herbert Küas im Gebiet des heutigen Matthäikirchhofs bestätigten. Erstmals erwähnt wurde Leipzig 1015, als [[Thietmar von Merseburg]] von einer ''urbs Libzi'' berichtete (Chronikon VII, 25). Als Gründungsjahr der Stadt gilt das Jahr 1165, in dem [[Graf#Markgraf|Markgraf]] [[Otto (Meißen)|Otto der Reiche]] von [[Meißen]] dem Ort an der Kreuzung der [[Via Regia]] mit der [[Via Imperii]] das [[Stadtrecht]] und das [[Marktrecht]] erteilte. Mit der Stadtgründung entstanden die beiden großen Kirchbauwerke der [[Thomaskirche (Leipzig)|Thomaskirche]] und der [[Nikolaikirche (Leipzig)|St. Nikolaikirche]].

Leipzig lag in der [[Markgrafschaft Meißen]], die 1439 [[Säkularisierung|säkularisiert]] zum [[Kurfürstentum Sachsen]] wurde. Das Kurfürstentum wurde bereits 1485 durch die beiden Brüder [[Albrecht der Beherzte (Sachsen)|Albrecht den Beherzten]] und [[Ernst (Sachsen)|Ernst]] mit der [[Leipziger Teilung]] aufgeteilt. Leipzig gehörte danach zum [[Herzogtum Sachsen]], zu dessen Hauptstadt das bis dahin im Vergleich zu Leipzig oder [[Meißen]] unbedeutende Dresden ernannt wurde. Leipzig war darin häufig Tagungsort des [[Landtag (historisch)|Landtags]]. Nach der Verwaltungsreform 1499 lag Leipzig als sogenanntes Amt im ''Leipziger Kreis'' neben dem es sieben weitere im Kurfürstentum gab.

Im Jahre 1409 wurde die [[Universität Leipzig]] als „Alma Mater Lipsiensis“ gegründet und gehört damit zu den ältesten Universitäten in Deutschland. 1519 trafen sich [[Martin Luther]], [[Andreas Karlstadt]] und [[Philipp Melanchthon]] mit dem katholischen Theologen [[Johannes Eck]] auf Einladung der Universität in der [[Pleißenburg]] zu einem Streitgespräch, das als [[Leipziger Disputation]] in die Geschichte einging. 

1539 wurde die Reformation endgültig durch Luther und [[Justus Jonas der Ältere|Justus Jonas]] in Leipzig eingeführt. Leipzig war auch vom [[Schmalkaldischer Krieg|Schmalkaldischen Krieg]] 1546 und 1547 betroffen, in dem es für Leipzig und Sachsen vorrangig um die Gleichstellung der protestantischen Konfession ging. In Folge wechselte die Kurwürde an die [[Albertiner|albertinische]] Linie, in deren Herzogtum Leipzig lag.

In diesen Jahren war die Entwicklung Leipzigs vor allem durch die sich stetig verbessernden Lebensbedingungen gekennzeichnet. Als immer bedeutendere Handels- und Messestadt profitierte Leipzig dabei von einem wohlhabenden Bürgertum. Bereits im 16. Jahrhundert entstand eine Trinkwasserversorgung. 1650 erschienen erstmals die [[Einkommende Zeitungen|Einkommenden Zeitungen]] sechs mal pro Woche und gelten als älteste [[Tageszeitung]] der Welt.

Leipzig erwarb sich den Spitznamen „Klein Paris“, als die fortschrittsbewusste Messestadt im Jahr 1701 mit einer Straßenbeleuchtung ausgestattet wurde und sich fortan mit der mondänen Seine-Metropole vergleichen konnte. 

[[Bild:Leipzig1876.png|thumb|200px|Historischer [[Stadtplan]] und Umgebungskarte von Leipzig von 1876]] 
[[Bild:Leipzig um 1900.jpg|thumb|200px|[[Neues Theater (Leipzig)|Neues Theater]] (Oper) am [[Augustusplatz]] um 1900]]

Im Jahre 1813 fand die [[Völkerschlacht bei Leipzig]] im Zuge der sogenannten [[Befreiungskriege]] statt. Die verbündeten Heere der [[Kaisertum Österreich|Österreicher]], [[Preußen]], [[Russisches Reich|Russen]] und Schweden brachten in dieser Schlacht [[Napoléon Bonaparte|Napoleons]] Truppen und deren Verbündeten, darunter das [[Königreich Sachsen]], die entscheidende Niederlage bei, die schließlich zu seiner Verbannung auf die Insel Elba führte.

1839 wurde die [[Leipzig-Dresdner Eisenbahn]] als erste deutsche Fern[[Eisenbahn|bahn]]strecke eröffnet. Leipzig entwickelte sich allmählich zum wichtigsten [[Verkehr]]sknotenpunkt in [[Mitteldeutschland]], was sich auch darin äußerte, dass der damals nach Mailands ''[[Stazione Centrale di Milano|Stazione Centrale]]'' größte [[Kopfbahnhof]] [[Europa]]s von 1902 bis 1915 in Leipzig entstand.

Infolge der [[Industrialisierung]], aber auch vielfältiger Eingemeindungen der Vororte, stieg am Ende des 19. Jahrhunderts die Bevölkerungszahl rasant an. 1871 wurde Leipzig mit 100.000 Einwohnern Großstadt. Im Jahr 1900 konstituierte sich in Leipzig der [[Deutscher Fußball-Bund|Deutsche Fußball-Bund]]. Der [[VfB Leipzig]] war 1903 erster deutscher Fußballmeister.

Am 1. Oktober 1879 entstand in Leipzig das [[Reichsgericht]] als oberstes Zivil- und Strafgericht des 1871 gegründeten [[Deutsches Reich|Deutschen Reiches]]. Es diente in der Funktion des heutigen [[Bundesgerichtshof]]s. Während der [[Leipziger Prozesse]] wurde versucht, am Gericht Verbrechen des [[Erster Weltkrieg|Ersten Weltkriegs]] aufzuklären und die Täter zu verurteilen. Mit der Machtübernahme 1933 integrierten die Nationalsozialisten das Gericht in das Regime Hitlers. Im Dezember 1933 verhandelte das Reichsgericht im Prozess um den [[Reichstagsbrand]] gegen [[Marinus van der Lubbe]]. Er wurde zum Tode verurteilt und im Januar 1934 in Leipzig hingerichtet. Freisprüche weiterer Angeklagter führten zur Einrichtung des [[Volksgerichtshof]]s, um die Justiz bei den Delikten Hoch- und Ladesverrat zu zentralisieren. Bis zum Ende der Krieges verschärfte man die Strafpraxis am Reichsgericht und revidierte viele Strafen zu Todesurteilen. Die Auflösung des Gerichtes erfolgte 1945.

Während des [[Zweiter Weltkrieg|Zweiten Weltkrieges]] kam es in den Jahren 1943 bis 1945 zu mehreren [[Luftangriffe auf Leipzig|Luftangriffen auf die Stadt]], die zu erheblichen Zerstörungen der Innenstadt führten –&amp;nbsp;bis zu 60&amp;nbsp;% der Bausubstanz waren betroffen&amp;nbsp;– und etwa 6.000 Opfer forderten. Am 18. April 1945 erreichten Einheiten der 3. [[United States Army|US-Armee]] die Stadt. Auf Grund des 1. Londoner Zonenprotokolls von 1944 und der Beschlüsse der [[Konferenz von Jalta]] übernahm am 2. Juli 1945 die [[Rote Armee]] Leipzig und die Stadt kam zur [[SBZ|sowjetischen Besatzungszone]]. Die sowjetische Militäradministration bildete den „[[Rat der Stadt]]“ und die [[Stadtverordnetenversammlung]], deren Zusammensetzung mit Gründung der [[Deutsche Demokratische Republik|DDR]] die [[SED]] diktierte.

Nach dem [[Zweiter Weltkrieg|Zweiten Weltkrieg]] ließ die wirtschaftliche Bedeutung Leipzigs in Folge der Zugehörigkeit zur sowjetischen Besatzungszone bzw. zur DDR stark nach, was sich auch in einem kontinuierlichen Rückgang der Einwohnerzahl äußerte. Während der DDR-Zeit war Leipzig Hauptstadt des [[Bezirk Leipzig|Bezirks Leipzig]] und bevölkerungsmäßig die zweitgrößte Stadt der Deutschen Demokratischen Republik. In die Großstädte Berlin, Leipzig und Dresden wurden die meisten [[Kombinat]]sleitungen und Stammbetriebe angelegt, so dass sich die wirtschaftliche Bedeutung Leipzigs in der DDR bis 1990 erhielt. 

1989 leiteten die von der [[Leipziger Nikolaikirche|Nikolaikirche]] ausgehenden [[Montagsdemonstrationen 1989/1990 in der DDR|Montagsdemonstration]]en mit das Ende der DDR ein. Bereits fünf Tage vor den ersten großen Demonstrationen gab es gewaltsame Auseinandersetzungen am [[Dresdner Hauptbahnhof]]. Aus der Erkenntnis, dass Gewalt gegen die staatlichen Ordnungsmächte und Zerstörungen von den DDR-Regierungen und -Behörden massiv propagandistisch ausgenutzt wurden, organisierte man die Montagsdemonstrationen unter der Losung „Keine Gewalt“ in Leipzig friedlich. 1990 wurden Leipzig und weite Teile des Bezirks Leipzig dem Freistaat Sachsen zugeordnet. Leipzig ist seitdem Hauptstadt des [[Regierungsbezirk Leipzig|Regierungsbezirks Leipzig]].

Am 12. April 1996 wurde mit einem Festakt das neue Messegelände eröffnet, das als modernstes Ausstellungs- und Kongresszentrum Europas in knapp dreijähriger Bauzeit errichtet wurde. Heute ist Leipzig wieder zunehmend als [[Messe (Wirtschaft)|Messe]]-, [[Medien]]- und [[Universität]]sstadt bekannt, wenn auch die Bedeutung  geringer ist als vor dem Zweiten Weltkrieg. Die Bewerbung um die [[Olympische Sommerspiele 2012|Olympischen Sommerspiele 2012]] scheiterte. 2006 war Leipzig ein Austragungsort der [[Fußball-Weltmeisterschaft 2006]], im Zentralstadion fanden vier Länderspiele statt.

=== Religionen ===
[[Bild:Leipzig Thomaskirche.jpg|thumb|right|Thomaskirche]]''Für eine ausführliche Geschichte der Religionen siehe:'' [[Geschichte der Religionen in Leipzig]]

Die Bevölkerung der Stadt Leipzig gehörte bis zur Reformation zum [[Bistum Merseburg]]. Merseburg war bereits ab [[968]] Sitz eines [[Archidiakonat]]s, das der [[Domdekan]] des Merseburger Hochstifts innehatte. Im 13.&amp;nbsp;Jahrhundert entstanden in Leipzig vier Klöster: ''St. Paul'' ([[Dominikaner]]), ''St. Thomas'' (Augustiner-Chorherren), ''Zum Heiligen Geist'' ([[Franziskaner]]) und [[Kloster St. Georg (Leipzig)|''St.&amp;nbsp;Georg'']] ([[Zisterzienser]]innen bzw. [[Benediktiner]]innen). 

Erste [[Lutheraner|lutherische]] Predigten wurden bereits 1522 abgehalten. 1539 wurde die Reformation eingeführt. Gegenwärtig gehören alle [[Kirchengemeinde]]n der Stadt zum Kirchenbezirk Leipzig, der [[Evangelisch-Lutherische Landeskirche Sachsens|Evangelisch-Lutherischen Landeskirche Sachsens]] gehört. Der Kirchenbezirk umfasst auch Gemeinden außerhalb der Stadt. Innerhalb der Landeskirche gibt es eine Landeskirchliche Gemeinschaft.

Seit 1697 gibt es in Leipzig wieder [[Katholiken|katholische]] Gottesdienste. 1921 wurde das Bistum Meißen (heute [[Bistum Dresden-Meißen|Dresden-Meißen]]) wiedererrichtet, in dem die Messestadt Sitz eines [[Dekanat]]s ist. Katholische Hauptkirche der Stadt ist die Propsteikirche St. Trinitatis.

[[Bild:Synagoge_Leipzig-Keilstr.jpg|thumb|right|Synagoge Keilstraße]]
[[Bild:Leipzig Russische Gedaechtniskirche.jpg|thumb|right| Die Russische Gedächtniskirche]]

Die erste Erwähnung [[Judentum|jüdischen]] Lebens in Leipzig stammt aus einer Urkunde [[Heinrich der Erlauchte|Heinrich des Erlauchten]] von 1248. Im 14. Jahrhundert kam es erstmals zu [[Pogrom]]en gegen Juden und es vergingen mehrere Jahrhunderte, in denen Juden untersagt war, in Leipzig zu siedeln. Erst ab 1710 durften sie wieder in Leipzig sesshaft werden. Nach 1800 bildete sich erstmals eine Jüdische Gemeinde. Einerseits ließen sich hier viele traditionell geprägte [[Juden in Osteuropa|osteuropäische Juden]] nieder, andererseits wurde 1820 eine [[Reformjudentum|Reformsynagoge]] errichtet, die allerdings nur während der Leipziger Messe in Betrieb war. Bis zum [[Nationalsozialismus]] prägten jüdische Bürger die Stadt als Unternehmer, Wissenschaftler, Künstler und Stifter wesentlich mit. 1912 gründete der Rabbiner [[Ephraim Carlebach]] die [[Höhere Israelitische Schule]], die erste jüdische Schule in Sachsen. Sie bestand bis 1942. 1929 hatte Leipzig mit über 14.000 Mitgliedern die größte jüdische Gemeinde Sachsens und eine der größten Deutschlands. Ab 1933 begann die systematische Auslöschung jüdischen Lebens in der Stadt, die mit der Deportation und Ermordung fast aller Leipziger Juden ihr Ende fand. Nach dem Krieg bestand die Jüdische Gemeinde nur noch aus 24 Mitgliedern. Die Mitgliederzahl stagnierte bis Anfang der 1990er Jahre. 2004 zählte die „Israelitische Religionsgemeinde zu Leipzig“, insbesondere durch die Einwanderung russischer Juden, wieder über 1.000 Mitglieder. In der heutigen Gottschedstraße, an der Stelle der ehemals größten Leipziger Synagoge, die in der [[Reichspogromnacht]] den Flammen zum Opfer fiel, erinnert seit 2001 unter Einbeziehung eines dort 1966 aufgestellten Denkmales eine Gedenkstätte an die Vertreibung und Ermordung der Leipziger Juden.

In Leipzig gibt es etwa 5.000 [[Islam|Muslime]]. Die größte  [[Moschee]] heißt ''Ar-Rahman-Moschee (e.V.)''. Des Weiteren gibt es hier eine türkische und eine schiitische Moschee, die aber eine eher geringe Rolle spielen.

=== Namensentwicklung ===
Der Name Leipzig leitet sich vom [[Sorbische Sprache|sorbischen]] ''Lipsk'' her (gleichlautend aus dem Altsorbischen abgeleitet) und bedeutet „Linden-Ort“. Im [[Latein]]ischen wird er mit ''Lipsia'' wiedergegeben.

{| class=&quot;prettytable&quot;   |
| bgcolor=&quot;#dfdfdf&quot; | '''Jahr'''  
| align=&quot;center&quot; width=&quot;60&quot; | 7.–9.&amp;nbsp;Jh. 
| align=&quot;center&quot; width=&quot;60&quot; | 1015  
| align=&quot;center&quot; width=&quot;60&quot; | 1165 
| align=&quot;center&quot; width=&quot;60&quot; | 1220 
| align=&quot;center&quot; width=&quot;60&quot; | 1232   
| align=&quot;center&quot; width=&quot;60&quot; | 1402     
| align=&quot;center&quot; width=&quot;60&quot; | 1459 
| align=&quot;center&quot; width=&quot;60&quot; | 1494 
| align=&quot;center&quot; width=&quot;60&quot; | 1507 
|-
| bgcolor=&quot;#dfdfdf&quot; | '''veränderter&amp;nbsp;Name&amp;nbsp;im&lt;br/ &gt; Laufe von Jahren''' 
| align=&quot;center&quot; | Lipsk     
| align=&quot;center&quot; | Libzi 
| align=&quot;center&quot; | Lipz 
| align=&quot;center&quot; | Liptzick 
| align=&quot;center&quot; | Lipzic 
| align=&quot;center&quot; | Leiptzgk 
| align=&quot;center&quot; | Leipczigk 
| align=&quot;center&quot; | Lips 
| align=&quot;center&quot; | Leipzig 
|}

In [[Faust I]] verewigte [[Johann Wolfgang von Goethe|Goethe]] in einer Szene in [[Auerbachs Keller]] seinen Studienort Leipzig als [[Klein-Paris]]. Goethe lässt einen Studenten sagen: ''Mein Leipzig lob' ich mir! Es ist ein klein Paris und bildet seine Leute.'' Die Bezeichnung etablierte sich in der Umgangssprache des zur Großstadt aufstrebenden und fortschrittlichen Leipzig des 19. Jahrhunderts.

=== Einwohnerentwicklung ===
''Für detaillierte Einwohnerzahlen siehe Hauptartikel:'' [[Einwohnerentwicklung von Leipzig]]

Leipzig zählt aktuell nach umfangreichen Eingemeindungen Ende der 1990er Jahre zu den [[Liste der flächengrößten Städte und Gemeinden Deutschlands|flächengrößten Städten Deutschlands]]. 

Vorher war es, im Gegensatz dazu, eine der kompaktesten Städte, die 1870 zur [[Großstadt]] wurde. Die gegenwärtige Bevölkerungszahl hatte Leipzig bereits vor 1914 erreicht. In den ersten Jahren des 20. Jahrhunderts holte die Bevölkerungszahl Leipzigs sprunghaft auf die größten Städte auf: Vor Beginn des [[Zweiter Weltkrieg|Zweiten Weltkriegs]] war es die [[Liste der größten Städte Deutschlands|fünftgrößte Stadt Deutschlands]] mit knapp 600.000 Einwohnern. 1939 hatte die Bevölkerungsentwicklung mit etwas mehr als 700.000 Einwohnern den historischen Höchststand erreicht. 

Nach kriegsbedingtem Rückgang stieg die Bevölkerung in Leipzig wieder bis etwa 600.000 Einwohner in den 1960er Jahren. Vor allem seit Ende der 1980er Jahre, aber schon in den 1970er Jahren, hat die Stadt einen erheblichen Bevölkerungsschwund zu verzeichnen. Der Tiefststand wurde Mitte der 1990er Jahre mit etwas weniger als 440.000 Einwohnern erreicht. Der Bevölkerungsschwund ist einerseits durch Abwanderung in Regionen der westlichen Bundesländer begründet, andererseits durch einsetzende [[Suburbanisierung]]. Wie alle größeren Städte versucht Leipzig die Bevölkerungszahl aktiv zu erhöhen, um die Erträge aus dem [[Kommunaler Finanzausgleich|Kommunalen Finanzausgleich]] zu steigern, die über die [[Schlüsselzuweisung]] berechnet werden. Durch umfangreiche Eingemeindungen im Jahr 1999, versuchte Leipzig der Suburbanisierung entgegen zu wirken. Es kamen mehrere große Industriegemeinden hinzu, so dass sich die Fläche der Stadt in etwa verdoppelt hat. Durch die Eingemeindungen, ansteigende Geburtenraten und eine positive Bilanz bei Zu- und Wegzügen wächst die Einwohnerzahl Leipzigs langsam wieder, so dass 2005 die Halbe-Million-Einwohnergrenze wieder überschritten wurde. Außerdem soll die [[Zweitwohnungsteuer]] Bewohner am Zweitwohnsitz dazu anregen, in Leipzig ihren Erstwohnsitz zu melden.

== Politik ==
Nach der [[Deutsche Wiedervereinigung|Wiedervereinigung Deutschlands]] wurde das zunächst als „Stadtverordnetenversammlung“, nunmehr als [[Stadtrat]] bezeichnete Gremium wieder frei gewählt. Erster Vorsitzender war zunächst der Stadtpräsident [[Friedrich Magirius]] (parteilos) in den Jahren 1990 bis 1994. Seit 1994 ist der Oberbürgermeister Vorsitzender des Stadtrats. Der Stadtrat wählte anfangs auch den [[Oberbürgermeister]], seit 1994 wird er jedoch direkt vom Volk gewählt.

Der amtierende Oberbürgermeister der Stadt ist seit März 2006 [[Burkhard Jung]] (SPD). Er löste [[Wolfgang Tiefensee]] ab, der die Stadtgeschäfte von 1998 bis 2005 führte, das Amt aber wegen seiner Berufung zum [[Bundesministerium für Verkehr, Bau und Stadtentwicklung|Bundesverkehrsminister]] am 22. November 2005 niederlegte. 

(''Liste aller Leipziger Bürgermeister seit 1778 im Hauptartikel:'' [[Liste der Bürgermeister der Stadt Leipzig]])

In den letzten Jahren wurde die Leipziger Kommunalpolitik von einer informellen Koalition der großen Parteien CDU und SPD geprägt, in die fallweise auch die PDS einbezogen wurde (so genanntes Leipziger Modell). Dadurch wurde die Kontrollfunktion des gewählten Stadtrats weitgehend ausgehebelt. Es kam deshalb zum überraschenden Konkurs städtischer Unternehmen und verschiedenen Korruptionsfällen, die 2004 zur Beurlaubung des Stadtkämmerers und 2005 zur Beurlaubung des beigeordneten Ordnungsbürgermeisters führten.

=== Ergebnis der Stadtratswahl vom 13. Juni 2004 ===
[[Bild:StimmverteilungLeipzigStadtratswahl2004.png|right|300px|thumb|Stimmverteilung 2004]] 
{| class=&quot;prettytable&quot; 
 |-bgcolor=&quot;#dfdfdf&quot;
 ! Partei
 ! Stimmenanteil 2004
 ! Stimmenanteil 1999
 ! Gewinne/Verluste
 ! Sitze im Stadtrat
 |-
 | SPD || 27 || 26,2 || 0,7 || 19 
 |-
 | PDS || 26,1 || 25,5 || 0,6 || 19
 |-
 | CDU || 25,5 || 31,9 || -6,4 || 19
 |-
 | GRÜNE || 10,0 || 7,4 || 2,6 || 7
 |-
 | FDP || 4,5 || 2,7 || 1,8 || 3 
 |-
 | DSU || 1,8 || 1,4 || 0,4 || 1
 |-
 | FORUM || 1,6 || 1,6 || 0,0 || 1
 |-
 | WV VS-BA || 2,6 || 3,2 || -0,6 || 1
 |}
Die Wahlbeteiligung sank von 42,3 auf 38,6 Prozent.
Der DSU-Stadtrat hat sich der CDU-Fraktion angeschlossen.

=== Ergebnis der letzten Oberbürgermeisterwahl ===
Die letzten Bürgermeisterwahlen fanden am 5. Februar (erster Wahlgang) und am 26. Februar 2006 (zweiter Wahlgang) statt. Da kein Kandidat im ersten Wahlgang die absolute Mehrheit der Stimmen auf sich vereinen konnte, bedurfte es des zweiten Wahlgangs, in dem bereits die einfache Mehrheit ausreicht. Im ersten Wahlgang kandidierten [[Burkhard Jung]] (SPD), [[Uwe Albrecht]] (CDU), ''Dietmar Pellmann'' (Linkspartei), [[Michael Weichert]] (B90/Grüne), ''Bernd-Rüdiger Kern'' (DSU),  ''Benedict Rehbein'' (parteilos) und ''Karsten Werner'' (BüSo). Im zweiten Wahlgang wurde Burkhard Jung mit 51,6 Prozent der Stimmen zum Oberbürgermeister gewählt. 

[[Bild:bj_portrait.gif|thumb|Oberbürgermeister Burkhard Jung]]
{| class=&quot;prettytable&quot; 
 |-bgcolor=&quot;#dfdfdf&quot;
 ! Bewerber
 ! Partei
 ! Erster Wahlgang
 ! Zweiter Wahlgang
 |-
 | [[Burkhard Jung]] || [[Sozialdemokratische Partei Deutschlands|SPD]] ||    41,6    ||    51,6 
 |-
 | [[Uwe Albrecht]] || [[Christlich Demokratische Union Deutschlands|CDU]] ||    32,7    ||    44,0
 |-
 | Dietmar Pellmann || [[Die Linkspartei.|PDS]] ||    15,5    ||    nicht mehr angetreten
 |-
 | [[Michael Weichert]] || [[Bündnis_90/Die_Grünen|Grüne]] ||    6,1    ||    nicht mehr angetreten
 |-
 | Benedict Rehbein || [[Einzelbewerber]] ||    2,4    ||    3,0
 |-
 | Bernd-Rüdiger Kern || [[Deutsche Soziale Union|DSU]] ||    0,9    ||    nicht mehr angetreten
 |-
 | Karsten Werner || [[Bürgerrechtsbewegung Solidarität|BüSo]] ||    0,8    ||    1,5
 |}
Die Wahlbeteiligung betrug 31,7 % (34,9 %) gegenüber 43,9 % im Jahr 2005.

=== Wappen ===
[[Bild:Stadtwappen Leipzig.svg|thumb|110px|left|Stadtwappen der Stadt Leipzig]]
Das [[Wappen]] der Stadt Leipzig zeigt in gespaltenem Schild, vorn in Gold einen rot gezungten und bewehrten schwarzen steigenden Löwen; hinten in Gold zwei blaue Pfähle. Der Löwe der [[Markgrafschaft Meißen|Markgrafen zu Meißen]] und die sogenannten „[[Landsberger Pfähle]]“ des Markgrafen von [[Landsberg (Saalkreis)|Landsberg]] sind alte [[Wettiner|wettinische]] Wappenbilder, die auf die Einbindung der Stadt Leipzig ins mittelalterliche [[Kurfürstentum Sachsen|Kursachsen]] verweisen. Nachweisen lässt sich das heutige Wappen erstmals 1468 als Siegel, auf denen vorher (um 1287) nur eine Burg bzw. eine Burg mit dem Löwen der Markgrafen zu sehen war. 

Im Volksmund des 17. Jahrhunderts erzählte man sich übrigens folgende Sage: der Löwe habe einst in die andere Richtung geblickt und mit den Tatzen nach den Pfählen gegriffen, sei später aber „zur Strafe“ umgekehrt worden. Und wirklich: Auf Groschen des 15. Jahrhunderts wendet sich der Löwe den Pfählen zu.

Der Unterschied zum [[Dresden|Dresdner]] Wappen besteht lediglich in der [[Tingierung]] der Landsberger Pfähle, der zum [[Chemnitz|Chemnitzer]] und [[Delitzsch|Delitzscher]] Wappen in der Anordnung der Schilde – beim Wappen des [[Landkreis Leipziger Land|Leipziger Lands]] wurde dem Leipziger Wappen noch ein Fluss hinzugefügt.

Die Stadtfarben sind dem Wappen entsprechend blau-gelb.

=== Bundestag und Bundespolitik ===
Das Leipziger Stadtgebiet bedeckt zwei Wahlkreise vollständig. Diese sind der Wahlkreis 153 ''Leipzig I'' mit etwa 197.000 Wahlberechtigten und der Wahlkreis 154 ''Leipzig II'' mit etwa 203.000 Wahlberechtigten. Seit 1998 vertritt der Bundestagsabgeordnete [[Rainer Fornahl]] ([[Sozialdemokratische Partei Deutschlands|SPD]]) den Wahlkreis ''Leipzig I''. [[Gunter Weißgerber]] (SPD) vertritt den Wahlkreis ''Leipzig II''.

Der langjährige Oberbürgermeister Leipzigs, [[Wolfgang Tiefensee]], ist seit dem Jahr 2005 [[Bundesministerium für Verkehr, Bau und Stadtentwicklung|Bundesminister für Verkehr, Bau und Stadtentwicklung]] im [[Kabinett Merkel]]. Bereits nach den Wahlen im Jahr 2002 erhielt er von [[Gerhard Schröder]] ein Angebot für diesen Ministerposten, lehnte diesen aber mit der Begründung der Verbundenheit mit seiner Arbeit in Leipzig ab. Wolfgang Tiefensee ist gegenwärtig der ''Beauftragte der Bundesregierung für die neuen Bundesländer''.

=== Städtepartnerschaften ===
Leipzig unterhält mit 13 Städten eine [[Städtepartnerschaft]]:
{| style=&quot;background: #F5F5F5; padding:0em 1em 0em 1em;&quot;
| style=&quot;vertical-align:top&quot; |
| valign = &quot;top&quot; |
*[[Bild:Flag of Ukraine.svg|20px]] [[Kiew]], [[Ukraine]] – seit 1961, erneuert 1992
*[[Bild:Flag of Italy.svg|20px]] [[Bologna]], [[Italien]] – seit 1962, erneuert 1997
*[[Bild:Flag of Poland.svg|20px]] [[Krakau]], [[Polen]] – seit 1973, erneuert 1995
*[[Bild:Flag of the Czech Republic.svg|20px]] [[Brünn]], [[Tschechien]] – seit 1973, erneuert 1999
*[[Bild:Flag of France.svg|20px]] [[Lyon]], [[Frankreich]] - seit 1981
*[[Bild:Flag of Greece.svg|20px]] [[Thessaloniki]], [[Griechenland]] – seit 1984
*[[Bild:Flag of Lower Saxony.svg|20px]] [[Hannover]], [[Deutschland]] ([[Niedersachsen]]) – seit 1987
| valign = &quot;top&quot; |
*[[Bild:Flag of the People's Republic of China.svg|20px]] [[Nanjing]], [[Volksrepublik China]] – seit 1988
*[[Bild:Flag of Hesse.svg|20px]] [[Frankfurt am Main]], [[Deutschland]] ([[Hessen]]) – seit 1990
*[[Bild:Flag of the United Kingdom.svg|20px]] [[Birmingham]], [[Vereinigtes Königreich|Großbritannien]] – seit 1992
*[[Bild:Flag of the United States.svg|20px]] [[Houston (Texas)|Houston]], [[USA]] – seit 1993
*[[Bild:Flag of Bosnia and Herzegovina.svg|20px]] [[Travnik]], [[Bosnien und Herzegowina]] – seit 2003
*[[Bild:Flag of Ethiopia.svg|20px]] [[Addis Abeba]], [[Äthiopien]] – seit Dezember 2004
|}

== Wirtschaft und Infrastruktur ==
Vor dem Zweiten Weltkrieg war Leipzig neben seiner Bedeutung als Handelsplatz ([[Leipziger Messe]]) auch ein bedeutender Wirtschaftsstandort. Traditionell waren hier Verlagswesen und [[Druck (Reproduktionstechnik)|polygrafische]] Industrie, [[Gießerei]]en, Maschinenbau, [[Pelzindustrie]], [[Textilindustrie]] ([[Leipziger Baumwollspinnerei]], [[Buntgarnwerke Leipzig]]) und [[Klavier]]bau ([[Julius Blüthner Pianofortefabrik GmbH|Blüthner]], [[Ludwig Hupfeld AG|Hupfeld]], [[Wilhelm Schimmel Pianofortefabrik GmbH|Schimmel]]) ansässig. 

In der DDR-Zeit blieb Leipzig ein bedeutender Wirtschaftsstandort. Der [[Bezirk Leipzig]] trug 1972 9,3% zur DDR-Industrieproduktion bei. Neben den bereits erwähnten Wirtschaftszweigen wurde insbesondere der Braunkohleabbau, Energieerzeugung und die chemische Industrie südlich von Leipzig stark ausgebaut. Mit der Bildung von [[Kombinat]]en wurde Leipzig Sitz der Kombinate für Baumaschinen, komplette Anlagen und Erdbewegungsmaschinen ([[Baukema]]), Gießereianlagenbau und Gusserzeugnisse ([[Gisag]]), [[Kombinat Polygraph Werner Lamberz|polygraphischen Maschinenbau]], Rundfunk- und Fernsehtechnik ([[RFT]]), Technische Gebäudeausrüstung (TGA), Tagebauausrüstungen, Krane und Förderanlagen ([[TAKRAF]]) und Chemieanlagenbau ([[Chemieanlagenbau Leipzig-Grimma]], CLG). Die fruchtbaren Böden der [[Leipziger Tieflandsbucht]] im Leipziger Raum wurden intensiv [[landwirtschaft]]lich genutzt.

=== Kennzahlen === 

Gegenwärtig befinden sich in Leipzig 32.500 bei der Industrie- und Handelskammer gemeldete Unternehmen und etwa 3.700 Handwerksbetriebe (Stand 2005). Die Zahl der sozialversicherungspflichtig Beschäftigten betrug 2005 188.845, die Arbeitslosenquote 17,1&amp;nbsp;% (November 2006). Auf die Arbeitsplatzdichte von 377 Arbeitsplätzen je 1000 Einwohner wirkt ein Pendlersaldo von etwa 42.000. Das Bruttoinlandsprodukt betrug 2004 11.670 Millionen Euro, pro Einwohner (23.500 Euro) bzw. pro Beschäftigtem (42.500 Euro) liegt Leipzig damit im Hinterfeld der deutschen Großstädte. Hinsichtlich der Bilanz aus Gewerbean- und abmeldungen nimmt Leipzig in Deutschland jedoch einen Spitzenplatz ein. &lt;ref&gt;[http://www.leipzig.de/de/business/wistandort/zahlen/wirtschaft/index.aspx Wirtschaftzahlen von www.leipzig.de]&lt;/ref&gt;&lt;ref&gt;http://www.wissenstank.com/downloads/grossstadtvergleich/2006/Leipzig.pdf Großstadtvergleich (PDF)&lt;/ref&gt;

=== Öffentliche Investitionen und Subventionen ===

Wie in allen Städten und Gemeinden in den Neuen Bundesländern flossen hohe Summen staatlicher Gelder nach Leipzig. Die Struktur der Investionen und Förderungen unterscheiden sich dabei etwas. Vergleichsweise stark wurde die „unternehmensnahe Infrastruktur“ gefördert (Im Zeitraum 1990 bis 2005 etwa 750 Mio. Euro). Ob die Förderung für den [[Flughafen Leipzig-Halle]] als Infrastrukturförderung ausschließlich [[DHL]] dient, untersucht derzeit die EU-Kommission, da sie die Rechtmäßigkeit bezweifelt. Nach Darstellung der Leipziger Wirtschaftsförderung können Zuschüsse für die gewerbliche Wirtschaft auf Grund der Wirtschaftsstruktur in Leipzig hauptsächlich für Großinvestionen genutzt werden. Sie betrugen von 1990 bis 2005 etwa 650 Mio. Euro. Vergleichsweise wenig wurde für die Technologieförderung aufgebracht, sie summierte sich im Zeitraum 1990 bis 2005 auf 81 Mio. Euro. &lt;ref&gt;[http://www.leipzig.de/imperia/md/content/80_wirtschaftsfoerderung/download-bereich/wi-bericht2005/wirtschaftsfoerderung.pdf Bericht zur Wirtschaftsförderung (PDF)]&lt;/ref&gt;&lt;ref&gt;[http://www.leipzig.de/imperia/md/content/leipzigtouristservice_special/2006_mplan_anlagewirtschaftskraft.pdf Anlagewirtschaftskraft (PDF)]&lt;/ref&gt;

Leipzig liegt in einer „Ziel-1-Region“ des [[Europäischer Fonds für regionale Entwicklung|Europäischen Fonds für regionale Entwicklung]]. Im Zuge der EU-Osterweiterung erreichen die sächsischen Regionen die Fördergrenze, die sich am Bruttoinlandsprodukt je Einwohner relativ zum EU-Durchschnitt bemisst. Zum Nachteil von Leipzig könnte sich der Umstand entwickeln, dass die anderen sächsischen Großstädte durch strukturschwache Regionen wie dem [[Erzgebirge]] oder der [[Oberlausitz]] länger in einer „Ziel-1-Regionen“ verbleiben könnten. Die Förderregionen entsprechen den [[Sachsen#Regierungsbezirke|sächsischen Regierungsbezirken]].

=== Ansässige Unternehmen ===

[[Bild:Porsche Diamond.jpg|thumb|right|200px|Das ''„Diamant“'' genannte Hauptgebäude des Porsche-Werks in Leipzig]]

Mit der Wende brach, wie in fast allen Regionen der ehemaligen DDR, nahezu die gesamte Industrieproduktion zusammen. Nur wenige Unternehmen blieben nach der Privatisierung erhalten. Es bestehen weiterhin die Maschinenbauunternehmen [[Kirow Leipzig AG]] (ein Hersteller von mobilen Kränen), die [[TAKRAF]] (ein Tochterunternehmen von [[MAN]] und Hersteller von Tagebauausrüstung und -einrichtungen) und [[Gebrüder Brehmer]] (ein Tochterunternehmen der [[Heidelberger Druckmaschinen]] und Hersteller von Buchheftmaschinen). Von den Klavierherstellern besteht noch die [[Julius Blüthner Pianofortefabrik GmbH|Julius Blüthner Pianofortefabrik]].

Nach der Wende gelangen aber auch einige große Industrieansiedlungen, darunter [[Siemens AG|Siemens]], [[Porsche]] und [[BMW]]. Mit der Ansiedlung der beiden letzteren konnte sich die Stadt als neuer Automobilstandort etablieren. 2005 stiegen die [[Leipziger Verkehrsbetriebe]] in den Schienenfahrzeugbau ein. Ein Tochterunternehmen baut seitdem die Straßenbahn [[Leoliner]], die sich mit einem konkurrenzfähigen Preis und ihrer Robustheit vor allem den osteuropäischen Markt erschließen soll.

Der umsatzstarke Energieversorger [[Verbundnetz Gas AG]], der für Stadtwerke und kommunale Energieversorger Erdgas transportiert bzw. bereitstellt, hat in Leipzig seinen Sitz. Auch Unternehmen der Kommunikations- und Informationstechnologien wie die [[PC-Ware|PC-Ware AG]] oder der überregionale Kabelnetzbetreiber [[Primacom|Primacom AG]] mit seiner größten ostdeutschen Niederlassung sind in Leipzig beheimatet. Im Medienbereich ist neben zahlreichen kleineren Film- und Fernsehproduktionen eines der größten deutschen Filmunternehmen, die [[Kinowelt GmbH]], in Leipzig ansässig. Neben [[Frankfurt am Main]], [[München]] und [[Stuttgart]] gilt Leipzig darüber hinaus als überregional bedeutsamer Banken- und Finanzstandort. In der Stadt wird mit der [[European Energy Exchange]] (EEX) die größte Energiebörse Kontinentaleuropas betrieben. 

Im Herbst 2006 stellte [[Amazon.com|Amazon]] sein zweites und größtes deutsches Logistikzentrum fertig. Ab 2008 geht das internationale Luftdrehkreuz der Post-Frachttochter [[DHL]] in Betrieb, das bisher in [[Brüssel]] beheimatet war. Damit sollen 3.500 Arbeitsplätze direkt am [[Flughafen Leipzig/Halle|Flughafen]] entstehen und schätzungsweise 7.000 in der näheren Umgebung. 

Auch der Gesundheitssektor spielt in Leipzig eine tragende Rolle. Das älteste Krankenhaus und größte unter städtischer Verwaltung ist das [[Klinikum St. Georg]], welches bereits 1213 urkundlich erwähnt und 1432 von der Stadt übernommen wurde. Es beschäftigt heute etwa 2.300 Mitarbeiter und dient neben dem Universitätsklinkum mit seinen 3.000 Mitarbeitern auch als Lehrkrankenhaus. Durch das am Standort vorhandene Know-How der Leipziger Universitätsklinik in Forschung und Praxis haben auch mehrere private Klinikbetreiber investiert. Mit dem [[Herzzentrum Leipzig]] in Trägerschaft der [[Rhön-Klinikum AG]], das etwa 1.000 Mitarbeiter beschäftigt, können beispielsweise durch enge Kooperation mit der Uni-Klinik umfangreiche [[Synergie|Synergien]] genutzt werden. Zur Ansiedlung von Unternehmen der Biotechnologie wurde 2003 am Rande des alten Messegeländes die [[BioCity Leipzig]] errichtet. Hier befinden sich das Biotechnologisch-Biomedizinische Zentrum der Universität Leipzig sowie verschiedene Unternehmen, unter anderem die [[VITA 34]] – Europas erste und größte [[Nabelschnurblut]]bank.

Leipzig ist ein bekanntes Ziel für [[Städtereise]]n und besitzt eine ausgebaute touristische Infrastruktur. Im Jahr 2005 übernachteten etwa 1,7 Mio. Besucher in den 92 Beherbergungsbetrieben. Die 42 Hotels mit insgesamt knapp 8000 Betten waren dabei in etwa 50% ausgelastet. Der Umsatz im Gastgewerbe und die zusätzlichen Umsätze durch Gäste in der Stadt betrugen 1,1 Mrd. Euro und wurden hauptsächlich durch Tagesgäste erzielt. Sowohl im nationalen als auch im internationalem Rahmen wuchs die Tourismuswirtschaft in den letzten Jahren stark.

=== Leipziger Messe ===
[[Bild:Leipzig_Neue_Messe.jpg|thumb|Das neue Gelände der Leipziger Messe]]
Die Stadt Leipzig ist über die Grenzen Deutschlands hinaus auch durch die [[Leipziger Messe]] bekannt. Sie gilt als eine der ältesten Messeplätze der Welt. Zum Frühjahr 1895 erfolgte die Umstellung von einer Waren- zur weltweit ersten Mustermesse. Während der Zeit des Bestehens der [[Deutsche Demokratische Republik|DDR]] waren die Frühjahrs- und Herbstmessen ein wichtiger Treffpunkt des Handels zwischen Ost und West. Mit der Wiedervereinigung wurden die beiden saisonalen Universalmessen durch Fachmessen abgelöst. Die Messegesellschaft steht seither national in  Konkurrenz mit vielen, oft erheblich größeren Standorten wie [[Deutsche Messe AG|Hannover]], [[Frankfurter Messe|Frankfurt]] oder [[Messe Düsseldorf GmbH|Düsseldorf]] und muss sich in einem engen Markt behaupten. Zu den wichtigsten Messen des Jahres zählen heute die [[Leipziger Buchmesse]] und die [[Automobil International]]. Mit der [[Games Convention]] konnte erstmals eine Messe etabliert werden, die in Europa Alleinstellungsmerkmale besitzt.

=== Medien ===
[[Bild:Leipzig MDR main building.jpg|thumb|MDR-Zentrale]]
Leipzig ist Hauptsitz des [[Mitteldeutscher Rundfunk|Mitteldeutschen Rundfunks]]  (MDR). Die Media City, ein Studiokomplex für Fernseh- und Filmproduktionen, an der der MDR beteiligt ist, befindet sich in unmittelbarer Nähe. Die [[Privatsender]] [[Radio PSR]], [[Energy Sachsen]], [[R.SA]] und [[Leipzig 91.3]], Deutschlands erstes lizenziertes Universitätsradio [[Mephisto 97.6]] und das [[Freies Radio|Freie Radio]] [[Radio Blau]] produzieren hier ihr Programm. Mit [[Leipzig Fernsehen]] sendet ein lokaler Fernsehsender sein Programm aus der Messestadt. 

Die [[Leipziger Volkszeitung]] erscheint als einzige regionale [[Tageszeitung]], produziert und gedruckt von der Leipziger Verlags- und Druckereigesellschaft. Das bedeutendste Leipziger Stadtmagazin ist der [[Kreuzer (Magazin)|Kreuzer]]. Außerdem erscheint regelmäßig [[REGJO]], das Regionaljournal für den Wirtschaftsraum Leipzig/Halle.

Leipzig ist zudem Sitz der [[Sächsische Landesanstalt für privaten Rundfunk und Neue Medien|Sächsischen Landesanstalt für privaten Rundfunk und Neue Medien]]. 

[[Bild:Haus_des_Buches_Leipzig_Buchwand.jpg|thumb|left|220px|Buchwand im Haus des Buches, bei der Bücher statt Steinen verwendet wurden.]]
Leipzig ist traditioneller Sitz vieler [[Verlag]]e, darunter der [[Evangelische Verlagsanstalt|Evangelischen Verlagsanstalt]] oder der [[Benedictus Gotthelf Teubner|Teubnerschen Verlagsbuchhandlung]]. Weiterhin finden sich hier Niederlassungen des ''Auer Verlags'', der [[R. Brockhaus Verlag GmbH &amp; Co.KG]], des [[Insel-Verlag]]s und des [[tologo verlag|tologo verlages]]. Dennoch ist von der ehemaligen Buchstadt, als die Leipzig einst weltweit berühmt war, nach der Wende 1990 nur wenig geblieben. Viele Verlage mussten schließen oder wurden verlegt. Ein jüngeres Beispiel hierfür ist der [[Reclam-Verlag]], der 1828 in Leipzig gegründet wurde, aber im Frühjahr 2006 komplett in das [[Stuttgart]]er Reclam-Verlagshaus integriert wurde. Lediglich die renommierte Buchreihe ''Reclam-Leipzig'' bleibt als Marke erhalten. &lt;br/ &gt;Die Stadt Leipzig verleiht seit 1959 den [[Gutenberg-Preis der Stadt Leipzig]] für besondere Leistungen in der Buchkunst.

=== Öffentliche Einrichtungen ===
Die Stadt Leipzig ist [[Sitz (juristische Person)|Sitz]] verschiedener Einrichtungen und Institutionen beziehungsweise [[Körperschaft des öffentlichen Rechts|Körperschaften des öffentlichen Rechts]].

[[Bild:Leipzig Reichsgericht.jpg|thumb|Reichsgerichtsgebäude (heute Sitz des [[Bundesverwaltungsgericht (Deutschland)|Bundesverwaltungsgerichtes]]) ]]
Das [[Bundesverwaltungsgericht (Deutschland)|Bundesverwaltungsgericht]] wurde am 26. August 2002 von [[Berlin]] nach Leipzig verlegt und hat seinen Sitz im [[Reichsgerichtsgebäude]]. Auch der 5. Strafsenat des [[Bundesgerichtshof]]s ist in Leipzig angesiedelt. Die [[Bundesnetzagentur|Bundesnetzagentur für Elektrizität, Gas, Telekommunikation, Post und Eisenbahnen]] unterhält eine Außenstelle in Leipzig. Die Hauptverwaltung der [[Deutsche Bundesbank|Deutschen Bundesbank]] für die Freistaaten [[Sachsen]] und [[Thüringen]] ist ebenfalls in Leipzig beheimatet.

Die [[Sächsische Akademie der Wissenschaften]] wurde als wissenschaftliche Organisation 1846 in Leipzig gegründet und hat hier bis heute am Standort der Sächsischen Landesuniversität ihren Sitz.
 
Die [[Sächsische Landesbank]] und die [[Sparkasse]] Leipzig, die für die Stadt Leipzig und die Landkreise [[Landkreis Delitzsch|Delitzsch]], [[Landkreis Leipziger Land|Leipziger  Land]] und [[Landkreis Torgau-Oschatz|Torgau-Oschatz]] zuständig ist, sind die wichtigsten öffentlichen Einrichtungen auf dem Finanzsektor.

Leipzig hat ein [[Zollamt|Hauptzollamt]]. Weitere öffentliche Einrichtungen sind die [[Handwerkskammer]], die [[IHK]] und das [[Kreiswehrersatzamt]] Leipzig.

=== Städtebau ===
Leipzig verfügt noch über einen beträchtlichen Teil der Vorkriegsbebauung, die zwischen 1919 und 1945 und während der [[Gründerzeit]], insbesondere um die Jahrhundertwende, entstand. Diese kompakten Altbauviertel wurden zu DDR-Zeiten vernachlässigt und verfielen. Stattdessen setzte man zwischen 1960 und 1980 auf Großsiedlungen, wie [[Grünau (Leipzig)|Grünau]] und [[Paunsdorf]], die ca. 40 Prozent der nach 1945 in Leipzig entstandenen Wohnungen ausmachen. Eine Umstellung der Wohnungsbaupolitik in Richtung auf den Grundsatz der „Stadterneuerung im Bestand“ hat nun die großflächige Restaurierung der Gründerzeitquartiere zum Ziel. Leipzig stand 1990 vor dem Problem, dass 196.000 der 257.000 Wohnungen sanierungsbedürftig waren. In den Gründerzeitvierteln waren davon 103.000 Wohnungen betroffen. Ein Großteil der Quartiere in [[Plagwitz (Leipzig)|Plagwitz]], [[Reudnitz (Leipzig)|Reudnitz]] und [[Connewitz]] war baufällig und drohte einzustürzen. Die Dächer waren nur notdürftig repariert, mehrere Straßenzüge komplett und dauerhaft eingerüstet, um Passanten vor herabfallenden Gebäudeteilen zu schützen. Mit der politischen Wende in der DDR nahmen sich die Medien dieses Problems an. Das [[DDR-Fernsehen]] sendete im November 1989 die aufsehenerregende Reportage „Ist Leipzig noch zu retten?“, die den Verfall Leipzigs am Beispiel des Stadtteils Plagwitz ungeschminkt darstellte.&lt;ref name=&quot;Städtbaubericht_Leipzig_k1&quot;&gt;[http://www.leipzig.de/imperia/md/content/61_Stadtplanungsamt/1.pdf Stadtentwicklungsplan Wohnungsbau und Stadterneuerung; Kapitel 1]&lt;/ref&gt;
[[Bild:Leipzig Palais Roßbach.jpg|thumb|Prunkvolles Gründerzeithaus von [[Arwed Roßbach]] aus dem Jahre 1892 im Musikviertel]]

Insgesamt konzentriert sich die Stadterneuerung im Bereich der Gründerzeitbebauung auf 13 Gebiete mit 464 Hektar und 29.000 Wohnungen.&lt;ref name=&quot;Städtbaubericht_Leipzig_k1&quot;&gt;&lt;nowiki&gt;[http://www.leipzig.de/imperia/md/content/61_Stadtplanungsamt/1.pdf Stadtentwicklungsplan Wohnungsbau und Stadterneuerung; Kapitel 1]&lt;/nowiki&gt;&lt;/ref&gt; Ein Beispiel dafür ist das zwischen der Innenstadt und dem [[Rosental (Leipzig)|Rosenthal]] gelegene ''Waldstraßenviertel''. Es ist heute eines der wenigen vollständig erhaltenen Gründerzeit-Wohngebiete in Deutschland. Auf einer Fläche von über 100 Hektar sind von 845 Gebäuden 626 als Einzeldenkmal ausgewiesen. Für ihre Strategie zum Erhalt dieses Ensembles erhielt die Stadt beim Bundeswettbewerb vom [[Bundesministerium für Raumordnung, Bauwesen und Städtebau]] 1994 eine Goldmedaille. 

Auch ein Großteil der übrigen Altbausubstanz wurde saniert. Direkte und indirekte staatliche Fördermodelle wie Investitionszulagen und Sonderabschreibungen trieben den Sanierungsprozess dabei  wesentlich voran. Der Anteil des Wohnungsneubaus blieb dabei im Vergleich zur Zahl der Sanierungen von Altsubstanz sehr gering. Mit einer einsetzenden Suburbanisierung in neu entstandene Einfamilienhaussiedlungen und der überregionalen Abwanderung in den 1990er Jahren führte dies aufgrund fehlender Lenkungsmaßnahmen zu einem großen Überhang an Wohnraum. Der Leipziger Wohnungsmarkt ist dadurch heute stark gesättigt. Investitionen in verbliebene unsanierte Objekte verringerten sich entsprechend der Marktsituation erheblich und erfolgten seitdem nun wesentlich gezielter meist in den attraktiveren Wohnlagen, die aufgrund der dort höhere Wohnraumnachfrage höhere Grundmieten ermöglichen. Diese grundsätzliche Bevorzugung gegenüber unattraktiveren Gebieten ist nach wie vor erkennbar, obwohl das Investitionspotenzial in den attraktiveren Viertel mit einem hohen Sanierungsstand nahezu ausgeschöpft ist.&lt;ref name=&quot;Städtbaubericht_Leipzig_k5&quot;&gt;[http://www.leipzig.de/imperia/md/content/61_Stadtplanungsamt/5.pdf Stadtentwicklungsplan Wohnungsbau und Stadterneuerung; Kapitel 5]&lt;/ref&gt; Daraus resultierend ist seit 1997 eine heterogene Entwicklung zwischen attraktiveren Standorten und solchen Altbauvierteln erkennbar, die in ihrer Entwicklung und Erneuerung zurückbleiben.&lt;ref name=&quot;Städtbaubericht_Leipzig_k1&quot;&gt;&lt;nowiki&gt;[http://www.leipzig.de/imperia/md/content/61_Stadtplanungsamt/1.pdf Stadtentwicklungsplan Wohnungsbau und Stadterneuerung; Kapitel 1]&lt;/nowiki&gt;&lt;/ref&gt; Stehen von den gründerzeitlichen Wohnungen, die saniert wurden, etwa 23 Prozent leer, so bleiben von den unsanierten Wohnungen 71 Prozent unbewohnt.&lt;ref name=&quot;Städtbaubericht_Leipzig_k2&quot;&gt;[http://www.leipzig.de/imperia/md/content/61_Stadtplanungsamt/2.pdf Stadtentwicklungsplan Wohnungsbau und Stadterneuerung; Kapitel 2]&lt;/ref&gt; 

Aufgrund ihrer höheren baulichen und architektonischen Qualität und der oftmals besseren Lage werden die sanierten Altbaustandorte auch den nunmehr ebenfalls größtenteils sanierten Großwohnsiedlungen vorgezogen. Dies führt zu einer beginnenden Verödung der Neubauviertel in [[Plattenbau]]weise. Dort wird versucht mit teilweisem Rückbau und Umfeldaufwertungen eine Gesundung der Immobilienstruktur in der Stadt zu erreichen.

=== Bildung und Forschung ===
[[Bild:Auerbachs_Keller.JPG|thumb|Faust-Szene vor Auerbachs Keller (Ort des Fassrittes in Goethes Faust I) in der Mädlerpassage]]
==== Universität Leipzig ====
Die 1409 gegründete [[Universität Leipzig]] (''Alma Mater lipsiensis'') ist die zweitälteste [[Universität]] auf dem Gebiet der heutigen Bundesrepublik Deutschland. 1953 wurde sie in [[Karl Marx|Karl-Marx]]-Universität umbenannt, erhielt 1991 aber wieder ihren alten bzw. keinen Namen. Anfang der 1990er Jahre wurde nach der Abwicklung der [[Deutsche Hochschule für Körperkultur und Sport|Deutschen Hochschule für Körperkultur]] (DHfK) als Ersatz eine Sportfakultät gegründet und die ehemalige ''Pädagogische Hochschule „Clara Zetkin“'' angeschlossen. Die Universität hat heute 14 [[Fakultät]]en und einige angeschlossene Institute wie das [[Herder-Institut (Leipzig)|Herder-Institut]] und das aus dem [[Johannes R. Becher]]-Institut der DDR hervorgegangene [[Deutsches Literaturinstitut Leipzig|Deutsche Literaturinstitut (DLL)]]. An dieser im deutschsprachigen Raum einmaligen Lehranstalt werden in einem künstlerischen Studiengang Schriftsteller ausgebildet. 

An der Leipziger Universität wurden einige bahnbrechende Forschungsleistungen erzielt. Hier unterrichteten unter anderem die [[Nobelpreis]]träger [[Werner Heisenberg]], [[Gustav Hertz]], [[Nathan Söderblom]] und [[Wilhelm Ostwald]] sowie der Begründer der experimentellen Psychologie [[Wilhelm Wundt]]. In den Fächern [[Soziologie]] und [[Psychologie]] wurde hier die so genannte [[Leipziger Schule]] begründet.

Prominente Studenten an der Universität waren unter anderem [[Georgius Agricola]], [[Tycho Brahe]], [[Johann Gottlieb Fichte]], [[Johann Wolfgang Goethe]],  [[Edvard Grieg]], [[Ulrich von Hutten]], [[Erich Kästner]], [[Gottfried Wilhelm Leibniz]], [[Gotthold Ephraim Lessing]], [[Karl Liebknecht]], [[Thomas Müntzer]], [[Friedrich Nietzsche]], [[Novalis]], [[Ferdinand de Saussure]], [[Robert Schumann]], [[Johann Gottfried Seume]], [[Georg Philipp Telemann]] und [[Richard Wagner]].

==== Hochschulen ====
[[Bild:HGB-Waechterstrasse.jpg|thumb|Hochschule für Grafik und Buchkunst]]
Die [[Hochschule für Grafik und Buchkunst Leipzig]] wurde bereits 1764 als Akademie für Malen, Zeichnen und Architektur gegründet. Einer ihrer berühmtesten Studenten war [[Johann Wolfgang Goethe]]. 1901 wurde die Akademie in ''Königliche Akademie für graphische Künste und Buchgewerbe'' umbenannt. 1947 erhielt sie ihre heutige Ausprägung. Sie zählt zu den renommiertesten Kunsthochschulen Deutschlands. U. a. durch [[Neo Rauch]] wurde hier Ende der 1990er Jahre die nunmehr weltbekannte [[Leipziger Schule (Bildende Kunst)|Leipziger Schule]] begründet.

Die [[Hochschule für Musik und Theater „Felix Mendelssohn Bartholdy“ Leipzig]] entstand im Jahre 1843 als ''Leipziger Konservatorium'' und war die erste höhere musikalische Bildungsstätte in Deutschland. Einer ihrer Mitbegründer war [[Felix Mendelssohn Bartholdy]]. 1992 wurde durch die Eingliederung der [[Theaterhochschule Leipzig|Theaterhochschule „Hans Otto“]] das Ausbildungsprofil erweitert.

Die [[Handelshochschule Leipzig]] (HHL) wurde am 25. April 1898 gegründet und ist die älteste Wirtschaftshochschule Deutschlands.

==== Fachhochschulen und Institute ====
Die [[Hochschule für Technik, Wirtschaft und Kultur Leipzig ]] (HTWK) trägt seit 1992 ihren heutigen Namen und entstand aus der ''Technischen Hochschule Leipzig''. Letztere wurde 1977 durch die Zusammenlegung der ''Hochschule für Bauwesen Leipzig'', der ''Ingenieurhochschule Leipzig'', der ''Fachschule für Bibliothekare und Buchhändler'', der ''Fachschule für wissenschaftliches Bibliothekswesen'' sowie dem ''Institut für Museologie'' gebildet.

Die [[Fachhochschule der Deutschen Telekom |Hochschule für Telekommunikation, Leipzig (FH)]] ist eine [[Fachhochschule]] in privater Trägerschaft der [[Deutsche Telekom AG|Deutschen Telekom AG]] und wurde 1991 als „Fachhochschule der Deutschen Bundespost TELEKOM“ durch den Freistaat Sachsen staatlich anerkannt.

Leipzig beherbergt drei [[Max-Planck-Institut]]e (für [[Max-Planck-Institut für evolutionäre Anthropologie|evolutionäre Anthropologie]], [[Max-Planck-Institut für Kognitions- und Neurowissenschaften|Kognitions- und Neurowissenschaften]] und 
[[Max-Planck-Institut für Mathematik in den Naturwissenschaften|Mathematik in den Naturwissenschaften]]), das [[Fraunhofer-Institut für Zelltherapie und Immunologie]], das Fraunhofer Mittel- und Osteuropazentrum, das [[Leibniz-Institut für Troposphärenforschung]] (IfT), das [[Leibniz-Institut für Oberflächenmodifizierung]] (IOM) und das [[Leibniz-Institut für Länderkunde]] (IfL) sowie das [[Helmholtz-Zentrum für Umweltforschung]]. 
[[Bild:Deutsche Bücherei Leipzig-Luftaufnahme.jpg|thumb|300px|Deutsche Bücherei mit Bücherturm (links vorn). Am unteren Bildrand: MPI für evolutionäre Anthropologie]]
Weitere höhere Bildungseinrichtungen sind die ''AKAD Fachhochschule Leipzig'', die ''Hochschule für Kreativitätspädagogik'' (HfK) und die ''Studienakademie Leipzig'', eine Zweigstelle der [[Berufsakademie]] Sachsen.

==== Die Deutsche Bücherei ====
Die [[Deutsche Bücherei]] wurde 1912 in Leipzig gegründet. Seit 1990 ist sie Teil der  [[Nationalbibliothek]] „[[Die Deutsche Bibliothek]]“ (DDB), zu der auch die 1947 gegründete [[Deutsche Bibliothek]] in [[Frankfurt am Main]] und das 1970 gegründete [[Deutsches Musikarchiv|Deutsche Musikarchiv]] in Berlin gehören. Die drei Standorte erfüllen gemeinsam die gesetzlich festgelegten Aufgaben zum Sammeln, Erschließen und bibliografischen Verzeichnen der deutschen und deutschsprachigen Literatur ab 1913. Eine Außenstelle des Deutschen Musikarchivs wurde in der Deutschen Bücherei etabliert, da dort bereits vor 1990 vor allem Noten gesammelt wurden.

Da der momentane Bestand von über 13 Millionen Medieneinheiten täglich um über 1.200 ansteigt, wird im Jahr 2007 wird mit der Errichtung eines neuen Erweiterungsbaus begonnen. Dieser vergrößert die Bibliothek bis zur Semmelweissstraße und schafft so den benötigten zusätzlichen Platz. Im Zuge der Bauarbeiten wird auch der 1981 errichtete, 16 Etagen hohe Bücherturm saniert sowie ein kleiner Park in Richtung der Russischen Kirche angelegt.

=== Verkehr ===
Leipzig war durch die Lage an der Kreuzung der Fernstraßen [[Via Regia]] und [[Via Imperii]] bereits frühzeitig ein wichtiger [[Verkehrsknotenpunkt]]. Die [[Leipzig-Dresdner Eisenbahn|erste deutsche Fernbahnstrecke]] führte seit 1839 von Leipzig nach [[Dresden]]. Insbesondere durch die nach der politischen Wende investierten Mittel für die Modernisierung und den Ausbau der Fernstraßen-, Schienen- und Flugverkehrsanbindung kann Leipzig heute eine hervorragende Verkehrsinfrastruktur vorweisen.

==== Bahnanbindung ====
[[Bild:Leipzig-Hauptbahnhof-overview.jpg|thumb|300px|Leipzig Hauptbahnhof]]
Der 1915 eröffnete [[Leipzig Hauptbahnhof|Leipziger Hauptbahnhof]] ist hinsichtlich der Fläche der größte [[Kopfbahnhof|Kopfbahnhof]] [[Europa]]s und ein wichtiger [[Eisenbahnknoten]]punkt für den [[Personenverkehr]].
Es bestehen stündliche [[InterCityExpress|ICE]]-Verbindungen über [[Berlin]] nach [[Hamburg]], über [[Nürnberg]] nach [[München]], über [[Erfurt]] / [[Fulda]] nach [[Frankfurt am Main]] sowie  nach [[Dresden]]. Die Strecke in Richtung [[Hannover]] wird ebenfalls stündlich von [[InterCity|IC]]-Zügen bedient.
Zusätzlich zu seiner Bedeutung als Fernverkehrsbahnhof ist der [[Leipzig Hauptbahnhof|Leipziger Hauptbahnhof]] der wichtigste Knotenpunkt im Nahverkehr des Großraumes Leipzig.

Für den Güterverkehr gibt es Güterbahnhöfe in den Stadtteilen Wahren und Engelsdorf. Außerdem wurde in der Nähe des Schkeuditzer Kreuzes für den Warenumschlag zwischen Straße und Bahn ein großes Güterverkehrszentrum eingerichtet. Der Güterbahnhof in Stötteritz, auf welchem auch Container verladen wurden, ist geschlossen worden.

==== Öffentlicher Nahverkehr ====
[[Bild:Straßenbahn_Leipzig.jpg|thumb|Eine Straßenbahn des Typs NGT8 am Augustusplatz]]
Leipzig verfügt über ein engmaschiges Netz aus Straßenbahn-, S-Bahn- und Buslinien, welche das Stadtgebiet nahezu lückenlos bedienen.

Die seit dem 1. Januar 1917 bestehenden [[Leipziger Verkehrsbetriebe]] (LVB) unterhalten in der Stadt momentan insgesamt 14 Straßenbahn- und über 30 Buslinien. In den vergangenen Jahren erfolgten umfangreiche Ausbauarbeiten an ausgewählten Strecken, so zum Beispiel an den Linien 15 und 16. Es wurden jedoch auch einige weniger stark frequentierte Straßenbahn- durch Buslinien ersetzt; zuletzt im Januar 2006 die Straßenbahnlinie 18, die Linie 14 steht momentan ebenfalls zur Disposition. Insgesamt umfasst das Straßenbahnnetz 149,9 Kilometer. Die längste Linie im Leipziger Netz ist die Linie 11, die auf 22 Kilometern [[Schkeuditz]] mit [[Markkleeberg]]-Ost verbindet und dabei als einzige Leipziger Straßenbahnlinie in drei Tarifzonen des [[Mitteldeutscher Verkehrsverbund|Mitteldeutschen Verkehrsverbundes]] fährt.
An den zentralen Haltestellen „Hauptbahnhof“ bzw. „Hauptbahnhof, Westseite“ und „Goerdelerring“ verkehren die Straßenbahnlinien montags bis freitags im Tagesverkehr im Minutentakt.
Die LVB modernisieren seit Jahren ihren Fuhrpark. Hauptsächlich auf den Linien 15 und 16 verkehren die 45 Meter langen [[Gelenktriebwagen NGT12-LEI]] des Herstellers [[Bombardier Transportation]] aus [[Bautzen]]. Die Beschaffung von insgesamt 24 dieser Triebwagen ist nahezu abgeschlossen. Zudem werden in [[Lindenau (Leipzig)|Lindenau]] die neuen Bahnen des Typs „[[Leoliner]]“ gefertigt, welche vor allem auf den Linien 7 (in Traktion), 12 und 14 zum Einsatz kommen.


Seit 1969 besitzt Leipzig ein [[S-Bahn Leipzig-Halle|S-Bahn-Netz]]. Dieses besteht derzeit aus vier Linien, die vom Leipziger Hauptbahnhof ausgehen und diesen mit [[Grünau (Leipzig)|Grünau]], [[Wurzen]], [[Halle (Saale)]] und [[Borna]] verbinden. Es wird kein einheitlicher Takt gefahren, die Taktzeiten variieren von 20 bis zu 60 Minuten.

Mit Fertigstellung des [[City-Tunnel (Leipzig)|City-Tunnels]] im Jahr 2011 erhält Leipzig ein völlig neue ausgerichtetes S-Bahn-Netz, das bis in die angrenzenden Bundesländer [[Sachsen-Anhalt]] und [[Thüringen]] reichen soll. 

{| class=&quot;prettytable&quot; 
|- bgcolor=#DEDEDE
! !!Geplantes Liniennetz der [[S-Bahn Leipzig-Halle|Leipziger S-Bahn]] ab 2011
|-

! {{S-Bahn-Linie|S1|white|#977AAE|Black}}
| '''Leipzig Miltitzer Allee''' – Leutzsch - [[Gohlis (Leipzig)|Leipzig-Gohlis]] – '''[[City-Tunnel (Leipzig)|City-Tunnel]]''' - [[Bahnhof Leipzig-Stötteritz|Leipzig-Stötteritz]] - '''[[Wurzen]]'''
|-
! {{S-Bahn-Linie|S2|white|#008439|Black}}
| ('''[[Dessau]]''' / '''[[Lutherstadt Wittenberg]]''' -) '''[[Bitterfeld]]''' – [[Delitzsch]] – [[Leipziger Messe|Leipzig-Messegelände]] - '''[[City-Tunnel (Leipzig)|City-Tunnel]]''' - [[Connewitz]] - [[Markkleeberg]] – '''[[Gaschwitz]]'''
|-
! {{S-Bahn-Linie|S3|white|#E27FAB|Black}}
| '''[[Halle (Saale) Hauptbahnhof|Halle (Saale)]]''' – [[Schkeuditz]] – [[Gohlis (Leipzig)|Leipzig-Gohlis]] – '''[[City-Tunnel (Leipzig)|City-Tunnel]]''' - [[Bahnhof Leipzig-Stötteritz|Leipzig-Stötteritz]] - '''[[Wurzen]]'''
|-
! {{S-Bahn-Linie|S4|white|#A12F53|Black}}
| '''[[Torgau]]''' – [[Eilenburg]] – [[Taucha]] - Leipzig-Mockau - '''[[City-Tunnel (Leipzig)|City-Tunnel]]''' - [[Connewitz]] - [[Markkleeberg]] - [[Borna]] - '''[[Geithain]]'''
|-
! {{S-Bahn-Linie|S5|white|#EFA100|Black}}
| '''[[Halle (Saale) Hauptbahnhof|Halle (Saale)]]''' - [[Flughafen Leipzig/Halle]] - [[Leipziger Messe|Leipzig-Messegelände]] - '''[[City-Tunnel (Leipzig)|City-Tunnel]]''' - [[Connewitz]] - [[Markkleeberg]] - '''[[Altenburg]]''' (- '''[[Zwickau]]''')
|}

Der knapp vier Kilometer lange [[City-Tunnel (Leipzig)|City-Tunnel]] befindet sich seit 2003 im Bau. Er wird die komplette Innenstadt vom [[Leipzig Hauptbahnhof|Hauptbahnhof]] zum [[Leipzig Bayerischer Bahnhof|Bayerischen Bahnhof]] unterqueren und soll mehr als 571 Millionen [[Euro]] kosten. Es entstehen vier unterirdische Bahnhöfe (Hauptbahnhof tief, Markt, Leuschner-Platz, Bayrischer Bahnhof). Mit dem Bau wird erstmals eine durchgängige Nord-Süd-Achse hergestellt, die durch den nach Norden ausgerichteten Kopfbahnhof bisher nicht existiert. Die Anbindung an den Südraum Leipzigs wird dadurch stark verbessert. Damit ist eine erhebliche Zeitersparnis für den Zugverkehr Richtung Südsachsen und Bayern verbunden, da die Züge keine Umwege um ganz Leipzig mehr fahren müssen. Die Fertigstellung wird für 2011 erwartet.

==== Autobahnen und Bundesstraßen ====
An Leipzig führen mehrere [[Autobahn]]en vorbei: im Norden die [[Bundesautobahn 14|A 14]], im Westen die [[Bundesautobahn 9|A 9]] und im Süden die [[Bundesautobahn 38|A 38]]. Die drei Autobahnen bilden einen dreieckigen Teilring des Autobahndoppelringes ''[[Mitteldeutsche Schleife]]'' um Halle und Leipzig. In Richtung Süden ist außerdem die [[Bundesautobahn 72|A 72]] teilweise im Bau beziehungsweise in Planung. Weitere Aus- und Neubauplanungen gibt es auch Im Bereich der Bundesstraßen. So wird derzeit eine neue Schnellstraße B 87n von Leipzig nach [[Torgau]] (als Ersatz [[Bundesautobahn 16|A 16]]) geplant. Hier ist jedoch der genaue Trassenverlauf noch nicht festgelegt. Auch die B 181 nach [[Merseburg]] soll neu trassiert werden. 

Durch die Stadt führen die Bundesstraßen [[Bundesstraße 2|B 2]], [[Bundesstraße 6|B 6]], [[Bundesstraße 87|B 87]], [[Bundesstraße 95|B 95]], [[Bundesstraße 181|B 181]], [[Bundesstraße 184|B 184]] und [[Bundesstraße 186|B 186]].

Quellen: [[Bundesministerium für Verkehr, Bau und Stadtentwicklung]], [[ADAC]]

==== Flughäfen ====
Im Einzugsgebiet von Leipzig befinden sich zwei Flughäfen: der Flughafen Leipzig/Halle und der Flughafen Altenburg-Nobitz. 

Der [[Flughafen Leipzig/Halle]] fungiert als internationaler Verkehrsflughafen für die gleichnamige Region. Er befindet sich am [[Schkeuditzer Kreuz]] nordwestlich von Leipzig auf halber Strecke zwischen den beiden Großstädten und verfügt über eine direkte Autobahnanbindung. Durch den östlichsten Abschnitt der im Bau befindlichen [[Neubaustrecke Erfurt–Leipzig/Halle]] erhielt der Flughafen einen [[Fernbahnhof]], der mit Fertigstellung der Eisenbahnstrecke im Jahr 2015 auch in das [[InterCityExpress|ICE-Netz]] eingebunden wird.

Angeflogen werden die großen deutschen Drehkreuzflughäfen, europäische Metropolen, Ferienziele vor allem im Mittelmeerraum und Nordafrika sowie einige Interkontinentalziele. Zunehmende Bedeutung erlangt der Flughafen auch im Frachtverkehr. [[DHL]] nimmt 2008 sein europäisches Hauptdrehkreuz in Leipzig/Halle in Betrieb. Auch [[Lufthansa Cargo]] beabsichtigt, seine derzeit in Köln/Bonn und Brüssel beheimateten Transportflugzeuge nach Leipzig/Halle umziehen zu lassen. &lt;ref&gt;http://www.welt.de/welt_print/article767638/Lufthansa_Cargo_und_DHL_ruecken_enger_zusammen.html&lt;/ref&gt; Mittlerweile gibt es zudem zwei direkte Frachtlinien nach China.

Der [[Flughafen Altenburg-Nobitz]] in [[Thüringen]] liegt etwa 50 km südlich von Leipzig unweit der Städte Gera, Zwickau und Chemnitz. Dieser [[Regionalflughafen]] wird im Linienverkehr ausschließlich durch die [[Billigfluggesellschaft]] [[Ryanair]] bedient.

==== Wasserwege ====
In der ersten Hälfte des 20. Jahrhunderts wurde der Bau des [[Elster-Saale-Kanal]]s, der [[Weiße Elster]] und [[Saale]] verbinden sollte, begonnen, um Leipzig an das [[Wasserstraße]]nnetz anzuschließen. Der Ausbruch des [[Zweiter Weltkrieg|Zweiten Weltkrieges]] stoppte die Arbeiten. Der [[Lindenauer Hafen]] war zwar fast fertiggestellt, aber noch nicht an Elster-Saale- und Karl-Heine-Kanal angeschlossen worden. Die Leipziger Flüsse ([[Weiße Elster]], [[Luppe (Fluss)|Luppe]], [[Pleiße]], [[Parthe]]) haben im Stadtraum größtenteils künstliche Flussbette und werden durch einige Kanäle ([[Karl-Heine-Kanal]]) ergänzt. Diese Wasserwege eignen sich nur für den Sportbootverkehr.

Durch die Anlage und Sanierung vorhandener Gräben und [[Fließgewässer]] im Süden der Stadt und die Verbindung gefluteter [[Tagebaurestloch|Tagebaurestlöcher]] soll ein Gewässerverbund entstehen. Zwischenzeitlich war auch immer wieder ein finaler Durchstich zwischen Karl-Heine-Kanal und dem Hafenbecken, sowie die Fertigstellung des Elster-Saale-Kanals geplant, zuletzt während der Olympiabewerbung. Ein solcher Schritt würde es Sportbooten ermöglichen, von Leipzig bis zur [[Elbe]] zu gelangen. Die Pläne wurden allerdings auf Grund der nicht vertretbaren Kosten-Nutzen-Relation wieder verworfen.

== Kultur und Sehenswürdigkeiten ==

=== Sprache ===
In Leipzig wird vorwiegend [[osterländisch]] gesprochen. Dieser Dialekt gehört zur [[Thüringisch-Obersächsische Dialektgruppe|thüringisch-obersächsischen Dialektgruppe]] und stellte vor einigen hundert Jahren, als Sprache [[Martin Luther|Martin Luthers]], den Vorreiter für das spätere [[deutsche Sprache|Hochdeutsch]] dar. Das breit gesprochene Leipziger Sächsisch symbolisiert seine meist gemütliche, freundliche Art. Das echte Leipziger Sächsisch ist oft in den Vorstädten zu hören, in den vielen Kaffeehäusern der Innenstadt, aber auch in den zahlreichen Kabarettbühnen Leipzigs. Ein über die Grenzen Sachsens bekanntes Lied in Leipziger Sprache war „Sing, mei Sachse, sing“ des Kabarettisten [[Jürgen Hart]]. Die Leipziger Kabarettbühnen bieten regelmäßig Programme in sächsischer Sprache, beispielsweise die bekannten [[Academixer]] sowie [[Bernd-Lutz Lange]] und [[Gunter Böhnke]] mit ihren Bühnenpartnern.

=== Theater ===
[[Bild:Leipziger_oper.jpg|thumb|Leipziger Oper (zum Opernball am 30. Oktober 2004)]]
Die [[Opernhaus Leipzig|Oper Leipzig]] blickt auf eine dreihundertjährige Tradition. Das heutige Gebäude wurde 1960 am [[Augustusplatz]] fertiggestellt. Die [[Musikalische Komödie]] (MuKo) im ''Haus Dreilinden'' in [[Lindenau (Leipzig)|Lindenau]], welche heute zur Oper Leipzig gehört, hat eine auf das Jahr 1713 zurückgehende Geschichte. Hier werden [[Operette]] und [[Musical]] gepflegt.

Das [[Schauspiel Leipzig]] verfügt über mehrere Spielstätten. Neben dem großen ''Schauspielhaus'' gehören noch kleinere Spielstätten wie das ''Theater hinterm Eisernen'' und die ''Neue Szene'' zum kommunalen Theaterbetrieb. Darüber hinaus gibt es in Leipzig eine lebendige Off-Theater-Szene mit vielen kleineren Spielstätten, die sich mit Künstlern anderer Genres in der Interessengemeinschaft [[Freie Szene Leipzig]] zusammengeschlossen haben. Das Kinder- und Jugendtheater hat in Leipzig eine lange Tradition. Hauptträger ist das [[Theater der Jungen Welt]], darüber hinaus gibt es einige Puppen- und Marionettentheater.

Leipzig ist eines der Zentren der deutschsprachigen [[Kabarett]]-, [[Varieté]]- und [[Kleinkunst]]szene. Hier gibt es pro Kopf die höchste Kabarettdichte in Deutschland. Über Leipzig hinaus bekannt sind die  [[Pfeffermühle]] und die [[Academixer]]. Aber auch kleinere Bühnen bieten Kabarett auf hohem Niveau.

=== Orchester und Chöre ===
Die Zahl hochklassiger Orchester und Chöre ist ein Ergebnis der jahrhundertlangen Musiktradition Leipzigs.

==== Orchester ====
[[Bild:Johann_Sebastian_Bach-Denkmal.JPG|thumb|[[Neues Bach-Denkmal in Leipzig|Johann-Sebastian-Bach-Denkmal]]]]
Das [[Gewandhausorchester Leipzig]] ist ein international renommiertes Orchester. Als ältestes bürgerliches Konzertorchester Deutschlands wurde es 1781 gegründet. Hauptspielstätte ist das [[Gewandhaus (Leipzig)|Gewandhaus]]. Chefdirigenten waren unter anderem [[Felix Mendelssohn Bartholdy]], [[Wilhelm Furtwängler]], [[Václav Neumann]], [[Kurt Masur]] und [[Herbert Blomstedt]], heute hat [[Riccardo Chailly]] das Amt des Gewandhauskapellmeisters inne. Das ''Neue Bachische Collegium Musicum zu Leipzig'' (NBCM) wurde 1979 aus dem Gewandhaus heraus gegründet. Als „historisches Bachorchester“ kombiniert es moderne Instrumente und „historische“ Spielweise. Seit 2003 wird das NBCM von [[Albrecht Winter]] geleitet.

Das [[MDR Sinfonieorchester]] wurde 1924 als ''Leipziger Sinfonieorchester'' gegründet. Es trat dabei die Nachfolge des seit 1915 existierenden Orchesters des Konzertvereins an. 1925 wurde es von der damaligen Mitteldeutschen Rundfunk AG übernommen und als ''Rundfunk-Sinfonieorchester Leipzig'' weithin bekannt. Chefdirigent war unter anderem [[Herbert Kegel]], heute leitet [[Fabio Luisi]] das Orchester. Nach Gründung des [[Mitteldeutscher Rundfunk|MDR]] in den 1990er Jahren erhielt es seinen heutigen Namen.

Die ''Capella Fidicinia am Musikinstrumenten-Museum der Universität Leipzig'' wurde von Hans Grüß 1957 gegründet. Das Kammerorchester spielt Werke alter Meister auf Originalinstrumenten. Das ''Akademisches Orchester Leipzig'' wurde 1954 von Horst Förster an der Universität Leipzig gegründet, welcher es bis heute leitet. Es gibt jährlich 6 „Akademische Konzerte“ im großen Saal des Gewandhauses. Das [[Leipziger Universitätsorchester]] entstand 2003 als ''Leipziger studentisches Orchester''. Es ist studentisch besetzt und gibt ein großes Sinfoniekonzert pro Semester sowie Kammermusikabende.

Das ''Pauliner Kammerorchester'' wurde 1992 gegründet und stand bis 2004 unter der Leitung von [[Wolfgang Unger]]. Es steht dem Universitätschor mit modernen Instrumenten zur Verfügung. Das ''Pauliner Barockensemble'' wurde 1994 aus dem Pauliner Kammerorchester heraus gegründet und musiziert ausschließlich auf historischem Instrumentarium.

Das [[Leipziger Streichquartett]] wurde 1988 von damaligen Studenten der Leipziger [[Hochschule für Musik und Theater „Felix Mendelssohn Bartholdy“ Leipzig|Hochschule für Musik und Theater]] und späteren Mitgliedern des Gewandhausorchesters gegründet. Es ist heute ein international anerkannter Bestandteil der Kammermusikszene.

==== Chöre ====
Der weltberühmte [[Thomanerchor]] wurde 1212 zusammen mit der [[Thomasschule]] für 12 Knaben gegründet und 1519 vom Stadtrat übernommen. Thomaskantor war unter anderem [[Johann Sebastian Bach]].

Der ''Gewandhauschor Leipzig'' wurde 1869 zur Uraufführung des ''Deutschen Requiems'' von [[Johannes Brahms]] gegründet und 1920 in den 1875 gegründeten Bach-Verein integriert. Seither trägt er seinen heutigen Namen.

Der ''MDR Rundfunkchor Leipzig'' entstand 1946 als Nachfolger des Leipziger Rundfunkchores. Der [[MDR Kinderchor]] wurde 1948 von [[Hans Sandig]] gegründet und zählt zu den bekanntesten Kinderchören Deutschlands. Er ist heute der einzige Kinderchor der [[ARD]] und wird von [[Gunter Berger]] geleitet.

Der [[Leipziger Universitätschor]] ging 1926 aus dem ''Madrigalkreis Leipziger Studenten'' hervor. Sein Leiter ist der Universitätsmusikdirektor [[David Timm]]. Unter der Leitung des inzwischen verstorbenen [[Wolfgang Unger]] erhielt der Chor im Jahr 2001 den von der Deutschen Phono-Akademie vergebenen [[Echo Klassik|Echo-Klassik-Preis]].

Der 1962 von Oberkantor [[Werner Sander]] gegründete und seit 1972 von [[Helmut Klotz]] geleitete [[Leipziger Synagogalchor]] stellt sich der anspruchsvollen Aufgabe, synagogale Musik des 19. und 20. Jh. sowie jiddische und hebräische [[Folklore]] als besonders wertvollen Bestandteil des jüdischkulturellen Erbes nicht nur in Leipzig zu erhalten und zu pflegen.

=== Museen ===
Als alte Universitäts- und Messestadt mit einem wohlhabenden Bürgertum hat Leipzig eine große Anzahl bedeutender Sammlungen. Das 1837 durch den Leipziger Kunstverein gegründete [[Museum der bildenden Künste]] besitzt eine der eindrucksvollsten Bildersammlungen Deutschlands, die etwa 58.500 Exponate vom Spätmittelalter bis zur Moderne zeigt. Die 1990 gegründete [[Galerie für Zeitgenössische Kunst]] ergänzt dieses Angebot mit wechselnden Ausstellungen moderner Kunst.

Das [[Bach-Archiv]] Leipzig unterhält am [[Thomaskirche (Leipzig)|Thomaskirchhof]] ein Bach-Museum zu Ehren einer der bedeutendsten Persönlichkeiten der Stadt: Johann Sebastian Bach. Das [[Deutsches Buch- und Schriftmuseum|Deutsche Buch- und Schriftmuseum]] der [[Deutsche Bücherei|Deutschen Bücherei]] Leipzig ist das weltweit älteste Fachmuseum zur Buch-, Schrift- und Papierkultur. Das [[Museum für Druckkunst]] erinnert an die große Leipziger Tradition als Buchstadt.

Die Universität Leipzig besitzt eine Reihe bedeutender Sammlungen. Einige, wie das [[Ägyptisches Museum Leipzig|Ägyptische Museum]], das [[Antikenmuseum der Universität Leipzig|Antikenmuseum]] und das [[Musikinstrumentenmuseum]], sind permanent der Öffentlichkeit zugänglich. Anlässlich der [[Museumsnacht]] der Stadt Leipzig präsentiert die Universität auch ihre Lehrsammlungen einem breiten Publikum. Die [[Hochschule für Technik, Wirtschaft und Kultur Leipzig (HTWK)|HTWK]] unterhält ein Automatik-Museum.

[[Bild:Schillerhaus1.jpg|thumb|Das Schillerhaus in Gohlis]]
Das ''Stadtgeschichtliche Museum'' ist im Alten Rathaus beheimatet. Darüber hinaus besitzt es Nebenstellen mit dem ältesten Kaffeehaus Deutschlands [[Zum Arabischen Coffe Baum]], dem [[Schillerhaus (Leipzig)|Schillerhaus]], in dem Friedrich Schiller den Sommer 1785 verbrachte, dem 1977 gegründeten [[Sportmuseum Leipzig]] und dem  [[Völkerschlachtdenkmal]]. Das Wohn- und Sterbehaus des Komponisten Felix Mendelssohn Bartholdy ist als [[Mendelssohn-Haus]] der Öffentlichkeit zugänglich. Im  [[Schumann-Haus]] verlebten Robert und Clara Schumann ihre ersten vier Ehejahre. Das [[Zeitgeschichtliches Forum Leipzig|Zeitgeschichtliche Forum]] in der Innenstadt untersteht als Bundeseinrichtung dem [[Bundeskanzleramt (Deutschland)|Bundeskanzleramt]]. Es stellt die Geschichte Deutschlands vom Zweiten Weltkrieg bis zur Gegenwart mit Schwerpunkt auf der [[Geschichte der DDR]] dar. Die [[Gedenkstätte Museum in der „Runden Ecke“]] im ehemaligen Sitz der Bezirksverwaltung des [[Ministerium für Staatssicherheit|MfS]] arbeitet die Mechanismen des Repressionsapparats in der ehemaligen DDR auf.

[[Bild:Runde-Ecke-Leipzig.jpg|thumb|left|Gedenkstätte Museum in der „Runden Ecke“]]
Im Komplex des [[Grassimuseum]]s befinden sich neben dem Musikinstrumentenmuseum auch das [[Museum für Kunsthandwerk]] und das [[Museum für Völkerkunde zu Leipzig]]. Das [[Naturkundemuseum Leipzig]] besitzt eine große Sammlung an [[Dermoplastik]]en und ergänzt dieses Angebot durch wechselnde Sonderausstellungen zu Naturthemen. Das [[Deutsches Kleingärtnermuseum|Deutsche Kleingärtnermuseum]] befindet sich im Vereinshaus des 1864 gegründeten, weltweit ersten [[Kleingarten|Schrebergarten]]vereins.

=== Zoologischer Garten ===
[[Bild:ZooLeipzigPongoland.jpg|thumb|Pongoland]]
Der [[Zoo Leipzig|Zoologische Garten Leipzig]] ist eine 22,5  Hektar große parkartig gestaltete Grünanlage nordwestlich der Leipziger Altstadt, in der ca. 900 Tierarten gehalten und präsentiert werden. Sie grenzt an das [[Rosental (Leipzig)|Rosental]], einen Stadtpark.

Der Leipziger Zoo ist einer der traditionsreichsten Deutschlands mit vielen historischen Bauten und war einst berühmt für seine [[Löwe]]n- und später auch [[Tiger]]zucht, für die er seither das Internationale Zuchtbuch führt. Er beherbergt viele seltene Tierarten wie [[Baikalrobbe]]n, [[Moschushirsche|Moschustiere]] oder [[Okapi]]s. Die wöchentliche Doku-Soap [[Elefant, Tiger &amp; Co]] des [[Mitteldeutscher Rundfunk|MDR]] machte den Zoo seit 2002 in ganz Deutschland bekannt. Zum 1910 erbauten Aquarium gehören heute Landschaftsbecken sowie ein Ringbecken für [[Haie]]. Dem Aquarium angegliedert ist das neu entstandene Terrarium. Eine der charakteristischen Backsteinanlagen ist die Bärenburg. Sie war Schauplatz vieler Zuchterfolge, ist aber längst veraltet. Noch in den 1990er Jahren war der Zoo stark sanierungsbedürftig und entsprach kaum mehr moderner Tierhaltung. Aufgrund dieser Situation wird er seit einigen Jahren komplett umgebaut und künftig in Regionen eingeteilt. Der Startschuss war die Löwensavanne ''Makasi Simba'', weiterhin fertiggestellte Projekte sind die [[Lippenbär]]en&lt;nowiki&gt;anlage&lt;/nowiki&gt;, Tiger-Taiga und der Afrikanische Streichelzoo. Als bisher größtes Bauprojekt wurde die weltgrößte Menschenaffenanlage ''Pongoland'' eröffnet, die auch der Forschung des [[Max-Planck-Institut für evolutionäre Anthropologie|Max-Planck-Instituts für evolutionäre Anthropologie]] (EVA) dient. Hier leben alle vier Menschenaffenformen in großen Gruppen. Auf der Kiwara-Savanne (Afrika-Bereich) leben [[Giraffe]]n, [[Antilope]]n, [[Afrikanischer Strauß|Strauße]] und [[Zebra]]s, nebenan ein [[Flamingo]]&lt;nowiki&gt;schwarm&lt;/nowiki&gt; und [[Hyänen]] zusammen. Der Bau eines Elefantenbullen-Hauses wurde bereits mit einem Elefanten-Baby belohnt. Im April 2006 eröffnete außerdem der neue [[Elefantenhaus|Elefantenbereich]] im Stil eines [[Kambodscha|kambodschanischen]] Tempels namens ''Ganesha Mandir'' mit einem verglasten Badebecken und insgesamt vier Freianlagen.

Zuletzt war der Zoo Austragungsort der [[World Association of Zoos and Aquariums]] (WAZA) Jahreskonferenz im August 2006.

Der [[Wildpark Leipzig]] ist ein Naturpark im Süden der Stadt und zeigt einheimische Tierarten.

=== Bauwerke ===
In Leipzig befinden sich einige bekannte Gebäude aus den Epochen der letzten Jahrhunderte. Leipzig war ein Zentrum des bürgerlichen [[Barock]] und wurde vor allem in der Gründerzeit durch viele öffentliche Gebäude des [[Historismus]] ergänzt. Außerdem befinden sich Gebäude der Vor- und Nachkriegsmoderne in Leipzig.

[[Bild:Leipzig Panorama Völkerschlachtdenkmal.jpg|thumb|700px|center|Blick über die Leipziger Innenstadt vom Völkerschlachtdenkmal aus]]

==== Sakralbauten ====
[[Bild:Leipzig_Nikolaikirche.jpg|thumb||Nikolaikirche]]
In der Innenstadt befinden sich zwei sehr bekannte Kirchenbauten. Die [[Thomaskirche (Leipzig)|Thomaskirche]] war die Wirkungsstätte des [[Orgel|Organisten]] Johann Sebastian Bach. Das [[Gotik|gotische]] Bauwerk stammt größtenteils aus dem späten 15. Jahrhundert.  Der [[Thomanerchor]] zählt zu den berühmtesten Kirchenchören Deutschlands. 

Die [[Nikolaikirche (Leipzig)|Nikolaikirche]] war einer der wichtigsten Orte der Friedensgebete und Ausgangspunkt der Montagsdemonstrationen, die maßgeblich zur Wiedervereinigung Deutschlands beitrugen. Sie wurde ab 1165, dem Jahr der Vergabe des Stadtrechts, im [[Romanik|romanischen]] Stil errichtet und im Spätmittelalter zu einer gotischen [[Hallenkirche]] umgestaltet. Unmittelbar neben der Nikolaikirche befindet sich die [[Alte Nikolaischule]].

Zum Gedächtnis der russischen Gefallen während der Völkerschlacht bei Leipzig entstand 1913 die [[Russische Gedächtniskirche (Leipzig)|Russische Gedächtniskirche]] im sogenannten [[Nowgoroder Stil]] russisch-orthodoxer Kirchen.

==== Historische Gebäude ====
[[Bild:Leipzig-Old-Townhall-1323.jpg|thumb|Altes Rathaus]]
Die Innenstadt Leipzigs hat ein sehr wechselvolles Antlitz. Im Herzen der Stadt dominiert das [[Altes Rathaus (Leipzig)|Alte Rathaus]], ein [[Renaissance]]bau aus den Jahren 1556/57. Bemerkenswert ist, dass dieses nicht den damaligen Regeln gemäß axialsymmetrisch in der Frontansicht aufgebaut, sonderm im [[Goldener Schnitt|Goldenen Schnitt]] geteilt ist. Der aus der Mittelachse gerückte Rathausturm galt als architektonische Avantgardeleistung der damaligen Zeit und stand mit dem dadurch verursachten Wirbel und Aufruhr für das städtische Selbtsbewusstsein und das typische Bestreben, stets einen eigenen, unabhängigen Weg zu wählen und zu behaupten. 

Sein Erbauer, [[Hieronymus Lotter]] –&amp;nbsp;Stadtbaumeister, Ratsherr und Bürgermeister &amp;nbsp;– errichtete auch die [[Alte Waage (Leipzig)|Alte Waage]] am Marktplatz sowie wesentliche Teile der Stadtbefestigung. So konstruierte er die noch heute erhaltene [[Moritzbastei]], die zwischen 1551 und 1554 erbaut wurde. Sie galt als Meisterwerk der Festungsbaukunst und uneinnehmbar. Im Dreißigjährigen Krieg wurde sie jedoch von schwedischen Truppen überrannt. Vorher befand sich in unmittelbarer Nähe die [[Pleißenburg]], die bereits im [[Schmalkaldischer Krieg|Schmalkaldischen Krieg]] im 16. Jahrhundert beschädigt und teilweise geschleift wurde. Das [[Neues Rathaus (Leipzig)|Neue Rathaus]] befindet sich auf den Resten der Pleißenburg. Es ist mit seinem 114&amp;nbsp;m hohen Hauptturm eines der größten Rathausgebäude weltweit. Mit dem starken Wachstum Leipzigs im 19. Jahrhundert benötigte die Stadtverwaltung dieses größere Bauwerk, das 1905 fertiggestellt wurde.

Ein großer Teil der Innenstadt wird durch ehemals von der Leipziger Messe genutzte Handelshöfe, prachtvolle Kaufmannshäuser mit charakteristischen [[Passage]]n, dominiert. Die Passagen wurden ursprünglich angelegt, um den [[Kutsche]]n in den engen Innenhöfen das Wenden zu ersparen. Der älteste noch erhaltene Handelshof ist [[Specks Hof]], weitere mittlerweile liebevoll restaurierte sind [[Barthels Hof]] oder [[Stenzlers Hof]]. Sie dienten hauptsächlich zur Ausrichtung von Handelsmessen. Das [[Städtisches Kaufhaus|Städtische Kaufhaus]] war das erste Mustermessehaus der Stadt. Andere Handelshäuser wie der [[Auerbachs Hof]] wurden bereits Anfang des 20. Jahrhunderts in Ladenstraßen umgewandelt, als sich der Rückzug der Leipziger Messe aus der Innenstadt mit dem Bau des Messegeländes abzeichnete. Auf dem Gelände von Auerbachs Hof befindet sich heute wohl die prachtvollste Passage Leipzigs, die nach mailändischem Vorbild von 1912 bis 1914 errichtete [[Mädlerpassage]]. Hier befindet sich der durch [[Johann Wolfgang von Goethe|Goethes]] [[Faust I|Faust]] weltberühmt gewordene [[Auerbachs Keller]]. 

[[Bild:AlteBoerseInLeipzig.jpg|thumb|Alte Börse zu Leipzig]]
In Leipzig gibt es noch viele Gebäude des bürgerlichen Barock, die in der wohlhabenden Kaufmannsstadt etwa zeitgleich mit den Gebäuden des kurfürstlichen Barock in Dresden entstanden. Unmittelbar hinter dem Alten Rathaus, am [[Leipziger Naschmarkt|Naschmarkt]], befindet sich die im [[Barock]]stil errichtete [[Alte Handelsbörse (Leipzig)|Alte Börse]], die einstmals als Versammlungsgebäude der Leipziger Kaufmannschaft diente. Wohlhabende Bürger erbauten Stadtpalais in der kompakten Innenstadt wie das [[Fregehaus]] und das [[Romanushaus]]. Teilweise bestanden die Gebäude auch schon vorher und wurden im 18. Jahrhundert umgebaut. In Randlage der Stadt entstand das [[Gohliser Schlösschen]] ebenfalls als barockes Bauwerk im bürgerlichen Besitz.

An die Aufenthalte und Wirkungsstätten von berühmten Personen erinnern einige Gebäude in Leipzig. So befindet sich westlich der Innenstadt das [[Mendelssohn-Haus]], in dem [[Felix Mendelssohn Bartholdy]], der als Komponist am Gewandhaus wirkte, bis zu seinem Tod lebte. Auch [[Friedrich Schiller]] verbrachte 1785 einige Monate in Leipzig bzw. im damals noch außerhalb der Stadtgrenzen gelegenen [[Gohlis (Leipzig)|Gohlis]]. Dort befindet sich das [[Schillerhaus (Leipzig)|Schillerhaus]], das eigentlich ein Bauernhaus ist, in dem Schiller unter anderem an der [[Ode an die Freude]] arbeitete.

[[Bild:Reichsgerichtsgebauede - frontal.jpg|thumb|Das historistische Portal des Reichsgerichtsgebäudes]]

Leipzig besitzt auch einige bedeutende Gebäude des [[Historismus]]. Das [[Völkerschlachtdenkmal]] als eines der bekanntesten [[Wahrzeichen]] der Stadt wurde ab 1898 als Mahn- und Denkmal an die [[Völkerschlacht bei Leipzig|Völkerschlacht]] 1813 errichtet. Seine Architektur ist über klassische Motive stark symbolbehaftet und wirkt durch Höhe und Stärke der Wände und Säulen äußerst massiv. Die Ähnlichkeit des [[Reichsgerichtsgebäude]]s, das von 1888 bis 1895 erbaut wurde, mit dem [[Reichstagsgebäude]] in Berlin ist nicht zu verkennen. Beide orientieren sich an Motiven der italienischen Renaissance und sollen über ihre monumentale Wirkung das gefestigte Deutsche Reich verkörpern. Die [[Deutsche Bücherei]] markiert am Ende des Vorkriegshistorismus einen Übergang zur Moderne. Ähnlich wie beim [[Deutsches Hygiene-Museum|Deutschen Hygienemuseum]] bleiben die Formen monumental und aufragend; die Auffüllung der Fassade wurde aber vergleichsweise sachlich angelegt. Oskar Pusch entwarf neben der Bücherei auch das neoklassizistische [[Achilleion (Leipzig)|Achilleion]] auf dem Messegelände Leipzigs. Das Gebäude der [[Universitätsbibliothek Leipzig|Universitätsbibliothek Albertina]] ist als Bauwerk der Neorenaissance mit einem mittigen Eingangsportal stark symmetrisch konzipiert. Der [[Brunnen in Leipzig#Mendebrunnen|Mendebrunnen]] ist die größten Zierbrunnenanlage in Leipzig und wurde 1883 im Stil des [[Neobarock]] erbaut.

==== Moderne und zeitgenössische Architektur ====

Leipzigs [[moderne (Architektur)|moderne Architektur]] ist vor allem durch die Hochhäuser geprägt. Das [[Krochhochhaus]] entstand 1927/28 als erstes Hochhaus in Leipzig in Stahlbetonskelettbauweise und gehört zu den erhaltenen Gebäuden der Vorkriegsmoderne. Der schlicht gestaltete, schlanke, ca. 50 m hohe Turm wird von einem markanten, dem des [[Markusplatz_%28Venedig%29#Uhrenturm|Torre dell'Orologio]] in Venedig nachempfundenen, Glockenspiel gekrönt.

Unweit davon überragt das [[City-Hochhaus Leipzig|City-Hochhaus]] - mit seinen 155,40 Metern das zweithöchste deutsche Hochhaus außerhalb von Frankfurt/Main -  weithin die Innenstadt. Das Hochhaus, von 1968 bis 1972 als Hauptgebäude für die Universität erbaut, trägt durch seine Form als aufgeschlagenes Buch eine eindeutige Symbolik.

1972 wurde das 95 m hohe [[Wintergartenhochhaus]] mit 31 Etagen am Hauptbahnhof als höchstes Wohngebäude Leipzigs eingeweiht. Ein weiteres architektonisch bedeutsames, hohes Gebäude am östlichen Innenstadtring ist das 1928/29 im Stil der [[Neue Sachlichkeit|Neuen Sachlichkeit]] errichete, 53 m hohe Europa-Hochhaus an der Südostseite des Augustusplatzes zu nennen, nach dem Krochhochhaus das zweite in Leipzig gebaute Hochhaus. Das Europa-Haus war Ausgangsbau des 1927 vom damaligen Stadtbaurat Hubert Ritter vorgelegten, nie verwirklichten, Ringcity-Konzeptes, das vorsah die City durch eine moderne Randbebauung mit mehreren Hochhäusern über den im 19. Jahrhundert angelegten Promenadenring hinweg zu erweitern und damit den kompakten Altstadtkern durch die Schaffung damals dringend benötigter neuer Gewerbeflächen zu entlasten und dessen historische Bebauung zu bewahren.&lt;ref&gt;Iris Reuther: ''Prototyp und Sonderfall - Über Hochhäuser in Leipzig''. In: Marianne Rodenstein (Hrsg.):''Hochhäuser in Deutschland. Zukunft oder Ruin der Städte''. Kohlhammer, Stuttgart 2000. ISBN 978-3170162747 ([http://www.urbaneprojekte.de/download/498/download/ PDF])&lt;/ref&gt; 
[[Bild:Gewandhaus.jpg|thumb|Das Neue Gewandhaus]]
Am [[Augustusplatz]] – der südöstlichen Grenze der Innenstadt – befinden sich das [[Gewandhaus (Leipzig)|Neue Gewandhaus]] und das [[Opernhaus Leipzig|Opernhaus]]. Beide sind moderne Neubauten, die an der Stelle von im Zweiten Weltkrieg zerstörten Kulturhäusern errichtet wurden. Das Opernhaus wurde zwischen 1956 und 1960 am Ort des [[Neues Theater (Leipzig)|Vorgängerbauwerks]] errichtet und nimmt dessen spätklassizistische Formen vereinfacht auf. Der Bau gilt durch seine Verbindung von Tradition und Moderne heute als Musterbeispiel sozialistischer Architektur jener Zeit. Das am Standort des ehemaligen Städtischen Museums erbaute Neue Gewandhaus als einziger vollwertiger Konzertsaalneubau der DDR gehörte zu ihren aufwändigsten Bauprojekten. Auffällig ist die hohe Glasfront, auf die ein massiver Betonsims gesetzt ist.
Mit dem Neubau moderner Kulturhäuser wurde in Leipzig ein anderer Weg gewählt als in Berlin und Dresden, wo [[Konzerthaus Berlin|Konzerthaus]] und [[Semperoper]] detailgetreu wiederaufgebaut wurden. Dies hatte neben den höheren Kosten auch konzeptionelle Gründe, da der damalige Karl-Marx-Platz in seiner Gesamtheit ein von sozialistisch geprägten Gestaltungsgrundsätzen geprägtes Antlitz erhalten sollte.

Auch der nördliche Innenstadtring wird durch zwei Hochhäuser flankiert. Das Verwaltungshochhaus der Sparkasse Leipzig/SachsenLB und das mit 96 m höchste Hotel der Stadt, das von 1978 bis 1981 von der japanischen Kajima Corporation ursprünglich insbesondere für Messegäste erbaute [[Hotel The Westin Leipzig|„The WestIn Leipzig“]], bilden hier ein interessantes Ensemble. 

Die Dominante der Ringbebauung im Südwesten der City ist der weit sichtbare Turm des Neuen Rathauses, welcher mit seinen fast 115&amp;nbsp;m der höchste Rathausturm Deutschlands ist.

==== Verkehrs- und Industriebauwerke ====
[[Bild:Leipzig Hauptbahnhof Passage.jpg|thumb|Der Querbahnsteig des Hauptbahnhof beherbergt ein großes Einkaufszentrum]]
Leipzig wird noch von einer Ringeisenbahn umgeben, an die sich zwei wichtige Kopfbahnhöfe anschließen. Beide Bahnhöfe, der [[Leipzig Hauptbahnhof|Hauptbahnhof]] und der [[Leipzig Bayerischer Bahnhof|Bayerische Bahnhof]] werden in Zukunft durch den [[City-Tunnel (Leipzig)|City-Tunnel]] verbunden.

Der Hauptbahnhof ist einer der größten [[Kopfbahnhof|Kopfbahnhöfe]] Europas. Er steht mit einer fast 300 Meter breiten [[Historismus|historistischen]] Fassade an der Grenze der Innenstadt und besteht dahinter aus zwei großen Empfangshallen und sechs Bahnsteighallen. Er wurde bis 1997 aufwändig restauriert und am Querbahnsteig um ein Einkaufszentrum ergänzt.

Im Süden der Stadt liegt der bis 1844 errichtete [[Leipzig Bayerischer Bahnhof|Bayerische Bahnhof]], der älteste erhaltene Kopfbahnhof Deutschlands. Markantes Merkmal des Bahnhofs ist der viertorige [[Portikus]] für die Eisenbahn.

Die [[Buntgarnwerke Leipzig|Buntgarnwerke]] in Plagwitz sind Deutschlands größtes Industriedenkmal aus der [[Gründerzeit]] mit über 100.000 Quadratmetern Geschossfläche. Im Süden liegen die Leipziger Großmarkthallen, scherzhaft „Kohlrabizirkus“ genannt (beherbergen jetzt eine Eislaufanlage und eine Diskothek).

=== Kino ===
Leipzig besitzt eine lebendige Kinoszene. Internationale Bedeutung gewann das seit 1955 alljährlich stattfindende [[Internationales Leipziger Festival für Dokumentar- und Animationsfilm|Festival für Dokumentar- und Animationsfilm]]. Nach zunehmender Beeinflussung des Festivalprogramms durch staatliche Organe der DDR in den Jahren ab 1968 entwickelte es sich nach der Wiedervereinigung mit modernisierter Ausrichtung erneut zu einem Publikumsmagneten.

Neben größeren Kinos, wie ''CineStar'' und ''Passage Kinos'' im Zentrum, ''Regina Filmpalast'' in [[Reudnitz (Leipzig)|Reudnitz]] und ''Cineplex Leipzig im Allee-Center'' in [[Grünau (Leipzig)|Grünau]] präsentieren zahlreiche [[Programmkino]]s anspruchsvolle Filme für kleinere Zielgruppen. Einige Filmtheater wie [[UT Connewitz]] und das ''Kino in der'' [[naTo]] werden auch für Musikveranstaltungen genutzt. Einmal jährlich finden seit 1995 in mehreren Spielstätten des Großraumes Halle-Leipzig die [[Französische Filmtage Leipzig/Halle|Französischen Filmtage]] statt. Ein Tip für den Sommer sind auch die vielen kleinen Freilichtbühnen wie die des Sommer-Kino Leipzig im Freibad Kleinzschocher (Schleußig/Kleinzschocher) und/oder die des Sommerkinos an der Pferderennbahn (Südvorstadt).

=== Nachtleben ===
Das alltägliche kulturelle Leben spielt sich vor allem in der Innenstadt, in der [[Gottschedstraße]] und der [[Südvorstadt (Leipzig)|Südvorstadt]] entlang der [[Karl-Liebknecht-Straße (Leipzig)|Karl-Liebknecht-Straße]] bis zum Stadtteil [[Connewitz]] ab. Die Stadt hat ein bemerkenswertes und reges Nachtleben. Die  Entwicklung der vielseitigen Kneipenlandschaft wurde dabei durch den Verzicht der Stadtverwaltung auf eine [[Sperrstunde]] begünstigt. Ganz besonders in den Abend- und Nachtstunden der Sommermonate kann man im Barfußgässchen und in der Gottschedstraße, wenn die Freisitze gefüllt sind, italienisches Flair erleben. Einmal im Jahr bietet darüber hinaus Deutschlands größtes [[Honky-Tonk|Honky-Tonk-Festival]] Live-Musik in zahlreichen Lokalen.

Durch den Verfall der Bausubstanz während der DDR-Zeit sind viele ehemalige Kulturhäuser in den Stadtteilen verschwunden, so dass Leipzig nur noch eine begrenzte Anzahl an größeren Sälen für Musikveranstaltungen besitzt. Im Norden sind dies der [[Anker (Leipzig)|Anker]] und das [[Haus Auensee]], in der Westvorstadt das [[Haus Leipzig]], im Zentrum die Moritzbastei, in der Südvorstadt die [[naTo]] und in Connewitz das [[Werk II]] und das [[Conne Island]]. Vor kurzem eröffnete mit dem Volkspalast eine neue Veranstaltungshalle, die auch größere Konzerte erlaubt, die bisher der Sport-Mehrzweckhalle [[Arena Leipzig]] vorbehalten waren. In Connewitz und Teilen der Südvorstadt entwickelte sich nach der Wende eine vivante alternative Szene. Aus einem ehemaligen Kino [[UT Connewitz]] entstand mit dem eine für alle Kulturformen genutzte Einrichtung. Das „Tanzcafé [[Ilses Erika]]“, ebenfalls in Connewitz gelegen, mit seiner heimeligen Wohnzimmeratmosphäre ist mit seinen Clubabenden und -konzerten einer der bekanntesten [[Indie]]-Adressen in Ostdeutschland. Mit der [[Distillery (Club)|Distillery]] hat auch Ostdeutschlands dienstältester Technoclub in Leipzig sein Domizil.

Mit den Beschlüssen der 3. Hochschulreform der DDR 1968 entstanden in Leipzig zahlreiche Studentenclubs, von denen die meisten heute noch existieren und die nicht nur von Studenten genutzt werden. Der älteste Studentenclub ist der [[TV-Club Leipzig]], der größte die Ende der 1970er Jahre aus einer mittelalterlichen Festungsanlage ausgebaute [[Moritzbastei]]. Sie ist gleichzeitig auch der größte Studentenclub [[Europa]]s. Die Studentenclubs haben sich mit dem ''Runden Tisch Leipziger unabhängiger Studentenclubs'' ([[RuTiLuSt]]) Anfang der 1990er Jahre eine gemeinsame Plattform geschaffen.

=== Regelmäßige Veranstaltungen ===

Das [[Bachfest Leipzig]] ist ein [[Musikfestival]], das erstmals 1908 stattfand. Seit 1999 wird es jährlich ausgerichtet und widmet sich ganz der Pflege der Werke von Johann Sebastian Bach. Das [[Internationales Kammermusikfestival Leipzig|Internationale Kammermusikfestival Leipzig]] wird in Kooperation mit dem Gewandhaus seit 1996 im November durchgeführt. Die [[Classic open Leipzig]] sind eine seit 1995 von [[Peter Degner]] und der Stadt Leipzig organisierte Konzertreihe mit Freiluftkonzerten und Videoübertragungen von Konzerten in der Leipziger Innenstadt im August. Das [[a-cappella - Festival für Vocalmusik]] ist ein seit 1997 stattfindendes Festival für [[Vokalmusik]] in Leipzig, bei dem Ende April international renommierte, aber auch Nachwuchskünstler dieses Genres auftreten.

Über [[Pfingsten]] ist Leipzig jährlich Austragungsort des viertägigen [[Wave-Gotik-Treffen|Wave-Gotik-Treffens]] (''WGT''), welches seit 1992 stattfindet, derzeit regelmäßig bis zu 20.000 Besucher aus der [[Schwarze Szene|Schwarzen Szene]] in die Stadt lockt und selbst szenefremde Leipziger und die Besucher mit „weniger schwarzen“ Veranstaltungen wie dem „Wikingerlager“, dem „Heidnischen Dorf“ und mehreren Mittelalter-Märkten erfreut. Die [[Leipziger Jazztage]] werden seit 1976 im Oktober ausgerichtet. Sie widmen sich dem zeitgenössischen [[Jazz]] und werden vom ''jazzclub leipzig e.V.'' ausgerichtet. Das [[Leipzig Pop Up]] ist eine alternative Messe zur Popkultur, zu der auch Diskussionsforen und ein Musikfestival in Leipziger Clubs gehören. 

Das Festival [[euro-scene Leipzig]] findet seit 1991 jährlich im November statt. Es widmet sich dem experimentellen Theater und dem modernen Tanz. Die [[Lachmesse]] ist ein Europäisches Humor- und Satire-Festival, das seit 1991 jährlich im Oktober in Leipzig stattfindet. Sie vergibt den mit 3.500 Euro dotierten Kleinkunstpreis ''Leipziger Löwenzahn''.
Seit ihrer Gründung im Jahr 1994 hat sich die [[Internationale Studentische Woche]] als ein akademischer und kultureller Höhepunkt in Leipzig entwickelt. Die ISW ist die bundesweit größte studentisch organisierte Veranstaltungsreihe mit internationalem Charakter. Während der Sommermonate finden weitere Freiluftveranstaltungen wie der [[Hörspielsommer]], das [[Leipziger Sommertheater]] und das Sommerkino statt.

Alljährlich richtet der Leipzig Tourist Service e.V. das Leipziger Stadtfest aus, welches mit seinen über 300.000 Besuchern zu den zehn größten Open Air Veranstaltungen Deutschlands zählt. Die [[Leipziger Kleinmesse]] ist ein dreimal jährlich stattfindendes Volksfest, das 1907 als Ableger der Leipziger Messe entstand. Der [[Leipziger Weihnachtsmarkt]] ist einer der größten in den neuen Bundesländern und wird seit 1767 ausgerichtet. 

[[Courage zeigen]] ist ein seit 1998 am [[30. April]] stattfindendes Rockkonzert vor dem Leipziger Völkerschlachtdenkmal, das als Antwort auf die Neonazi-Aufmärsche am 1. Mai entstand. Bei den Gegenveranstaltungen dieser Aufmärsche kommt es meist zu Zerstörungen und Krawallen durch [[Linksextremisten]], besonders in der [[Südvorstadt (Leipzig)|Südvorstadt]]. Der Sprachenabend ist eine wöchentliche Veranstaltung im [[Soziokulturelles Zentrum „Die VILLA“|Soziokulturellen Zentrum „Die VILLA“]], die dem interkulturellen Kontakt dient.

Der Karneval spielt im protestantischen Leipzig nur eine untergeordnete Rolle. Ab den 1950er Jahren entstand mit dem [[Leipziger Studentenfasching]] eine ganz eigene Spielart. 1992 gründete sich das  ''Förderkomitee Leipziger Karneval e.V.'' und richtet alljährlich einen Rosensonntagsumzug unter dem Motto ''Leila helau'' aus.

Von April bis Oktober jedes Jahres hat der Vergnügungspark [[Belantis]] im Süden Leipzigs geöffnet, der unmittelbar an der [[Bundesautobahn 38]] und dem Cospudener See gelegen ist.

=== Kulinarische Spezialitäten === 
Leipzig hat mehrere lokale Spezialitäten zu bieten, darunter das [[Leipziger Allerlei]], die [[Leipziger Lerche]] und die [[Gose|Leipziger Gose]]. Das Leipziger Allerlei ist ein gemischtes Gemüse, das in der Originalversion auch mit [[Flusskrebs]]en, [[Krebsbutter]] und Semmelklößchen angerichtet wurde. Die Leipziger Lerchen wurden im 18. und 19. Jahrhundert wirklich aus [[Singvögel]]n hergestellt. Diese wurden beispielsweise als gefüllte Pasteten gereicht. Nachdem 1876 ein Fangverbot für Singvögel verhängt wurde, entwickelten findige Bäcker ein feines Gebäck, das heute in der Regel aus [[Mürbeteig]] mit Marzipanfüllung besteht und nur noch in der Form an die damaligen Pasteten erinnert. Die Gose ist ein ursprünglich aus [[Goslar]] stammendes [[obergärige Hefe|obergäriges]] [[Bier]].

== Sport ==
Leipzig besitzt eine lange und große [[Sport]]tradition. Es war 1900 Gründungsort des [[Deutscher Fußball-Bund|DFB]]. Die Gründung fand in der Karlstraße 10, im Restaurant „Zum Mariengarten“ statt. Der [[VfB Leipzig]] war der [[Deutscher Meister (Fußball) 1902/03|erste deutsche Fußballmeister]] und konnte diesen Triumph zweimal (1906, 1913) wiederholen. Nach dem Zweiten Weltkrieg wurde er von der sowjetischen Besatzungsmacht aufgelöst und bestand von 1966 bis 1991 als [[1. FC Lokomotive Leipzig]], dessen Namen der inoffizielle Nachfolgeverein des aufgrund einer Insolvenz liquidierten VfB Leipzig seit 2004 wieder trägt. Lok Leipzig war viermaliger [[FDGB-Pokal|DDR-Pokalsieger]], dreimaliger DDR-Vizemeister und schaffte es 1987 bis in das Finale des [[Europapokal der Pokalsieger (Fußball)|Europapokals der Pokalsieger]]. Der zweite traditionsreiche Fußballclub, der [[FC Sachsen Leipzig]] (bis 1990 ''BSG Chemie Leipzig''), war zweimaliger DDR-Meister und einmal FDGB-Pokal-Gewinner. Beide Mannschaften spielen aktuell nur in der [[Fußball-Oberliga Nordost (Staffel Süd)|Oberliga]] bzw. [[Bezirksliga]].

[[Bild:L%C3%A4nderspiel_Deutschland_-_Kamerun.jpg|Zentralstadion vor dem Länderspiel Deutschland-Kamerun (Nov. 2004)|thumb]] 
Das [[Zentralstadion Leipzig|Zentralstadion]] wurde 1956 mit 100.000 Plätzen als größtes Stadion Deutschlands eröffnet. Der Zuschauerrekord liegt weit über dem Fassungsvermögen und datiert aus dem Spiel Wismut Aue – 1.FC Kaiserslautern, bei dem 125.000 Zuschauer im Stadion waren (1958). Dies ist bis heute auch der Zuschauerrekord für Fußballspiele in Deutschland.
Zwischen 2000 und 2004 wurde innerhalb des alten Stadionwalls ein neues Fußballstadion mit 44.345 Plätzen integriert, es gehört heute mit der [[Arena Leipzig]] und der Festwiese zum [[Sportforum Leipzig|Leipziger Sportforum]]. Hier fanden fünf Spiele der [[Fußball-Weltmeisterschaft 2006|Fußball-WM 2006]] statt. Das [[Bruno-Plache-Stadion]] in [[Probstheida]] war bei seiner Einweihung 1922 das größte vereinseigene Stadion Deutschlands (40.000 Plätze) und ist heute Spielstätte des 1. FC Lokomotive Leipzig. Der [[Alfred-Kunze-Sportpark]] in Leutzsch ist das Heimstadion des FC Sachsen Leipzig.

Die [[Deutsche Hochschule für Körperkultur und Sport]] (DHfK) war in der DDR eine international renommierte Sporthochschule, aus der zahlreiche Spitzensportler und -trainer hervorgingen. Einige Angehörige waren allerdings auch in das in der DDR systematisch betriebene [[Doping]] verwickelt. Dies war einer der Gründe, warum diese Hochschule 1990 abgewickelt wurde. In ihrer Tradition steht die 1993 gegründete ''Sportwissenschaftliche Fakultät'' der [[Universität Leipzig]]. Die Abkürzung „DHfK“ tragen noch die ''HSG DHfK'' und der ''SC DHfK'' im Namen.

Der [[Handball-Club Leipzig]] (HCL) ist einer der besten Frauen-[[Handball]]clubs Deutschlands. Er war viermal Europapokal-Sieger, viermal Deutscher Meister, dreimal DHB-Pokalsieger und 13 Mal DDR-Meister. Der [[VC Leipzig]] spielt in der [[Deutsche Volleyball-Bundesliga (Herren)|Volleyball-Bundesliga]]. Als SC Leipzig war er 1964 Europapokalsieger der Landesmeister und vielmaliger DDR-Meister (1962-1976, 1982, 1983, 1985, 1987, 1989). Der ''Basketball Verein Leipzig'' (BBVL) spielt in der [[Basketball-Bundesliga]] der Damen, der ''CFC-Leipzig'' und die ''Unihockey-Löwen-Leipzig'' in der [[Unihockey|Unihockeybundesliga]]. Die Eishockeymannschaft [[Blue Lions Leipzig]] spielt in der Eishockey-Regionalliga Nord/Ost. Das [[LAZ Leipzig|Leichtathletikzentrum Leipzig]] übernahm die ehemals sehr erfolgreiche Leichtathletiksektion der DHfK. Der 1992 gegründete [[American Football]] Club ''Leipzig Lions'' ist der erste sächsische Verein in dieser Sportart. Er engagiert sich in Zusammenarbeit mit dem [[Rotary Club]] auch in einer Vielzahl sozialer Projekte.

Leipzig konnte sich mit seiner Bewerbung um die Ausrichtung der [[Olympische Sommerspiele 2012|Olympischen Sommerspiele 2012]] national durchsetzen, wurde auf internationaler Ebene jedoch am 18. Mai 2004 in der Vorauswahl abgelehnt.

In Leipzig wurden im Rahmen der [[Fußball-Weltmeisterschaft 2006]] am 9. Dezember 2005, die Gruppen des Turniers in der Messehalle ausgelost.

=== Regelmäßige Sportveranstaltungen ===
Der [[Leipzig-Marathon]] wird seit 1977 ausgetragen und findet im April statt. Der erste deutsche Marathon überhaupt fand am 5. September 1897 ebenfalls in Leipzig statt. Der ''Leipzig City Man'' ist ein internationaler [[Triathlon]] und wird seit 1984 am [[Kulkwitzer See]] ausgetragen.

Die Sparkasse Leipzig sponsert eine Reihe von Weltcupwettkämpfen, so einen Einzel-Weltcup im [[Florett]]fechten der Damen und im [[Tennis]] der Damen. Seit Eröffnung der Arena in Leipzig, findet jährlich im Februar das von der LAZ Leipzig ausgerichtete, internationale Leichtathletik-Meeting [[LE-Athletics]] statt. 

Im Rahmen des ''German Beach Cups'' findet jährlich ein Wettkampf im [[Beach-Volleyball]] in Leipzig statt. Die [[Saxonia International Balloon Fiesta]] ist mit über 100 Ballons aus aller Welt eines der größten Ballonfahrertreffen Europas und findet am [[Silbersee (Leipzig)|Silbersee]] in [[Lößnig]] statt. Auf der [[Galopprennbahn Scheibenholz]] werden jährlich mehrere Pferderennen ausgetragen.

== Persönlichkeiten ==
[[Bild:Leibniz-Denkmal.jpeg|thumb|Leibniz-Denkmal]]
Leipzig hat zahlreiche prominente Söhne und Töchter, beispielsweise den Philosophen und Wissenschaftler [[Gottfried Wilhelm Leibniz]], den Komponisten [[Richard Wagner]] (geb. 1813), den Kunsthistoriker [[Nikolaus Pevsner]] (geb. 1902) oder den Sozialisten [[Karl Liebknecht]]. 

Zahlreiche nicht weniger berühmte Persönlichkeiten haben zumindest Teile ihres Lebens in Leipzig verbracht und gewirkt, wie die Komponisten [[Johann Sebastian Bach]] und [[Felix Mendelssohn Bartholdy]], der Philosoph [[Friedrich Nietzsche]], der Physiknobelpreisträger [[Werner Heisenberg]] oder der Automobilbauer [[August Horch]].
* (''Siehe auch die Artikel'' [[Liste der Söhne und Töchter der Stadt Leipzig]] ''und'' [[Prominente Bewohner der Stadt Leipzig]]).

Die Stadt Leipzig hat seit 1832 82 Persönlichkeiten das [[Ehrenbürger]]recht verliehen. Vier Personen ([[Adolf Hitler]], [[Hans Frank]], [[Wilhelm Frick]] und [[Walter Ulbricht]]) wurde das Ehrenbürgerrecht wieder aberkannt.
* (''Siehe auch:'' [[Liste der Ehrenbürger von Leipzig]]).

== Zitate ==
* ''„Mein Leipzig lob' ich mir! Es ist ein klein Paris und bildet seine Leute.“'' – [[Johann Wolfgang von Goethe]] in [[Faust I]], Z. 2171 f.
* ''„Ach wie beneide ich immer Leipzig um seine Musik!“'' – [[Clara Schumann]], Briefwechsel
* ''„Ich komme nach Leipzig, an den Ort, wo man die ganze Welt im Kleinen sehen kann.“'' – [[Gotthold Ephraim Lessing]]
* ''„Ich war ganz benommen und möchte behaupten, daß, soweit Architektur und Stadtbild in Betracht kommen, nichts wieder in meinem Leben einen so großen, ja, komisch zu sagen, einen so berauschenden Eindruck auf mich gemacht hat wie dieser in seiner Kunstbedeutung nur mäßig einzuschätzende Weg vom Post- und Universitätsplatz bis zur Hainstraße.“'' [[Theodor Fontane]]:   ''„Von Zwanzig bis Dreißig“''
* ''„Leipzig [...], dieser gewiß welthaltigen Stadt,[...]“'' [[Thomas Mann]]: [[Doktor Faustus]], Kapitel XXI

== Literatur ==

=== Stadtführer ===
* Tobias Gohlis: ''DuMont-Reisetaschenbuch „LEIPZIG“''. DuMont Reiseverlag Köln, 2004
* Janka Löwe, Bettina Meißner: ''DUMONT direkt „Leipzig“''. DuMont Reiseverlag, Köln 2005
* Gabriele Walter: ''Merian „Leipzig“''. 4. Aufl., Gräfe &amp; Unzer, München 2005 
* Maren Goltz: „Musikstadtführer Leipzig“. Kamprad Verlag, Altenburg 2004
* Stefan Sachs: ''Go Vista CITY GUIDE „Leipzig“''. Vista Point Verlag, Köln 2005 
* Toma Babovic, Edgar S. Hasse: ''Leipzig. In englischer, deutscher und französischer Sprache''. Verlag Ellert &amp; Richter Hamburg 2005, ISBN  3-8319-0024-8
* Evelyn TerVehn: ''Marco Polo „Leipzig“ mit City Atlas''. 2. aktual. Aufl., Mairs Geographischer Verlag, Ostfildern 2003 
* D. Mundus: ''Leipziger Landpartien. 15 Tagesausflüge für Neugierige''. 3. überarb. Aufl., Edition Neureuter, Leipzig 2002
* Wolfgang Hocquél: ''Leipzig - Architektur von der Romanik bis zur Gegenwart''. Passage-Verlag, Leipzig 2004, ISBN 3-932900-54-5

* Thomas Nabert (Red.): ''Quer durch Leipzig mit dem Rad''. Herausgegeben von PRO LEIPZIG in Zusammenarbeit mit dem Planungsbüro StadtLabor und dem ADFC Leipzig, Leipzig, 2. überarb. Aufl. 2006, ISBN 3-9807201-5-2, 292 Seiten mit zahlreichen Karten und ca. 500 farbigen Abbildungen, Format: 12 x 18 cm, fadengeheftete Broschur.

=== Denkmalinventare ===
* Cornelius Gurlitt (Bearb.): ''Beschreibende Darstellung der älteren Bau- und Kunstdenkmäler des Königreichs Sachsen, Heft 16: Amtshauptmannschaft Leipzig''. Meinhold, Dresden 1894 (betrifft zahlreiche heute eingemeindete Stadtteile)
* Cornelius Gurlitt (Bearb.): ''Beschreibende Darstellung der älteren Bau- und Kunstdenkmäler des Königreichs Sachsen, Heft 17–18: Stadt Leipzig''. Meinhold, Dresden 1895–1896
* Heinrich Magirius u. a. (Bearb.): ''Die Bau- und Kunstdenkmäler von Sachsen. Stadt Leipzig. Die Sakralbauten: mit einem Überblick über die städtebauliche Entwicklung von den Anfängen bis 1989''. 2 Bde., Deutscher Kunstverlag, München 1995, ISBN 3-422-00568-4
* Christoph Kühn, Brunhilde Rothbauer (Bearb.): ''Denkmale in Sachsen. Stadt Leipzig, Bd. 1: Südliche Stadterweiterung''. Verlag für Bauwesen, Berlin 1998, ISBN 3-345-00628-6
* Markus Cottin et al: ''Leipziger Denkmale''. Sax Verlag, Beucha 1998, ISBN 3-930076-71-3

=== Belletristik ===
* [[Martin Jankowski]]: ''Rabet oder das Verschwinden einer Himmelsrichtung''. Via-Verbis-Verlag, Scheidegg 1999, ISBN 3-933902-03-7
* [[Erich Loest]]: ''Völkerschlachtdenkmal''. 4. Aufl., Deutscher Taschenbuch-Verlag, München 1998, ISBN 3-423-12533-0
* Erich Loest: ''Nikolaikirche''. 8. Aufl., Deutscher Taschenbuch-Verlag, München 2002, ISBN 3-423-12448-2
* Erich Loest: ''Reichsgericht''. Linden-Verlag, Leipzig 2001, ISBN 3-86152-003-6
* [[Dieter Zimmer]]: ''Für'n Groschen Brause''. 26. Aufl., Lübbe, Bergisch-Gladbach 2003, ISBN 3-404-10183-9
* Dieter Zimmer: ''Das Hochzeitsfoto''. Lübbe, Bergisch-Gladbach 1994, ISBN 3-404-12211-9
* [[Clemens Meyer]]: ''Als wir träumten''. 3. Aufl., Fischer Verlag, Frankfurt 2006, ISBN 3-10048-600-5

=== Sachbücher ===
* Erich Keyser (Hrsg.): ''Deutsches Städtebuch. Handbuch städtischer Geschichte''. Im Auftrag der Konferenz der landesgeschichtlichen Kommissionen Deutschlands mit der Unterstützung des Deutschen Gemeindetages, Stuttgart 1941 (Band 2 Mitteldeutschland)
* Niels Gormsen, Armin Kühne: ''Leipzig. Den Wandel zeigen''. 3. Aufl., Edition Leipzig, Leipzig 2000 ISBN 3-361-00509-4
* Birgit Horn: ''Die Nacht, als der Feuertod vom Himmel stürzte - Leipzig, 4. Dezember 1943''. Wartberg-Verlag, Gudensberg-Gleichen 2003, ISBN 3-8313-1340-7
* Horst Riedel: ''Chronik der Stadt Leipzig. 2500 Ereignisse in Wort und Bild''. Wartberg-Verlag, Gudensberg-Gleichen 2001, ISBN 3-8313-1111-0
* Horst Riedel: ''Stadtlexikon Leipzig von A – Z'', PRO LEIPZIG, Leipzig 2005, ISBN 3-936508-03-8
* Thomas Nabert (Red.): ''Eine Wohnung für alle. Geschichte des kommunalen Wohnungsbaus in Leipzig 1900-2000.'' PRO LEIPZIG, Leipzig 2000, ISBN 3-9807201-1-X
* Joachim Tesch (Hrsg.): ''BAUEN IN LEIPZIG 1945 - 1990. Akteure und Zeitzeugen auf persönlichen Spuren der Leipziger Baugeschichte''. Rosa-Luxemburg-Stiftung Sachsen, 2003, ISBN 3-89819-159-1
* Birk Engmann: ''Bauen für die Ewigkeit. Monumentalarchitektur des zwanzigsten Jahrhunderts und Städtebau in Leipzig in den fünfziger Jahren.'' SAX- Verlag Beucha, 2006, ISBN 3-934544-81-9

== Fußnoten ==
&lt;references /&gt;

== Weblinks ==
{{Portal|Leipzig}}
{{Wikinews|Portal:Leipzig|Themenportal Leipzig}}
{{Wiktionary|Leipzig}}
{{Commons|Leipzig}}
{{Wikiquote|Leipzig}}
* [http://www.leipzig-lexikon.de/ Leipzig-Lexikon – Umfangreiches Weblexikon über Leipzig]
* [http://www.lipsikon.de/ Lipsikon – Foto- und Kartensammlung]
* [http://www.leipziginfo.de/stadtinfo-tourismus/geschichte/historische-bilder/ Historische Fotos und Bilder von Leipzig]
* [http://www.superleipzig.de/ Superlativ-Sammlung über Leipzig]
* {{dmoz|World/Deutsch/Regional/Europa/Deutschland/Sachsen/St%c3%a4dte_und_Gemeinden/L/Leipzig|Leipzig}}

{{NaviBlock
|Navigationsleiste Stadtteile Leipzig
|Navigationsleiste Landkreise und kreisfreie Städte in Sachsen
|Navigationsleiste Metropolregion Sachsendreieck
}}

{{Lesenswert}}

[[Kategorie:Ort in Sachsen]]
[[Kategorie:Gemeinde in Sachsen]]
[[Kategorie:Leipzig|!]]

[[af:Leipzig]]
[[ar:لايبزغ]]
[[bg:Лайпциг]]
[[bn:লাইপ্‌ৎসিশ]]
[[bs:Leipzig]]
[[ca:Leipzig]]
[[cs:Lipsko]]
[[cv:Лейпциг]]
[[cy:Leipzig]]
[[da:Leipzig]]
[[el:Λειψία]]
[[en:Leipzig]]
[[eo:Leipzig]]
[[es:Leipzig]]
[[et:Leipzig]]
[[fa:لایپزیگ]]
[[fi:Leipzig]]
[[fr:Leipzig]]
[[gl:Leipzig]]
[[he:לייפציג]]
[[hr:Leipzig]]
[[hsb:Lipsk]]
[[hu:Lipcse]]
[[id:Leipzig]]
[[io:Leipzig]]
[[is:Leipzig]]
[[it:Lipsia]]
[[ja:ライプツィヒ]]
[[ko:라이프치히]]
[[la:Lipsia]]
[[lb:Leipzig]]
[[lt:Leipcigas]]
[[lv:Leipciga]]
[[ms:Leipzig]]
[[nap:Lipsia]]
[[nds:Leipzig]]
[[nl:Leipzig]]
[[nn:Leipzig]]
[[no:Leipzig]]
[[oc:Leipzig]]
[[pl:Lipsk]]
[[pt:Leipzig]]
[[qu:Leipzig]]
[[ro:Lipsca]]
[[ru:Лейпциг]]
[[scn:Lipsia]]
[[simple:Leipzig]]
[[sk:Lipsko]]
[[sl:Leipzig]]
[[sq:Leipzig]]
[[sr:Лајпциг]]
[[sv:Leipzig]]
[[th:ไลพ์ซิก]]
[[tr:Leipzig]]
[[vi:Leipzig]]
[[vo:Leipzig]]
[[zh:萊比錫]]
</textarea>
		<div id="editpage-copywarn">
<div id="editpage-copywarn-copywarn" class="hintergrundfarbe2 rahmenfarbe3" style="border-style: solid; font-size: 90%">
<table cellspacing="4">

<tr>
<td align="center" style="font-size:110%"> <b><a href="/wiki/Wikipedia:Urheberrechte_beachten" title="Wikipedia:Urheberrechte beachten">Das Kopieren urheberrechtlich geschützter Werke ist verboten!</a></b>
</td><td> Ich versichere hiermit, dass ich den Beitrag selbst verfasst habe bzw. dass er keine fremden Rechte verletzt, und willige ein, ihn unter der <a href="/wiki/Wikipedia:Lizenzbestimmungen" title="Wikipedia:Lizenzbestimmungen">GNU-Lizenz für freie Dokumentation</a> zu veröffentlichen.
</td><td align="center" style="font-size:110%"> <b><a href="/wiki/Wikipedia:Quellenangaben" title="Wikipedia:Quellenangaben">Bitte gib deine Quellen an!</a></b>
</td></tr></table>
</div>
</div>


<span id='wpSummaryLabel'><label for='wpSummary'><a style="text-align:left;" href="http://de.wikipedia.org/wiki/Hilfe:Zusammenfassung%20und%20Quelle" class="internal" title="Bitte die vorgenommenen Änderungen kurz beschreiben.">Zusammenfassung und Quellen</a>:</label></span>
<div class='editOptions'>
<input tabindex='2' type='text' value="" name='wpSummary' id='wpSummary' maxlength='200' size='60' /><br />




<div class='editButtons'>
<input id="wpSave" name="wpSave" type="submit" tabindex="3" value="Seite speichern" accesskey="s" title="Änderungen speichern [s]" />
<input id="wpPreview" name="wpPreview" type="submit" tabindex="4" value="Vorschau zeigen" accesskey="p" title="Vorschau der Änderungen an dieser Seite. Bitte vor dem Speichern benutzen! [p]" />

<input id="wpDiff" name="wpDiff" type="submit" tabindex="5" value="Änderungen zeigen" accesskey="v" title="Zeigt Änderungen am Text tabellarisch an [v]" />
	<span class='editHelp'><a href="/wiki/Leipzig" title="Leipzig">Abbrechen</a> | <a target="helpwindow" href="/wiki/Hilfe:Bearbeitungshilfe">Bearbeitungshilfe</a> (wird in einem neuen Fenster geöffnet)</span>
</div><!-- editButtons -->
</div><!-- editOptions --><div class="mw-editTools"><p><br />
</p>
<div id="specialchars" style="margin-top:3px; border-style:solid; border-width:1px; border-color:#aaaaaa; padding:1px; text-align:left; background-color:white;" title="Klicke auf das gewünschte Sonderzeichen">
<p class="specialbasic" id="Standard">
<a href="/wiki/Hilfe:Sonderzeichen" title="Hilfe:Sonderzeichen">Sonderzeichen</a>:
<a onclick="insertTags('Ä','','');return false" href="#">Ä</a>
<a onclick="insertTags('ä','','');return false" href="#">ä</a>
<a onclick="insertTags('Ö','','');return false" href="#">Ö</a>
<a onclick="insertTags('ö','','');return false" href="#">ö</a>
<a onclick="insertTags('ß','','');return false" href="#">ß</a>
<a onclick="insertTags('Ü','','');return false" href="#">Ü</a>
<a onclick="insertTags('ü','','');return false" href="#">ü</a> |
<a onclick="insertTags('„','“','');return false" href="#">„“</a>
<a onclick="insertTags('’','','');return false" href="#">’</a>
<a onclick="insertTags('‚','‘','');return false" href="#">‚‘</a>
<a onclick="insertTags('“','”','');return false" href="#">“”</a>
<a onclick="insertTags('«','»','');return false" href="#">«»</a>
<a onclick="insertTags('–','','');return false" href="#">–</a> |
<a onclick="insertTags('+','','');return false" href="#">+</a>
<a onclick="insertTags('−','','');return false" href="#">−</a>
<a onclick="insertTags('·','','');return false" href="#">·</a>
<a onclick="insertTags('×','','');return false" href="#">×</a>
<a onclick="insertTags('÷','','');return false" href="#">÷</a>
<a onclick="insertTags('≈','','');return false" href="#">≈</a>
<a onclick="insertTags('≠','','');return false" href="#">≠</a>
<a onclick="insertTags('±','','');return false" href="#">±</a>
<a onclick="insertTags('≤','','');return false" href="#">≤</a>
<a onclick="insertTags('≥','','');return false" href="#">≥</a>
<a onclick="insertTags('²','','');return false" href="#">²</a>
<a onclick="insertTags('³','','');return false" href="#">³</a>
<a onclick="insertTags('½','','');return false" href="#">½</a>
<a onclick="insertTags('€','','');return false" href="#">€</a>
<a onclick="insertTags('†','','');return false" href="#">†</a>
<a onclick="insertTags('#','','');return false" href="#">#</a>
<a onclick="insertTags('*','','');return false" href="#">*</a>
<a onclick="insertTags('‰','','');return false" href="#">‰</a>
<a onclick="insertTags('§','','');return false" href="#">§</a>
<a onclick="insertTags('¢','','');return false" href="#">¢</a>
<a onclick="insertTags('$','','');return false" href="#">$</a>
<a onclick="insertTags('¿','','');return false" href="#">¿</a>
<a onclick="insertTags('¡','','');return false" href="#">¡</a>
<a onclick="insertTags('∞','','');return false" href="#">∞</a>
<a onclick="insertTags('‣','','');return false" href="#">‣</a>
<a onclick="insertTags('•','','');return false" href="#">•</a>
<a onclick="insertTags('〈〉','','');return false" href="#">〈〉</a>
<a onclick="insertTags('…','','');return false" href="#">…</a>
<a onclick="insertTags('→','','');return false" href="#">→</a>
<a onclick="insertTags('↔','','');return false" href="#">↔</a> |
<a onclick="insertTags('&amp;','nbsp;','');return false" href="#">&amp;nbsp;</a>
<a onclick="insertTags('[[',']]','');return false" href="#">[[]]</a>
<a onclick="insertTags('|','','');return false" href="#">|</a>
<a onclick="insertTags('{{','}}','');return false" href="#">{{}}</a>
<a onclick="insertTags('~~~~','','');return false" href="#">~~~~</a> |
<a onclick="insertTags('°','','');return false" href="#">°</a>
<a onclick="insertTags('′','','');return false" href="#">′</a>
<a onclick="insertTags('″','','');return false" href="#">″</a>
</p>
<p class="specialbasic" id="WikiSyntax" style="display:none">
WikiSyntax:
<font face="Arial Unicode MS,Lucida Sans Unicode,MS Mincho,Arial,sans-serif" style="text-decoration:none;"><a onclick="insertTags('[[Kategorie:',']]','');return false" href="#">[[Kategorie:]]</a>
<a onclick="insertTags('[[Bild:',']]','');return false" href="#">[[Bild:]]</a>
<a onclick="insertTags('#REDIRECT [[',']]','');return false" href="#">#REDIRECT [[]]</a>
<a onclick="insertTags('&lt;ref&gt;','&lt;/ref&gt;','');return false" href="#">&lt;ref&gt;&lt;/ref&gt;</a>
<a onclick="insertTags('&lt;ref name=\&quot;','\&quot;&gt;&lt;/ref&gt;','');return false" href="#">&lt;ref name=&quot;&quot;&gt;&lt;/ref&gt;</a>
<a onclick="insertTags('&lt;references/&gt;','','');return false" href="#">&lt;references/&gt;</a></font> 
</p>
<p class="specialbasic" id="IPA" style="display:none">
<a href="/wiki/Wikipedia:Liste_der_IPA-Zeichen" title="Wikipedia:Liste der IPA-Zeichen">IPA-Lautschrift</a>: 
<font face="Arial Unicode MS,Lucida Sans Unicode,MS Mincho,Arial,sans-serif" style="text-decoration:none;"><a onclick="insertTags('a','','');return false" href="#">a</a>
<a onclick="insertTags('ɐ','','');return false" href="#">ɐ</a>
<a onclick="insertTags('ɑ','','');return false" href="#">ɑ</a>
<a onclick="insertTags('ɒ','','');return false" href="#">ɒ</a>
<a onclick="insertTags('æ','','');return false" href="#">æ</a>&nbsp;· <a onclick="insertTags('b','','');return false" href="#">b</a>
<a onclick="insertTags('ɓ','','');return false" href="#">ɓ</a>
<a onclick="insertTags('ʙ','','');return false" href="#">ʙ</a>
<a onclick="insertTags('β','','');return false" href="#">β</a>&nbsp;· <a onclick="insertTags('c','','');return false" href="#">c</a>
<a onclick="insertTags('ç','','');return false" href="#">ç</a>
<a onclick="insertTags('ɕ','','');return false" href="#">ɕ</a>&nbsp;· <a onclick="insertTags('d','','');return false" href="#">d</a>
<a onclick="insertTags('ɗ','','');return false" href="#">ɗ</a>
<a onclick="insertTags('ɖ','','');return false" href="#">ɖ</a>
<a onclick="insertTags('ð','','');return false" href="#">ð</a>&nbsp;· <a onclick="insertTags('e','','');return false" href="#">e</a>
<a onclick="insertTags('ə','','');return false" href="#">ə</a>
<a onclick="insertTags('ɘ','','');return false" href="#">ɘ</a>
<a onclick="insertTags('ɚ','','');return false" href="#">ɚ</a>
<a onclick="insertTags('ɛ','','');return false" href="#">ɛ</a>
<a onclick="insertTags('ɜ','','');return false" href="#">ɜ</a>
<a onclick="insertTags('ɝ','','');return false" href="#">ɝ</a>
<a onclick="insertTags('ɞ','','');return false" href="#">ɞ</a>&nbsp;· <a onclick="insertTags('f','','');return false" href="#">f</a>&nbsp;· <a onclick="insertTags('g','','');return false" href="#">g</a>
<a onclick="insertTags('ɠ','','');return false" href="#">ɠ</a>
<a onclick="insertTags('ɢ','','');return false" href="#">ɢ</a>
<a onclick="insertTags('ʛ','','');return false" href="#">ʛ</a>
<a onclick="insertTags('ɣ','','');return false" href="#">ɣ</a>
<a onclick="insertTags('ɤ','','');return false" href="#">ɤ</a>&nbsp;· <a onclick="insertTags('h','','');return false" href="#">h</a>
<a onclick="insertTags('ħ','','');return false" href="#">ħ</a>
<a onclick="insertTags('ɦ','','');return false" href="#">ɦ</a>
<a onclick="insertTags('ɧ','','');return false" href="#">ɧ</a>
<a onclick="insertTags('ɥ','','');return false" href="#">ɥ</a>
<a onclick="insertTags('ʜ','','');return false" href="#">ʜ</a>&nbsp;· <a onclick="insertTags('i','','');return false" href="#">i</a>
<a onclick="insertTags('ɨ','','');return false" href="#">ɨ</a>
<a onclick="insertTags('ɪ','','');return false" href="#">ɪ</a>&nbsp;· <a onclick="insertTags('j','','');return false" href="#">j</a>
<a onclick="insertTags('ʝ','','');return false" href="#">ʝ</a>
<a onclick="insertTags('ɟ','','');return false" href="#">ɟ</a>
<a onclick="insertTags('ʄ','','');return false" href="#">ʄ</a>&nbsp;· <a onclick="insertTags('k','','');return false" href="#">k</a>&nbsp;· <a onclick="insertTags('l','','');return false" href="#">l</a>
<a onclick="insertTags('ɫ','','');return false" href="#">ɫ</a>
<a onclick="insertTags('ɬ','','');return false" href="#">ɬ</a>
<a onclick="insertTags('ɭ','','');return false" href="#">ɭ</a>
<a onclick="insertTags('ʟ','','');return false" href="#">ʟ</a>
<a onclick="insertTags('ɮ','','');return false" href="#">ɮ</a>&nbsp;· <a onclick="insertTags('m','','');return false" href="#">m</a>
<a onclick="insertTags('ɱ','','');return false" href="#">ɱ</a>
<a onclick="insertTags('ɯ','','');return false" href="#">ɯ</a>
<a onclick="insertTags('ɰ','','');return false" href="#">ɰ</a>&nbsp;· <a onclick="insertTags('n','','');return false" href="#">n</a>
<a onclick="insertTags('ɲ','','');return false" href="#">ɲ</a>
<a onclick="insertTags('ŋ','','');return false" href="#">ŋ</a>
<a onclick="insertTags('ɳ','','');return false" href="#">ɳ</a>
<a onclick="insertTags('ɴ','','');return false" href="#">ɴ</a>&nbsp;· <a onclick="insertTags('o','','');return false" href="#">o</a>
<a onclick="insertTags('ʘ','','');return false" href="#">ʘ</a>
<a onclick="insertTags('ɵ','','');return false" href="#">ɵ</a>
<a onclick="insertTags('ø','','');return false" href="#">ø</a>
<a onclick="insertTags('œ','','');return false" href="#">œ</a>
<a onclick="insertTags('ɶ','','');return false" href="#">ɶ</a>
<a onclick="insertTags('ɔ','','');return false" href="#">ɔ</a>&nbsp;· <a onclick="insertTags('p','','');return false" href="#">p</a>
<a onclick="insertTags('ɸ','','');return false" href="#">ɸ</a>&nbsp;· <a onclick="insertTags('q','','');return false" href="#">q</a>&nbsp;· <a onclick="insertTags('r','','');return false" href="#">r</a>
<a onclick="insertTags('ɾ','','');return false" href="#">ɾ</a>
<a onclick="insertTags('ɺ','','');return false" href="#">ɺ</a>
<a onclick="insertTags('ɽ','','');return false" href="#">ɽ</a>
<a onclick="insertTags('ɹ','','');return false" href="#">ɹ</a>
<a onclick="insertTags('ɻ','','');return false" href="#">ɻ</a>
<a onclick="insertTags('ʀ','','');return false" href="#">ʀ</a>
<a onclick="insertTags('ʁ','','');return false" href="#">ʁ</a>&nbsp;· <a onclick="insertTags('s','','');return false" href="#">s</a>
<a onclick="insertTags('ʂ','','');return false" href="#">ʂ</a>
<a onclick="insertTags('ʃ','','');return false" href="#">ʃ</a>&nbsp;· <a onclick="insertTags('t','','');return false" href="#">t</a>
<a onclick="insertTags('ʈ','','');return false" href="#">ʈ</a>
<a onclick="insertTags('θ','','');return false" href="#">θ</a>&nbsp;· <a onclick="insertTags('u','','');return false" href="#">u</a>
<a onclick="insertTags('ʉ','','');return false" href="#">ʉ</a>
<a onclick="insertTags('ʊ','','');return false" href="#">ʊ</a>&nbsp;· <a onclick="insertTags('v','','');return false" href="#">v</a>
<a onclick="insertTags('ʋ','','');return false" href="#">ʋ</a>
<a onclick="insertTags('ʌ','','');return false" href="#">ʌ</a>
<a onclick="insertTags('','','');return false" href="#"></a>&nbsp;· <a onclick="insertTags('w','','');return false" href="#">w</a>
<a onclick="insertTags('ʍ','','');return false" href="#">ʍ</a>&nbsp;· <a onclick="insertTags('x','','');return false" href="#">x</a>
<a onclick="insertTags('χ','','');return false" href="#">χ</a>&nbsp;· <a onclick="insertTags('y','','');return false" href="#">y</a>
<a onclick="insertTags('ʎ','','');return false" href="#">ʎ</a>
<a onclick="insertTags('ʏ','','');return false" href="#">ʏ</a>&nbsp;· <a onclick="insertTags('z','','');return false" href="#">z</a>
<a onclick="insertTags('ʑ','','');return false" href="#">ʑ</a>
<a onclick="insertTags('ʐ','','');return false" href="#">ʐ</a>
<a onclick="insertTags('ʒ','','');return false" href="#">ʒ</a>&nbsp;· <a onclick="insertTags('ʔ','','');return false" href="#">ʔ</a>
<a onclick="insertTags('ʡ','','');return false" href="#">ʡ</a>
<a onclick="insertTags('ʕ','','');return false" href="#">ʕ</a>
<a onclick="insertTags('ʢ','','');return false" href="#">ʢ</a>
<a onclick="insertTags('ǀ','','');return false" href="#">ǀ</a>
<a onclick="insertTags('ǂ','','');return false" href="#">ǂ</a>
<a onclick="insertTags('ǁ','','');return false" href="#">ǁ</a>
<a onclick="insertTags('ǃ','','');return false" href="#">ǃ</a>&nbsp;· <a onclick="insertTags('ˈ','','');return false" href="#">ˈ</a>
<a onclick="insertTags('ˌ','','');return false" href="#">ˌ</a>
<a onclick="insertTags('ː','','');return false" href="#">ː</a>
<a onclick="insertTags('ˑ','','');return false" href="#">ˑ</a></font>··· 
<font face="Arial Unicode MS,Lucida Sans Unicode,MS Mincho,Arial,sans-serif" style="text-decoration:none;"></font>
</p>
<p class="specialbasic" style="display:none">
Lateinisch: 
<a onclick="insertTags('Á','','');return false" href="#">Á</a>
<a onclick="insertTags('á','','');return false" href="#">á</a>
<a onclick="insertTags('Ć','','');return false" href="#">Ć</a>
<a onclick="insertTags('ć','','');return false" href="#">ć</a>
<a onclick="insertTags('É','','');return false" href="#">É</a>
<a onclick="insertTags('é','','');return false" href="#">é</a>
<a onclick="insertTags('Í','','');return false" href="#">Í</a>
<a onclick="insertTags('í','','');return false" href="#">í</a>
<a onclick="insertTags('Ó','','');return false" href="#">Ó</a>
<a onclick="insertTags('ó','','');return false" href="#">ó</a>
<a onclick="insertTags('Ś','','');return false" href="#">Ś</a>
<a onclick="insertTags('ś','','');return false" href="#">ś</a>
<a onclick="insertTags('Ú','','');return false" href="#">Ú</a>
<a onclick="insertTags('ú','','');return false" href="#">ú</a>
<a onclick="insertTags('Ý','','');return false" href="#">Ý</a>
<a onclick="insertTags('ý','','');return false" href="#">ý</a>
<a onclick="insertTags('Ǿ','','');return false" href="#">Ǿ</a>
<a onclick="insertTags('ǿ','','');return false" href="#">ǿ</a> ···
<a onclick="insertTags('À','','');return false" href="#">À</a>
<a onclick="insertTags('à','','');return false" href="#">à</a>
<a onclick="insertTags('È','','');return false" href="#">È</a>
<a onclick="insertTags('è','','');return false" href="#">è</a>
<a onclick="insertTags('Ì','','');return false" href="#">Ì</a>
<a onclick="insertTags('ì','','');return false" href="#">ì</a>
<a onclick="insertTags('Ò','','');return false" href="#">Ò</a>
<a onclick="insertTags('ò','','');return false" href="#">ò</a>
<a onclick="insertTags('Ù','','');return false" href="#">Ù</a>
<a onclick="insertTags('ù','','');return false" href="#">ù</a> ···
<a onclick="insertTags('Â','','');return false" href="#">Â</a>
<a onclick="insertTags('â','','');return false" href="#">â</a>
<a onclick="insertTags('Ĉ','','');return false" href="#">Ĉ</a>
<a onclick="insertTags('ĉ','','');return false" href="#">ĉ</a>
<a onclick="insertTags('Ê','','');return false" href="#">Ê</a>
<a onclick="insertTags('ê','','');return false" href="#">ê</a>
<a onclick="insertTags('Ĝ','','');return false" href="#">Ĝ</a>
<a onclick="insertTags('ĝ','','');return false" href="#">ĝ</a>
<a onclick="insertTags('Ĥ','','');return false" href="#">Ĥ</a>
<a onclick="insertTags('ĥ','','');return false" href="#">ĥ</a>
<a onclick="insertTags('Î','','');return false" href="#">Î</a>
<a onclick="insertTags('î','','');return false" href="#">î</a>
<a onclick="insertTags('Ĵ','','');return false" href="#">Ĵ</a>
<a onclick="insertTags('ĵ','','');return false" href="#">ĵ</a>
<a onclick="insertTags('Ô','','');return false" href="#">Ô</a>
<a onclick="insertTags('ô','','');return false" href="#">ô</a>
<a onclick="insertTags('ŝ','','');return false" href="#">ŝ</a>
<a onclick="insertTags('Ŝ','','');return false" href="#">Ŝ</a>
<a onclick="insertTags('Û','','');return false" href="#">Û</a>
<a onclick="insertTags('û','','');return false" href="#">û</a> ···
<a onclick="insertTags('Ä','','');return false" href="#">Ä</a>
<a onclick="insertTags('ä','','');return false" href="#">ä</a>
<a onclick="insertTags('Ë','','');return false" href="#">Ë</a>
<a onclick="insertTags('ë','','');return false" href="#">ë</a>
<a onclick="insertTags('Ï','','');return false" href="#">Ï</a>
<a onclick="insertTags('ï','','');return false" href="#">ï</a>
<a onclick="insertTags('Ö','','');return false" href="#">Ö</a>
<a onclick="insertTags('ö','','');return false" href="#">ö</a>
<a onclick="insertTags('Ü','','');return false" href="#">Ü</a>
<a onclick="insertTags('ü','','');return false" href="#">ü</a>
<a onclick="insertTags('ÿ','','');return false" href="#">ÿ</a> ···
<a onclick="insertTags('Ã','','');return false" href="#">Ã</a>
<a onclick="insertTags('ã','','');return false" href="#">ã</a>
<a onclick="insertTags('Ñ','','');return false" href="#">Ñ</a>
<a onclick="insertTags('ñ','','');return false" href="#">ñ</a>
<a onclick="insertTags('Õ','','');return false" href="#">Õ</a>
<a onclick="insertTags('õ','','');return false" href="#">õ</a> ···
<a onclick="insertTags('Å','','');return false" href="#">Å</a>
<a onclick="insertTags('å','','');return false" href="#">å</a> ···
<a onclick="insertTags('Ç','','');return false" href="#">Ç</a>
<a onclick="insertTags('ç','','');return false" href="#">ç</a> ···
<a onclick="insertTags('Č','','');return false" href="#">Č</a>
<a onclick="insertTags('č','','');return false" href="#">č</a>
<a onclick="insertTags('Š','','');return false" href="#">Š</a>
<a onclick="insertTags('š','','');return false" href="#">š</a>
<a onclick="insertTags('ŭ','','');return false" href="#">ŭ</a> ···
<a onclick="insertTags('Ł','','');return false" href="#">Ł</a>
<a onclick="insertTags('ł','','');return false" href="#">ł</a> ···
<a onclick="insertTags('Ő','','');return false" href="#">Ő</a>
<a onclick="insertTags('ő','','');return false" href="#">ő</a>
<a onclick="insertTags('Ű','','');return false" href="#">Ű</a>
<a onclick="insertTags('ű','','');return false" href="#">ű</a> ···
<a onclick="insertTags('Ø','','');return false" href="#">Ø</a>
<a onclick="insertTags('ø','','');return false" href="#">ø</a> ···
<a onclick="insertTags('Ā','','');return false" href="#">Ā</a>
<a onclick="insertTags('ā','','');return false" href="#">ā</a>
<a onclick="insertTags('Ē','','');return false" href="#">Ē</a>
<a onclick="insertTags('ē','','');return false" href="#">ē</a>
<a onclick="insertTags('Ī','','');return false" href="#">Ī</a>
<a onclick="insertTags('ī','','');return false" href="#">ī</a>
<a onclick="insertTags('Ō','','');return false" href="#">Ō</a>
<a onclick="insertTags('ō','','');return false" href="#">ō</a>
<a onclick="insertTags('Ū','','');return false" href="#">Ū</a>
<a onclick="insertTags('ū','','');return false" href="#">ū</a>
<a onclick="insertTags('Ȳ','','');return false" href="#">Ȳ</a>
<a onclick="insertTags('ȳ','','');return false" href="#">ȳ</a> ···
<font face="Arial Unicode MS,Lucida Sans Unicode,MS Mincho,Arial,sans-serif" style="text-decoration:none;"><a onclick="insertTags('Ă','','');return false" href="#">Ă</a>
<a onclick="insertTags('ă','','');return false" href="#">ă</a>
<a onclick="insertTags('Ĕ','','');return false" href="#">Ĕ</a>
<a onclick="insertTags('ĕ','','');return false" href="#">ĕ</a>
<a onclick="insertTags('Ğ','','');return false" href="#">Ğ</a>
<a onclick="insertTags('ğ','','');return false" href="#">ğ</a>
<a onclick="insertTags('Ĭ','','');return false" href="#">Ĭ</a>
<a onclick="insertTags('ĭ','','');return false" href="#">ĭ</a>
<a onclick="insertTags('Ŏ','','');return false" href="#">Ŏ</a>
<a onclick="insertTags('ŏ','','');return false" href="#">ŏ</a>
<a onclick="insertTags('Ŭ','','');return false" href="#">Ŭ</a>
<a onclick="insertTags('ŭ','','');return false" href="#">ŭ</a>
<a onclick="insertTags('Y̆','','');return false" href="#">Y̆</a>
<a onclick="insertTags('y̆','','');return false" href="#">y̆</a></font> ...
<a onclick="insertTags('ß','','');return false" href="#">ß</a> ...
<a onclick="insertTags('Æ','','');return false" href="#">Æ</a>
<a onclick="insertTags('æ','','');return false" href="#">æ</a>
<a onclick="insertTags('Œ','','');return false" href="#">Œ</a>
<a onclick="insertTags('œ','','');return false" href="#">œ</a> ··· 
<a onclick="insertTags('Ð','','');return false" href="#">Ð</a>
<a onclick="insertTags('ð','','');return false" href="#">ð</a>
<a onclick="insertTags('Þ','','');return false" href="#">Þ</a>
<a onclick="insertTags('þ','','');return false" href="#">þ</a>
<a onclick="insertTags('|','','');return false" href="#">|</a><br/>
</p>
<p class="speciallang" style="display:none">
AHD-Lautschrift: 
<font face="Arial Unicode MS,Lucida Sans Unicode,MS Mincho,Arial,sans-serif" style="text-decoration:none;"><a onclick="insertTags('ā','','');return false" href="#">ā</a>
<a onclick="insertTags('ă','','');return false" href="#">ă</a>
<a onclick="insertTags('ä','','');return false" href="#">ä</a>
<a onclick="insertTags('â','','');return false" href="#">â</a>
<a onclick="insertTags('ē','','');return false" href="#">ē</a>
<a onclick="insertTags('ĕ','','');return false" href="#">ĕ</a>
<a onclick="insertTags('ī','','');return false" href="#">ī</a>
<a onclick="insertTags('ĭ','','');return false" href="#">ĭ</a>
<a onclick="insertTags('î','','');return false" href="#">î</a>
<a onclick="insertTags('ō','','');return false" href="#">ō</a>
<a onclick="insertTags('ŏ','','');return false" href="#">ŏ</a>
<a onclick="insertTags('ô','','');return false" href="#">ô</a>
<a onclick="insertTags('ŭ','','');return false" href="#">ŭ</a>
<a onclick="insertTags('o͞o','','');return false" href="#">o͞o</a></font> („food") <font face="Arial Unicode MS,Lucida Sans Unicode,MS Mincho,Arial,sans-serif" style="text-decoration:none;"><a onclick="insertTags('o͝o','','');return false" href="#">o͝o</a></font> („foot") <a onclick="insertTags('û','','');return false" href="#">û</a>
<a onclick="insertTags('ə','','');return false" href="#">ə</a> ··· 
</p>
<p class="speciallang" style="display:none">
Altenglisch: 
<font face="Arial Unicode MS,Lucida Sans Unicode,MS Mincho,Arial,sans-serif" style="text-decoration:none;"><a onclick="insertTags('Ā','','');return false" href="#">Ā</a>
<a onclick="insertTags('ā','','');return false" href="#">ā</a>
<a onclick="insertTags('Æ','','');return false" href="#">Æ</a>
<a onclick="insertTags('æ','','');return false" href="#">æ</a>
<a onclick="insertTags('Ǣ','','');return false" href="#">Ǣ</a>
<a onclick="insertTags('ǣ','','');return false" href="#">ǣ</a>
<a onclick="insertTags('Ǽ','','');return false" href="#">Ǽ</a>
<a onclick="insertTags('ǽ','','');return false" href="#">ǽ</a>
<a onclick="insertTags('Ċ','','');return false" href="#">Ċ</a>
<a onclick="insertTags('ċ','','');return false" href="#">ċ</a>
<a onclick="insertTags('Ð','','');return false" href="#">Ð</a>
<a onclick="insertTags('ð','','');return false" href="#">ð</a>
<a onclick="insertTags('Ē','','');return false" href="#">Ē</a>
<a onclick="insertTags('ē','','');return false" href="#">ē</a>
<a onclick="insertTags('Ġ','','');return false" href="#">Ġ</a>
<a onclick="insertTags('ġ','','');return false" href="#">ġ</a>
<a onclick="insertTags('Ī','','');return false" href="#">Ī</a>
<a onclick="insertTags('ī','','');return false" href="#">ī</a>
<a onclick="insertTags('Ō','','');return false" href="#">Ō</a>
<a onclick="insertTags('ō','','');return false" href="#">ō</a>
<a onclick="insertTags('Ū','','');return false" href="#">Ū</a>
<a onclick="insertTags('ū','','');return false" href="#">ū</a>
<a onclick="insertTags('Ƿ','','');return false" href="#">Ƿ</a>
<a onclick="insertTags('ƿ','','');return false" href="#">ƿ</a>
<a onclick="insertTags('Ȳ','','');return false" href="#">Ȳ</a>
<a onclick="insertTags('ȳ','','');return false" href="#">ȳ</a>
<a onclick="insertTags('Þ','','');return false" href="#">Þ</a>
<a onclick="insertTags('þ','','');return false" href="#">þ</a>
<a onclick="insertTags('Ȝ','','');return false" href="#">Ȝ</a>
<a onclick="insertTags('ȝ','','');return false" href="#">ȝ</a></font>
</p>
<p class="speciallang" style="display:none">
Altgriechisch: 
<font face="Arial Unicode MS,Lucida Sans Unicode,MS Mincho,Arial,sans-serif" style="text-decoration:none;"><a onclick="insertTags('Α','','');return false" href="#">Α</a>
<a onclick="insertTags('α','','');return false" href="#">α</a>
<a onclick="insertTags('Ά','','');return false" href="#">Ά</a>
<a onclick="insertTags('ά','','');return false" href="#">ά</a>
<a onclick="insertTags('Β','','');return false" href="#">Β</a>
<a onclick="insertTags('β','','');return false" href="#">β</a>
<a onclick="insertTags('Γ','','');return false" href="#">Γ</a>
<a onclick="insertTags('γ','','');return false" href="#">γ</a>
<a onclick="insertTags('Δ','','');return false" href="#">Δ</a>
<a onclick="insertTags('δ','','');return false" href="#">δ</a>
<a onclick="insertTags('Ε','','');return false" href="#">Ε</a>
<a onclick="insertTags('ε','','');return false" href="#">ε</a>
<a onclick="insertTags('Έ','','');return false" href="#">Έ</a>
<a onclick="insertTags('έ','','');return false" href="#">έ</a>
<a onclick="insertTags('Ζ','','');return false" href="#">Ζ</a>
<a onclick="insertTags('ζ','','');return false" href="#">ζ</a>
<a onclick="insertTags('Η','','');return false" href="#">Η</a>
<a onclick="insertTags('η','','');return false" href="#">η</a>
<a onclick="insertTags('Ή','','');return false" href="#">Ή</a>
<a onclick="insertTags('ή','','');return false" href="#">ή</a>
<a onclick="insertTags('Θ','','');return false" href="#">Θ</a>
<a onclick="insertTags('θ','','');return false" href="#">θ</a>
<a onclick="insertTags('Ι','','');return false" href="#">Ι</a>
<a onclick="insertTags('ι','','');return false" href="#">ι</a>
<a onclick="insertTags('Ί','','');return false" href="#">Ί</a>
<a onclick="insertTags('ί','','');return false" href="#">ί</a>
<a onclick="insertTags('Ϊ','','');return false" href="#">Ϊ</a>
<a onclick="insertTags('ϊ','','');return false" href="#">ϊ</a>
<a onclick="insertTags('ΐ','','');return false" href="#">ΐ</a>
<a onclick="insertTags('Κ','','');return false" href="#">Κ</a>
<a onclick="insertTags('κ','','');return false" href="#">κ</a>
<a onclick="insertTags('Λ','','');return false" href="#">Λ</a>
<a onclick="insertTags('λ','','');return false" href="#">λ</a>
<a onclick="insertTags('Μ','','');return false" href="#">Μ</a>
<a onclick="insertTags('μ','','');return false" href="#">μ</a>
<a onclick="insertTags('Ν','','');return false" href="#">Ν</a>
<a onclick="insertTags('ν','','');return false" href="#">ν</a>
<a onclick="insertTags('Ξ','','');return false" href="#">Ξ</a>
<a onclick="insertTags('ξ','','');return false" href="#">ξ</a>
<a onclick="insertTags('Ο','','');return false" href="#">Ο</a>
<a onclick="insertTags('ο','','');return false" href="#">ο</a>
<a onclick="insertTags('Ό','','');return false" href="#">Ό</a>
<a onclick="insertTags('ό','','');return false" href="#">ό</a>
<a onclick="insertTags('Π','','');return false" href="#">Π</a>
<a onclick="insertTags('π','','');return false" href="#">π</a>
<a onclick="insertTags('Ρ','','');return false" href="#">Ρ</a>
<a onclick="insertTags('ρ','','');return false" href="#">ρ</a>
<a onclick="insertTags('Σ','','');return false" href="#">Σ</a>
<a onclick="insertTags('σ','','');return false" href="#">σ</a>
<a onclick="insertTags('ς','','');return false" href="#">ς</a>
<a onclick="insertTags('Τ','','');return false" href="#">Τ</a>
<a onclick="insertTags('τ','','');return false" href="#">τ</a>
<a onclick="insertTags('Υ','','');return false" href="#">Υ</a>
<a onclick="insertTags('υ','','');return false" href="#">υ</a>
<a onclick="insertTags('Ϋ','','');return false" href="#">Ϋ</a>
<a onclick="insertTags('ϋ','','');return false" href="#">ϋ</a>
<a onclick="insertTags('Ύ','','');return false" href="#">Ύ</a>
<a onclick="insertTags('ύ','','');return false" href="#">ύ</a>
<a onclick="insertTags('ΰ','','');return false" href="#">ΰ</a>
<a onclick="insertTags('Φ','','');return false" href="#">Φ</a>
<a onclick="insertTags('φ','','');return false" href="#">φ</a>
<a onclick="insertTags('Χ','','');return false" href="#">Χ</a>
<a onclick="insertTags('χ','','');return false" href="#">χ</a>
<a onclick="insertTags('Ψ','','');return false" href="#">Ψ</a>
<a onclick="insertTags('ψ','','');return false" href="#">ψ</a>
<a onclick="insertTags('Ω','','');return false" href="#">Ω</a>
<a onclick="insertTags('ω','','');return false" href="#">ω</a>
<a onclick="insertTags('Ώ','','');return false" href="#">Ώ</a>
<a onclick="insertTags('ώ','','');return false" href="#">ώ</a>
<a onclick="insertTags(';','','');return false" href="#">;</a>
<a onclick="insertTags('·','','');return false" href="#">·</a>
<a onclick="insertTags('ἀ','','');return false" href="#">ἀ</a>
<a onclick="insertTags('ἁ','','');return false" href="#">ἁ</a>
<a onclick="insertTags('ὰ','','');return false" href="#">ὰ</a>
<a onclick="insertTags('ᾶ','','');return false" href="#">ᾶ</a>
<a onclick="insertTags('ἂ','','');return false" href="#">ἂ</a>
<a onclick="insertTags('ἃ','','');return false" href="#">ἃ</a>
<a onclick="insertTags('ἄ','','');return false" href="#">ἄ</a>
<a onclick="insertTags('ἅ','','');return false" href="#">ἅ</a>
<a onclick="insertTags('ἆ','','');return false" href="#">ἆ</a>
<a onclick="insertTags('ἇ','','');return false" href="#">ἇ</a>
<a onclick="insertTags('ᾳ','','');return false" href="#">ᾳ</a>
<a onclick="insertTags('ᾀ','','');return false" href="#">ᾀ</a>
<a onclick="insertTags('ᾁ','','');return false" href="#">ᾁ</a>
<a onclick="insertTags('ᾴ','','');return false" href="#">ᾴ</a>
<a onclick="insertTags('ᾲ','','');return false" href="#">ᾲ</a>
<a onclick="insertTags('ᾷ','','');return false" href="#">ᾷ</a>
<a onclick="insertTags('ᾄ','','');return false" href="#">ᾄ</a>
<a onclick="insertTags('ᾅ','','');return false" href="#">ᾅ</a>
<a onclick="insertTags('ᾂ','','');return false" href="#">ᾂ</a>
<a onclick="insertTags('ᾃ','','');return false" href="#">ᾃ</a>
<a onclick="insertTags('ᾆ','','');return false" href="#">ᾆ</a>
<a onclick="insertTags('ᾇ','','');return false" href="#">ᾇ</a>
<a onclick="insertTags('ἐ','','');return false" href="#">ἐ</a>
<a onclick="insertTags('ἑ','','');return false" href="#">ἑ</a>
<a onclick="insertTags('ὲ','','');return false" href="#">ὲ</a>
<a onclick="insertTags('ἔ','','');return false" href="#">ἔ</a>
<a onclick="insertTags('ἕ','','');return false" href="#">ἕ</a>
<a onclick="insertTags('ἒ','','');return false" href="#">ἒ</a>
<a onclick="insertTags('ἓ','','');return false" href="#">ἓ</a>
<a onclick="insertTags('ἠ','','');return false" href="#">ἠ</a>
<a onclick="insertTags('ἡ','','');return false" href="#">ἡ</a>
<a onclick="insertTags('ὴ','','');return false" href="#">ὴ</a>
<a onclick="insertTags('ῆ','','');return false" href="#">ῆ</a>
<a onclick="insertTags('ἤ','','');return false" href="#">ἤ</a>
<a onclick="insertTags('ἢ','','');return false" href="#">ἢ</a>
<a onclick="insertTags('ἣ','','');return false" href="#">ἣ</a>
<a onclick="insertTags('ἥ','','');return false" href="#">ἥ</a>
<a onclick="insertTags('ἦ','','');return false" href="#">ἦ</a>
<a onclick="insertTags('ἧ','','');return false" href="#">ἧ</a>
<a onclick="insertTags('ῃ','','');return false" href="#">ῃ</a>
<a onclick="insertTags('ῄ','','');return false" href="#">ῄ</a>
<a onclick="insertTags('ῂ','','');return false" href="#">ῂ</a>
<a onclick="insertTags('ῇ','','');return false" href="#">ῇ</a>
<a onclick="insertTags('ᾐ','','');return false" href="#">ᾐ</a>
<a onclick="insertTags('ᾑ','','');return false" href="#">ᾑ</a>
<a onclick="insertTags('ᾔ','','');return false" href="#">ᾔ</a>
<a onclick="insertTags('ᾒ','','');return false" href="#">ᾒ</a>
<a onclick="insertTags('ᾕ','','');return false" href="#">ᾕ</a>
<a onclick="insertTags('ᾓ','','');return false" href="#">ᾓ</a>
<a onclick="insertTags('ᾖ','','');return false" href="#">ᾖ</a>
<a onclick="insertTags('ᾗ','','');return false" href="#">ᾗ</a>
<a onclick="insertTags('ἰ','','');return false" href="#">ἰ</a>
<a onclick="insertTags('ἱ','','');return false" href="#">ἱ</a>
<a onclick="insertTags('ὶ','','');return false" href="#">ὶ</a>
<a onclick="insertTags('ῖ','','');return false" href="#">ῖ</a>
<a onclick="insertTags('ἴ','','');return false" href="#">ἴ</a>
<a onclick="insertTags('ἲ','','');return false" href="#">ἲ</a>
<a onclick="insertTags('ἵ','','');return false" href="#">ἵ</a>
<a onclick="insertTags('ἶ','','');return false" href="#">ἶ</a>
<a onclick="insertTags('ἷ','','');return false" href="#">ἷ</a>
<a onclick="insertTags('ὀ','','');return false" href="#">ὀ</a>
<a onclick="insertTags('ὁ','','');return false" href="#">ὁ</a>
<a onclick="insertTags('ὄ','','');return false" href="#">ὄ</a>
<a onclick="insertTags('ὅ','','');return false" href="#">ὅ</a>
<a onclick="insertTags('ὂ','','');return false" href="#">ὂ</a>
<a onclick="insertTags('ὃ','','');return false" href="#">ὃ</a>
<a onclick="insertTags('ὐ','','');return false" href="#">ὐ</a>
<a onclick="insertTags('ὑ','','');return false" href="#">ὑ</a>
<a onclick="insertTags('ὺ','','');return false" href="#">ὺ</a>
<a onclick="insertTags('ῦ','','');return false" href="#">ῦ</a>
<a onclick="insertTags('ὔ','','');return false" href="#">ὔ</a>
<a onclick="insertTags('ὕ','','');return false" href="#">ὕ</a>
<a onclick="insertTags('ὒ','','');return false" href="#">ὒ</a>
<a onclick="insertTags('ὓ','','');return false" href="#">ὓ</a>
<a onclick="insertTags('ὖ','','');return false" href="#">ὖ</a>
<a onclick="insertTags('ὗ','','');return false" href="#">ὗ</a>
<a onclick="insertTags('ὠ','','');return false" href="#">ὠ</a>
<a onclick="insertTags('ὡ','','');return false" href="#">ὡ</a>
<a onclick="insertTags('ὼ','','');return false" href="#">ὼ</a>
<a onclick="insertTags('ῶ','','');return false" href="#">ῶ</a>
<a onclick="insertTags('ὤ','','');return false" href="#">ὤ</a>
<a onclick="insertTags('ὢ','','');return false" href="#">ὢ</a>
<a onclick="insertTags('ὥ','','');return false" href="#">ὥ</a>
<a onclick="insertTags('ὣ','','');return false" href="#">ὣ</a>
<a onclick="insertTags('ὦ','','');return false" href="#">ὦ</a>
<a onclick="insertTags('ὧ','','');return false" href="#">ὧ</a>
<a onclick="insertTags('ῴ','','');return false" href="#">ῴ</a>
<a onclick="insertTags('ῲ','','');return false" href="#">ῲ</a>
<a onclick="insertTags('ῷ','','');return false" href="#">ῷ</a>
<a onclick="insertTags('ᾠ','','');return false" href="#">ᾠ</a>
<a onclick="insertTags('ᾡ','','');return false" href="#">ᾡ</a>
<a onclick="insertTags('ᾤ','','');return false" href="#">ᾤ</a>
<a onclick="insertTags('ᾢ','','');return false" href="#">ᾢ</a>
<a onclick="insertTags('ᾥ','','');return false" href="#">ᾥ</a>
<a onclick="insertTags('ᾣ','','');return false" href="#">ᾣ</a>
<a onclick="insertTags('ᾦ','','');return false" href="#">ᾦ</a>
<a onclick="insertTags('ᾧ','','');return false" href="#">ᾧ</a>
<a onclick="insertTags('`','','');return false" href="#">`</a>
<a onclick="insertTags('᾿','','');return false" href="#">᾿</a>
<a onclick="insertTags('῾','','');return false" href="#">῾</a>
<a onclick="insertTags('῍','','');return false" href="#">῍</a>
<a onclick="insertTags('῎','','');return false" href="#">῎</a>
<a onclick="insertTags('῏','','');return false" href="#">῏</a>
<a onclick="insertTags('῟','','');return false" href="#">῟</a>
<a onclick="insertTags('῞','','');return false" href="#">῞</a>
<a onclick="insertTags('῝','','');return false" href="#">῝</a>
<a onclick="insertTags('῍','','');return false" href="#">῍</a>
<a onclick="insertTags('῎','','');return false" href="#">῎</a></font>
</p>
<p class="speciallang" style="display:none">
Arabisch: 
<span style="font-family: 'Traditional Arabic', 'Arial Unicode MS' , 'Lucida Sans Unicode' , 'MS Mincho', sans-serif; font-size: 1.5em"><a onclick="insertTags('؛','','');return false" href="#">؛</a>
<a onclick="insertTags('؟','','');return false" href="#">؟</a>
<a onclick="insertTags('ء','','');return false" href="#">ء</a>
<a onclick="insertTags('آ','','');return false" href="#">آ</a>
<a onclick="insertTags('أ','','');return false" href="#">أ</a>
<a onclick="insertTags('ؤ','','');return false" href="#">ؤ</a>
<a onclick="insertTags('إ','','');return false" href="#">إ</a>
<a onclick="insertTags('ئ','','');return false" href="#">ئ</a>
<a onclick="insertTags('ا','','');return false" href="#">ا</a>
<a onclick="insertTags('ب','','');return false" href="#">ب</a>
<a onclick="insertTags('ة','','');return false" href="#">ة</a>
<a onclick="insertTags('ت','','');return false" href="#">ت</a>
<a onclick="insertTags('ث','','');return false" href="#">ث</a>
<a onclick="insertTags('ج','','');return false" href="#">ج</a>
<a onclick="insertTags('ح','','');return false" href="#">ح</a>
<a onclick="insertTags('خ','','');return false" href="#">خ</a>
<a onclick="insertTags('د','','');return false" href="#">د</a>
<a onclick="insertTags('ذ','','');return false" href="#">ذ</a>
<a onclick="insertTags('ر','','');return false" href="#">ر</a>
<a onclick="insertTags('ز','','');return false" href="#">ز</a>
<a onclick="insertTags('س','','');return false" href="#">س</a>
<a onclick="insertTags('ش','','');return false" href="#">ش</a>
<a onclick="insertTags('ص','','');return false" href="#">ص</a>
<a onclick="insertTags('ض','','');return false" href="#">ض</a>
<a onclick="insertTags('ط','','');return false" href="#">ط</a>
<a onclick="insertTags('ظ','','');return false" href="#">ظ</a>
<a onclick="insertTags('ع','','');return false" href="#">ع</a>
<a onclick="insertTags('غ','','');return false" href="#">غ</a>
<a onclick="insertTags('ف','','');return false" href="#">ف</a>
<a onclick="insertTags('ق','','');return false" href="#">ق</a>
<a onclick="insertTags('ك','','');return false" href="#">ك</a>
<a onclick="insertTags('ل','','');return false" href="#">ل</a>
<a onclick="insertTags('م','','');return false" href="#">م</a>
<a onclick="insertTags('ن','','');return false" href="#">ن</a>
<a onclick="insertTags('ه','','');return false" href="#">ه</a>
<a onclick="insertTags('و','','');return false" href="#">و</a>
<a onclick="insertTags('ى','','');return false" href="#">ى</a>
<a onclick="insertTags('ي','','');return false" href="#">ي</a>
<a onclick="insertTags('،','','');return false" href="#">،</a>··· 
<a onclick="insertTags('پ','','');return false" href="#">پ</a>
<a onclick="insertTags('چ','','');return false" href="#">چ</a>
<a onclick="insertTags('ژ','','');return false" href="#">ژ</a>
<a onclick="insertTags('گ','','');return false" href="#">گ</a>
<a onclick="insertTags('ڭ','','');return false" href="#">ڭ</a></span>
</p>
<p class="speciallang" style="display:none">
DMG-Umschrift: 
<a onclick="insertTags('ʾ','','');return false" href="#">ʾ</a>
<a onclick="insertTags('ʿ','','');return false" href="#">ʿ</a>
<a onclick="insertTags('Ā','','');return false" href="#">Ā</a>
<a onclick="insertTags('ā','','');return false" href="#">ā</a>
<a onclick="insertTags('Č','','');return false" href="#">Č</a>
<a onclick="insertTags('č','','');return false" href="#">č</a>
<a onclick="insertTags('Ḍ','','');return false" href="#">Ḍ</a>
<a onclick="insertTags('ḍ','','');return false" href="#">ḍ</a>
<a onclick="insertTags('Ḏ','','');return false" href="#">Ḏ</a>
<a onclick="insertTags('ḏ','','');return false" href="#">ḏ</a>
<a onclick="insertTags('Ǧ','','');return false" href="#">Ǧ</a>
<a onclick="insertTags('ǧ','','');return false" href="#">ǧ</a>
<a onclick="insertTags('Ġ','','');return false" href="#">Ġ</a>
<a onclick="insertTags('ġ','','');return false" href="#">ġ</a>
<a onclick="insertTags('Ḥ','','');return false" href="#">Ḥ</a>
<a onclick="insertTags('ḥ','','');return false" href="#">ḥ</a>
<a onclick="insertTags('Ḫ','','');return false" href="#">Ḫ</a>
<a onclick="insertTags('ḫ','','');return false" href="#">ḫ</a>
<a onclick="insertTags('Ī','','');return false" href="#">Ī</a>
<a onclick="insertTags('ī','','');return false" href="#">ī</a>
<a onclick="insertTags('ḷ','','');return false" href="#">ḷ</a>
<a onclick="insertTags('ŋ','','');return false" href="#">ŋ</a>
<a onclick="insertTags('Ṣ','','');return false" href="#">Ṣ</a>
<a onclick="insertTags('ṣ','','');return false" href="#">ṣ</a>
<a onclick="insertTags('Š','','');return false" href="#">Š</a>
<a onclick="insertTags('š','','');return false" href="#">š</a>
<a onclick="insertTags('Ṭ','','');return false" href="#">Ṭ</a>
<a onclick="insertTags('ṭ','','');return false" href="#">ṭ</a>
<a onclick="insertTags('Ṯ','','');return false" href="#">Ṯ</a>
<a onclick="insertTags('ṯ','','');return false" href="#">ṯ</a>
<a onclick="insertTags('Ū','','');return false" href="#">Ū</a>
<a onclick="insertTags('ū','','');return false" href="#">ū</a>
<a onclick="insertTags('Ẓ','','');return false" href="#">Ẓ</a>
<a onclick="insertTags('ẓ','','');return false" href="#">ẓ</a>
<a onclick="insertTags('Ẕ','','');return false" href="#">Ẕ</a>
<a onclick="insertTags('ẕ','','');return false" href="#">ẕ</a>
<a onclick="insertTags('Ž','','');return false" href="#">Ž</a>
<a onclick="insertTags('ž','','');return false" href="#">ž</a>
</p>
<p class="speciallang" style="display:none">
Esperanto: 
<a onclick="insertTags('Ĉ','','');return false" href="#">Ĉ</a>
<a onclick="insertTags('ĉ','','');return false" href="#">ĉ</a>
<a onclick="insertTags('Ĝ','','');return false" href="#">Ĝ</a>
<a onclick="insertTags('ĝ','','');return false" href="#">ĝ</a>
<a onclick="insertTags('Ĥ','','');return false" href="#">Ĥ</a>
<a onclick="insertTags('ĥ','','');return false" href="#">ĥ</a>
<a onclick="insertTags('Ĵ','','');return false" href="#">Ĵ</a>
<a onclick="insertTags('ĵ','','');return false" href="#">ĵ</a>
<a onclick="insertTags('Ŝ','','');return false" href="#">Ŝ</a>
<a onclick="insertTags('ŝ','','');return false" href="#">ŝ</a>
<a onclick="insertTags('Ŭ','','');return false" href="#">Ŭ</a>
<a onclick="insertTags('ŭ','','');return false" href="#">ŭ</a>
</p>
<p class="speciallang" style="display:none">
Estnisch: 
<a onclick="insertTags('Č','','');return false" href="#">Č</a>
<a onclick="insertTags('č','','');return false" href="#">č</a>
<a onclick="insertTags('Š','','');return false" href="#">Š</a>
<a onclick="insertTags('š','','');return false" href="#">š</a>
<a onclick="insertTags('Ž','','');return false" href="#">Ž</a>
<a onclick="insertTags('ž','','');return false" href="#">ž</a>
<a onclick="insertTags('Õ','','');return false" href="#">Õ</a>
<a onclick="insertTags('õ','','');return false" href="#">õ</a>
<a onclick="insertTags('Ä','','');return false" href="#">Ä</a>
<a onclick="insertTags('ä','','');return false" href="#">ä</a>
<a onclick="insertTags('Ö','','');return false" href="#">Ö</a>
<a onclick="insertTags('ö','','');return false" href="#">ö</a>
<a onclick="insertTags('Ü','','');return false" href="#">Ü</a>
<a onclick="insertTags('ü','','');return false" href="#">ü</a>
</p>
<p class="speciallang" style="display:none">
Französisch: 
<a onclick="insertTags('À','','');return false" href="#">À</a>
<a onclick="insertTags('à','','');return false" href="#">à</a>
<a onclick="insertTags('Â','','');return false" href="#">Â</a>
<a onclick="insertTags('â','','');return false" href="#">â</a>
<a onclick="insertTags('Ç','','');return false" href="#">Ç</a>
<a onclick="insertTags('ç','','');return false" href="#">ç</a>
<a onclick="insertTags('É','','');return false" href="#">É</a>
<a onclick="insertTags('é','','');return false" href="#">é</a>
<a onclick="insertTags('È','','');return false" href="#">È</a>
<a onclick="insertTags('è','','');return false" href="#">è</a>
<a onclick="insertTags('Ê','','');return false" href="#">Ê</a>
<a onclick="insertTags('ê','','');return false" href="#">ê</a>
<a onclick="insertTags('Ë','','');return false" href="#">Ë</a>
<a onclick="insertTags('ë','','');return false" href="#">ë</a>
<a onclick="insertTags('Î','','');return false" href="#">Î</a>
<a onclick="insertTags('î','','');return false" href="#">î</a>
<a onclick="insertTags('Ï','','');return false" href="#">Ï</a>
<a onclick="insertTags('ï','','');return false" href="#">ï</a>
<a onclick="insertTags('Ô','','');return false" href="#">Ô</a>
<a onclick="insertTags('ô','','');return false" href="#">ô</a>
<a onclick="insertTags('Œ','','');return false" href="#">Œ</a>
<a onclick="insertTags('œ','','');return false" href="#">œ</a>
<a onclick="insertTags('Ù','','');return false" href="#">Ù</a>
<a onclick="insertTags('ù','','');return false" href="#">ù</a>
<a onclick="insertTags('Û','','');return false" href="#">Û</a>
<a onclick="insertTags('û','','');return false" href="#">û</a>
<a onclick="insertTags('Ü','','');return false" href="#">Ü</a>
<a onclick="insertTags('ü','','');return false" href="#">ü</a>
<a onclick="insertTags('Ÿ','','');return false" href="#">Ÿ</a>
<a onclick="insertTags('ÿ','','');return false" href="#">ÿ</a>
</p>
<p class="speciallang" style="display:none">
Galicisch: 
<a onclick="insertTags('Á','','');return false" href="#">Á</a>
<a onclick="insertTags('á','','');return false" href="#">á</a>
<a onclick="insertTags('À','','');return false" href="#">À</a>
<a onclick="insertTags('à','','');return false" href="#">à</a>
<a onclick="insertTags('Â','','');return false" href="#">Â</a>
<a onclick="insertTags('â','','');return false" href="#">â</a>
<a onclick="insertTags('Ä','','');return false" href="#">Ä</a>
<a onclick="insertTags('ä','','');return false" href="#">ä</a>
<a onclick="insertTags('É','','');return false" href="#">É</a>
<a onclick="insertTags('é','','');return false" href="#">é</a>
<a onclick="insertTags('È','','');return false" href="#">È</a>
<a onclick="insertTags('è','','');return false" href="#">è</a>
<a onclick="insertTags('Ê','','');return false" href="#">Ê</a>
<a onclick="insertTags('ê','','');return false" href="#">ê</a>
<a onclick="insertTags('Ë','','');return false" href="#">Ë</a>
<a onclick="insertTags('ë','','');return false" href="#">ë</a>
<a onclick="insertTags('Ì','','');return false" href="#">Ì</a>
<a onclick="insertTags('ì','','');return false" href="#">ì</a>
<a onclick="insertTags('Î','','');return false" href="#">Î</a>
<a onclick="insertTags('î','','');return false" href="#">î</a>
<a onclick="insertTags('Ï','','');return false" href="#">Ï</a>
<a onclick="insertTags('ï','','');return false" href="#">ï</a>
<a onclick="insertTags('Ó','','');return false" href="#">Ó</a>
<a onclick="insertTags('ó','','');return false" href="#">ó</a>
<a onclick="insertTags('Ò','','');return false" href="#">Ò</a>
<a onclick="insertTags('ò','','');return false" href="#">ò</a>
<a onclick="insertTags('Ô','','');return false" href="#">Ô</a>
<a onclick="insertTags('ô','','');return false" href="#">ô</a>
<a onclick="insertTags('Ö','','');return false" href="#">Ö</a>
<a onclick="insertTags('ö','','');return false" href="#">ö</a>
<a onclick="insertTags('Ù','','');return false" href="#">Ù</a>
<a onclick="insertTags('ù','','');return false" href="#">ù</a>
<a onclick="insertTags('Û','','');return false" href="#">Û</a>
<a onclick="insertTags('û','','');return false" href="#">û</a>
<a onclick="insertTags('Ẁ','','');return false" href="#">Ẁ</a>
<a onclick="insertTags('ẁ','','');return false" href="#">ẁ</a>
<a onclick="insertTags('Ŵ','','');return false" href="#">Ŵ</a>
<a onclick="insertTags('ŵ','','');return false" href="#">ŵ</a>
<a onclick="insertTags('Ẅ','','');return false" href="#">Ẅ</a>
<a onclick="insertTags('ẅ','','');return false" href="#">ẅ</a>
<a onclick="insertTags('Ý','','');return false" href="#">Ý</a>
<a onclick="insertTags('ý','','');return false" href="#">ý</a>
<a onclick="insertTags('Ỳ','','');return false" href="#">Ỳ</a>
<a onclick="insertTags('ỳ','','');return false" href="#">ỳ</a>
<a onclick="insertTags('Ŷ','','');return false" href="#">Ŷ</a>
<a onclick="insertTags('ŷ','','');return false" href="#">ŷ</a>
<a onclick="insertTags('Ÿ','','');return false" href="#">Ÿ</a>
<a onclick="insertTags('ÿ','','');return false" href="#">ÿ</a>
</p>
<p class="specialbasic" style="display:none">
Griechisch: 
<a onclick="insertTags('Α','','');return false" href="#">Α</a>
<a onclick="insertTags('Ά','','');return false" href="#">Ά</a>
<a onclick="insertTags('Β','','');return false" href="#">Β</a>
<a onclick="insertTags('Γ','','');return false" href="#">Γ</a>
<a onclick="insertTags('Δ','','');return false" href="#">Δ</a>
<a onclick="insertTags('Ε','','');return false" href="#">Ε</a>
<a onclick="insertTags('Έ','','');return false" href="#">Έ</a>
<a onclick="insertTags('Ζ','','');return false" href="#">Ζ</a>
<a onclick="insertTags('Η','','');return false" href="#">Η</a>
<a onclick="insertTags('Ή','','');return false" href="#">Ή</a>
<a onclick="insertTags('Θ','','');return false" href="#">Θ</a>
<a onclick="insertTags('Ι','','');return false" href="#">Ι</a>
<a onclick="insertTags('Ί','','');return false" href="#">Ί</a>
<a onclick="insertTags('Κ','','');return false" href="#">Κ</a>
<a onclick="insertTags('Λ','','');return false" href="#">Λ</a>
<a onclick="insertTags('Μ','','');return false" href="#">Μ</a>
<a onclick="insertTags('Ν','','');return false" href="#">Ν</a>
<a onclick="insertTags('Ξ','','');return false" href="#">Ξ</a>
<a onclick="insertTags('Ο','','');return false" href="#">Ο</a>
<a onclick="insertTags('Ό','','');return false" href="#">Ό</a>
<a onclick="insertTags('Π','','');return false" href="#">Π</a>
<a onclick="insertTags('Ρ','','');return false" href="#">Ρ</a>
<a onclick="insertTags('Σ','','');return false" href="#">Σ</a>
<a onclick="insertTags('Τ','','');return false" href="#">Τ</a>
<a onclick="insertTags('Υ','','');return false" href="#">Υ</a>
<a onclick="insertTags('Ύ','','');return false" href="#">Ύ</a>
<a onclick="insertTags('Φ','','');return false" href="#">Φ</a>
<a onclick="insertTags('Χ','','');return false" href="#">Χ</a>
<a onclick="insertTags('Ψ','','');return false" href="#">Ψ</a>
<a onclick="insertTags('Ω','','');return false" href="#">Ω</a>
<a onclick="insertTags('Ώ','','');return false" href="#">Ώ</a>  ··· 
<a onclick="insertTags('α','','');return false" href="#">α</a>
<a onclick="insertTags('ά','','');return false" href="#">ά</a>
<a onclick="insertTags('β','','');return false" href="#">β</a>
<a onclick="insertTags('γ','','');return false" href="#">γ</a>
<a onclick="insertTags('δ','','');return false" href="#">δ</a>
<a onclick="insertTags('ε','','');return false" href="#">ε</a>
<a onclick="insertTags('έ','','');return false" href="#">έ</a>
<a onclick="insertTags('ζ','','');return false" href="#">ζ</a>
<a onclick="insertTags('η','','');return false" href="#">η</a>
<a onclick="insertTags('ή','','');return false" href="#">ή</a>
<a onclick="insertTags('θ','','');return false" href="#">θ</a>
<a onclick="insertTags('ι','','');return false" href="#">ι</a>
<a onclick="insertTags('ί','','');return false" href="#">ί</a>
<a onclick="insertTags('κ','','');return false" href="#">κ</a>
<a onclick="insertTags('λ','','');return false" href="#">λ</a>
<a onclick="insertTags('μ','','');return false" href="#">μ</a>
<a onclick="insertTags('ν','','');return false" href="#">ν</a>
<a onclick="insertTags('ξ','','');return false" href="#">ξ</a>
<a onclick="insertTags('ο','','');return false" href="#">ο</a>
<a onclick="insertTags('ό','','');return false" href="#">ό</a>
<a onclick="insertTags('π','','');return false" href="#">π</a>
<a onclick="insertTags('ρ','','');return false" href="#">ρ</a>
<a onclick="insertTags('σ','','');return false" href="#">σ</a>
<a onclick="insertTags('ς','','');return false" href="#">ς</a>
<a onclick="insertTags('τ','','');return false" href="#">τ</a>
<a onclick="insertTags('υ','','');return false" href="#">υ</a>
<a onclick="insertTags('ύ','','');return false" href="#">ύ</a>
<a onclick="insertTags('φ','','');return false" href="#">φ</a>
<a onclick="insertTags('χ','','');return false" href="#">χ</a>
<a onclick="insertTags('ψ','','');return false" href="#">ψ</a>
<a onclick="insertTags('ω','','');return false" href="#">ω</a>
<a onclick="insertTags('ώ','','');return false" href="#">ώ</a><br/>
</p>
<p class="speciallang" style="display:none">
Hawaiianisch: 
<font face="Arial Unicode MS,Lucida Sans Unicode,MS Mincho,Arial,sans-serif" style="text-decoration:none;"><a onclick="insertTags('Ā','','');return false" href="#">Ā</a>
<a onclick="insertTags('ā','','');return false" href="#">ā</a>
<a onclick="insertTags('Ē','','');return false" href="#">Ē</a>
<a onclick="insertTags('ē','','');return false" href="#">ē</a>
<a onclick="insertTags('Ī','','');return false" href="#">Ī</a>
<a onclick="insertTags('ī','','');return false" href="#">ī</a>
<a onclick="insertTags('Ō','','');return false" href="#">Ō</a>
<a onclick="insertTags('ō','','');return false" href="#">ō</a>
<a onclick="insertTags('Ū','','');return false" href="#">Ū</a>
<a onclick="insertTags('ū','','');return false" href="#">ū</a>
<a onclick="insertTags('ʻ','','');return false" href="#">ʻ</a></font>
</p>
<p class="speciallang" style="display:none">
Isländisch: 
<a onclick="insertTags('Á','','');return false" href="#">Á</a>
<a onclick="insertTags('á','','');return false" href="#">á</a>
<a onclick="insertTags('Ð','','');return false" href="#">Ð</a>
<a onclick="insertTags('ð','','');return false" href="#">ð</a>
<a onclick="insertTags('É','','');return false" href="#">É</a>
<a onclick="insertTags('é','','');return false" href="#">é</a>
<a onclick="insertTags('Í','','');return false" href="#">Í</a>
<a onclick="insertTags('í','','');return false" href="#">í</a>
<a onclick="insertTags('Ó','','');return false" href="#">Ó</a>
<a onclick="insertTags('ó','','');return false" href="#">ó</a>
<a onclick="insertTags('Ú','','');return false" href="#">Ú</a>
<a onclick="insertTags('ú','','');return false" href="#">ú</a>
<a onclick="insertTags('Ý','','');return false" href="#">Ý</a>
<a onclick="insertTags('ý','','');return false" href="#">ý</a>
<a onclick="insertTags('Þ','','');return false" href="#">Þ</a>
<a onclick="insertTags('þ','','');return false" href="#">þ</a>
<a onclick="insertTags('Æ','','');return false" href="#">Æ</a>
<a onclick="insertTags('æ','','');return false" href="#">æ</a>
<a onclick="insertTags('Ö','','');return false" href="#">Ö</a>
<a onclick="insertTags('ö','','');return false" href="#">ö</a>
</p>
<p class="speciallang" style="display:none">
Italienisch: 
<a onclick="insertTags('Á','','');return false" href="#">Á</a>
<a onclick="insertTags('á','','');return false" href="#">á</a>
<a onclick="insertTags('À','','');return false" href="#">À</a>
<a onclick="insertTags('à','','');return false" href="#">à</a>
<a onclick="insertTags('É','','');return false" href="#">É</a>
<a onclick="insertTags('é','','');return false" href="#">é</a>
<a onclick="insertTags('È','','');return false" href="#">È</a>
<a onclick="insertTags('è','','');return false" href="#">è</a>
<a onclick="insertTags('Í','','');return false" href="#">Í</a>
<a onclick="insertTags('í','','');return false" href="#">í</a>
<a onclick="insertTags('Ì','','');return false" href="#">Ì</a>
<a onclick="insertTags('ì','','');return false" href="#">ì</a>
<a onclick="insertTags('Ó','','');return false" href="#">Ó</a>
<a onclick="insertTags('ó','','');return false" href="#">ó</a>
<a onclick="insertTags('Ò','','');return false" href="#">Ò</a>
<a onclick="insertTags('ò','','');return false" href="#">ò</a>
<a onclick="insertTags('Ú','','');return false" href="#">Ú</a>
<a onclick="insertTags('ú','','');return false" href="#">ú</a>
<a onclick="insertTags('Ù','','');return false" href="#">Ù</a>
<a onclick="insertTags('ù','','');return false" href="#">ù</a>
</p>
<p class="speciallang" style="display:none">
Jiddisch: 
<a onclick="insertTags('א','','');return false" href="#">א</a>
<a onclick="insertTags('אַ','','');return false" href="#">אַ</a>
<a onclick="insertTags('אָ','','');return false" href="#">אָ</a>
<a onclick="insertTags('ב','','');return false" href="#">ב</a>
<a onclick="insertTags('בֿ','','');return false" href="#">בֿ</a>
<a onclick="insertTags('ג','','');return false" href="#">ג</a>
<a onclick="insertTags('ד','','');return false" href="#">ד</a>
<a onclick="insertTags('ה','','');return false" href="#">ה</a>
<a onclick="insertTags('ו','','');return false" href="#">ו</a>
<a onclick="insertTags('וּ','','');return false" href="#">וּ</a>
<a onclick="insertTags('װ','','');return false" href="#">װ</a>
<a onclick="insertTags('ױ','','');return false" href="#">ױ</a>
<a onclick="insertTags('ז','','');return false" href="#">ז</a>
<a onclick="insertTags('זש','','');return false" href="#">זש</a>
<a onclick="insertTags('ח','','');return false" href="#">ח</a>
<a onclick="insertTags('ט','','');return false" href="#">ט</a>
<a onclick="insertTags('י','','');return false" href="#">י</a>
<a onclick="insertTags('יִ','','');return false" href="#">יִ</a>
<a onclick="insertTags('ײ','','');return false" href="#">ײ</a>
<a onclick="insertTags('ײַ','','');return false" href="#">ײַ</a>
<a onclick="insertTags('כ','','');return false" href="#">כ</a>
<a onclick="insertTags('ך','','');return false" href="#">ך</a>
<a onclick="insertTags('כּ','','');return false" href="#">כּ</a>
<a onclick="insertTags('ל','','');return false" href="#">ל</a>
<a onclick="insertTags('ל','','');return false" href="#">ל</a>
<a onclick="insertTags('מ','','');return false" href="#">מ</a>
<a onclick="insertTags('ם','','');return false" href="#">ם</a>
<a onclick="insertTags('נ','','');return false" href="#">נ</a>
<a onclick="insertTags('ן','','');return false" href="#">ן</a>
<a onclick="insertTags('ס','','');return false" href="#">ס</a>
<a onclick="insertTags('ע','','');return false" href="#">ע</a>
<a onclick="insertTags('ע','','');return false" href="#">ע</a>
<a onclick="insertTags('פ','','');return false" href="#">פ</a>
<a onclick="insertTags('פּ','','');return false" href="#">פּ</a>
<a onclick="insertTags('פֿ','','');return false" href="#">פֿ</a>
<a onclick="insertTags('ף','','');return false" href="#">ף</a>
<a onclick="insertTags('צ','','');return false" href="#">צ</a>
<a onclick="insertTags('ץ','','');return false" href="#">ץ</a>
<a onclick="insertTags('ק','','');return false" href="#">ק</a>
<a onclick="insertTags('ר','','');return false" href="#">ר</a>
<a onclick="insertTags('ש','','');return false" href="#">ש</a>
<a onclick="insertTags('שׂ','','');return false" href="#">שׂ</a>
<a onclick="insertTags('תּ','','');return false" href="#">תּ</a>
<a onclick="insertTags('ת','','');return false" href="#">ת</a>
<a onclick="insertTags('׳','','');return false" href="#">׳</a>
<a onclick="insertTags('״','','');return false" href="#">״</a>
<a onclick="insertTags('־','','');return false" href="#">־</a>
</p>
<p class="speciallang" style="display:none">
Katalanisch: 
<a onclick="insertTags('Á','','');return false" href="#">Á</a>
<a onclick="insertTags('á','','');return false" href="#">á</a>
<a onclick="insertTags('À','','');return false" href="#">À</a>
<a onclick="insertTags('à','','');return false" href="#">à</a>
<a onclick="insertTags('Ç','','');return false" href="#">Ç</a>
<a onclick="insertTags('ç','','');return false" href="#">ç</a>
<a onclick="insertTags('É','','');return false" href="#">É</a>
<a onclick="insertTags('é','','');return false" href="#">é</a>
<a onclick="insertTags('È','','');return false" href="#">È</a>
<a onclick="insertTags('è','','');return false" href="#">è</a>
<a onclick="insertTags('Ë','','');return false" href="#">Ë</a>
<a onclick="insertTags('ë','','');return false" href="#">ë</a>
<a onclick="insertTags('Í','','');return false" href="#">Í</a>
<a onclick="insertTags('í','','');return false" href="#">í</a>
<a onclick="insertTags('Ï','','');return false" href="#">Ï</a>
<a onclick="insertTags('ï','','');return false" href="#">ï</a>
<a onclick="insertTags('Ó','','');return false" href="#">Ó</a>
<a onclick="insertTags('ó','','');return false" href="#">ó</a>
<a onclick="insertTags('Ò','','');return false" href="#">Ò</a>
<a onclick="insertTags('ò','','');return false" href="#">ò</a>
<a onclick="insertTags('Ö','','');return false" href="#">Ö</a>
<a onclick="insertTags('ö','','');return false" href="#">ö</a>
<a onclick="insertTags('Ú','','');return false" href="#">Ú</a>
<a onclick="insertTags('ú','','');return false" href="#">ú</a>
<a onclick="insertTags('Ù','','');return false" href="#">Ù</a>
<a onclick="insertTags('ù','','');return false" href="#">ù</a>
</p>
<p class="speciallang" style="display:none">
Kroatisch/Serbisch/Bosnisch: 
<a onclick="insertTags('Č','','');return false" href="#">Č</a>
<a onclick="insertTags('č','','');return false" href="#">č</a>
<a onclick="insertTags('Ć','','');return false" href="#">Ć</a>
<a onclick="insertTags('ć','','');return false" href="#">ć</a>
<a onclick="insertTags('Dž','','');return false" href="#">Dž</a>
<a onclick="insertTags('dž','','');return false" href="#">dž</a>
<a onclick="insertTags('Đ','','');return false" href="#">Đ</a>
<a onclick="insertTags('đ','','');return false" href="#">đ</a>
<a onclick="insertTags('Š','','');return false" href="#">Š</a>
<a onclick="insertTags('š','','');return false" href="#">š</a>
<a onclick="insertTags('Ž','','');return false" href="#">Ž</a>
<a onclick="insertTags('ž','','');return false" href="#">ž</a>
</p>
<p class="specialbasic" style="display:none">
Kyrillisch: 
<a onclick="insertTags('А','','');return false" href="#">А</a>
<a onclick="insertTags('Ә','','');return false" href="#">Ә</a>
<a onclick="insertTags('Б','','');return false" href="#">Б</a>
<a onclick="insertTags('В','','');return false" href="#">В</a>
<a onclick="insertTags('Г','','');return false" href="#">Г</a>
<a onclick="insertTags('Ґ','','');return false" href="#">Ґ</a>
<a onclick="insertTags('Ѓ','','');return false" href="#">Ѓ</a>
<a onclick="insertTags('Ғ','','');return false" href="#">Ғ</a>
<a onclick="insertTags('Д','','');return false" href="#">Д</a>
<a onclick="insertTags('Ђ','','');return false" href="#">Ђ</a>
<a onclick="insertTags('Е','','');return false" href="#">Е</a>
<a onclick="insertTags('Є','','');return false" href="#">Є</a>
<a onclick="insertTags('Ё','','');return false" href="#">Ё</a>
<a onclick="insertTags('Ж','','');return false" href="#">Ж</a>
<a onclick="insertTags('З','','');return false" href="#">З</a>
<a onclick="insertTags('Ѕ','','');return false" href="#">Ѕ</a>
<a onclick="insertTags('И','','');return false" href="#">И</a>
<a onclick="insertTags('І','','');return false" href="#">І</a>
<a onclick="insertTags('Ї','','');return false" href="#">Ї</a>
<a onclick="insertTags('İ','','');return false" href="#">İ</a>
<a onclick="insertTags('Й','','');return false" href="#">Й</a>
<a onclick="insertTags('Ӣ','','');return false" href="#">Ӣ</a>
<a onclick="insertTags('Ј','','');return false" href="#">Ј</a>
<a onclick="insertTags('К','','');return false" href="#">К</a>
<a onclick="insertTags('Ќ','','');return false" href="#">Ќ</a>
<a onclick="insertTags('Қ','','');return false" href="#">Қ</a>
<a onclick="insertTags('Л','','');return false" href="#">Л</a>
<a onclick="insertTags('Љ','','');return false" href="#">Љ</a>
<a onclick="insertTags('М','','');return false" href="#">М</a>
<a onclick="insertTags('Н','','');return false" href="#">Н</a>
<a onclick="insertTags('Њ','','');return false" href="#">Њ</a>
<a onclick="insertTags('Ң','','');return false" href="#">Ң</a>
<a onclick="insertTags('О','','');return false" href="#">О</a>
<a onclick="insertTags('Ө','','');return false" href="#">Ө</a>
<a onclick="insertTags('П','','');return false" href="#">П</a>
<a onclick="insertTags('Р','','');return false" href="#">Р</a>
<a onclick="insertTags('С','','');return false" href="#">С</a>
<a onclick="insertTags('Т','','');return false" href="#">Т</a>
<a onclick="insertTags('Ћ','','');return false" href="#">Ћ</a>
<a onclick="insertTags('У','','');return false" href="#">У</a>
<a onclick="insertTags('Ў','','');return false" href="#">Ў</a>
<a onclick="insertTags('Ӯ','','');return false" href="#">Ӯ</a>
<a onclick="insertTags('Ұ','','');return false" href="#">Ұ</a>
<a onclick="insertTags('Ү','','');return false" href="#">Ү</a>
<a onclick="insertTags('Ф','','');return false" href="#">Ф</a>
<a onclick="insertTags('Х','','');return false" href="#">Х</a>
<a onclick="insertTags('Ҳ','','');return false" href="#">Ҳ</a>
<a onclick="insertTags('Һ','','');return false" href="#">Һ</a>
<a onclick="insertTags('Ц','','');return false" href="#">Ц</a>
<a onclick="insertTags('Ч','','');return false" href="#">Ч</a>
<a onclick="insertTags('Ҷ','','');return false" href="#">Ҷ</a>
<a onclick="insertTags('Џ','','');return false" href="#">Џ</a>
<a onclick="insertTags('Ш','','');return false" href="#">Ш</a>
<a onclick="insertTags('Щ','','');return false" href="#">Щ</a>
<a onclick="insertTags('Ъ','','');return false" href="#">Ъ</a>
<a onclick="insertTags('Ы','','');return false" href="#">Ы</a>
<a onclick="insertTags('Ь','','');return false" href="#">Ь</a>
<a onclick="insertTags('Э','','');return false" href="#">Э</a>
<a onclick="insertTags('Ю','','');return false" href="#">Ю</a>
<a onclick="insertTags('Я','','');return false" href="#">Я</a> ··· 
<a onclick="insertTags('а','','');return false" href="#">а</a>
<a onclick="insertTags('ә','','');return false" href="#">ә</a>
<a onclick="insertTags('б','','');return false" href="#">б</a>
<a onclick="insertTags('в','','');return false" href="#">в</a>
<a onclick="insertTags('г','','');return false" href="#">г</a>
<a onclick="insertTags('ґ','','');return false" href="#">ґ</a>
<a onclick="insertTags('ѓ','','');return false" href="#">ѓ</a>
<a onclick="insertTags('ғ','','');return false" href="#">ғ</a>
<a onclick="insertTags('д','','');return false" href="#">д</a>
<a onclick="insertTags('ђ','','');return false" href="#">ђ</a>
<a onclick="insertTags('е','','');return false" href="#">е</a>
<a onclick="insertTags('є','','');return false" href="#">є</a>
<a onclick="insertTags('ё','','');return false" href="#">ё</a>
<a onclick="insertTags('ж','','');return false" href="#">ж</a>
<a onclick="insertTags('з','','');return false" href="#">з</a>
<a onclick="insertTags('ѕ','','');return false" href="#">ѕ</a>
<a onclick="insertTags('и','','');return false" href="#">и</a>
<a onclick="insertTags('і','','');return false" href="#">і</a>
<a onclick="insertTags('ї','','');return false" href="#">ї</a>
<a onclick="insertTags('й','','');return false" href="#">й</a>
<a onclick="insertTags('ӣ','','');return false" href="#">ӣ</a>
<a onclick="insertTags('ј','','');return false" href="#">ј</a>
<a onclick="insertTags('к','','');return false" href="#">к</a>
<a onclick="insertTags('ќ','','');return false" href="#">ќ</a>
<a onclick="insertTags('қ','','');return false" href="#">қ</a>
<a onclick="insertTags('л','','');return false" href="#">л</a>
<a onclick="insertTags('љ','','');return false" href="#">љ</a>
<a onclick="insertTags('м','','');return false" href="#">м</a>
<a onclick="insertTags('н','','');return false" href="#">н</a>
<a onclick="insertTags('њ','','');return false" href="#">њ</a>
<a onclick="insertTags('ң','','');return false" href="#">ң</a>
<a onclick="insertTags('о','','');return false" href="#">о</a>
<a onclick="insertTags('ө','','');return false" href="#">ө</a>
<a onclick="insertTags('п','','');return false" href="#">п</a>
<a onclick="insertTags('р','','');return false" href="#">р</a>
<a onclick="insertTags('с','','');return false" href="#">с</a>
<a onclick="insertTags('т','','');return false" href="#">т</a>
<a onclick="insertTags('ћ','','');return false" href="#">ћ</a>
<a onclick="insertTags('у','','');return false" href="#">у</a>
<a onclick="insertTags('ў','','');return false" href="#">ў</a>
<a onclick="insertTags('ӯ','','');return false" href="#">ӯ</a>
<a onclick="insertTags('ұ','','');return false" href="#">ұ</a>
<a onclick="insertTags('ү','','');return false" href="#">ү</a>
<a onclick="insertTags('ф','','');return false" href="#">ф</a>
<a onclick="insertTags('х','','');return false" href="#">х</a>
<a onclick="insertTags('ҳ','','');return false" href="#">ҳ</a>
<a onclick="insertTags('һ','','');return false" href="#">һ</a>
<a onclick="insertTags('ц','','');return false" href="#">ц</a>
<a onclick="insertTags('ч','','');return false" href="#">ч</a>
<a onclick="insertTags('ҷ','','');return false" href="#">ҷ</a>
<a onclick="insertTags('џ','','');return false" href="#">џ</a>
<a onclick="insertTags('ш','','');return false" href="#">ш</a>
<a onclick="insertTags('щ','','');return false" href="#">щ</a>
<a onclick="insertTags('ъ','','');return false" href="#">ъ</a>
<a onclick="insertTags('ы','','');return false" href="#">ы</a>
<a onclick="insertTags('ь','','');return false" href="#">ь</a>
<a onclick="insertTags('э','','');return false" href="#">э</a>
<a onclick="insertTags('ю','','');return false" href="#">ю</a>
<a onclick="insertTags('я','','');return false" href="#">я</a><br/>
</p>
<p class="specialbasic" style="display:none">
Lettisch: 
<a onclick="insertTags('Ā','','');return false" href="#">Ā</a>
<a onclick="insertTags('Č','','');return false" href="#">Č</a>
<a onclick="insertTags('Ē','','');return false" href="#">Ē</a>
<a onclick="insertTags('Ģ','','');return false" href="#">Ģ</a>
<a onclick="insertTags('Ī','','');return false" href="#">Ī</a>
<a onclick="insertTags('Ķ','','');return false" href="#">Ķ</a>
<a onclick="insertTags('Ļ','','');return false" href="#">Ļ</a>
<a onclick="insertTags('Ņ','','');return false" href="#">Ņ</a>
<a onclick="insertTags('Š','','');return false" href="#">Š</a>
<a onclick="insertTags('Ū','','');return false" href="#">Ū</a>
<a onclick="insertTags('Ž','','');return false" href="#">Ž</a> ··· 
<a onclick="insertTags('ā','','');return false" href="#">ā</a>
<a onclick="insertTags('č','','');return false" href="#">č</a>
<a onclick="insertTags('ē','','');return false" href="#">ē</a>
<a onclick="insertTags('ģ','','');return false" href="#">ģ</a>
<a onclick="insertTags('ī','','');return false" href="#">ī</a>
<a onclick="insertTags('ķ','','');return false" href="#">ķ</a>
<a onclick="insertTags('ļ','','');return false" href="#">ļ</a>
<a onclick="insertTags('ņ','','');return false" href="#">ņ</a>
<a onclick="insertTags('š','','');return false" href="#">š</a>
<a onclick="insertTags('ū','','');return false" href="#">ū</a>
<a onclick="insertTags('ž','','');return false" href="#">ž</a><br/>
</p>
<p class="specialbasic" style="display:none">
Litauisch: 
<a onclick="insertTags('Ą','','');return false" href="#">Ą</a>
<a onclick="insertTags('Č','','');return false" href="#">Č</a>
<a onclick="insertTags('Ę','','');return false" href="#">Ę</a>
<a onclick="insertTags('Ė','','');return false" href="#">Ė</a>
<a onclick="insertTags('Į','','');return false" href="#">Į</a>
<a onclick="insertTags('Š','','');return false" href="#">Š</a>
<a onclick="insertTags('Ų','','');return false" href="#">Ų</a>
<a onclick="insertTags('Ū','','');return false" href="#">Ū</a>
<a onclick="insertTags('Ž','','');return false" href="#">Ž</a> ··· 
<a onclick="insertTags('ą','','');return false" href="#">ą</a>
<a onclick="insertTags('č','','');return false" href="#">č</a>
<a onclick="insertTags('ę','','');return false" href="#">ę</a>
<a onclick="insertTags('ė','','');return false" href="#">ė</a>
<a onclick="insertTags('į','','');return false" href="#">į</a>
<a onclick="insertTags('š','','');return false" href="#">š</a>
<a onclick="insertTags('ų','','');return false" href="#">ų</a>
<a onclick="insertTags('ū','','');return false" href="#">ū</a>
<a onclick="insertTags('ž','','');return false" href="#">ž</a><br/>
</p>
<p class="speciallang" style="display:none">
Maltesisch: 
<a onclick="insertTags('Ċ','','');return false" href="#">Ċ</a>
<a onclick="insertTags('ċ','','');return false" href="#">ċ</a>
<a onclick="insertTags('Ġ','','');return false" href="#">Ġ</a>
<a onclick="insertTags('ġ','','');return false" href="#">ġ</a>
<a onclick="insertTags('Ħ','','');return false" href="#">Ħ</a>
<a onclick="insertTags('ħ','','');return false" href="#">ħ</a>
<a onclick="insertTags('Ż','','');return false" href="#">Ż</a>
<a onclick="insertTags('ż','','');return false" href="#">ż</a>
</p>
<p class="speciallang" style="display:none">
Pinyin: 
<a onclick="insertTags('Á','','');return false" href="#">Á</a>
<a onclick="insertTags('á','','');return false" href="#">á</a>
<a onclick="insertTags('À','','');return false" href="#">À</a>
<a onclick="insertTags('à','','');return false" href="#">à</a>
<a onclick="insertTags('Ǎ','','');return false" href="#">Ǎ</a>
<a onclick="insertTags('ǎ','','');return false" href="#">ǎ</a>
<a onclick="insertTags('Ā','','');return false" href="#">Ā</a>
<a onclick="insertTags('ā','','');return false" href="#">ā</a>
<a onclick="insertTags('É','','');return false" href="#">É</a>
<a onclick="insertTags('é','','');return false" href="#">é</a>
<a onclick="insertTags('È','','');return false" href="#">È</a>
<a onclick="insertTags('è','','');return false" href="#">è</a>
<a onclick="insertTags('Ě','','');return false" href="#">Ě</a>
<a onclick="insertTags('ě','','');return false" href="#">ě</a>
<a onclick="insertTags('Ē','','');return false" href="#">Ē</a>
<a onclick="insertTags('ē','','');return false" href="#">ē</a>
<a onclick="insertTags('Í','','');return false" href="#">Í</a>
<a onclick="insertTags('í','','');return false" href="#">í</a>
<a onclick="insertTags('Ì','','');return false" href="#">Ì</a>
<a onclick="insertTags('ì','','');return false" href="#">ì</a>
<a onclick="insertTags('Ǐ','','');return false" href="#">Ǐ</a>
<a onclick="insertTags('ǐ','','');return false" href="#">ǐ</a>
<a onclick="insertTags('Ī','','');return false" href="#">Ī</a>
<a onclick="insertTags('ī','','');return false" href="#">ī</a>
<a onclick="insertTags('Ó','','');return false" href="#">Ó</a>
<a onclick="insertTags('ó','','');return false" href="#">ó</a>
<a onclick="insertTags('Ò','','');return false" href="#">Ò</a>
<a onclick="insertTags('ò','','');return false" href="#">ò</a>
<a onclick="insertTags('Ǒ','','');return false" href="#">Ǒ</a>
<a onclick="insertTags('ǒ','','');return false" href="#">ǒ</a>
<a onclick="insertTags('Ō','','');return false" href="#">Ō</a>
<a onclick="insertTags('ō','','');return false" href="#">ō</a>
<a onclick="insertTags('Ú','','');return false" href="#">Ú</a>
<a onclick="insertTags('ú','','');return false" href="#">ú</a>
<a onclick="insertTags('Ù','','');return false" href="#">Ù</a>
<a onclick="insertTags('ù','','');return false" href="#">ù</a>
<a onclick="insertTags('Ü','','');return false" href="#">Ü</a>
<a onclick="insertTags('ü','','');return false" href="#">ü</a>
<a onclick="insertTags('Ǔ','','');return false" href="#">Ǔ</a>
<a onclick="insertTags('ǔ','','');return false" href="#">ǔ</a>
<a onclick="insertTags('Ū','','');return false" href="#">Ū</a>
<a onclick="insertTags('ū','','');return false" href="#">ū</a>
<a onclick="insertTags('Ǘ','','');return false" href="#">Ǘ</a>
<a onclick="insertTags('ǘ','','');return false" href="#">ǘ</a>
<a onclick="insertTags('Ǜ','','');return false" href="#">Ǜ</a>
<a onclick="insertTags('ǜ','','');return false" href="#">ǜ</a>
<a onclick="insertTags('Ǚ','','');return false" href="#">Ǚ</a>
<a onclick="insertTags('ǚ','','');return false" href="#">ǚ</a>
<a onclick="insertTags('Ǖ','','');return false" href="#">Ǖ</a>
<a onclick="insertTags('ǖ','','');return false" href="#">ǖ</a>
</p>
<p class="speciallang" style="display:none">
Polnisch: 
<a onclick="insertTags('ą','','');return false" href="#">ą</a>
<a onclick="insertTags('Ą','','');return false" href="#">Ą</a>
<a onclick="insertTags('ć','','');return false" href="#">ć</a>
<a onclick="insertTags('Ć','','');return false" href="#">Ć</a>
<a onclick="insertTags('ę','','');return false" href="#">ę</a>
<a onclick="insertTags('Ę','','');return false" href="#">Ę</a>
<a onclick="insertTags('ł','','');return false" href="#">ł</a>
<a onclick="insertTags('Ł','','');return false" href="#">Ł</a>
<a onclick="insertTags('ń','','');return false" href="#">ń</a>
<a onclick="insertTags('Ń','','');return false" href="#">Ń</a>
<a onclick="insertTags('ó','','');return false" href="#">ó</a>
<a onclick="insertTags('Ó','','');return false" href="#">Ó</a>
<a onclick="insertTags('ś','','');return false" href="#">ś</a>
<a onclick="insertTags('Ś','','');return false" href="#">Ś</a>
<a onclick="insertTags('ź','','');return false" href="#">ź</a>
<a onclick="insertTags('Ź','','');return false" href="#">Ź</a>
<a onclick="insertTags('ż','','');return false" href="#">ż</a>
<a onclick="insertTags('Ż','','');return false" href="#">Ż</a>
</p>
<p class="speciallang" style="display:none">
Portugiesisch: 
<a onclick="insertTags('Á','','');return false" href="#">Á</a>
<a onclick="insertTags('á','','');return false" href="#">á</a>
<a onclick="insertTags('À','','');return false" href="#">À</a>
<a onclick="insertTags('à','','');return false" href="#">à</a>
<a onclick="insertTags('Â','','');return false" href="#">Â</a>
<a onclick="insertTags('â','','');return false" href="#">â</a>
<a onclick="insertTags('Ã','','');return false" href="#">Ã</a>
<a onclick="insertTags('ã','','');return false" href="#">ã</a>
<a onclick="insertTags('Ç','','');return false" href="#">Ç</a>
<a onclick="insertTags('ç','','');return false" href="#">ç</a>
<a onclick="insertTags('É','','');return false" href="#">É</a>
<a onclick="insertTags('é','','');return false" href="#">é</a>
<a onclick="insertTags('Ê','','');return false" href="#">Ê</a>
<a onclick="insertTags('ê','','');return false" href="#">ê</a>
<a onclick="insertTags('Í','','');return false" href="#">Í</a>
<a onclick="insertTags('í','','');return false" href="#">í</a>
<a onclick="insertTags('Ó','','');return false" href="#">Ó</a>
<a onclick="insertTags('ó','','');return false" href="#">ó</a>
<a onclick="insertTags('Ô','','');return false" href="#">Ô</a>
<a onclick="insertTags('ô','','');return false" href="#">ô</a>
<a onclick="insertTags('Õ','','');return false" href="#">Õ</a>
<a onclick="insertTags('õ','','');return false" href="#">õ</a>
<a onclick="insertTags('Ú','','');return false" href="#">Ú</a>
<a onclick="insertTags('ú','','');return false" href="#">ú</a>
<a onclick="insertTags('Ü','','');return false" href="#">Ü</a>
<a onclick="insertTags('ü','','');return false" href="#">ü</a>
</p>
<p class="speciallang" style="display:none">
Romanisch: 
<a onclick="insertTags('Ā','','');return false" href="#">Ā</a>
<a onclick="insertTags('ā','','');return false" href="#">ā</a>
<a onclick="insertTags('Ē','','');return false" href="#">Ē</a>
<a onclick="insertTags('ē','','');return false" href="#">ē</a>
<a onclick="insertTags('Ī','','');return false" href="#">Ī</a>
<a onclick="insertTags('ī','','');return false" href="#">ī</a>
<a onclick="insertTags('Ō','','');return false" href="#">Ō</a>
<a onclick="insertTags('ō','','');return false" href="#">ō</a>
<a onclick="insertTags('Ū','','');return false" href="#">Ū</a>
<a onclick="insertTags('ū','','');return false" href="#">ū</a>
</p>
<p class="speciallang" style="display:none">
Rumänisch: 
<a onclick="insertTags('Ă','','');return false" href="#">Ă</a>
<a onclick="insertTags('ă','','');return false" href="#">ă</a>
<a onclick="insertTags('Â','','');return false" href="#">Â</a>
<a onclick="insertTags('â','','');return false" href="#">â</a>
<a onclick="insertTags('Î','','');return false" href="#">Î</a>
<a onclick="insertTags('î','','');return false" href="#">î</a>
<a onclick="insertTags('Ş','','');return false" href="#">Ş</a>
<a onclick="insertTags('ş','','');return false" href="#">ş</a>
<a onclick="insertTags('Ţ','','');return false" href="#">Ţ</a>
<a onclick="insertTags('ţ','','');return false" href="#">ţ</a>
</p>
<p class="speciallang" style="display:none">
Serbisch: 
<a onclick="insertTags('А','','');return false" href="#">А</a>
<a onclick="insertTags('а','','');return false" href="#">а</a>
<a onclick="insertTags('Б','','');return false" href="#">Б</a>
<a onclick="insertTags('б','','');return false" href="#">б</a>
<a onclick="insertTags('В','','');return false" href="#">В</a>
<a onclick="insertTags('в','','');return false" href="#">в</a>
<a onclick="insertTags('Г','','');return false" href="#">Г</a>
<a onclick="insertTags('г','','');return false" href="#">г</a>
<a onclick="insertTags('Д','','');return false" href="#">Д</a>
<a onclick="insertTags('д','','');return false" href="#">д</a>
<a onclick="insertTags('Ђ','','');return false" href="#">Ђ</a>
<a onclick="insertTags('ђ','','');return false" href="#">ђ</a>
<a onclick="insertTags('Е','','');return false" href="#">Е</a>
<a onclick="insertTags('е','','');return false" href="#">е</a>
<a onclick="insertTags('Ж','','');return false" href="#">Ж</a>
<a onclick="insertTags('ж','','');return false" href="#">ж</a>
<a onclick="insertTags('З','','');return false" href="#">З</a>
<a onclick="insertTags('з','','');return false" href="#">з</a>
<a onclick="insertTags('И','','');return false" href="#">И</a>
<a onclick="insertTags('и','','');return false" href="#">и</a>
<a onclick="insertTags('Ј','','');return false" href="#">Ј</a>
<a onclick="insertTags('ј','','');return false" href="#">ј</a>
<a onclick="insertTags('К','','');return false" href="#">К</a>
<a onclick="insertTags('к','','');return false" href="#">к</a>
<a onclick="insertTags('Л','','');return false" href="#">Л</a>
<a onclick="insertTags('л','','');return false" href="#">л</a>
<a onclick="insertTags('Љ','','');return false" href="#">Љ</a>
<a onclick="insertTags('љ','','');return false" href="#">љ</a>
<a onclick="insertTags('М','','');return false" href="#">М</a>
<a onclick="insertTags('м','','');return false" href="#">м</a>
<a onclick="insertTags('Н','','');return false" href="#">Н</a>
<a onclick="insertTags('н','','');return false" href="#">н</a>
<a onclick="insertTags('Њ','','');return false" href="#">Њ</a>
<a onclick="insertTags('њ','','');return false" href="#">њ</a>
<a onclick="insertTags('О','','');return false" href="#">О</a>
<a onclick="insertTags('о','','');return false" href="#">о</a>
<a onclick="insertTags('П','','');return false" href="#">П</a>
<a onclick="insertTags('п','','');return false" href="#">п</a>
<a onclick="insertTags('Р','','');return false" href="#">Р</a>
<a onclick="insertTags('р','','');return false" href="#">р</a>
<a onclick="insertTags('С','','');return false" href="#">С</a>
<a onclick="insertTags('с','','');return false" href="#">с</a>
<a onclick="insertTags('Т','','');return false" href="#">Т</a>
<a onclick="insertTags('т','','');return false" href="#">т</a>
<a onclick="insertTags('Ћ','','');return false" href="#">Ћ</a>
<a onclick="insertTags('ћ','','');return false" href="#">ћ</a>
<a onclick="insertTags('У','','');return false" href="#">У</a>
<a onclick="insertTags('у','','');return false" href="#">у</a>
<a onclick="insertTags('Ф','','');return false" href="#">Ф</a>
<a onclick="insertTags('ф','','');return false" href="#">ф</a>
<a onclick="insertTags('Х','','');return false" href="#">Х</a>
<a onclick="insertTags('х','','');return false" href="#">х</a>
<a onclick="insertTags('Ц','','');return false" href="#">Ц</a>
<a onclick="insertTags('ц','','');return false" href="#">ц</a>
<a onclick="insertTags('Ч','','');return false" href="#">Ч</a>
<a onclick="insertTags('ч','','');return false" href="#">ч</a>
<a onclick="insertTags('Џ','','');return false" href="#">Џ</a>
<a onclick="insertTags('џ','','');return false" href="#">џ</a>
<a onclick="insertTags('Ш','','');return false" href="#">Ш</a>
<a onclick="insertTags('ш','','');return false" href="#">ш</a>
</p>
<p class="speciallang" style="display:none">
Skandinavisch: 
<a onclick="insertTags('À','','');return false" href="#">À</a>
<a onclick="insertTags('à','','');return false" href="#">à</a>
<a onclick="insertTags('É','','');return false" href="#">É</a>
<a onclick="insertTags('é','','');return false" href="#">é</a>
<a onclick="insertTags('Å','','');return false" href="#">Å</a>
<a onclick="insertTags('å','','');return false" href="#">å</a>
<a onclick="insertTags('Æ','','');return false" href="#">Æ</a>
<a onclick="insertTags('æ','','');return false" href="#">æ</a>
<a onclick="insertTags('Ä','','');return false" href="#">Ä</a>
<a onclick="insertTags('ä','','');return false" href="#">ä</a>
<a onclick="insertTags('Ø','','');return false" href="#">Ø</a>
<a onclick="insertTags('ø','','');return false" href="#">ø</a>
<a onclick="insertTags('Ö','','');return false" href="#">Ö</a>
<a onclick="insertTags('ö','','');return false" href="#">ö</a>
</p>
<p class="speciallang" style="display:none">
Slowakisch: 
<a onclick="insertTags('Á','','');return false" href="#">Á</a>
<a onclick="insertTags('á','','');return false" href="#">á</a>
<a onclick="insertTags('Č','','');return false" href="#">Č</a>
<a onclick="insertTags('č','','');return false" href="#">č</a>
<a onclick="insertTags('Ď','','');return false" href="#">Ď</a>
<a onclick="insertTags('ď','','');return false" href="#">ď</a>
<a onclick="insertTags('É','','');return false" href="#">É</a>
<a onclick="insertTags('é','','');return false" href="#">é</a>
<a onclick="insertTags('Í','','');return false" href="#">Í</a>
<a onclick="insertTags('í','','');return false" href="#">í</a>
<a onclick="insertTags('Ľ','','');return false" href="#">Ľ</a>
<a onclick="insertTags('ľ','','');return false" href="#">ľ</a>
<a onclick="insertTags('Ň','','');return false" href="#">Ň</a>
<a onclick="insertTags('ň','','');return false" href="#">ň</a>
<a onclick="insertTags('Ó','','');return false" href="#">Ó</a>
<a onclick="insertTags('ó','','');return false" href="#">ó</a>
<a onclick="insertTags('Ô','','');return false" href="#">Ô</a>
<a onclick="insertTags('ô','','');return false" href="#">ô</a>
<a onclick="insertTags('Ŕ','','');return false" href="#">Ŕ</a>
<a onclick="insertTags('ŕ','','');return false" href="#">ŕ</a>
<a onclick="insertTags('Š','','');return false" href="#">Š</a>
<a onclick="insertTags('š','','');return false" href="#">š</a>
<a onclick="insertTags('Ť','','');return false" href="#">Ť</a>
<a onclick="insertTags('ť','','');return false" href="#">ť</a>
<a onclick="insertTags('Ú','','');return false" href="#">Ú</a>
<a onclick="insertTags('ú','','');return false" href="#">ú</a>
<a onclick="insertTags('Ý','','');return false" href="#">Ý</a>
<a onclick="insertTags('ý','','');return false" href="#">ý</a>
<a onclick="insertTags('Ž','','');return false" href="#">Ž</a>
<a onclick="insertTags('ž','','');return false" href="#">ž</a>
</p>
<p class="speciallang" style="display:none">
Spanisch: 
<a onclick="insertTags('Á','','');return false" href="#">Á</a>
<a onclick="insertTags('á','','');return false" href="#">á</a>
<a onclick="insertTags('É','','');return false" href="#">É</a>
<a onclick="insertTags('é','','');return false" href="#">é</a>
<a onclick="insertTags('Í','','');return false" href="#">Í</a>
<a onclick="insertTags('í','','');return false" href="#">í</a>
<a onclick="insertTags('Ñ','','');return false" href="#">Ñ</a>
<a onclick="insertTags('ñ','','');return false" href="#">ñ</a>
<a onclick="insertTags('Ó','','');return false" href="#">Ó</a>
<a onclick="insertTags('ó','','');return false" href="#">ó</a>
<a onclick="insertTags('Ú','','');return false" href="#">Ú</a>
<a onclick="insertTags('ú','','');return false" href="#">ú</a>
<a onclick="insertTags('Ü','','');return false" href="#">Ü</a>
<a onclick="insertTags('ü','','');return false" href="#">ü</a>
<a onclick="insertTags('¡','','');return false" href="#">¡</a>
<a onclick="insertTags('¿','','');return false" href="#">¿</a>
</p>
<p class="speciallang" style="display:none">
Tschechisch: 
<a onclick="insertTags('Á','','');return false" href="#">Á</a>
<a onclick="insertTags('á','','');return false" href="#">á</a>
<a onclick="insertTags('Č','','');return false" href="#">Č</a>
<a onclick="insertTags('č','','');return false" href="#">č</a>
<a onclick="insertTags('Ď','','');return false" href="#">Ď</a>
<a onclick="insertTags('ď','','');return false" href="#">ď</a>
<a onclick="insertTags('É','','');return false" href="#">É</a>
<a onclick="insertTags('é','','');return false" href="#">é</a>
<a onclick="insertTags('Ě','','');return false" href="#">Ě</a>
<a onclick="insertTags('ě','','');return false" href="#">ě</a>
<a onclick="insertTags('Í','','');return false" href="#">Í</a>
<a onclick="insertTags('í','','');return false" href="#">í</a>
<a onclick="insertTags('Ň','','');return false" href="#">Ň</a>
<a onclick="insertTags('ň','','');return false" href="#">ň</a>
<a onclick="insertTags('Ó','','');return false" href="#">Ó</a>
<a onclick="insertTags('ó','','');return false" href="#">ó</a>
<a onclick="insertTags('Ř','','');return false" href="#">Ř</a>
<a onclick="insertTags('ř','','');return false" href="#">ř</a>
<a onclick="insertTags('Š','','');return false" href="#">Š</a>
<a onclick="insertTags('š','','');return false" href="#">š</a>
<a onclick="insertTags('Ť','','');return false" href="#">Ť</a>
<a onclick="insertTags('ť','','');return false" href="#">ť</a>
<a onclick="insertTags('Ú','','');return false" href="#">Ú</a>
<a onclick="insertTags('ú','','');return false" href="#">ú</a>
<a onclick="insertTags('Ů','','');return false" href="#">Ů</a>
<a onclick="insertTags('ů','','');return false" href="#">ů</a>
<a onclick="insertTags('Ý','','');return false" href="#">Ý</a>
<a onclick="insertTags('ý','','');return false" href="#">ý</a>
<a onclick="insertTags('Ž','','');return false" href="#">Ž</a>
<a onclick="insertTags('ž','','');return false" href="#">ž</a>
</p>
<p class="speciallang" style="display:none">
Türkisch: 
<a onclick="insertTags('Â','','');return false" href="#">Â</a>
<a onclick="insertTags('Ə','','');return false" href="#">Ə</a>
<a onclick="insertTags('Ç','','');return false" href="#">Ç</a>
<a onclick="insertTags('Ğ','','');return false" href="#">Ğ</a>
<a onclick="insertTags('G‘','','');return false" href="#">G‘</a>
<a onclick="insertTags('Î','','');return false" href="#">Î</a>
<a onclick="insertTags('İ','','');return false" href="#">İ</a>
<a onclick="insertTags('Ñ','','');return false" href="#">Ñ</a>
<a onclick="insertTags('Ň','','');return false" href="#">Ň</a>
<a onclick="insertTags('O‘','','');return false" href="#">O‘</a>
<a onclick="insertTags('Ş','','');return false" href="#">Ş</a>
<a onclick="insertTags('Û','','');return false" href="#">Û</a>
<a onclick="insertTags('Ý','','');return false" href="#">Ý</a>
<a onclick="insertTags('Ž','','');return false" href="#">Ž</a> | 
<a onclick="insertTags('â','','');return false" href="#">â</a>
<a onclick="insertTags('ə','','');return false" href="#">ə</a>
<a onclick="insertTags('ç','','');return false" href="#">ç</a>
<a onclick="insertTags('ğ','','');return false" href="#">ğ</a>
<a onclick="insertTags('g‘','','');return false" href="#">g‘</a>
<a onclick="insertTags('î','','');return false" href="#">î</a>
<a onclick="insertTags('ı','','');return false" href="#">ı</a>
<a onclick="insertTags('ñ','','');return false" href="#">ñ</a>
<a onclick="insertTags('ň','','');return false" href="#">ň</a>
<a onclick="insertTags('o‘','','');return false" href="#">o‘</a>
<a onclick="insertTags('ş','','');return false" href="#">ş</a>
<a onclick="insertTags('û','','');return false" href="#">û</a>
<a onclick="insertTags('ý','','');return false" href="#">ý</a>
<a onclick="insertTags('ž','','');return false" href="#">ž</a>
</p>
<p class="speciallang" style="display:none">
Ungarisch: 
<a onclick="insertTags('á','','');return false" href="#">á</a>
<a onclick="insertTags('é','','');return false" href="#">é</a>
<a onclick="insertTags('í','','');return false" href="#">í</a>
<a onclick="insertTags('Ő','','');return false" href="#">Ő</a>
<a onclick="insertTags('ö','','');return false" href="#">ö</a>
<a onclick="insertTags('ó','','');return false" href="#">ó</a>
<a onclick="insertTags('ő','','');return false" href="#">ő</a>
<a onclick="insertTags('Ű','','');return false" href="#">Ű</a>
<a onclick="insertTags('ú','','');return false" href="#">ú</a>
<a onclick="insertTags('ü','','');return false" href="#">ü</a>
<a onclick="insertTags('ű','','');return false" href="#">ű</a>
</p>
<p class="speciallang" style="display:none">
Vietnamesisch: 
<a onclick="insertTags('À','','');return false" href="#">À</a>
<a onclick="insertTags('à','','');return false" href="#">à</a>
<a onclick="insertTags('Ả','','');return false" href="#">Ả</a>
<a onclick="insertTags('ả','','');return false" href="#">ả</a>
<a onclick="insertTags('Á','','');return false" href="#">Á</a>
<a onclick="insertTags('á','','');return false" href="#">á</a>
<a onclick="insertTags('Ạ','','');return false" href="#">Ạ</a>
<a onclick="insertTags('ạ','','');return false" href="#">ạ</a>
<a onclick="insertTags('Ã','','');return false" href="#">Ã</a>
<a onclick="insertTags('ã','','');return false" href="#">ã</a>
<a onclick="insertTags('Ă','','');return false" href="#">Ă</a>
<a onclick="insertTags('ă','','');return false" href="#">ă</a>
<a onclick="insertTags('Ằ','','');return false" href="#">Ằ</a>
<a onclick="insertTags('ằ','','');return false" href="#">ằ</a>
<a onclick="insertTags('Ẳ','','');return false" href="#">Ẳ</a>
<a onclick="insertTags('ẳ','','');return false" href="#">ẳ</a>
<a onclick="insertTags('Ẵ','','');return false" href="#">Ẵ</a>
<a onclick="insertTags('ẵ','','');return false" href="#">ẵ</a>
<a onclick="insertTags('Ắ','','');return false" href="#">Ắ</a>
<a onclick="insertTags('ắ','','');return false" href="#">ắ</a>
<a onclick="insertTags('Ặ','','');return false" href="#">Ặ</a>
<a onclick="insertTags('ặ','','');return false" href="#">ặ</a>
<a onclick="insertTags('Â','','');return false" href="#">Â</a>
<a onclick="insertTags('â','','');return false" href="#">â</a>
<a onclick="insertTags('Ầ','','');return false" href="#">Ầ</a>
<a onclick="insertTags('ầ','','');return false" href="#">ầ</a>
<a onclick="insertTags('Ẩ','','');return false" href="#">Ẩ</a>
<a onclick="insertTags('ẩ','','');return false" href="#">ẩ</a>
<a onclick="insertTags('Ẫ','','');return false" href="#">Ẫ</a>
<a onclick="insertTags('ẫ','','');return false" href="#">ẫ</a>
<a onclick="insertTags('Ấ','','');return false" href="#">Ấ</a>
<a onclick="insertTags('ấ','','');return false" href="#">ấ</a>
<a onclick="insertTags('Ậ','','');return false" href="#">Ậ</a>
<a onclick="insertTags('ậ','','');return false" href="#">ậ</a>
<a onclick="insertTags('Đ','','');return false" href="#">Đ</a>
<a onclick="insertTags('đ','','');return false" href="#">đ</a>
<a onclick="insertTags('È','','');return false" href="#">È</a>
<a onclick="insertTags('è','','');return false" href="#">è</a>
<a onclick="insertTags('Ẻ','','');return false" href="#">Ẻ</a>
<a onclick="insertTags('ẻ','','');return false" href="#">ẻ</a>
<a onclick="insertTags('Ẽ','','');return false" href="#">Ẽ</a>
<a onclick="insertTags('ẽ','','');return false" href="#">ẽ</a>
<a onclick="insertTags('É','','');return false" href="#">É</a>
<a onclick="insertTags('é','','');return false" href="#">é</a>
<a onclick="insertTags('Ẹ','','');return false" href="#">Ẹ</a>
<a onclick="insertTags('ẹ','','');return false" href="#">ẹ</a>
<a onclick="insertTags('Ê','','');return false" href="#">Ê</a>
<a onclick="insertTags('ê','','');return false" href="#">ê</a>
<a onclick="insertTags('Ề','','');return false" href="#">Ề</a>
<a onclick="insertTags('ề','','');return false" href="#">ề</a>
<a onclick="insertTags('Ể','','');return false" href="#">Ể</a>
<a onclick="insertTags('ể','','');return false" href="#">ể</a>
<a onclick="insertTags('Ễ','','');return false" href="#">Ễ</a>
<a onclick="insertTags('ễ','','');return false" href="#">ễ</a>
<a onclick="insertTags('Ế','','');return false" href="#">Ế</a>
<a onclick="insertTags('ế','','');return false" href="#">ế</a>
<a onclick="insertTags('Ệ','','');return false" href="#">Ệ</a>
<a onclick="insertTags('ệ','','');return false" href="#">ệ</a>
<a onclick="insertTags('Ỉ','','');return false" href="#">Ỉ</a>
<a onclick="insertTags('ỉ','','');return false" href="#">ỉ</a>
<a onclick="insertTags('Ĩ','','');return false" href="#">Ĩ</a>
<a onclick="insertTags('ĩ','','');return false" href="#">ĩ</a>
<a onclick="insertTags('Í','','');return false" href="#">Í</a>
<a onclick="insertTags('í','','');return false" href="#">í</a>
<a onclick="insertTags('Ị','','');return false" href="#">Ị</a>
<a onclick="insertTags('ị','','');return false" href="#">ị</a>
<a onclick="insertTags('Ì','','');return false" href="#">Ì</a>
<a onclick="insertTags('ì','','');return false" href="#">ì</a>
<a onclick="insertTags('Ỏ','','');return false" href="#">Ỏ</a>
<a onclick="insertTags('ỏ','','');return false" href="#">ỏ</a>
<a onclick="insertTags('Ó','','');return false" href="#">Ó</a>
<a onclick="insertTags('ó','','');return false" href="#">ó</a>
<a onclick="insertTags('Ọ','','');return false" href="#">Ọ</a>
<a onclick="insertTags('ọ','','');return false" href="#">ọ</a>
<a onclick="insertTags('Ò','','');return false" href="#">Ò</a>
<a onclick="insertTags('ò','','');return false" href="#">ò</a>
<a onclick="insertTags('Õ','','');return false" href="#">Õ</a>
<a onclick="insertTags('õ','','');return false" href="#">õ</a>
<a onclick="insertTags('Ô','','');return false" href="#">Ô</a>
<a onclick="insertTags('ô','','');return false" href="#">ô</a>
<a onclick="insertTags('Ồ','','');return false" href="#">Ồ</a>
<a onclick="insertTags('ồ','','');return false" href="#">ồ</a>
<a onclick="insertTags('Ổ','','');return false" href="#">Ổ</a>
<a onclick="insertTags('ổ','','');return false" href="#">ổ</a>
<a onclick="insertTags('Ỗ','','');return false" href="#">Ỗ</a>
<a onclick="insertTags('ỗ','','');return false" href="#">ỗ</a>
<a onclick="insertTags('Ố','','');return false" href="#">Ố</a>
<a onclick="insertTags('ố','','');return false" href="#">ố</a>
<a onclick="insertTags('Ộ','','');return false" href="#">Ộ</a>
<a onclick="insertTags('ộ','','');return false" href="#">ộ</a>
<a onclick="insertTags('Ơ','','');return false" href="#">Ơ</a>
<a onclick="insertTags('ơ','','');return false" href="#">ơ</a>
<a onclick="insertTags('Ờ','','');return false" href="#">Ờ</a>
<a onclick="insertTags('ờ','','');return false" href="#">ờ</a>
<a onclick="insertTags('Ở','','');return false" href="#">Ở</a>
<a onclick="insertTags('ở','','');return false" href="#">ở</a>
<a onclick="insertTags('Ỡ','','');return false" href="#">Ỡ</a>
<a onclick="insertTags('ỡ','','');return false" href="#">ỡ</a>
<a onclick="insertTags('Ớ','','');return false" href="#">Ớ</a>
<a onclick="insertTags('ớ','','');return false" href="#">ớ</a>
<a onclick="insertTags('Ợ','','');return false" href="#">Ợ</a>
<a onclick="insertTags('ợ','','');return false" href="#">ợ</a>
<a onclick="insertTags('Ù','','');return false" href="#">Ù</a>
<a onclick="insertTags('ù','','');return false" href="#">ù</a>
<a onclick="insertTags('Ủ','','');return false" href="#">Ủ</a>
<a onclick="insertTags('ủ','','');return false" href="#">ủ</a>
<a onclick="insertTags('Ũ','','');return false" href="#">Ũ</a>
<a onclick="insertTags('ũ','','');return false" href="#">ũ</a>
<a onclick="insertTags('Ú','','');return false" href="#">Ú</a>
<a onclick="insertTags('ú','','');return false" href="#">ú</a>
<a onclick="insertTags('Ụ','','');return false" href="#">Ụ</a>
<a onclick="insertTags('ụ','','');return false" href="#">ụ</a>
<a onclick="insertTags('Ư','','');return false" href="#">Ư</a>
<a onclick="insertTags('ư','','');return false" href="#">ư</a>
<a onclick="insertTags('Ừ','','');return false" href="#">Ừ</a>
<a onclick="insertTags('ừ','','');return false" href="#">ừ</a>
<a onclick="insertTags('Ử','','');return false" href="#">Ử</a>
<a onclick="insertTags('ử','','');return false" href="#">ử</a>
<a onclick="insertTags('Ữ','','');return false" href="#">Ữ</a>
<a onclick="insertTags('ữ','','');return false" href="#">ữ</a>
<a onclick="insertTags('Ứ','','');return false" href="#">Ứ</a>
<a onclick="insertTags('ứ','','');return false" href="#">ứ</a>
<a onclick="insertTags('Ự','','');return false" href="#">Ự</a>
<a onclick="insertTags('ự','','');return false" href="#">ự</a>
<a onclick="insertTags('Ỳ','','');return false" href="#">Ỳ</a>
<a onclick="insertTags('ỳ','','');return false" href="#">ỳ</a>
<a onclick="insertTags('Ỷ','','');return false" href="#">Ỷ</a>
<a onclick="insertTags('ỷ','','');return false" href="#">ỷ</a>
<a onclick="insertTags('Ỹ','','');return false" href="#">Ỹ</a>
<a onclick="insertTags('ỹ','','');return false" href="#">ỹ</a>
<a onclick="insertTags('Ỵ','','');return false" href="#">Ỵ</a>
<a onclick="insertTags('ỵ','','');return false" href="#">ỵ</a>
<a onclick="insertTags('Ý','','');return false" href="#">Ý</a>
<a onclick="insertTags('ý','','');return false" href="#">ý</a>
</p>
</div>
</div>
<div class='templatesUsed'>
<div class="mw-templatesUsedExplanation"><p>Folgende <a href="/wiki/Hilfe:Vorlagen" title="Hilfe:Vorlagen">Vorlagen</a> werden von diesem Artikel verwendet:
</p></div><ul><li><a href="/wiki/Vorlage:%21" title="Vorlage:!">Vorlage:!</a> (schreibgeschützt)</li><li><a href="/wiki/Vorlage:Audio" title="Vorlage:Audio">Vorlage:Audio</a> </li><li><a href="/wiki/Vorlage:Bausteindesign1" title="Vorlage:Bausteindesign1">Vorlage:Bausteindesign1</a> (schreibgeschützt)</li><li><a href="/wiki/Vorlage:Bausteindesign2" title="Vorlage:Bausteindesign2">Vorlage:Bausteindesign2</a> (schreibgeschützt für unangemeldete und neue Benutzer)</li><li><a href="/wiki/Vorlage:Commons" title="Vorlage:Commons">Vorlage:Commons</a> (schreibgeschützt für unangemeldete und neue Benutzer)</li><li><a href="/wiki/Vorlage:Dieser_Artikel" title="Vorlage:Dieser Artikel">Vorlage:Dieser Artikel</a> (schreibgeschützt)</li><li><a href="/wiki/Vorlage:Dmoz" title="Vorlage:Dmoz">Vorlage:Dmoz</a> (schreibgeschützt für unangemeldete und neue Benutzer)</li><li><a href="/wiki/Vorlage:Hintergrundfarbe8" title="Vorlage:Hintergrundfarbe8">Vorlage:Hintergrundfarbe8</a> </li><li><a href="/wiki/Vorlage:H%C3%B6he" title="Vorlage:Höhe">Vorlage:Höhe</a> (schreibgeschützt für unangemeldete und neue Benutzer)</li><li><a href="/wiki/Vorlage:KoordinateURL" title="Vorlage:KoordinateURL">Vorlage:KoordinateURL</a> (schreibgeschützt)</li><li><a href="/wiki/Vorlage:Koordinate_Text_Artikel" title="Vorlage:Koordinate Text Artikel">Vorlage:Koordinate Text Artikel</a> (schreibgeschützt)</li><li><a href="/wiki/Vorlage:Lesenswert" title="Vorlage:Lesenswert">Vorlage:Lesenswert</a> (schreibgeschützt für unangemeldete und neue Benutzer)</li><li><a href="/wiki/Vorlage:Link-Bild-Inline" title="Vorlage:Link-Bild-Inline">Vorlage:Link-Bild-Inline</a> </li><li><a href="/wiki/Vorlage:NaviBlock" title="Vorlage:NaviBlock">Vorlage:NaviBlock</a> (schreibgeschützt für unangemeldete und neue Benutzer)</li><li><a href="/wiki/Vorlage:Navigationsleiste" title="Vorlage:Navigationsleiste">Vorlage:Navigationsleiste</a> (schreibgeschützt)</li><li><a href="/wiki/Vorlage:Navigationsleiste_Landkreise_und_kreisfreie_St%C3%A4dte_in_Sachsen" title="Vorlage:Navigationsleiste Landkreise und kreisfreie Städte in Sachsen">Vorlage:Navigationsleiste Landkreise und kreisfreie Städte in Sachsen</a> </li><li><a href="/wiki/Vorlage:Navigationsleiste_Metropolregion_Sachsendreieck" title="Vorlage:Navigationsleiste Metropolregion Sachsendreieck">Vorlage:Navigationsleiste Metropolregion Sachsendreieck</a> </li><li><a href="/wiki/Vorlage:Navigationsleiste_Stadtteile_Leipzig" title="Vorlage:Navigationsleiste Stadtteile Leipzig">Vorlage:Navigationsleiste Stadtteile Leipzig</a> </li><li><a href="/wiki/Vorlage:Portal" title="Vorlage:Portal">Vorlage:Portal</a> </li><li><a href="/wiki/Vorlage:S-Bahn-Linie" title="Vorlage:S-Bahn-Linie">Vorlage:S-Bahn-Linie</a> </li><li><a href="/wiki/Vorlage:Text_oben_rechts" title="Vorlage:Text oben rechts">Vorlage:Text oben rechts</a> (schreibgeschützt für unangemeldete und neue Benutzer)</li><li><a href="/wiki/Vorlage:Trunc" title="Vorlage:Trunc">Vorlage:Trunc</a> </li><li><a href="/wiki/Vorlage:Wikinews" title="Vorlage:Wikinews">Vorlage:Wikinews</a> </li><li><a href="/wiki/Vorlage:Wikiquote" title="Vorlage:Wikiquote">Vorlage:Wikiquote</a> (schreibgeschützt)</li><li><a href="/wiki/Vorlage:Wiktionary" title="Vorlage:Wiktionary">Vorlage:Wiktionary</a> (schreibgeschützt für unangemeldete und neue Benutzer)</li></ul>
</div>

<input type='hidden' value="\" name="wpEditToken" />
<input name="wpAutoSummary" type="hidden" value="d41d8cd98f00b204e9800998ecf8427e" /></form>
<div class="printfooter">
Von „<a href="http://de.wikipedia.org/wiki/Leipzig">http://de.wikipedia.org/wiki/Leipzig</a>“</div>
						<!-- end content -->
			<div class="visualClear"></div>
		</div>
	</div>
		</div>
		<div id="column-one">
	<div id="p-cactions" class="portlet">
		<h5>Diese Seite</h5>
		<div class="pBody">
			<ul>
					 <li id="ca-nstab-main" class="selected"><a href="/wiki/Leipzig" title="Seiteninhalt anzeigen [c]" accesskey="c">Artikel</a></li>
					 <li id="ca-talk"><a href="/wiki/Diskussion:Leipzig" title="Diskussion zum Seiteninhalt [t]" accesskey="t">Diskussion</a></li>
					 <li id="ca-edit" class="selected"><a href="/w/index.php?title=Leipzig&amp;action=edit" title="Seite bearbeiten. Bitte vor dem Speichern die Vorschaufunktion benutzen. [e]" accesskey="e">Seite bearbeiten</a></li>
					 <li id="ca-history"><a href="/w/index.php?title=Leipzig&amp;action=history" title="Frühere Versionen dieser Seite [h]" accesskey="h">Versionen/Autoren</a></li>
				</ul>
		</div>
	</div>
	<div class="portlet" id="p-personal">
		<h5>Persönliche Werkzeuge</h5>
		<div class="pBody">
			<ul>
				<li id="pt-login"><a href="/w/index.php?title=Spezial:Anmelden&amp;returnto=Leipzig" title="Sich einzuloggen wird zwar gerne gesehen, ist aber keine Pflicht. [o]" accesskey="o">Anmelden</a></li>
			</ul>
		</div>
	</div>
	<div class="portlet" id="p-logo">
		<a style="background-image: url(http://upload.wikimedia.org/wikipedia/de/b/bc/Wiki.png);" href="/wiki/Hauptseite" title="Hauptseite anzeigen [z]" accesskey="z"></a>
	</div>
	<script type="text/javascript"> if (window.isMSIE55) fixalpha(); </script>
		<div class='portlet' id='p-navigation'>
		<h5>Navigation</h5>
		<div class='pBody'>
			<ul>
				<li id="n-mainpage"><a href="/wiki/Hauptseite" title="Hauptseite anzeigen [z]" accesskey="z">Hauptseite</a></li>
				<li id="n-aboutsite"><a href="/wiki/Wikipedia:%C3%9Cber_Wikipedia">Über Wikipedia</a></li>
				<li id="n-topics"><a href="/wiki/Portal:Wikipedia_nach_Themen">Themenportale</a></li>
				<li id="n-alphindex"><a href="/wiki/Spezial:Alle_Seiten">Von A bis Z</a></li>
				<li id="n-randompage"><a href="/wiki/Spezial:Zuf%C3%A4llige_Seite" title="Zufällige Seite [x]" accesskey="x">Zufälliger Artikel</a></li>
			</ul>
		</div>
	</div>
		<div class='portlet' id='p-Mitmachen'>
		<h5>Mitmachen</h5>
		<div class='pBody'>
			<ul>
				<li id="n-help"><a href="/wiki/Wikipedia:Hilfe" title="Hilfeseite anzeigen">Hilfe</a></li>
				<li id="n-portal"><a href="/wiki/Wikipedia:Autorenportal" title="Über das Portal, was Sie tun können, wo was zu finden ist">Autorenportal</a></li>
				<li id="n-recentchanges"><a href="/wiki/Spezial:Letzte_%C3%84nderungen" title="Liste der letzten Änderungen in Wikipedia. [r]" accesskey="r">Letzte Änderungen</a></li>
				<li id="n-sitesupport"><a href="http://wikimediafoundation.org/wiki/Spenden" title="Unterstützen Sie uns">Spenden</a></li>
			</ul>
		</div>
	</div>
		<div id="p-search" class="portlet">
		<h5><label for="searchInput">Suche</label></h5>
		<div id="searchBody" class="pBody">
			<form action="/wiki/Spezial:Suche" id="searchform"><div>
				<input id="searchInput" name="search" type="text" title="Durchsuche die Wikipedia [f]" accesskey="f" value="" />
				<input type='submit' name="go" class="searchButton" id="searchGoButton"	value="Artikel" />&nbsp;
				<input type='submit' name="fulltext" class="searchButton" id="mw-searchButton" value="Volltext" />
			</div></form>
		</div>
	</div>
	<div class="portlet" id="p-tb">
		<h5>Werkzeuge</h5>
		<div class="pBody">
			<ul>
				<li id="t-whatlinkshere"><a href="/wiki/Spezial:Verweisliste/Leipzig" title="Liste aller Seiten, die hierher zeigen [j]" accesskey="j">Links auf diese Seite</a></li>
				<li id="t-recentchangeslinked"><a href="/wiki/Spezial:%C3%84nderungen_an_verlinkten_Seiten/Leipzig" title="Letzte Änderungen an Seiten, die von hier verlinkt sind [k]" accesskey="k">Änderungen an verlinkten Seiten</a></li>
<li id="t-upload"><a href="/wiki/Spezial:Hochladen" title="Dateien hochladen [u]" accesskey="u">Hochladen</a></li>
<li id="t-specialpages"><a href="/wiki/Spezial:Spezialseiten" title="Liste aller Spezialseiten [q]" accesskey="q">Spezialseiten</a></li>
			</ul>
		</div>
	</div>
		</div><!-- end of the left (by default at least) column -->
			<div class="visualClear"></div>
			<div id="footer">
				<div id="f-poweredbyico"><a href="http://www.mediawiki.org/"><img src="/skins-1.5/common/images/poweredby_mediawiki_88x31.png" alt="Powered by MediaWiki" /></a></div>
				<div id="f-copyrightico"><a href="http://wikimediafoundation.org/"><img src="/images/wikimedia-button.png" border="0" alt="Wikimedia Foundation"/></a></div>
			<ul id="f-list">
				<li id="privacy"><a href="/wiki/Wikipedia:Datenschutz" title="Wikipedia:Datenschutz">Datenschutz</a></li>
				<li id="about"><a href="/wiki/Wikipedia:%C3%9Cber_Wikipedia" title="Wikipedia:Über Wikipedia">Über Wikipedia</a></li>
				<li id="disclaimer"><a href="/wiki/Wikipedia:Impressum" title="Wikipedia:Impressum">Impressum</a></li>
			</ul>
		</div>
		
	
		<script type="text/javascript">if (window.runOnloadHook) runOnloadHook();</script>
</div>
<!-- Served by srv55 in 0.416 secs. --></body></html>
