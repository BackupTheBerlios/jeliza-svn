<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de" dir="ltr">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="robots" content="noindex,nofollow" />
		<meta name="keywords" content="Ersten,Artikel,Erste Schritte,Quellenangaben,Relevanzkriterien,Spielwiese,Ersten,Ersten,Quellenangaben,Lizenzbestimmungen,Urheberrechte beachten,Ersten,Liste der IPA-Zeichen,Sonderzeichen" />
		<link rel="shortcut icon" href="/favicon.ico" />
		<link rel="search" type="application/opensearchdescription+xml" href="/w/opensearch_desc.php" title="Wikipedia (Deutsch)" />
		<link rel="copyright" href="http://www.gnu.org/copyleft/fdl.html" />
		<title>Bearbeiten von Ersten - Wikipedia</title>
		<style type="text/css" media="screen,projection">/*<![CDATA[*/ @import "/skins-1.5/monobook/main.css?61"; /*]]>*/</style>
		<link rel="stylesheet" type="text/css" media="print" href="/skins-1.5/common/commonPrint.css?61" />
		<link rel="stylesheet" type="text/css" media="handheld" href="/skins-1.5/monobook/handheld.css?61" />
		<!--[if lt IE 5.5000]><style type="text/css">@import "/skins-1.5/monobook/IE50Fixes.css?61";</style><![endif]-->
		<!--[if IE 5.5000]><style type="text/css">@import "/skins-1.5/monobook/IE55Fixes.css?61";</style><![endif]-->
		<!--[if IE 6]><style type="text/css">@import "/skins-1.5/monobook/IE60Fixes.css?61";</style><![endif]-->
		<!--[if IE 7]><style type="text/css">@import "/skins-1.5/monobook/IE70Fixes.css?61";</style><![endif]-->
		<!--[if lt IE 7]><script type="text/javascript" src="/skins-1.5/common/IEFixes.js?61"></script>
		<meta http-equiv="imagetoolbar" content="no" /><![endif]-->
		
		<script type= "text/javascript">/*<![CDATA[*/
var skin = "monobook";
var stylepath = "/skins-1.5";
var wgArticlePath = "/wiki/$1";
var wgScriptPath = "/w";
var wgServer = "http://de.wikipedia.org";
var wgCanonicalNamespace = "";
var wgCanonicalSpecialPageName = false;
var wgNamespaceNumber = 0;
var wgPageName = "Ersten";
var wgTitle = "Ersten";
var wgArticleId = 0;
var wgIsArticle = false;
var wgUserName = null;
var wgUserGroups = null;
var wgUserLanguage = "de";
var wgContentLanguage = "de";
var wgBreakFrames = false;
var wgCurRevisionId = false;
/*]]>*/</script>
                
		<script type="text/javascript" src="/skins-1.5/common/wikibits.js?61"><!-- wikibits js --></script>
		<script type="text/javascript" src="/w/index.php?title=-&amp;action=raw&amp;gen=js"><!-- site js --></script>
		<style type="text/css">/*<![CDATA[*/
@import "/w/index.php?title=MediaWiki:Common.css&usemsgcache=yes&action=raw&ctype=text/css&smaxage=2678400";
@import "/w/index.php?title=MediaWiki:Monobook.css&usemsgcache=yes&action=raw&ctype=text/css&smaxage=2678400";
@import "/w/index.php?title=-&action=raw&gen=css&maxage=2678400";
/*]]>*/</style>
		<!-- Head Scripts -->
		<script type="text/javascript" src="/skins-1.5/common/ajax.js?61"></script>
	</head>
<body  class="mediawiki ns-0 ltr page-Ersten">
	<div id="globalWrapper">
		<div id="column-content">
	<div id="content">
		<a name="top" id="top"></a>
				<h1 class="firstHeading">Bearbeiten von Ersten</h1>
		<div id="bodyContent">
			<h3 id="siteSub">aus Wikipedia, der freien Enzyklopädie</h3>
			<div id="contentSub"></div>
									<div id="jump-to-nav">Wechseln zu: <a href="#column-one">Navigation</a>, <a href="#searchInput">Suche</a></div>			<!-- start content -->
			<div id="newarticletext">
<div style="font-size: 100%; color: #003333; border: 1px solid #aaaaaa; padding: 3px">
<p><b>Diese Seite existiert noch nicht.</b> Du kannst hier einen neuen Wikipedia-Artikel verfassen. Hilfe dazu gibt es in unseren <a href="/wiki/Wikipedia:Erste_Schritte" title="Wikipedia:Erste Schritte">ersten Schritten</a>. Falls du nichts eingeben möchtest, klicke auf den Zurück-Button des Browsers, um zu der letzten Seite zurückzukehren. 
</p><p><b>Beachte bitte:</b>
</p>
<ul><li> Der Artikel sollte ein <a href="/wiki/Wikipedia:Artikel" title="Wikipedia:Artikel">Mindestniveau</a> erfüllen, es passiert leider zu oft, dass schlechte Artikel gelöscht werden müssen.
</li><li> Unsinnige Eingaben kosten die Wikipedia-Mitarbeiter jeden Tag unnötig viel Zeit. Es gibt dafür die <a href="/wiki/Wikipedia:Spielwiese" title="Wikipedia:Spielwiese">Spielwiese</a>.
</li><li> Für Werbeeinträge gibt es Branchenverzeichnisse, daher werden sie hier gelöscht. Neutrale Artikel über Unternehmen, welche die <a href="/wiki/Wikipedia:Relevanzkriterien" title="Wikipedia:Relevanzkriterien">Relevanzkriterien</a> erfüllen, sind selbstverständlich erwünscht.
</li><li> Es muss angegeben werden, <a href="/wiki/Wikipedia:Quellenangaben" title="Wikipedia:Quellena