<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de" dir="ltr">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="robots" content="noindex,nofollow" />
		<meta name="keywords" content="Metall,Metall,Entsperrwünsche,Geschützte Seiten,MediaWiki-Namensraum,Metall" />
		<link rel="shortcut icon" href="/favicon.ico" />
		<link rel="search" type="application/opensearchdescription+xml" href="/w/opensearch_desc.php" title="Wikipedia (Deutsch)" />
		<link rel="copyright" href="http://www.gnu.org/copyleft/fdl.html" />
		<title>Quelltext betrachten - Wikipedia</title>
		<style type="text/css" media="screen,projection">/*<![CDATA[*/ @import "/skins-1.5/monobook/main.css?61"; /*]]>*/</style>
		<link rel="stylesheet" type="text/css" media="print" href="/skins-1.5/common/commonPrint.css?61" />
		<link rel="stylesheet" type="text/css" media="handheld" href="/skins-1.5/monobook/handheld.css?61" />
		<!--[if lt IE 5.5000]><style type="text/css">@import "/skins-1.5/monobook/IE50Fixes.css?61";</style><![endif]-->
		<!--[if IE 5.5000]><style type="text/css">@import "/skins-1.5/monobook/IE55Fixes.css?61";</style><![endif]-->
		<!--[if IE 6]><style type="text/css">@import "/skins-1.5/monobook/IE60Fixes.css?61";</style><![endif]-->
		<!--[if IE 7]><style type="text/css">@import "/skins-1.5/monobook/IE70Fixes.css?61";</style><![endif]-->
		<!--[if lt IE 7]><script type="text/javascript" src="/skins-1.5/common/IEFixes.js?61"></script>
		<meta http-equiv="imagetoolbar" content="no" /><![endif]-->
		
		<script type= "text/javascript">/*<![CDATA[*/
var skin = "monobook";
var stylepath = "/skins-1.5";
var wgArticlePath = "/wiki/$1";
var wgScriptPath = "/w";
var wgServer = "http://de.wikipedia.org";
var wgCanonicalNamespace = "";
var wgCanonicalSpecialPageName = false;
var wgNamespaceNumber = 0;
var wgPageName = "Metall";
var wgTitle = "Metall";
var wgArticleId = "1272527";
var wgIsArticle = false;
var wgUserName = null;
var wgUserGroups = null;
var wgUserLanguage = "de";
var wgContentLanguage = "de";
var wgBreakFrames = false;
var wgCurRevisionId = "30244479";
/*]]>*/</script>
                
		<script type="text/javascript" src="/skins-1.5/common/wikibits.js?61"><!-- wikibits js --></script>
		<script type="text/javascript" src="/w/index.php?title=-&amp;action=raw&amp;gen=js"><!-- site js --></script>
		<style type="text/css">/*<![CDATA[*/
@import "/w/index.php?title=MediaWiki:Common.css&usemsgcache=yes&action=raw&ctype=text/css&smaxage=2678400";
@import "/w/index.php?title=MediaWiki:Monobook.css&usemsgcache=yes&action=raw&ctype=text/css&smaxage=2678400";
@import "/w/index.php?title=-&action=raw&gen=css&maxage=2678400";
/*]]>*/</style>
		<!-- Head Scripts -->
		<script type="text/javascript" src="/skins-1.5/common/ajax.js?61"></script>
	</head>
<body  class="mediawiki ns-0 ltr page-Metall">
	<div id="globalWrapper">
		<div id="column-content">
	<div id="content">
		<a name="top" id="top"></a>
				<h1 class="firstHeading">Quelltext betrachten</h1>
		<div id="bodyContent">
			<h3 id="siteSub">aus Wikipedia, der freien Enzyklopädie</h3>
			<div id="contentSub">für <a href="/wiki/Metall" title="Metall">Metall</a></div>
									<div id="jump-to-nav">Wechseln zu: <a href="#column-one">Navigation</a>, <a href="#searchInput">Suche</a></div>			<!-- start content -->
			<p>Diese Seite ist für das Bearbeiten gesperrt. Gründe für den Seitenschutz finden sich im <a href="http://de.wikipedia.org/w/index.php?title=Spezial:Log&amp;type=protect&amp;page=Metall" class="external text" title="http://de.wikipedia.org/w/index.php?title=Spezial:Log&amp;type=protect&amp;page=Metall" rel="nofollow">Seitenschutz-Logbuch</a>, auf der <a href="/wiki/Diskussion:Metall" title="Diskussion:Metall">Diskussionsseite</a> oder in den <a href="/wiki/Wikipedia:Gesch%C3%BCtzte_Seiten" title="Wikipedia:Geschützte Seiten">Regeln für geschützte Seiten</a>. Seiten im <a href="/wiki/Hilfe:MediaWiki-Namensraum" title="Hilfe:MediaWiki-Namensraum">MediaWiki-Namensraum</a> sind grundsätzlich nur von Administratoren bearbeitbar.
</p><p>Du kannst Änderungswünsche für diese Seite auf der zugehörigen Diskussionsseite vorschlagen. Wenn du meinst, dass der Bearbeitungsschutz aufgehoben werden sollte, kannst du dies auf <a href="/wiki/Wikipedia:Entsperrw%C3%BCnsche" title="Wikipedia:Entsperrwünsche">Wikipedia:Entsperrwünsche</a> erklären.
</p><p>Du kannst jedoch den Quelltext dieser Seite betrachten und kopieren:
</p>
<textarea name='wpTextbox1' id='wpTextbox1' cols='80' rows='25' readonly='readonly'>{{Dieser Artikel|handelt von chemischen Elementen. Für die ukrainische Fachzeitschrift siehe [[Metall (Zeitschrift)]].}}

'''Metalle''' sind die größte Gruppe der [[Chemisches Element|chemischen Elemente]], etwa 80&amp;nbsp;% der Elemente sind Metalle. 
[[Bild:Gallium1 640x480.jpg|thumb|400px|[[Gallium]]]]

&lt;br /&gt;

== Einteilung ==
Traditionell unterteilt man Metalle nach der Dichte in [[Schwermetall]]e und [[Leichtmetall]]e und nach der Reaktivität in [[Edelmetall]]e und [[unedle Metalle]]. ''Siehe hierzu auch den Hauptartikel'' [[Metallischer Werkstoff]].

Im [[Periodensystem der Elemente]] sind Metalle nicht bestimmten Reihen oder Perioden zugeordnet, vielmehr befinden sie sich links und unterhalb einer Linie vom [[Bor]] zum [[Polonium]]. Oben rechts befinden sich die [[Nichtmetall]]e, dazwischen die [[Halbmetall]]e. Die [[Nebengruppe]]nelemente sind ausnahmslos Metalle.

Für das chemische Verhalten ist auch die Zugehörigkeit zu Haupt- oder Nebengruppen des Periodensystems entscheidend.

{|
! H|| colspan=&quot;17&quot; |&amp;nbsp; ||He
|-
! bgcolor=&quot;#DDDDDD&quot;|Li||bgcolor=&quot;#DDDDDD&quot;|Be|| colspan=&quot;11&quot; |&amp;nbsp; ||B ||C ||N ||O ||F ||Ne
|-
! bgcolor=&quot;#DDDDDD&quot;|Na||bgcolor=&quot;#DDDDDD&quot;|Mg|| colspan=&quot;11&quot; |&amp;nbsp; ||bgcolor=&quot;#DDDDDD&quot;|Al||Si||P ||S ||Cl||Ar
|-
! bgcolor=&quot;#DDDDDD&quot;|K ||bgcolor=&quot;#DDDDDD&quot;|Ca||bgcolor=&quot;#DDDDDD&quot;|Sc||&amp;nbsp;||bgcolor=&quot;#DDDDDD&quot;|Ti||bgcolor=&quot;#AAAAAA&quot;|V ||bgcolor=&quot;#AAAAAA&quot;|Cr||bgcolor=&quot;#AAAAAA&quot;|Mn||bgcolor=&quot;#AAAAAA&quot;|Fe||bgcolor=&quot;#AAAAAA&quot;|Co||bgcolor=&quot;#AAAAAA&quot;|Ni||bgcolor=&quot;#AAAAAA&quot;|Cu||bgcolor=&quot;#AAAAAA&quot;|Zn||bgcolor=&quot;#AAAAAA&quot;|Ga||bgcolor=&quot;#AAAAAA&quot;|Ge ||As||Se||Br||Kr
|-
! bgcolor=&quot;#DDDDDD&quot;|Rb||bgcolor=&quot;#DDDDDD&quot;|Sr||bgcolor=&quot;#DDDDDD&quot;|Y ||&amp;nbsp; ||bgcolor=&quot;#AAAAAA&quot;|Zr||bgcolor=&quot;#AAAAAA&quot;|Nb||bgcolor=&quot;#777777&quot;|Mo||bgcolor=&quot;#777777&quot;|Tc||bgcolor=&quot;#777777&quot;|Ru||bgcolor=&quot;#777777&quot;|Rh||bgcolor=&quot;#777777&quot;|Pd||bgcolor=&quot;#777777&quot;|Ag||bgcolor=&quot;#AAAAAA&quot;|Cd||bgcolor=&quot;#AAAAAA&quot;|In||bgcolor=&quot;#AAAAAA&quot;|Sn||bgcolor=&quot;#AAAAAA&quot;|Sb||Te||I ||Xe
|-
! bgcolor=&quot;#DDDDDD&quot;|Cs||bgcolor=&quot;#DDDDDD&quot;|Ba||bgcolor=&quot;#AAAAAA&quot;|La||* ||bgcolor=&quot;#777777&quot;|Hf||bgcolor=&quot;#777777&quot;|Ta||bgcolor=&quot;#777777&quot;|W ||bgcolor=&quot;#777777&quot;|Re||bgcolor=&quot;#777777&quot;|Os||bgcolor=&quot;#777777&quot;|Ir||bgcolor=&quot;#777777&quot;|Pt||bgcolor=&quot;#777777&quot;|Au||bgcolor=&quot;#777777&quot;|Hg||bgcolor=&quot;#777777&quot;|Tl||bgcolor=&quot;#777777&quot;|Pb||bgcolor=&quot;#AAAAAA&quot;|Bi||bgcolor=&quot;#AAAAAA&quot;|Po||At||Rn 
|-
! bgcolor=&quot;#DDDDDD&quot;|Fr||bgcolor=&quot;#AAAAAA&quot;|Ra||bgcolor=&quot;#777777&quot;|Ac||** ||bgcolor=&quot;#777777&quot;|Rf||bgcolor=&quot;#777777&quot;|Db||bgcolor=&quot;#777777&quot;|Sg||bgcolor=&quot;#777777&quot;|Bh||bgcolor=&quot;#777777&quot;|Hs||bgcolor=&quot;#777777&quot;|Mt||bgcolor=&quot;#777777&quot;|Ds||bgcolor=&quot;#777777&quot;|Rg
|-
| colspan=&quot;19&quot;|&amp;nbsp;
|-
! colspan=&quot;3&quot;|&amp;nbsp; ||* ||bgcolor=&quot;#AAAAAA&quot;|Ce||bgcolor=&quot;#AAAAAA&quot;|Pr||bgcolor=&quot;#AAAAAA&quot;|Nd||bgcolor=&quot;#AAAAAA&quot;|Pm||bgcolor=&quot;#AAAAAA&quot;|Sm||bgcolor=&quot;#AAAAAA&quot;|Eu||bgcolor=&quot;#AAAAAA&quot;|Gd||bgcolor=&quot;#AAAAAA&quot;|Tb||bgcolor=&quot;#AAAAAA&quot;|Dy||bgcolor=&quot;#AAAAAA&quot;|Ho||bgcolor=&quot;#AAAAAA&quot;|Er||bgcolor=&quot;#AAAAAA&quot;|Tm||bgcolor=&quot;#AAAAAA&quot;|Yb||bgcolor=&quot;#AAAAAA&quot;|Lu||
|-
! colspan=&quot;3&quot;|&amp;nbsp; ||**||bgcolor=&quot;#777777&quot;|Th||bgcolor=&quot;#777777&quot;|Pa||bgcolor=&quot;#777777&quot;|U ||bgcolor=&quot;#777777&quot;|Np||bgcolor=&quot;#777777&quot;|Pu||bgcolor=&quot;#777777&quot;|Am||bgcolor=&quot;#777777&quot;|Cm||bgcolor=&quot;#777777&quot;|Bk||bgcolor=&quot;#777777&quot;|Cf||bgcolor=&quot;#777777&quot;|Es||bgcolor=&quot;#777777&quot;|Fm||bgcolor=&quot;#777777&quot;|Md||bgcolor=&quot;#777777&quot;|No||bgcolor=&quot;#777777&quot;|Lr||
|}

{|
| bgcolor=&quot;#DDDDDD&quot;| Leichtmetalle &lt; 5 g/cm³
| bgcolor=&quot;#AAAAAA&quot;| Schwermetalle &lt; 10 g/cm³
| bgcolor=&quot;#777777&quot;| Schwermetalle &gt; 10 g/cm³
|}

''Siehe auch'': [[Refraktärmetalle]]

== Physikalische Eigenschaften ==
=== Allgemeines ===
Metall[[Atom|atome]] sind durch folgende Eigenschaften gekennzeichnet:
* Die Zahl der [[Elektron]]en in der äußeren Schale ist gering und kleiner als die [[Koordinationszahl]]
* Die (zur Abspaltung dieser Außenelektronen nötige) [[Ionisierungsenergie]] ist klein (&lt; etwa 10 [[Elektronenvolt|eV]])

Daraus resultiert, dass Metallatome sich untereinander nicht wie viele Nichtmetalle über Atombindungen zu Molekülen oder Gittern verbinden können. Allenfalls in Metalldämpfen kommen solche Atombindungen vor, z.&amp;nbsp;B. besteht [[Natrium]]dampf zu etwa 1&amp;nbsp;% aus Na&lt;sub&gt;2&lt;/sub&gt;-Molekülen. 

Metalle ordnen sich vielmehr zu einem [[Metallgitter]] aus positiv geladenen [[Metallische Bindung|Atomrümpfen]], während die [[Valenzelektron]]en über das ganze Gitter verteilt sind. Keines dieser Elektronen gehört mehr zu einem bestimmten Kern, diese Elektronen sind frei beweglich, also nicht an bestimmte Energieniveaus (Orbitale) gebunden, sie befinden sich in der „Leiterbahn“ und bilden ein „Elektronengas“. Eine exaktere Betrachtung unter Berücksichtigung des [[Orbitalmodell]]s liefert das [[Bändermodell]].

Aus dieser Bindungsart und diesem Gitteraufbau resultieren folgende typische Eigenschaften der Metalle: 

* Glanz (Spiegelglanz)
:Die frei beweglichen Elektronen können die gesamte eingestrahlte, aufgenommene Energie - also alle Wellenlängen - wieder unverändert emittieren; so entstehen der Glanz und der Spiegeleffekt. Das nennt man auch [[Reflexion]]; aus glatten Metallflächen werden deshalb [[Spiegel]] angefertigt.

* Undurchsichtigkeit 
:Die vorbeschriebene, an der Metalloberfläche stattfindende Reflexion bewirkt zugleich, dass Licht das Metall nicht durchdringen kann. Metalle sehen deshalb bereits in dünnsten Schichten in der Durchsicht grau bis schwarz aus. 

* Gute [[Elektrische Leitfähigkeit|elektrische Leitfähigkeit]] 
:Die Wanderung der frei beweglichen Elektronen in eine Richtung ist der elektrische Strom. 

* Gute [[Thermische Leitfähigkeit|thermische Leitfähigkeit]] 
:Die leicht verschiebbaren Elektronen nehmen an der Wärmebewegung teil und tragen so zum Wärmetransport bei, vgl. [[Wärmeleitung#Mechanismen|Wärmeleitung]]

* Gute Verformbarkeit ([[Duktilität]])
:Im Metallgitter befinden sich Versetzungen, die sich schon bei einer Spannung unterhalb der Trennspannung bewegen können; je nach Gittertyp verformt sich also ein Metall eher, als dass es bricht

* Hoher [[Schmelzpunkt]] 
:durch die allseitig gerichteten Bindungskräfte

=== Schmelz- und Siedetemperaturen ===
Die folgende Tabelle zeigt die Schmelz- und Siedetemperaturen einiger Metalle (in °C bei [[Normaldruck]]):

:{| class=&quot;prettytable sortable&quot;
|-- class=&quot;hintergrundfarbe6&quot;
!Metall !!Schmelztemperatur !! Siedetemperatur
|-
|[[Aluminium]] || align=&quot;center&quot; | &lt;span style=&quot;display:none&quot;&gt;06590&lt;/span&gt; &lt;span style=&quot;visibility:hidden;&quot;&gt;0&lt;/span&gt;659&lt;span style=&quot;visibility:hidden;&quot;&gt;,0&lt;/span&gt; || align=&quot;center&quot; | 2467 
|-
|[[Blei]] ||  align=&quot;center&quot; | &lt;span style=&quot;display:none&quot;&gt;03274&lt;/span&gt; &lt;span style=&quot;visibility:hidden;&quot;&gt;0&lt;/span&gt;327,4 ||  align=&quot;center&quot; | 1751
|-
|[[Eisen]] ||  align=&quot;center&quot; | &lt;span style=&quot;display:none&quot;&gt;15360&lt;/span&gt; 1536&lt;span style=&quot;visibility:hidden;&quot;&gt;,0&lt;/span&gt; ||  align=&quot;center&quot; | 3070
|-
|[[Kupfer]] || align=&quot;center&quot; | &lt;span style=&quot;display:none&quot;&gt;10830&lt;/span&gt; 1083&lt;span style=&quot;visibility:hidden;&quot;&gt;,0&lt;/span&gt; ||  align=&quot;center&quot; | 2595 
|-
|[[Magnesium]] || align=&quot;center&quot; | &lt;span style=&quot;display:none&quot;&gt;06500&lt;/span&gt; &lt;span style=&quot;visibility:hidden;&quot;&gt;0&lt;/span&gt;650&lt;span style=&quot;visibility:hidden;&quot;&gt;,0&lt;/span&gt; || align=&quot;center&quot; | 1120
|-
|[[Wolfram]] ||  align=&quot;center&quot; | &lt;span style=&quot;display:none&quot;&gt;34220&lt;/span&gt; 3422&lt;span style=&quot;visibility:hidden;&quot;&gt;,0&lt;/span&gt; ||  align=&quot;center&quot; | 5555
|-
|[[Zink]] || align=&quot;center&quot; | &lt;span style=&quot;display:none&quot;&gt;04195&lt;/span&gt; &lt;span style=&quot;visibility:hidden;&quot;&gt;0&lt;/span&gt;419,5 ||  align=&quot;center&quot; | &lt;span style=&quot;visibility:hidden;&quot;&gt;0&lt;/span&gt;907
|-
|[[Zinn]] ||  align=&quot;center&quot; | &lt;span style=&quot;display:none&quot;&gt;02319&lt;/span&gt; &lt;span style=&quot;visibility:hidden;&quot;&gt;0&lt;/span&gt;231,9 || align=&quot;center&quot; | 2687
|}

Als '''hochschmelzend''' bezeichnet man Metalle, deren Schmelzpunkt T&lt;sub&gt;E&lt;/sub&gt; über 2000K bzw. über dem Schmelzpunkt von [[Platin]] (T&lt;sub&gt;E&lt;/sub&gt;-Platin = 2045K = 1772°C) liegt.

Dazu gehören die Edelmetalle [[Ruthenium]], [[Rhodium]], [[Osmium]] und [[Iridium]] und Metalle der Gruppen IVA ([[Zirkonium]], [[Hafnium]]), VA ([[Vanadium]], [[Niob]], [[Tantal]]), VIA ([[Chrom]], [[Molybdän]], [[Wolfram]]) und VIIA ([[Technetium]], [[Rhenium]]).

=== Wärmeleiteigenschaften ===
Die für die Wärmeleitung relevanten Eigenschaften wie [[Dichte]], [[Wärmekapazität]], [[Wärmeleitfähigkeit]] und [[Temperaturleitfähigkeit]] variieren stark. So hat etwa Silber mit 427 W/(m K) eine ca. 20-fach höhere Wärmeleitfähigkeit als Mangan, siehe [[Temperaturleitfähigkeit|Liste mit Werten]].

== Legierungen ==
Die Verbindungen oder auch [[Lösung (Chemie)|Lösungen]] von verschiedenen Metallen miteinander oder ineinander heißen [[Legierung]]en. Diese haben oft völlig andere physikalische und chemische Eigenschaften als die reinen Metalle. Vor allem die Härte ist teilweise um Größenordnungen höher. Ebenso ist vielfach die [[Korrosion (Chemie)|Korrosionsbeständigkeit]] deutlich erhöht. Der Schmelzpunkt von Legierungen liegt dagegen unter dem der reinen Metalle; bei einer bestimmten Zusammensetzung wird der tiefste Schmelzpunkt erreicht, das [[Eutektikum]]. 

Reine Metalle werden praktisch nicht verwendet, außer bei der Herstellung elektrischer Leitungen, da reine Metalle die größte Leitfähigkeit besitzen. Hier werden unlegierte Metalle verwendet, vor allem [[Kupfer]] und [[Aluminium]].

== Chemische Eigenschaften ==
In Verbindung mit Nichtmetallen treten die Metalle im Allgemeinen als [[Kation]]en auf, d.&amp;nbsp;h. die äußeren Elektronen werden vollständig an die Nichtmetallatome abgegeben und es bildet sich eine Ionenverbindung ([[Salze|Salz]]). In einem [[Ionengitter]] werden die Ionen nur durch [[Elektrostatische Kraft|elektrostatische Kräfte]] zusammengehalten.

Bei Verbindungen mit [[Übergangsmetall]]en und bei größeren [[Anion]]en (wie dem [[Sulfide|Sulfid-Ion]]) können alle Übergangsstufen zur Atombindung vorkommen.

Mit Nichtmetallen wie [[Wasserstoff]], [[Kohlenstoff]] und [[Stickstoff]] werden auch [[Einlagerungsmischkristall|Einlagerungsverbindungen]] gebildet, wobei sich die Nichtmetallatome in Lücken des Metallgitters befinden, ohne dieses wesentlich zu verändern. Diese Einlagerungsverbindungen behalten die typischen Metalleigenschaften wie die [[Elektrische Leitfähigkeit]].

Metallkationen, v.&amp;nbsp;a. die der Nebengruppenmetalle, bilden mit Basen ([[Wasser]], [[Ammoniak]], [[Halogenide]]n, [[Cyanide]]n u.&amp;nbsp;v.&amp;nbsp;a.) [[Komplexverbindung]]en, deren Stabilität nicht allein durch die elektrostatische Anziehung erklärt werden kann.

Metalle in höheren [[Oxidationszahl|Oxidationsstufen]] bilden auch [[Komplexanion]]en, z.&amp;nbsp;B. löst sich [[Chromtrioxid]] CrO&lt;sub&gt;3&lt;/sub&gt; in [[Kalilauge]] unter Bildung des [[Chromate|Chromat-Anions]] CrO&lt;sub&gt;4&lt;/sub&gt;&lt;sup&gt;2-&lt;/sup&gt;:
: CrO&lt;sub&gt;3&lt;/sub&gt; + 2 KOH → K&lt;sub&gt;2&lt;/sub&gt;CrO&lt;sub&gt;4&lt;/sub&gt; + H&lt;sub&gt;2&lt;/sub&gt;O

== Vorkommen ==
Der [[Erdkern]] besteht zum größten Teil aus [[Eisen]], da es das [[Kernphysik|kernphysikalisch]] stabilste Element ist. 

In der [[Erdkruste]] dagegen überwiegen die Nichtmetalle, relativ häufige Metalle sind [[Aluminium]], [[Eisen]], [[Mangan]], [[Titan (Element)|Titan]], [[Calcium]], [[Magnesium]], [[Natrium]] und [[Kalium]]. Viele seltene Metalle treten aber in ihren Abbaustätten stark angereichert auf.
[[Gestein]]e, die klassische [[Werkmetall]]e in abbauwürdigen Konzentrationen enthalten, werden [[Erz]]e genannt. Zu den wichtigsten Erzen gehören:

* [[Oxide]]
* [[Sulfide]]
* [[Carbonate]]

Andere Metallverbindungen wie [[Kochsalz]] oder [[Kalziumkarbonat|Kalk]] werden dagegen nicht als Erze bezeichnet.

Manche Edelmetalle, v.&amp;nbsp;a. [[Gold]], kommen auch [[gediegen]], d.&amp;nbsp;h. in reiner Form und nicht als Verbindung/Erz vor.

== Verwendung ==
Viele Metalle sind wichtige Werkstoffe. Unsere moderne Welt wäre ohne Metalle unmöglich. Nicht ohne Grund werden Phasen der Menschheitsentwicklung nach den verwendeten Werkstoffen als [[Steinzeit]], [[Bronzezeit]], [[Eisenzeit]] bezeichnet.

Die folgende Liste enthält die wichtigsten Metalle und [[Legierung]]sbestandteile, keine Verbindungen.

* [[Aluminium]]: bedeutendstes Leichtmetall
* [[Beryllium]]: Legierungen, vor allem mit Kupfer und Aluminium; Waffentechnik
* [[Bismut]]: Legierungen
* [[Blei]]: Legierungen, [[Bleiakkumulator]], [[Lot (Metall)|Lote]], Korrosionsschutz, Gewicht
* [[Cadmium]]: Bestandteil von [[Akkumulator]]en
* [[Chrom]]: Legierungsbestandteil (Chrom-Vanadium-Stahl, Chrom-Nickel-Stahl), Überzugsmetall
* [[Eisen]]: wichtigstes Werkmetall ([[Gusseisen]], [[Stahl]]), viele Legierungen
* [[Gallium]]: [[Halbleiter]]
* [[Gold]]: Schmuckmetall, [[Blattgold]], Elektrotechnik, Wertanlage, Währungsabsicherung
* [[Indium]]: [[Halbleiter]], [[Indiumdichtung]]
* [[Iridium]]: Elektroden, Zündkerzen, Kugelschreiberminen (Kugeln)
* [[Kalium]]: legiert mit Natrium als [[Kühlmittel]] in [[Kernreaktor]]en
* [[Cobalt]]: Magnete
* [[Kupfer]]: Elektrotechnik (zweithöchste Leitfähigkeit nach Silber), Bronze, Messing
* [[Magnesium]]: für besonders leichte Werkstücke mit nicht allzuhohen Ansprüchen an die Festigkeit; Einweg-[[Blitzbirne]]n bzw. [[Blitzlichtpulver]]
* [[Mangan]]: Legierungsbestandteil (Manganstahl)
* [[Molybdän]]: Legierungsbestandteil (Molybdän-Stahl) zur Erhöhung der Warmfestigkeit
* [[Natrium]]: legiert mit Kalium als [[Kühlmittel]] in [[Kernreaktor]]en
* [[Nickel]]: Legierungen (Nickel-Eisen, Nickel-Chrom, Nickel-Kupfer etc.), Legierungsbestandteil (Chrom-Vanadium-Stahl, Chrom-Nickel-Stahl), Magnete
* [[Osmium]]: legiert mit Wolfram in [[Glühlampe]]n
* [[Palladium]]: [[Katalyse]], Wasserstoffspeicherung
* [[Platin]]: [[Schmuck]]metall, [[Katalyse]], wertvollstes Metall
* [[Quecksilber]]: [[Thermometer]]
* [[Rhodium]]: Schmuckmetall
* [[Ruthenium]]: Katalysator, Erhöhung des Härtegrades von Platin und Palladium
* [[Silber]]: Schmuckmetall, [[Fotografie]]
* [[Tantal]]: [[Kondensator (Elektrotechnik)|Kondensator]]en
* [[Titan (Element)|Titan]]: für Leichtbauweise ohne Rücksicht auf die Kosten, Schmuck
* [[Uran]]: Kernreaktoren, Radioaktivität, [[Geschoss]]e
* [[Vanadium]]: Legierungsbestandteil (Chrom-Vanadium-Stahl) für wärmfeste Stähle, Katalysator zur Synthese von Schwefelsäure (Vanadium-V-Oxid)
* [[Wolfram]]: [[Glühlampe]]n (höchster Schmelzpunkt aller Metalle), Spezialstähle
* [[Zink]]: Legierungsbestandteil (Messing), Zinkdruckgussteile ([[Zamak-Legierung]]), Verzinkung von Stahlteilen ([[Feuerverzinken]], Bandverzinken..)
* [[Zinn]]: Legierungsbestandteil (Bronze), [[Lot (Metall)|Lote]] (Lötzinn), [[Weißblech]], Zinnfiguren
* [[Zirkonium]]: [[Lambdasonde]] im Auto (Messung des Sauerstoffgehalts im Abgas)

== Metall als zivilisatorisches Entwicklungsmerkmal ==
Anhand der Nutzungs- und Verarbeitungsweisen von Metallen werden wichtige Epochen der Menscheitsgeschichte unterschieden.

Im Allgemeinen sind dies:
* [[Kupfersteinzeit]]
* [[Bronzezeit]]
* [[Eisenzeit]]

== Metalle in der Astronomie ==
In der [[Astronomie]] bezeichnet '''Metall''' jedes chemische Element mit einer [[Ordnungszahl]] höher als [[Helium]]. Diese Unterscheidung ist sinnvoll, da [[Wasserstoff]] und Helium zusammen mit einigen Spuren von [[Lithium]] die einzigen Elemente sind, welche im [[Universum]] durch den [[Urknall]] entstanden sind. Alle weiteren Elemente entstanden später, zum Beispiel in Sternen durch [[Kernfusion]] oder durch [[Supernova]]e. Die [[Metallizität]] von Objekten des [[Weltraum]]s kann daher als [[Indikator]] für seine stellare Aktivität aufgefasst werden.

== Metall in der Chinesischen Philosophie ==

'''Metall''' bezeichnet ein Element der traditionellen [[Fünf-Elemente-Lehre]].

==Heraldik==
Als Metalle werden in der Heraldik die [[Tinktur]]en (Wappenfarben) [[Gold]] und [[Silber]] bezeichnet. Ersatz bei [[Wappenmalerei]]en ist für Gold die Farbe [[Gelb]] und für Silber die Farbe [[Weiß]].

== Weblinks ==
*Animationen der Atome von Metallen und Nichtmetallen: http://www.physik.rwth-aachen.de/~harm/aixphysik/atom/Periodic/index.html

== Siehe auch ==
{{Wiktionary|Metall}}

* [[Metallurgie]]
* [[Metallgitter]] – [[Metallbindung]]
* [[Halbmetall]] – [[Nichtmetall]]
* [[Periodensystem]]
* [[Festkörper]]

{{Navigationsleiste Serien (Periodensystem)}}

[[Kategorie:Metall| ]]
[[Kategorie:Metallverarbeitung]]

[[ar:فلز]]
[[bg:Метал]]
[[bs:Metal (hemija)]]
[[ca:Metall]]
[[chr:ᎠᎾᎦᎵᏍᎩ ᎦᏂᏱᏍᎩ]]
[[cs:Kov]]
[[cy:Metel]]
[[da:Metal]]
[[el:Μέταλλα]]
[[en:Metal]]
[[eo:Metalo (fiziko)]]
[[es:Metal]]
[[et:Metallid]]
[[fa:فلز]]
[[fi:Metalli]]
[[fr:Métal]]
[[gd:Meatailt]]
[[he:מתכת]]
[[hr:Kovine]]
[[hu:Fémek]]
[[id:Logam]]
[[is:Málmur]]
[[it:Metallo]]
[[ja:金属]]
[[jbo:jinme]]
[[ko:금속]]
[[ku:Lajwerd]]
[[la:Metallum]]
[[lb:Metall]]
[[lmo:Metàj]]
[[lt:Metalai]]
[[lv:Metāls]]
[[mk:Метал]]
[[ms:Logam]]
[[nds:Metall]]
[[nl:Metaal]]
[[nn:Metall]]
[[no:Metall]]
[[pl:Metale (chemia)]]
[[pt:Metal]]
[[qu:Q'illay]]
[[ro:Metal]]
[[ru:Металлы]]
[[sh:Metal (hemija)]]
[[simple:Metal]]
[[sk:Kov]]
[[sl:Kovina]]
[[sr:Метал (хемија)]]
[[sv:Metall]]
[[ta:உலோகம்]]
[[th:โลหะ]]
[[tl:Metal]]
[[tr:Metal (kimya)]]
[[ug:مېتلا]]
[[uk:Метали]]
[[vi:Kim loại]]
[[yi:אייזן]]
[[zh:金属]]
[[zh-yue:金屬]]
</textarea><div class="mw-templatesUsedExplanation"><p>Folgende <a href="/wiki/Hilfe:Vorlagen" title="Hilfe:Vorlagen">Vorlagen</a> werden von diesem Artikel verwendet:
</p></div><ul><li><a href="/wiki/Vorlage:Bausteindesign1" title="Vorlage:Bausteindesign1">Vorlage:Bausteindesign1</a> (schreibgeschützt)</li><li><a href="/wiki/Vorlage:Dieser_Artikel" title="Vorlage:Dieser Artikel">Vorlage:Dieser Artikel</a> (schreibgeschützt)</li><li><a href="/wiki/Vorlage:Navigationsleiste" title="Vorlage:Navigationsleiste">Vorlage:Navigationsleiste</a> (schreibgeschützt)</li><li><a href="/wiki/Vorlage:Navigationsleiste_Serien_%28Periodensystem%29" title="Vorlage:Navigationsleiste Serien (Periodensystem)">Vorlage:Navigationsleiste Serien (Periodensystem)</a> </li><li><a href="/wiki/Vorlage:Wiktionary" title="Vorlage:Wiktionary">Vorlage:Wiktionary</a> (schreibgeschützt für unangemeldete und neue Benutzer)</li></ul>
<p>Zurück zur Seite <a href="/wiki/Hauptseite" title="Hauptseite">Hauptseite</a>.</p>
<div class="printfooter">
Von „<a href="http://de.wikipedia.org/wiki/Metall">http://de.wikipedia.org/wiki/Metall</a>“</div>
						<!-- end content -->
			<div class="visualClear"></div>
		</div>
	</div>
		</div>
		<div id="column-one">
	<div id="p-cactions" class="portlet">
		<h5>Diese Seite</h5>
		<div class="pBody">
			<ul>
					 <li id="ca-nstab-main" class="selected"><a href="/wiki/Metall" title="Seiteninhalt anzeigen [c]" accesskey="c">Artikel</a></li>
					 <li id="ca-talk"><a href="/wiki/Diskussion:Metall" title="Diskussion zum Seiteninhalt [t]" accesskey="t">Diskussion</a></li>
					 <li id="ca-viewsource" class="selected"><a href="/w/index.php?title=Metall&amp;action=edit" title="Diese Seite ist geschützt. Der Quelltext kann angesehen werden. [e]" accesskey="e">Quelltext betrachten</a></li>
					 <li id="ca-history"><a href="/w/index.php?title=Metall&amp;action=history" title="Frühere Versionen dieser Seite [h]" accesskey="h">Versionen/Autoren</a></li>
				</ul>
		</div>
	</div>
	<div class="portlet" id="p-personal">
		<h5>Persönliche Werkzeuge</h5>
		<div class="pBody">
			<ul>
				<li id="pt-login"><a href="/w/index.php?title=Spezial:Anmelden&amp;returnto=Metall" title="Sich einzuloggen wird zwar gerne gesehen, ist aber keine Pflicht. [o]" accesskey="o">Anmelden</a></li>
			</ul>
		</div>
	</div>
	<div class="portlet" id="p-logo">
		<a style="background-image: url(http://upload.wikimedia.org/wikipedia/de/b/bc/Wiki.png);" href="/wiki/Hauptseite" title="Hauptseite anzeigen [z]" accesskey="z"></a>
	</div>
	<script type="text/javascript"> if (window.isMSIE55) fixalpha(); </script>
		<div class='portlet' id='p-navigation'>
		<h5>Navigation</h5>
		<div class='pBody'>
			<ul>
				<li id="n-mainpage"><a href="/wiki/Hauptseite" title="Hauptseite anzeigen [z]" accesskey="z">Hauptseite</a></li>
				<li id="n-aboutsite"><a href="/wiki/Wikipedia:%C3%9Cber_Wikipedia">Über Wikipedia</a></li>
				<li id="n-topics"><a href="/wiki/Portal:Wikipedia_nach_Themen">Themenportale</a></li>
				<li id="n-alphindex"><a href="/wiki/Spezial:Alle_Seiten">Von A bis Z</a></li>
				<li id="n-randompage"><a href="/wiki/Spezial:Zuf%C3%A4llige_Seite" title="Zufällige Seite [x]" accesskey="x">Zufälliger Artikel</a></li>
			</ul>
		</div>
	</div>
		<div class='portlet' id='p-Mitmachen'>
		<h5>Mitmachen</h5>
		<div class='pBody'>
			<ul>
				<li id="n-help"><a href="/wiki/Wikipedia:Hilfe" title="Hilfeseite anzeigen">Hilfe</a></li>
				<li id="n-portal"><a href="/wiki/Wikipedia:Autorenportal" title="Über das Portal, was Sie tun können, wo was zu finden ist">Autorenportal</a></li>
				<li id="n-recentchanges"><a href="/wiki/Spezial:Letzte_%C3%84nderungen" title="Liste der letzten Änderungen in Wikipedia. [r]" accesskey="r">Letzte Änderungen</a></li>
				<li id="n-sitesupport"><a href="http://wikimediafoundation.org/wiki/Spenden" title="Unterstützen Sie uns">Spenden</a></li>
			</ul>
		</div>
	</div>
		<div id="p-search" class="portlet">
		<h5><label for="searchInput">Suche</label></h5>
		<div id="searchBody" class="pBody">
			<form action="/wiki/Spezial:Suche" id="searchform"><div>
				<input id="searchInput" name="search" type="text" title="Durchsuche die Wikipedia [f]" accesskey="f" value="" />
				<input type='submit' name="go" class="searchButton" id="searchGoButton"	value="Artikel" />&nbsp;
				<input type='submit' name="fulltext" class="searchButton" id="mw-searchButton" value="Volltext" />
			</div></form>
		</div>
	</div>
	<div class="portlet" id="p-tb">
		<h5>Werkzeuge</h5>
		<div class="pBody">
			<ul>
				<li id="t-whatlinkshere"><a href="/wiki/Spezial:Verweisliste/Metall" title="Liste aller Seiten, die hierher zeigen [j]" accesskey="j">Links auf diese Seite</a></li>
				<li id="t-recentchangeslinked"><a href="/wiki/Spezial:%C3%84nderungen_an_verlinkten_Seiten/Metall" title="Letzte Änderungen an Seiten, die von hier verlinkt sind [k]" accesskey="k">Änderungen an verlinkten Seiten</a></li>
<li id="t-upload"><a href="/wiki/Spezial:Hochladen" title="Dateien hochladen [u]" accesskey="u">Hochladen</a></li>
<li id="t-specialpages"><a href="/wiki/Spezial:Spezialseiten" title="Liste aller Spezialseiten [q]" accesskey="q">Spezialseiten</a></li>
			</ul>
		</div>
	</div>
		</div><!-- end of the left (by default at least) column -->
			<div class="visualClear"></div>
			<div id="footer">
				<div id="f-poweredbyico"><a href="http://www.mediawiki.org/"><img src="/skins-1.5/common/images/poweredby_mediawiki_88x31.png" alt="Powered by MediaWiki" /></a></div>
				<div id="f-copyrightico"><a href="http://wikimediafoundation.org/"><img src="/images/wikimedia-button.png" border="0" alt="Wikimedia Foundation"/></a></div>
			<ul id="f-list">
				<li id="privacy"><a href="/wiki/Wikipedia:Datenschutz" title="Wikipedia:Datenschutz">Datenschutz</a></li>
				<li id="about"><a href="/wiki/Wikipedia:%C3%9Cber_Wikipedia" title="Wikipedia:Über Wikipedia">Über Wikipedia</a></li>
				<li id="disclaimer"><a href="/wiki/Wikipedia:Impressum" title="Wikipedia:Impressum">Impressum</a></li>
			</ul>
		</div>
		
	
		<script type="text/javascript">if (window.runOnloadHook) runOnloadHook();</script>
</div>
<!-- Served by srv148 in 0.092 secs. --></body></html>
