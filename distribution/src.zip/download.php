<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de" dir="ltr">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="robots" content="noindex,nofollow" />
		<meta name="keywords" content="Wetter,Wetter,Entsperrwünsche,Geschützte Seiten,MediaWiki-Namensraum,Wetter" />
		<link rel="shortcut icon" href="/favicon.ico" />
		<link rel="search" type="application/opensearchdescription+xml" href="/w/opensearch_desc.php" title="Wikipedia (Deutsch)" />
		<link rel="copyright" href="http://www.gnu.org/copyleft/fdl.html" />
		<title>Quelltext betrachten - Wikipedia</title>
		<style type="text/css" media="screen,projection">/*<![CDATA[*/ @import "/skins-1.5/monobook/main.css?61"; /*]]>*/</style>
		<link rel="stylesheet" type="text/css" media="print" href="/skins-1.5/common/commonPrint.css?61" />
		<link rel="stylesheet" type="text/css" media="handheld" href="/skins-1.5/monobook/handheld.css?61" />
		<!--[if lt IE 5.5000]><style type="text/css">@import "/skins-1.5/monobook/IE50Fixes.css?61";</style><![endif]-->
		<!--[if IE 5.5000]><style type="text/css">@import "/skins-1.5/monobook/IE55Fixes.css?61";</style><![endif]-->
		<!--[if IE 6]><style type="text/css">@import "/skins-1.5/monobook/IE60Fixes.css?61";</style><![endif]-->
		<!--[if IE 7]><style type="text/css">@import "/skins-1.5/monobook/IE70Fixes.css?61";</style><![endif]-->
		<!--[if lt IE 7]><script type="text/javascript" src="/skins-1.5/common/IEFixes.js?61"></script>
		<meta http-equiv="imagetoolbar" content="no" /><![endif]-->
		
		<script type= "text/javascript">/*<![CDATA[*/
var skin = "monobook";
var stylepath = "/skins-1.5";
var wgArticlePath = "/wiki/$1";
var wgScriptPath = "/w";
var wgServer = "http://de.wikipedia.org";
var wgCanonicalNamespace = "";
var wgCanonicalSpecialPageName = false;
var wgNamespaceNumber = 0;
var wgPageName = "Wetter";
var wgTitle = "Wetter";
var wgArticleId = "7927";
var wgIsArticle = false;
var wgUserName = null;
var wgUserGroups = null;
var wgUserLanguage = "de";
var wgContentLanguage = "de";
var wgBreakFrames = false;
var wgCurRevisionId = "30001940";
/*]]>*/</script>
                
		<script type="text/javascript" src="/skins-1.5/common/wikibits.js?61"><!-- wikibits js --></script>
		<script type="text/javascript" src="/w/index.php?title=-&amp;action=raw&amp;gen=js"><!-- site js --></script>
		<style type="text/css">/*<![CDATA[*/
@import "/w/index.php?title=MediaWiki:Common.css&usemsgcache=yes&action=raw&ctype=text/css&smaxage=2678400";
@import "/w/index.php?title=MediaWiki:Monobook.css&usemsgcache=yes&action=raw&ctype=text/css&smaxage=2678400";
@import "/w/index.php?title=-&action=raw&gen=css&maxage=2678400";
/*]]>*/</style>
		<!-- Head Scripts -->
		<script type="text/javascript" src="/skins-1.5/common/ajax.js?61"></script>
	</head>
<body  class="mediawiki ns-0 ltr page-Wetter">
	<div id="globalWrapper">
		<div id="column-content">
	<div id="content">
		<a name="top" id="top"></a>
				<h1 class="firstHeading">Quelltext betrachten</h1>
		<div id="bodyContent">
			<h3 id="siteSub">aus Wikipedia, der freien Enzyklopädie</h3>
			<div id="contentSub">für <a href="/wiki/Wetter" title="Wetter">Wetter</a></div>
									<div id="jump-to-nav">Wechseln zu: <a href="#column-one">Navigation</a>, <a href="#searchInput">Suche</a></div>			<!-- start content -->
			<p>Diese Seite ist für das Bearbeiten gesperrt. Gründe für den Seitenschutz finden sich im <a href="http://de.wikipedia.org/w/index.php?title=Spezial:Log&amp;type=protect&amp;page=Wetter" class="external text" title="http://de.wikipedia.org/w/index.php?title=Spezial:Log&amp;type=protect&amp;page=Wetter" rel="nofollow">Seitenschutz-Logbuch</a>, auf der <a href="/wiki/Diskussion:Wetter" title="Diskussion:Wetter">Diskussionsseite</a> oder in den <a href="/wiki/Wikipedia:Gesch%C3%BCtzte_Seiten" title="Wikipedia:Geschützte Seiten">Regeln für geschützte Seiten</a>. Seiten im <a href="/wiki/Hilfe:MediaWiki-Namensraum" title="Hilfe:MediaWiki-Namensraum">MediaWiki-Namensraum</a> sind grundsätzlich nur von Administratoren bearbeitbar.
</p><p>Du kannst Änderungswünsche für diese Seite auf der zugehörigen Diskussionsseite vorschlagen. Wenn du meinst, dass der Bearbeitungsschutz aufgehoben werden sollte, kannst du dies auf <a href="/wiki/Wikipedia:Entsperrw%C3%BCnsche" title="Wikipedia:Entsperrwünsche">Wikipedia:Entsperrwünsche</a> erklären.
</p><p>Du kannst jedoch den Quelltext dieser Seite betrachten und kopieren:
</p>
<textarea name='wpTextbox1' id='wpTextbox1' cols='80' rows='25' readonly='readonly'>{{Dieser Artikel|behandelt das meteorologische Wetter, weitere Bedeutungen unter [[Wetter (Begriffsklärung)]]}}
Als '''Wetter''' (v. [[althochdeutsch|althochdt.]]: ''wetar'' = Wind, Wehen) bezeichnet man den spürbaren, kurzfristigen Zustand der [[Erdatmosphäre|Atmosphäre]] (auch: messbarer Zustand der Trophosphäre) an einem bestimmten Ort der [[Erdoberfläche]], der unter anderem als [[Sonnenschein]], [[Bewölkung]], [[Regen]], [[Wind]], [[Hitze]] und [[Kälte]] in Erscheinung tritt.

[[Bild:Aprilwetter.jpg|thumb|300px|„Aprilwetter“]]
Die [[Meteorologie]] klassifiziert das ''örtliche Wetter'' einer bestimmten Zeit anhand der verschiedenen [[Phänomen]]e in der [[Troposphäre]], dem unteren Teil der Atmosphäre. Den Verlauf des Wetters bestimmt die von [[Sonnenstrahlung]] und  regionaler [[Energiebilanz]] geprägte atmosphärische [[Atmosphärische Zirkulation|Zirkulation]].

Im strengen physikalischen Sinne ist das ''Wetter'' ein bestimmter Zustand an einem bestimmten Ort auf der Erdoberfläche, den die [[Messgröße|Größen]] [[Gasdruck]], [[Gasdichte]] und [[Gasgemisch]] vollständig ''determinieren''. Ein „''Wetter''“ kann in einem Labor ebenso stattfinden wie über einem Kontinent, ohne dass die Definition von „Wetter“ verändert wird.

== Begriffliche Abgrenzung ==
Das Wetter charakterisiert den Zustand der Atmosphäre an einem bestimmten Ort und zu einem bestimmten Zeitpunkt. Kennzeichnend sind die meteorologischen Elemente Strahlung, Luftdruck, Lufttemperatur, Luftfeuchte und Wind, sowie die daraus ableitbaren Elemente Bewölkung, Niederschlag, Sichtweite etc. Das Wetter ist das augenblickliche Bild eines Vorganges (Wettergeschehen), das sich hauptsächlich in der [[Troposphäre]] abspielt. Es kann sich – im Gegensatz zur Wetterlage und Witterung – mehrmals täglich ändern.
* ''[[Wetterlage]]'': Zustand der Atmosphäre in einem größeren [[Gebiet]] und zu einem bestimmten Zeitpunkt, geprägt von  Hoch- und [[Tiefdruckgebiet]]en. Das  ändert sich  von Tag zu Tag mehr oder weniger stark.
* ''[[Witterung]]'': Das Wetter an einem Ort über einen Zeitraum mehrerer Tage oder Wochen betrachtet.
* ''[[Klima]]'': Der für eine Region (bzw. eine größere [[Klimazone]]) typische [[jährlich]]e Ablauf der Witterung, zum Beispiel mildes, raues oder winterfeuchtes Klima. Detailliert beschreiben das [[Monatskurve]]n von Temperatur und Niederschlägen, die sich aus Wetterstatistiken vieler Jahre bis Jahrzehnte ergeben. Wichtigste Klimaparameter sind unter anderem die Solarkonstante, Strahlungsbilanz, fühlbare und latente Wärmeströme, Wärmeflüsse der Ozeane, allgemeine Zirkulation der Atmosphäre, sowie große Vulkanausbrüche.
* ''[[Klimaänderung]]'': eine langfristige, tiefgreifende Veränderung in größeren Gebieten oder Klimazonen. So wird sich die globale Erwärmung in [[Sibirien]] und in der [[Sahelzone]] stark auswirken (Auftauen von [[Permafrost]]-Böden, die zunehmende Trockenheit), in Mitteleuropa hingegen kaum.
* Ein  ''[[Wetterumschwung]]'' ist eine – verhältnismäßig rasche und plötzliche – Änderung der Wetterlage in einem bestimmten Gebiet und zu einem bestimmten Zeitpunkt.
Das Wetter ist ein kurzzeitiges Zusammenwirken von Temperatur, Niederschlag, Bewölkung, Wind und Luftdruck.

== Wetter in Meteorologie und Umgangssprache ==
[[Bild:Tallinn-hafen.jpg|250px|right|thumb|Himmel über dem Hafen von Tallinn (Estland) am 29. Juni 2005 um 15:00&amp;nbsp;Uhr]]
Die [[Meteorologe]]n erfassen die einzelnen Elemente des Wetters mit [[Messgerät]]en und die [[Wetterlage|Wetterlage]] mit Begriffen wie [[stabil]] oder wechselhaft, [[heiter]] oder [[wolken]]frei, 3/8 bewölkt, bedeckt oder trüb, [[Nebel]]tendenz, regnerisch, [[Niederschlag|Regenschauer]] oder stürmisch.

Umgangssprachlich sind sehr unscharfe Begriffe üblich:
* &quot;Gutes Wetter&quot; bedeutet meist [[Sonnenschein]] – ist zum Beispiel für einen [[Landwirt]], dessen Saat spriessen soll, schlecht.
* &quot;Kaltes Wetter&quot; heißt für [[Mitteleuropa|Mitteleuropäer]] – je nach [[Jahreszeit]] – Temperaturen unter −5&amp;nbsp;°C oder im Hochsommer unter etwa 15&amp;nbsp;°C.
* bei &quot;heißem Wetter&quot; schwanken die Vorstellungen weniger (etwa ab 30&amp;nbsp;°C), während &quot;warm&quot; wieder sehr relativ ist.
* Was &quot;[[Sturmwarnung|stürmisches]]&quot; Wetter ist, hängt oft vom vorherrschenden [[Verkehr]] und vom Wohnort ab, der Richtung seiner Straßen und allgemein vom [[Gelände]], auch von einer gerade ausgeübten [[Sportart]].
* &quot;[[Aprilwetter]]&quot; steht für  &quot;launisches&quot;, wechselhaftes Wetter mit rascher Abfolge von Sonne, Wolken und [[Schauer]]n, während
* eine &quot;[[ruhig]]e Wetterlage&quot; für Wissenschaft und Allgemeinheit dasselbe bedeutet: eine tagelang [[Stabilität|stabile]] Wetterlage (&quot;[[Hochdruckgebiet|Hochdrucklage]]&quot;) mit wenig oder nur gleichmäßigem [[Wind]].
* [[Inversionswetterlage]] ist häufig die Ursache für [[Smog]] in Großstädten. Dort liegt eine kalte Luftschicht unter einer wärmeren und verhindert so eine Durchmischung (stabile [[Atmosphärenschichtung]]. In der kälteren Luftschicht sammeln sich Staub, Ruß und Abgase der Stadt und sorgen für Smog).&lt;br /&gt;Feuerwehren müssen bei solchen Wetterlagen besonders vorsichtig sein: giftige Verbrennungsgase können nicht nach oben entweichen (werden ebenfalls am Boden gehalten).

== Elemente des Wetters und deren Messung ==
Die [[Meteorologie]] untersucht das Wetter, quantifiziert seine einzelnen Elemente und charakterisiert sie durch eine Reihe fundamentaler sowie spezieller Größen (Wetterelemente):
* [[Temperatur|Lufttemperatur]]
** zeitlicher Temperaturverlauf
** vertikaler [[Temperaturgradient]] (durchschnittlich −0,6&amp;nbsp;°C pro 100&amp;nbsp;m)
* [[Luftfeuchtigkeit]] und [[Taupunkt]]
** Wolkenbasis und [[Kondensation]]sniveau
* [[Luftdruck]] und Drucktendenz
** [[Hochdruckgebiet|Hoch]]- und [[Tiefdruckgebiet]]e
* [[Winde und Windsysteme]]
** [[Windrichtung]] bzw. [[Hauptwindrichtung]] und [[Windstärke]]
** regionale und lokale/zyklische [[Wind]]e ([[Talwind|Tal]]-, [[Bergwind|Berg]]-, [[Seewind|See-]], [[Aufwind|Auf]] und [[Abwind]]e, [[Föhn]] usw.)
*** [[Beaufort-Skala]]
*** [[Fujita-Tornado-Skala]]
** [[Passat (Windsystem)|Passate]], [[Monsun]]
* [[atmosphärische Dynamik]] und [[Energiebilanz]]
** [[Turbulenz]], [[Szintillation]] usw.
* [[Niederschlag|Niederschlagsarten]]
** [[Regen]] und [[Starkregen]]
** [[Nieselregen]], [[Graupeln]]
** [[Hagel]] und seine [[Korngröße]]n
** [[Schnee]], [[Schneeregen]]
* [[Niederschlagsmenge]], [[Wasseräquivalent]]
* [[Bewölkung]] (meist in Achteln oder Zehnteln)
** [[Wolke|Wolkenart]] (Cumulus, Cumulonimbus, Alto-, Cirrostratus, Cirren usw.)
* [[Sichtweite]] (siehe [[Flughafen]] oder [[Seewetterdienst]]e)
** vertikale Sicht, [[Bodensicht]], [[Horizontalsicht]]
** [[Dunst]] und [[Nebel]]
* Besondere Erscheinungen
** [[Gewitter]], [[Unwetter]], [[Schneesturm]]
** [[Fata Morgana]], [[Halo (Lichteffekt)|Halo]], [[Nebensonne]]
** [[Regenbogen]], [[Nebel]]reissen, [[Wetterleuchten]] (siehe [[atmosphärische Optik]])
** [[Wirbelsturm]], [[Hurrikan]], [[Tornado]], [[Zyklone]]
** [[Sandsturm]], [[Calima]]

Diese Grundgrößen werden in [[Wetterstation]]en, auf [[Schiff]]en und [[Leuchtturm|Leuchttürmen]], mit [[Wetterballon]]s oder [[Radiosonde]]n, mit [[Flugzeug]]en und [[Boje|Bojen]] gemessen. [[Erdsatellit]]en betrachten die [[Troposphäre]] aus dem Weltall und geben besonders viele Informationen zur Bewölkung, [[Wasserwelle|Wellenhöhen]] auf den Meeren und Luftströmungen.

[[Bild:WartauBurgruine.jpg|300px|right|thumb|[[Stimmung]]sbild von [[Wartau]], [[Schweiz]]]]

Wettermessgeräte sind Messinstrumente die der Messung der Wetterelemente dienen.

== Faktoren des Wetters und deren Dynamik ==
Das Wetter findet fast ausschließlich in den unteren 10 Kilometern der irdischen [[Luft]]hülle statt, der [[Troposphäre]]. Nur hier gibt es merkliche [[Bewölkung]], weil der [[Wasserdampf]] als entscheidender Faktor nicht über die [[Tropopause]] (je nach Ort und Jahreszeit etwa 8 bis 15&amp;nbsp;km hoch) hinaus gelangen kann.

Überwiegend prägten die unteren 2&amp;nbsp;km der [[Peplosphäre]] das Wetter. Hier findet sich oft Dunst durch Anreicherung von [[Aerosol]]en, und die nächtliche [[Abkühlung]] durch Wärmestrahlung. Die [[Bodenreibung]] bremst den [[geostrophischer Wind| geostrophische Wind]], weshalb er mehr in Richtung zum tieferen Druck weht als in größerer Höhe.

Der primäre Motor des Wetters ist die Energieeinstrahlung der [[Sonne]] und die Abstrahlung (Licht und [[Infrarot]]) zu den Wolken bzw. in den [[Weltraum]]. Das  erfassen heute neben [[terrestrisch]]en Messungen auch großräumig [[Satellit (Raumfahrt)|Satelliten]] und Wetterschiffe, [[Radiosonde]]n und andere moderne Methoden gut.

Für den ''Verlauf'' des Wetters sind jedoch die [[Strömung]]s-Verhältnisse in der Atmosphäre entscheidend, die von ihrer wechselnden [[Feuchtigkeit]] und den globalen [[Windsystem]]en abhängen, ferner vom regionalen [[Albedo]] der Erdoberfläche, vom [[Gelände]] (insbesondere den [[Gebirge]]n, Küsten und Wüsten) und von starken [[lokal]]en Einflüssen (zyklische [[Aufwind|Winde]], Neigung und [[Bewuchs]] von [[Berghang| Berghängen]]. ..), und vom Widerstand gegen Winde, über den die Rauhheit der Oberfläche (Wälder, Wind[[schneise]]n, große [[Gebäude]] usw.) entscheidet.

Daher sind in Mitteleuropa nur dann ''lokal exakte Wetterprognosen'' möglich, wenn alle diese Einzelheiten einer [[Modellierung]] oder verlässlichen [[Erfahrung]] zugänglich sind. Letztere wissen auch [[Laie]]n zu nutzen - siehe die vielfach bewährten [[Bauernregel]]n mit &quot;wetterzeigenden&quot; Bergen ([[Wetterstein]], Wolkenstein, [[Mittagskogel]] usw.) oder typischen [[Wolke]]n-Formationen wie [[Schönwetter]]- und Schäfchenwolken, [[Nebel]]reißen, [[Regenwolke|Regen]]- und Fetzenwolken, Zirren, [[Föhnmauer]]n usw.

== Vorhersage des Wetters ==
''Hauptartikel: '''[[Wettervorhersage]]'''''

Ausgehend vom durch großflächige Messungen erfassten Wetter und damit dem Zustand der Atmosphäre werden in der Meteorologie [[Wettermodell]]e genutzt, um die weitere Entwicklung des Wetters zu prognostizieren. Davon abgesehen ist es jedoch auch möglich, auf lokaler Ebene und mit vergleichsweise wenig Hilfsmitteln gute Vorhersagen zu geben, wozu jedoch auch mehr oder weniger umfangreiche Kenntnisse notwendig sind.

== Geschichte des Wetters und der [[Wetterbeobachtung]] ==
''siehe'' [[Geschichte des Wetters und der Wetterbeobachtung]]

== Wetter als wirtschaftlicher Faktor ==
Für eine Reihe von Unternehmen hat das Wetter Auswirkungen auf die betrieblichen Erfolgsgrößen. Klassisches Beispiel dafür ist die [[Landwirtschaft]] und die [[Getränkeindustrie]], bei denen Wetter sich stark auf den Umsatz auswirken kann. Während bei der Landwirtschaft überwiegend die Erntemengen betroffen sind, schwankt bei den Abfüllern von [[Mineralwasser]] und [[Erfrischungsgetränk]]en der Absatz in Abhängigkeit zur Temperatur. Zu den weiteren Branchen, bei denen sich das Wetter stark auswirken kann, gehören die [[Baubranche]] sowie die [[Tourismus]]- und [[Freizeitindustrie]]. Für einige Unternehmen kann das [[Wetterrisiko]] so signifikant sein, dass es gezielt im [[Risikomanagement]] des Unternehmens beobachtet und beispielsweise über so genannte [[Wetterderivat]]e abgesichert wird.

=== anthropogener Niederschlag ===
Seit den fünziger Jahren gibt es Experimente mit dem Ziel das Wetter zu beeinflussen. So wird zum Beispiel [[Silberjodid]] mit Flugzeugen oder Raketen in Wolken ausgebracht um ein frühzeitiges abregnen der Wolke herbeizuführen. Vor der Eröffnungsfeier der Olympischen Spiele in China soll zum Beispiel Silberjodid ausgebracht worden sein um Regenwolken vor der Eröffnungsfeier abzuregnen. In der Landwirtschaft spielen eher die sogenannten [[Hagelflieger]] eine Rolle. Hier wird auch Silberjodid in Wolken versprüht um Hagel mit kleineren Körnern herbeizuführen und damit den Schaden gering zu Halten.
Der Nutzen der Methode ist höchst umstritten.

== Siehe auch ==
* [[Wetterkontrolle]]
* [[Wettervorhersage]]

== Literatur ==
''Für allgemein meteorologische Literatur siehe [[Meteorologie#Literatur|Meteorologie]].''
* J. Kachelmann, S. Schöpfer: ''Wie wird das Wetter?'' Rowohlt, Reinbek 2004. ISBN 3498063774
* J. Klage: ''Wetter macht Geschichte. Der Einfluß des Wetters auf den Lauf der Geschichte.'' FAZ-Buch, Frankfurt 2002. ISBN 3898430979
* H. Schirmer et al.: ''Wie funktioniert das? Wetter und Klima.'' Meyers Lexikonverlag, Mannheim/Wien/Zürich 1989. ISBN 3411023821

* Verena Burhenne, Monika Weyer, Rosa Rosinski (Hrsg.): ''Wetter: verhext, gedeutet, erforscht. Katalog zur gleichnamigen Wanderausstellung des Westfälischen Museumsamtes (LWL) in Zusammenarbeit mit dem Bauernhaus-Museum Bielefeld.'' Westfälisches Museumsamt, Münster ISBN 3-927204-64-1

== Weblinks ==
{{Wikinews|Portal:Wetter|Wetter}}
{{Wiktionary|Wetter}}
{{Commons|Category:Weather|Wetter}}
{{Wikiquote|Wetter}}
* [http://www.wolken-online.de Wolken und Ihre Wetterbedeutungen]
* [http://www.earthstation.de EarthStation.de] - Umfangreiche Datenbank für Umwelt- und Naturkatastrophen
* [http://www.121.nu/onetoone/vadret.aspx Wetter in Schweden und in Europa]
* [http://www.quarks.de/wetter/index.htm www.quarks.de/...] - Wissenschaftssendung Quarks &amp; Co: Das Wetter
* [http://www.top-wetter.de/themen/overview.htm Ein Wetterkurs]
* [http://www.fz-juelich.de/gs/meteo/ Die Wetter- und Klimastation des Forschungszentrums Jülich], die Teil des Messnetzes des [[Deutscher Wetterdienst|Deutschen Wetterdienstes]] ist, mit aktuellen [http://www.fz-juelich.de/gs/meteo/metmess1de/ Messwerten und der Wetterentwicklung der letzten 24 Stunden].
* [http://www.austriawetter.eu/index.php AustriaWetter]
* [http://www.meteo.sf.tv Meteo Schweiz - Das Wetter in der Schweiz]
* [http://www.gsf.de/flugs/neu/themen7.php Wetterextreme, Klimawandel und Klimaschutz] - Beiträge des FLUGS-
Fachinformationsdienstes am GSF - Forschungszentrum für Umwelt und Gesundheit
* [http://www.marcokaschuba.com Bilder, Videos und Informationen über's Wetter (Unwetter)]

* [http://demo.scalarvis.de/scalarvis@web/?user=wetter&amp;host=localhost&amp;port=1024&amp;lang=de&amp;pwd=wetter Wetterstation] in [[Burghausen]]
''Für Weblinks zu [[Wettervorhersage]]n und speziell [[Unwetter]]n sowie für [[Wetterkarte]]n und [[Wetterdienst]]leister siehe im jeweiligen Artikel.''

&lt;!-- Hinweis: Dieser Artikel hat das Wetter zum Thema und jeder Weblink sollte daher dem Leser beim Verständnis dessen helfen, was das Wetter ist. Dies ist nicht der Artikel Wettervorhersage und die Wikipedia ist auch ganz allgemein kein Verzeichnis für deren Anbieter. Da eine neutrale Auswahl zwischen diesen sowieso nicht getroffen werden kann, werden alle entsprechenden Weblinks entfernt. --Saperaud --&gt;

[[Kategorie:Meteorologie]]
[[Kategorie:Klimatologie]]

[[ar:طقس]]
[[be:Надвор'е]]
[[ca:Temps atmosfèric]]
[[cs:Počasí]]
[[da:Vejr]]
[[el:Καιρός]]
[[en:Weather]]
[[eo:Vetero]]
[[es:Tiempo atmosférico]]
[[et:Ilm]]
[[fi:Sää]]
[[fr:Temps (météorologie)]]
[[ga:Aimsir (meitéareolaíocht)]]
[[gl:Tempo atmosférico]]
[[he:מזג אוויר]]
[[hi:मौसम]]
[[id:Cuaca]]
[[ja:気象]]
[[ms:Cuaca]]
[[nl:Weer (meteorologie)]]
[[nn:Vêr]]
[[no:Vær (meteorologi)]]
[[pl:Pogoda]]
[[pt:Fenômeno climático]]
[[ru:Погода]]
[[simple:Weather]]
[[sk:Počasie]]
[[sl:Vreme]]
[[sv:Väder]]
[[tr:Hava (iklim)]]
[[uk:Погода]]
[[zh:天气]]
[[zh-yue:天氣]]
</textarea><div class="mw-templatesUsedExplanation"><p>Folgende <a href="/wiki/Hilfe:Vorlagen" title="Hilfe:Vorlagen">Vorlagen</a> werden von diesem Artikel verwendet:
</p></div><ul><li><a href="/wiki/Vorlage:Bausteindesign1" title="Vorlage:Bausteindesign1">Vorlage:Bausteindesign1</a> (schreibgeschützt)</li><li><a href="/wiki/Vorlage:Commons" title="Vorlage:Commons">Vorlage:Commons</a> (schreibgeschützt für unangemeldete und neue Benutzer)</li><li><a href="/wiki/Vorlage:Dieser_Artikel" title="Vorlage:Dieser Artikel">Vorlage:Dieser Artikel</a> (schreibgeschützt)</li><li><a href="/wiki/Vorlage:Wikinews" title="Vorlage:Wikinews">Vorlage:Wikinews</a> </li><li><a href="/wiki/Vorlage:Wikiquote" title="Vorlage:Wikiquote">Vorlage:Wikiquote</a> (schreibgeschützt)</li><li><a href="/wiki/Vorlage:Wiktionary" title="Vorlage:Wiktionary">Vorlage:Wiktionary</a> (schreibgeschützt für unangemeldete und neue Benutzer)</li></ul>
<p>Zurück zur Seite <a href="/wiki/Hauptseite" title="Hauptseite">Hauptseite</a>.</p>
<div class="printfooter">
Von „<a href="http://de.wikipedia.org/wiki/Wetter">http://de.wikipedia.org/wiki/Wetter</a>“</div>
						<!-- end content -->
			<div class="visualClear"></div>
		</div>
	</div>
		</div>
		<div id="column-one">
	<div id="p-cactions" class="portlet">
		<h5>Diese Seite</h5>
		<div class="pBody">
			<ul>
					 <li id="ca-nstab-main" class="selected"><a href="/wiki/Wetter" title="Seiteninhalt anzeigen [c]" accesskey="c">Artikel</a></li>
					 <li id="ca-talk"><a href="/wiki/Diskussion:Wetter" title="Diskussion zum Seiteninhalt [t]" accesskey="t">Diskussion</a></li>
					 <li id="ca-viewsource" class="selected"><a href="/w/index.php?title=Wetter&amp;action=edit" title="Diese Seite ist geschützt. Der Quelltext kann angesehen werden. [e]" accesskey="e">Quelltext betrachten</a></li>
					 <li id="ca-history"><a href="/w/index.php?title=Wetter&amp;action=history" title="Frühere Versionen dieser Seite [h]" accesskey="h">Versionen/Autoren</a></li>
				</ul>
		</div>
	</div>
	<div class="portlet" id="p-personal">
		<h5>Persönliche Werkzeuge</h5>
		<div class="pBody">
			<ul>
				<li id="pt-login"><a href="/w/index.php?title=Spezial:Anmelden&amp;returnto=Wetter" title="Sich einzuloggen wird zwar gerne gesehen, ist aber keine Pflicht. [o]" accesskey="o">Anmelden</a></li>
			</ul>
		</div>
	</div>
	<div class="portlet" id="p-logo">
		<a style="background-image: url(http://upload.wikimedia.org/wikipedia/de/b/bc/Wiki.png);" href="/wiki/Hauptseite" title="Hauptseite anzeigen [z]" accesskey="z"></a>
	</div>
	<script type="text/javascript"> if (window.isMSIE55) fixalpha(); </script>
		<div class='portlet' id='p-navigation'>
		<h5>Navigation</h5>
		<div class='pBody'>
			<ul>
				<li id="n-mainpage"><a href="/wiki/Hauptseite" title="Hauptseite anzeigen [z]" accesskey="z">Hauptseite</a></li>
				<li id="n-aboutsite"><a href="/wiki/Wikipedia:%C3%9Cber_Wikipedia">Über Wikipedia</a></li>
				<li id="n-topics"><a href="/wiki/Portal:Wikipedia_nach_Themen">Themenportale</a></li>
				<li id="n-alphindex"><a href="/wiki/Spezial:Alle_Seiten">Von A bis Z</a></li>
				<li id="n-randompage"><a href="/wiki/Spezial:Zuf%C3%A4llige_Seite" title="Zufällige Seite [x]" accesskey="x">Zufälliger Artikel</a></li>
			</ul>
		</div>
	</div>
		<div class='portlet' id='p-Mitmachen'>
		<h5>Mitmachen</h5>
		<div class='pBody'>
			<ul>
				<li id="n-help"><a href="/wiki/Wikipedia:Hilfe" title="Hilfeseite anzeigen">Hilfe</a></li>
				<li id="n-portal"><a href="/wiki/Wikipedia:Autorenportal" title="Über das Portal, was Sie tun können, wo was zu finden ist">Autorenportal</a></li>
				<li id="n-recentchanges"><a href="/wiki/Spezial:Letzte_%C3%84nderungen" title="Liste der letzten Änderungen in Wikipedia. [r]" accesskey="r">Letzte Änderungen</a></li>
				<li id="n-sitesupport"><a href="http://wikimediafoundation.org/wiki/Spenden" title="Unterstützen Sie uns">Spenden</a></li>
			</ul>
		</div>
	</div>
		<div id="p-search" class="portlet">
		<h5><label for="searchInput">Suche</label></h5>
		<div id="searchBody" class="pBody">
			<form action="/wiki/Spezial:Suche" id="searchform"><div>
				<input id="searchInput" name="search" type="text" title="Durchsuche die Wikipedia [f]" accesskey="f" value="" />
				<input type='submit' name="go" class="searchButton" id="searchGoButton"	value="Artikel" />&nbsp;
				<input type='submit' name="fulltext" class="searchButton" id="mw-searchButton" value="Volltext" />
			</div></form>
		</div>
	</div>
	<div class="portlet" id="p-tb">
		<h5>Werkzeuge</h5>
		<div class="pBody">
			<ul>
				<li id="t-whatlinkshere"><a href="/wiki/Spezial:Verweisliste/Wetter" title="Liste aller Seiten, die hierher zeigen [j]" accesskey="j">Links auf diese Seite</a></li>
				<li id="t-recentchangeslinked"><a href="/wiki/Spezial:%C3%84nderungen_an_verlinkten_Seiten/Wetter" title="Letzte Änderungen an Seiten, die von hier verlinkt sind [k]" accesskey="k">Änderungen an verlinkten Seiten</a></li>
<li id="t-upload"><a href="/wiki/Spezial:Hochladen" title="Dateien hochladen [u]" accesskey="u">Hochladen</a></li>
<li id="t-specialpages"><a href="/wiki/Spezial:Spezialseiten" title="Liste aller Spezialseiten [q]" accesskey="q">Spezialseiten</a></li>
			</ul>
		</div>
	</div>
		</div><!-- end of the left (by default at least) column -->
			<div class="visualClear"></div>
			<div id="footer">
				<div id="f-poweredbyico"><a href="http://www.mediawiki.org/"><img src="/skins-1.5/common/images/poweredby_mediawiki_88x31.png" alt="Powered by MediaWiki" /></a></div>
				<div id="f-copyrightico"><a href="http://wikimediafoundation.org/"><img src="/images/wikimedia-button.png" border="0" alt="Wikimedia Foundation"/></a></div>
			<ul id="f-list">
				<li id="privacy"><a href="/wiki/Wikipedia:Datenschutz" title="Wikipedia:Datenschutz">Datenschutz</a></li>
				<li id="about"><a href="/wiki/Wikipedia:%C3%9Cber_Wikipedia" title="Wikipedia:Über Wikipedia">Über Wikipedia</a></li>
				<li id="disclaimer"><a href="/wiki/Wikipedia:Impressum" title="Wikipedia:Impressum">Impressum</a></li>
			</ul>
		</div>
		
	
		<script type="text/javascript">if (window.runOnloadHook) runOnloadHook();</script>
</div>
<!-- Served by srv86 in 0.123 secs. --></body></html>
