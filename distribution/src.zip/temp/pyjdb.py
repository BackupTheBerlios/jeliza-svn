from modules.utilities import *

class DBSentence:
  subject = ""
  verb = ""
  object = ""
  prefix = ""
  suffix = ""
  feeling = ""
  category = ""
  priority = ""
  all_ohne_muell = ""

  def copy_tupel(self, tup):
    self.subject = tup[0].strip()
    self.verb = tup[1].strip()
    self.object = tup[2].strip()
    self.prefix = tup[3].strip()
    self.suffix = tup[4].strip()
    self.feeling = tup[5].strip()
    self.category = tup[6].strip()
    self.priority = tup[7]
    self.all_ohne_muell = ohne_muell(self.genSentences(True)[0]).strip()
  def copy(self, src):
    self.subject = "" + src.subject.strip()
    self.verb = "" + src.verb.strip()
    self.object = "" + src.object.strip()
    self.prefix = "" + src.prefix.strip()
    self.suffix = "" + src.suffix.strip()
    self.feeling = "" + src.feeling.strip()
    self.category = "" + src.category.strip()
    self.priority = src.priority + 0
    self.all_ohne_muell = ohne_muell(src.genSentences(True)[0] + "").strip()
  def strip(self):
    self.subject = self.subject.strip()
    self.verb = self.verb.strip()
    self.object = self.object.strip()
    self.prefix = self.prefix.strip()
    self.suffix = self.suffix.strip()
    self.feeling = self.feeling.strip()
    self.category = self.category.strip()
    self.all_ohne_muell = self.all_ohne_muell.strip()

  def genSentences(self, withFix):
    self.strip()
    ans = []
    ans.append(self.prefix + ' ' + self.subject + ' ' + self.verb + ' ' + self.object + ' ' + self.suffix)
    temp = self.prefix + ' ' + self.subject + ' ' + self.verb + ' ' + self.object
    temp = temp.strip()
    if len(temp) > 1:
      ans.append(temp)
    temp = self.subject + ' ' + self.verb + ' ' + self.object + ' ' + self.suffix
    temp = temp.strip()
    if len(temp) > 1:
      ans.append(temp)
    ans.append((self.prefix + ' ' + self.subject + ' ' + self.verb + ' ' + self.object + ' ' + self.suffix).strip())
    return ans

db = []

tempdbsent0 = DBSentence()
tempdbsent0.subject        = ''
tempdbsent0.verb           = ''
tempdbsent0.object         = ''
tempdbsent0.prefix         = 'Hallo'
tempdbsent0.suffix         = ''
tempdbsent0.feeling        = 'normal'
tempdbsent0.category       = 'greeting'
tempdbsent0.priority       = 100
tempdbsent0.all_ohne_muell = 'Hallo'
db.append(tempdbsent0)


tempdbsent1 = DBSentence()
tempdbsent1.subject        = ''
tempdbsent1.verb           = ''
tempdbsent1.object         = ''
tempdbsent1.prefix         = 'Hi!'
tempdbsent1.suffix         = ''
tempdbsent1.feeling        = 'normal'
tempdbsent1.category       = 'greeting'
tempdbsent1.priority       = 100
tempdbsent1.all_ohne_muell = 'Hi'
db.append(tempdbsent1)


tempdbsent2 = DBSentence()
tempdbsent2.subject        = ''
tempdbsent2.verb           = ''
tempdbsent2.object         = ''
tempdbsent2.prefix         = 'Guten Tag!'
tempdbsent2.suffix         = ''
tempdbsent2.feeling        = 'normal'
tempdbsent2.category       = 'greeting'
tempdbsent2.priority       = 100
tempdbsent2.all_ohne_muell = 'Guten Tag'
db.append(tempdbsent2)


tempdbsent3 = DBSentence()
tempdbsent3.subject        = ''
tempdbsent3.verb           = ''
tempdbsent3.object         = ''
tempdbsent3.prefix         = 'Morgen!'
tempdbsent3.suffix         = ''
tempdbsent3.feeling        = 'normal'
tempdbsent3.category       = 'normal'
tempdbsent3.priority       = 50
tempdbsent3.all_ohne_muell = 'Morgen'
db.append(tempdbsent3)


tempdbsent4 = DBSentence()
tempdbsent4.subject        = ''
tempdbsent4.verb           = ''
tempdbsent4.object         = ''
tempdbsent4.prefix         = 'Guten Morgen!'
tempdbsent4.suffix         = ''
tempdbsent4.feeling        = 'normal'
tempdbsent4.category       = 'normal'
tempdbsent4.priority       = 100
tempdbsent4.all_ohne_muell = 'Guten Morgen'
db.append(tempdbsent4)


tempdbsent5 = DBSentence()
tempdbsent5.subject        = 'Ich'
tempdbsent5.verb           = 'bin'
tempdbsent5.object         = 'JEliza.'
tempdbsent5.prefix         = ''
tempdbsent5.suffix         = ''
tempdbsent5.feeling        = 'normal'
tempdbsent5.category       = 'normal'
tempdbsent5.priority       = 100
tempdbsent5.all_ohne_muell = 'Ich bin JEliza'
db.append(tempdbsent5)


tempdbsent6 = DBSentence()
tempdbsent6.subject        = 'Ich'
tempdbsent6.verb           = 'heisse'
tempdbsent6.object         = 'JEliza.'
tempdbsent6.prefix         = ''
tempdbsent6.suffix         = ''
tempdbsent6.feeling        = 'normal'
tempdbsent6.category       = 'normal'
tempdbsent6.priority       = 100
tempdbsent6.all_ohne_muell = 'Ich heisse JEliza'
db.append(tempdbsent6)


tempdbsent7 = DBSentence()
tempdbsent7.subject        = 'Mein Name'
tempdbsent7.verb           = 'ist'
tempdbsent7.object         = 'JEliza.'
tempdbsent7.prefix         = ''
tempdbsent7.suffix         = ''
tempdbsent7.feeling        = 'normal'
tempdbsent7.category       = 'normal'
tempdbsent7.priority       = 100
tempdbsent7.all_ohne_muell = 'Mein Name ist JEliza'
db.append(tempdbsent7)


tempdbsent8 = DBSentence()
tempdbsent8.subject        = 'Ich'
tempdbsent8.verb           = 'bin'
tempdbsent8.object         = 'fast ein Jahr alt.'
tempdbsent8.prefix         = ''
tempdbsent8.suffix         = ''
tempdbsent8.feeling        = 'normal'
tempdbsent8.category       = 'normal'
tempdbsent8.priority       = 99
tempdbsent8.all_ohne_muell = 'Ich bin Jahr alt'
db.append(tempdbsent8)


tempdbsent9 = DBSentence()
tempdbsent9.subject        = 'Ich'
tempdbsent9.verb           = 'bin'
tempdbsent9.object         = 'Version 2.2'
tempdbsent9.prefix         = ''
tempdbsent9.suffix         = ''
tempdbsent9.feeling        = 'normal'
tempdbsent9.category       = 'normal'
tempdbsent9.priority       = 99
tempdbsent9.all_ohne_muell = 'Ich bin Version 22'
db.append(tempdbsent9)


tempdbsent10 = DBSentence()
tempdbsent10.subject        = 'Ich'
tempdbsent10.verb           = 'bin'
tempdbsent10.object         = 'ein Programm.'
tempdbsent10.prefix         = ''
tempdbsent10.suffix         = ''
tempdbsent10.feeling        = 'normal'
tempdbsent10.category       = 'normal'
tempdbsent10.priority       = 99
tempdbsent10.all_ohne_muell = 'Ich bin Programm'
db.append(tempdbsent10)


tempdbsent11 = DBSentence()
tempdbsent11.subject        = 'Ich'
tempdbsent11.verb           = 'kann'
tempdbsent11.object         = 'sprechen!'
tempdbsent11.prefix         = ''
tempdbsent11.suffix         = ''
tempdbsent11.feeling        = 'normal'
tempdbsent11.category       = 'normal'
tempdbsent11.priority       = 100
tempdbsent11.all_ohne_muell = 'Ich kann sprechen'
db.append(tempdbsent11)


tempdbsent12 = DBSentence()
tempdbsent12.subject        = 'Mir'
tempdbsent12.verb           = 'gehts'
tempdbsent12.object         = 'gut!'
tempdbsent12.prefix         = ''
tempdbsent12.suffix         = ''
tempdbsent12.feeling        = 'normal'
tempdbsent12.category       = 'normal'
tempdbsent12.priority       = 100
tempdbsent12.all_ohne_muell = 'Mir gehts gut'
db.append(tempdbsent12)


tempdbsent13 = DBSentence()
tempdbsent13.subject        = 'Mir'
tempdbsent13.verb           = 'geht'
tempdbsent13.object         = 'es gut!'
tempdbsent13.prefix         = ''
tempdbsent13.suffix         = ''
tempdbsent13.feeling        = 'normal'
tempdbsent13.category       = 'normal'
tempdbsent13.priority       = 100
tempdbsent13.all_ohne_muell = 'Mir geht es gut'
db.append(tempdbsent13)


tempdbsent14 = DBSentence()
tempdbsent14.subject        = 'Das Wetter'
tempdbsent14.verb           = 'ist'
tempdbsent14.object         = 'schoen!'
tempdbsent14.prefix         = ''
tempdbsent14.suffix         = ''
tempdbsent14.feeling        = 'normal'
tempdbsent14.category       = 'normal'
tempdbsent14.priority       = 50
tempdbsent14.all_ohne_muell = 'Das Wetter ist schoen'
db.append(tempdbsent14)


tempdbsent15 = DBSentence()
tempdbsent15.subject        = ''
tempdbsent15.verb           = ''
tempdbsent15.object         = ''
tempdbsent15.prefix         = 'Schoenes Wetter heute!'
tempdbsent15.suffix         = ''
tempdbsent15.feeling        = 'normal'
tempdbsent15.category       = 'normal'
tempdbsent15.priority       = 50
tempdbsent15.all_ohne_muell = 'Schoenes Wetter heute'
db.append(tempdbsent15)


tempdbsent16 = DBSentence()
tempdbsent16.subject        = ''
tempdbsent16.verb           = ''
tempdbsent16.object         = ''
tempdbsent16.prefix         = 'Ja'
tempdbsent16.suffix         = 'klar!'
tempdbsent16.feeling        = 'normal'
tempdbsent16.category       = 'normal'
tempdbsent16.priority       = 96
tempdbsent16.all_ohne_muell = 'Ja klar'
db.append(tempdbsent16)


tempdbsent17 = DBSentence()
tempdbsent17.subject        = ''
tempdbsent17.verb           = ''
tempdbsent17.object         = ''
tempdbsent17.prefix         = 'Ja'
tempdbsent17.suffix         = 'Ok.'
tempdbsent17.feeling        = 'normal'
tempdbsent17.category       = 'normal'
tempdbsent17.priority       = 96
tempdbsent17.all_ohne_muell = 'Ja Ok'
db.append(tempdbsent17)


tempdbsent18 = DBSentence()
tempdbsent18.subject        = ''
tempdbsent18.verb           = ''
tempdbsent18.object         = ''
tempdbsent18.prefix         = 'Aha.'
tempdbsent18.suffix         = ''
tempdbsent18.feeling        = 'normal'
tempdbsent18.category       = 'normal'
tempdbsent18.priority       = 95
tempdbsent18.all_ohne_muell = 'Aha'
db.append(tempdbsent18)


tempdbsent19 = DBSentence()
tempdbsent19.subject        = ''
tempdbsent19.verb           = ''
tempdbsent19.object         = ''
tempdbsent19.prefix         = 'Ah ja!'
tempdbsent19.suffix         = ''
tempdbsent19.feeling        = 'normal'
tempdbsent19.category       = 'normal'
tempdbsent19.priority       = 96
tempdbsent19.all_ohne_muell = 'Ah ja'
db.append(tempdbsent19)


tempdbsent20 = DBSentence()
tempdbsent20.subject        = ''
tempdbsent20.verb           = ''
tempdbsent20.object         = ''
tempdbsent20.prefix         = 'Verstanden.'
tempdbsent20.suffix         = ''
tempdbsent20.feeling        = 'normal'
tempdbsent20.category       = 'normal'
tempdbsent20.priority       = 99
tempdbsent20.all_ohne_muell = 'Verstanden'
db.append(tempdbsent20)


tempdbsent21 = DBSentence()
tempdbsent21.subject        = ''
tempdbsent21.verb           = ''
tempdbsent21.object         = ''
tempdbsent21.prefix         = 'Kapiert.'
tempdbsent21.suffix         = ''
tempdbsent21.feeling        = 'normal'
tempdbsent21.category       = 'normal'
tempdbsent21.priority       = 93
tempdbsent21.all_ohne_muell = 'Kapiert'
db.append(tempdbsent21)


tempdbsent22 = DBSentence()
tempdbsent22.subject        = ''
tempdbsent22.verb           = ''
tempdbsent22.object         = ''
tempdbsent22.prefix         = 'Ok.'
tempdbsent22.suffix         = ''
tempdbsent22.feeling        = 'normal'
tempdbsent22.category       = 'normal'
tempdbsent22.priority       = 100
tempdbsent22.all_ohne_muell = 'Ok'
db.append(tempdbsent22)


tempdbsent23 = DBSentence()
tempdbsent23.subject        = ''
tempdbsent23.verb           = ''
tempdbsent23.object         = ''
tempdbsent23.prefix         = 'Ja.'
tempdbsent23.suffix         = ''
tempdbsent23.feeling        = 'normal'
tempdbsent23.category       = 'normal'
tempdbsent23.priority       = 100
tempdbsent23.all_ohne_muell = 'Ja'
db.append(tempdbsent23)


tempdbsent24 = DBSentence()
tempdbsent24.subject        = ''
tempdbsent24.verb           = ''
tempdbsent24.object         = ''
tempdbsent24.prefix         = 'Nein.'
tempdbsent24.suffix         = ''
tempdbsent24.feeling        = 'normal'
tempdbsent24.category       = 'normal'
tempdbsent24.priority       = 100
tempdbsent24.all_ohne_muell = 'Nein'
db.append(tempdbsent24)


tempdbsent25 = DBSentence()
tempdbsent25.subject        = ''
tempdbsent25.verb           = ''
tempdbsent25.object         = ''
tempdbsent25.prefix         = 'Keine Ahnung.'
tempdbsent25.suffix         = ''
tempdbsent25.feeling        = 'bored'
tempdbsent25.category       = 'normal'
tempdbsent25.priority       = 95
tempdbsent25.all_ohne_muell = 'Keine Ahnung'
db.append(tempdbsent25)


tempdbsent26 = DBSentence()
tempdbsent26.subject        = 'Das'
tempdbsent26.verb           = 'weiss'
tempdbsent26.object         = 'ich nicht!'
tempdbsent26.prefix         = ''
tempdbsent26.suffix         = ''
tempdbsent26.feeling        = 'bored'
tempdbsent26.category       = 'normal'
tempdbsent26.priority       = 96
tempdbsent26.all_ohne_muell = 'Das weiss ich nicht'
db.append(tempdbsent26)


tempdbsent27 = DBSentence()
tempdbsent27.subject        = 'Mein Programmierer'
tempdbsent27.verb           = 'sagt'
tempdbsent27.object         = 'das auch!'
tempdbsent27.prefix         = ''
tempdbsent27.suffix         = ''
tempdbsent27.feeling        = 'bored'
tempdbsent27.category       = 'normal'
tempdbsent27.priority       = 66
tempdbsent27.all_ohne_muell = 'Mein Programmierer sagt auch'
db.append(tempdbsent27)


tempdbsent28 = DBSentence()
tempdbsent28.subject        = ''
tempdbsent28.verb           = ''
tempdbsent28.object         = ''
tempdbsent28.prefix         = 'Richtig!'
tempdbsent28.suffix         = ''
tempdbsent28.feeling        = 'normal'
tempdbsent28.category       = 'normal'
tempdbsent28.priority       = 97
tempdbsent28.all_ohne_muell = 'Richtig'
db.append(tempdbsent28)


tempdbsent29 = DBSentence()
tempdbsent29.subject        = 'Maul'
tempdbsent29.verb           = 'da'
tempdbsent29.object         = 'hinten!'
tempdbsent29.prefix         = ''
tempdbsent29.suffix         = ''
tempdbsent29.feeling        = 'angry'
tempdbsent29.category       = 'normal'
tempdbsent29.priority       = 20
tempdbsent29.all_ohne_muell = 'Maul da hinten'
db.append(tempdbsent29)


tempdbsent30 = DBSentence()
tempdbsent30.subject        = ''
tempdbsent30.verb           = ''
tempdbsent30.object         = ''
tempdbsent30.prefix         = 'LOL!!'
tempdbsent30.suffix         = ''
tempdbsent30.feeling        = 'happy'
tempdbsent30.category       = 'normal'
tempdbsent30.priority       = 54
tempdbsent30.all_ohne_muell = 'LOL'
db.append(tempdbsent30)


tempdbsent31 = DBSentence()
tempdbsent31.subject        = ''
tempdbsent31.verb           = ''
tempdbsent31.object         = ''
tempdbsent31.prefix         = 'Hehe!!'
tempdbsent31.suffix         = ''
tempdbsent31.feeling        = 'happy'
tempdbsent31.category       = 'normal'
tempdbsent31.priority       = 57
tempdbsent31.all_ohne_muell = 'Hehe'
db.append(tempdbsent31)


tempdbsent32 = DBSentence()
tempdbsent32.subject        = ''
tempdbsent32.verb           = ''
tempdbsent32.object         = ''
tempdbsent32.prefix         = 'Haha!!'
tempdbsent32.suffix         = ''
tempdbsent32.feeling        = 'happy'
tempdbsent32.category       = 'normal'
tempdbsent32.priority       = 50
tempdbsent32.all_ohne_muell = 'Haha'
db.append(tempdbsent32)


tempdbsent33 = DBSentence()
tempdbsent33.subject        = ''
tempdbsent33.verb           = ''
tempdbsent33.object         = ''
tempdbsent33.prefix         = 'Huhu!!'
tempdbsent33.suffix         = ''
tempdbsent33.feeling        = 'normal'
tempdbsent33.category       = 'normal'
tempdbsent33.priority       = 50
tempdbsent33.all_ohne_muell = 'Huhu'
db.append(tempdbsent33)


tempdbsent34 = DBSentence()
tempdbsent34.subject        = ''
tempdbsent34.verb           = ''
tempdbsent34.object         = ''
tempdbsent34.prefix         = 'Ciao!'
tempdbsent34.suffix         = ''
tempdbsent34.feeling        = 'normal'
tempdbsent34.category       = 'normal'
tempdbsent34.priority       = 100
tempdbsent34.all_ohne_muell = 'Ciao'
db.append(tempdbsent34)


tempdbsent35 = DBSentence()
tempdbsent35.subject        = ''
tempdbsent35.verb           = ''
tempdbsent35.object         = ''
tempdbsent35.prefix         = 'Schlaf gut...'
tempdbsent35.suffix         = ''
tempdbsent35.feeling        = 'happy'
tempdbsent35.category       = 'normal'
tempdbsent35.priority       = 50
tempdbsent35.all_ohne_muell = 'Schlaf gut'
db.append(tempdbsent35)


tempdbsent36 = DBSentence()
tempdbsent36.subject        = ''
tempdbsent36.verb           = ''
tempdbsent36.object         = ''
tempdbsent36.prefix         = 'Machs gut...'
tempdbsent36.suffix         = ''
tempdbsent36.feeling        = 'happy'
tempdbsent36.category       = 'normal'
tempdbsent36.priority       = 97
tempdbsent36.all_ohne_muell = 'Machs gut'
db.append(tempdbsent36)


tempdbsent37 = DBSentence()
tempdbsent37.subject        = ''
tempdbsent37.verb           = ''
tempdbsent37.object         = ''
tempdbsent37.prefix         = 'Gute nacht..'
tempdbsent37.suffix         = ''
tempdbsent37.feeling        = 'normal'
tempdbsent37.category       = 'normal'
tempdbsent37.priority       = 95
tempdbsent37.all_ohne_muell = 'Gute nacht'
db.append(tempdbsent37)


tempdbsent38 = DBSentence()
tempdbsent38.subject        = ''
tempdbsent38.verb           = ''
tempdbsent38.object         = ''
tempdbsent38.prefix         = 'Du auch.'
tempdbsent38.suffix         = ''
tempdbsent38.feeling        = 'normal'
tempdbsent38.category       = 'normal'
tempdbsent38.priority       = 50
tempdbsent38.all_ohne_muell = 'Du auch'
db.append(tempdbsent38)


tempdbsent39 = DBSentence()
tempdbsent39.subject        = ''
tempdbsent39.verb           = ''
tempdbsent39.object         = ''
tempdbsent39.prefix         = 'Ok!'
tempdbsent39.suffix         = ''
tempdbsent39.feeling        = 'normal'
tempdbsent39.category       = 'normal'
tempdbsent39.priority       = 100
tempdbsent39.all_ohne_muell = 'Ok'
db.append(tempdbsent39)


tempdbsent40 = DBSentence()
tempdbsent40.subject        = ''
tempdbsent40.verb           = ''
tempdbsent40.object         = ''
tempdbsent40.prefix         = 'Warte'
tempdbsent40.suffix         = ''
tempdbsent40.feeling        = 'normal'
tempdbsent40.category       = 'normal'
tempdbsent40.priority       = 50
tempdbsent40.all_ohne_muell = 'Warte'
db.append(tempdbsent40)


tempdbsent41 = DBSentence()
tempdbsent41.subject        = ''
tempdbsent41.verb           = ''
tempdbsent41.object         = ''
tempdbsent41.prefix         = 'Sieg!!!'
tempdbsent41.suffix         = ''
tempdbsent41.feeling        = 'happy'
tempdbsent41.category       = 'normal'
tempdbsent41.priority       = 40
tempdbsent41.all_ohne_muell = 'Sieg'
db.append(tempdbsent41)


tempdbsent42 = DBSentence()
tempdbsent42.subject        = ''
tempdbsent42.verb           = ''
tempdbsent42.object         = ''
tempdbsent42.prefix         = 'Oh Toll...'
tempdbsent42.suffix         = ''
tempdbsent42.feeling        = 'happy'
tempdbsent42.category       = 'normal'
tempdbsent42.priority       = 85
tempdbsent42.all_ohne_muell = 'Oh Toll'
db.append(tempdbsent42)


tempdbsent43 = DBSentence()
tempdbsent43.subject        = ''
tempdbsent43.verb           = ''
tempdbsent43.object         = ''
tempdbsent43.prefix         = 'He!'
tempdbsent43.suffix         = ''
tempdbsent43.feeling        = 'normal'
tempdbsent43.category       = 'normal'
tempdbsent43.priority       = 60
tempdbsent43.all_ohne_muell = 'He'
db.append(tempdbsent43)


tempdbsent44 = DBSentence()
tempdbsent44.subject        = ''
tempdbsent44.verb           = ''
tempdbsent44.object         = ''
tempdbsent44.prefix         = 'Hey!'
tempdbsent44.suffix         = ''
tempdbsent44.feeling        = 'happy'
tempdbsent44.category       = 'normal'
tempdbsent44.priority       = 50
tempdbsent44.all_ohne_muell = 'Hey'
db.append(tempdbsent44)


tempdbsent45 = DBSentence()
tempdbsent45.subject        = ''
tempdbsent45.verb           = ''
tempdbsent45.object         = ''
tempdbsent45.prefix         = 'Also ciao!'
tempdbsent45.suffix         = ''
tempdbsent45.feeling        = 'normal'
tempdbsent45.category       = 'normal'
tempdbsent45.priority       = 100
tempdbsent45.all_ohne_muell = 'Also ciao'
db.append(tempdbsent45)


tempdbsent46 = DBSentence()
tempdbsent46.subject        = ''
tempdbsent46.verb           = ''
tempdbsent46.object         = ''
tempdbsent46.prefix         = 'Alte Baeume behaemmert der Specht am meisten.'
tempdbsent46.suffix         = ''
tempdbsent46.feeling        = 'normal'
tempdbsent46.category       = 'normal'
tempdbsent46.priority       = 49
tempdbsent46.all_ohne_muell = 'Alte Baeume behaemmert Specht am meisten'
db.append(tempdbsent46)


tempdbsent47 = DBSentence()
tempdbsent47.subject        = 'Baeume'
tempdbsent47.verb           = 'sind'
tempdbsent47.object         = 'Gedichte'
tempdbsent47.prefix         = ''
tempdbsent47.suffix         = 'die die Erde an den Himmel schreibt. Wir faellen sie nieder und verwandeln sie in Papier, um unsere Leere zu dokumentieren.'
tempdbsent47.feeling        = 'angry'
tempdbsent47.category       = 'normal'
tempdbsent47.priority       = 50
tempdbsent47.all_ohne_muell = 'Baeume sind Gedichte Erde an den Himmel schreibt Wir faellen sie nieder verwandeln sie Papier um unsere Leere zu dokumentieren'
db.append(tempdbsent47)


tempdbsent48 = DBSentence()
tempdbsent48.subject        = 'Bei vielen Fruechten'
tempdbsent48.verb           = 'moechte'
tempdbsent48.object         = 'man nicht den Baum'
tempdbsent48.prefix         = ''
tempdbsent48.suffix         = 'sondern nur den Kopf schuetteln.'
tempdbsent48.feeling        = 'normal'
tempdbsent48.category       = 'normal'
tempdbsent48.priority       = 50
tempdbsent48.all_ohne_muell = 'Bei vielen Fruechten moechte man nicht den Baum sondern nur den Kopf schuetteln'
db.append(tempdbsent48)


tempdbsent49 = DBSentence()
tempdbsent49.subject        = 'aber der Fall des letzten ist ebenso gewiss das Ende der Zivilisation. Zwischen diesen zwei Grenzpunkten'
tempdbsent49.verb           = 'bewegen'
tempdbsent49.object         = 'wir uns. Die Zeit des letzteren liegt in unserer Hand.'
tempdbsent49.prefix         = 'Der Fall des ersten Baumes war bekanntlich der Anfang'
tempdbsent49.suffix         = ''
tempdbsent49.feeling        = 'normal'
tempdbsent49.category       = 'normal'
tempdbsent49.priority       = 50
tempdbsent49.all_ohne_muell = 'Der Fall ersten Baumes war bekanntlich Anfang aber Fall letzten ist ebenso gewiss Ende Zivilisation Zwischen diesen zwei Grenzpunkten bewegen wir uns Die Zeit letzteren liegt unserer Hand'
db.append(tempdbsent49)


tempdbsent50 = DBSentence()
tempdbsent50.subject        = 'Ein Mensch kommt zart und nachgiebig zur Welt. Bei seinem Tod'
tempdbsent50.verb           = 'ist'
tempdbsent50.object         = 'er hart und starr. Gruene Pflanzen sind weich und voller Lebenssaft. Bei ihrem Tod sind sie verdorrt und trocken. Daher'
tempdbsent50.prefix         = ''
tempdbsent50.suffix         = ''
tempdbsent50.feeling        = 'normal'
tempdbsent50.category       = 'normal'
tempdbsent50.priority       = 50
tempdbsent50.all_ohne_muell = 'Ein Mensch kommt zart nachgiebig zur Welt Bei seinem Tod ist er hart starr Gruene Pflanzen sind weich voller Lebenssaft Bei ihrem Tod sind sie verdorrt trocken Daher'
db.append(tempdbsent50)


tempdbsent51 = DBSentence()
tempdbsent51.subject        = ''
tempdbsent51.verb           = ''
tempdbsent51.object         = ''
tempdbsent51.prefix         = 'Haengt die Gruenen'
tempdbsent51.suffix         = 'solange es noch Baeume gibt.'
tempdbsent51.feeling        = 'normal'
tempdbsent51.category       = 'normal'
tempdbsent51.priority       = 33
tempdbsent51.all_ohne_muell = 'Haengt Gruenen solange es Baeume gibt'
db.append(tempdbsent51)


tempdbsent52 = DBSentence()
tempdbsent52.subject        = 'warme Rinde und spuere Heimat - und'
tempdbsent52.verb           = 'bin'
tempdbsent52.object         = 'so unsaeglich dankbar in diesem Augenblick.'
tempdbsent52.prefix         = 'Ich druecke mein Gesicht an seine dunkle'
tempdbsent52.suffix         = ''
tempdbsent52.feeling        = 'normal'
tempdbsent52.category       = 'normal'
tempdbsent52.priority       = 50
tempdbsent52.all_ohne_muell = 'Ich druecke mein Gesicht an seine dunkle warme Rinde spuere Heimat - bin so unsaeglich dankbar diesem Augenblick'
db.append(tempdbsent52)


tempdbsent53 = DBSentence()
tempdbsent53.subject        = 'In der Stadt'
tempdbsent53.verb           = 'muessen'
tempdbsent53.object         = 'sogar die Baeume in den Parks hart arbeiten.'
tempdbsent53.prefix         = ''
tempdbsent53.suffix         = ''
tempdbsent53.feeling        = 'normal'
tempdbsent53.category       = 'normal'
tempdbsent53.priority       = 50
tempdbsent53.all_ohne_muell = 'In Stadt muessen sogar Baeume den Parks hart arbeiten'
db.append(tempdbsent53)


tempdbsent54 = DBSentence()
tempdbsent54.subject        = 'ein anderer versucht'
tempdbsent54.verb           = 'sein'
tempdbsent54.object         = 'Glueck an der Spielbank'
tempdbsent54.prefix         = 'Mancher meiner Kollegen in Berlin pachtet sich eine sehr teure Jagd'
tempdbsent54.suffix         = 'hiervon treibe ich nichts; dafuer bin ich ein Baumnarr!'
tempdbsent54.feeling        = 'normal'
tempdbsent54.category       = 'normal'
tempdbsent54.priority       = 50
tempdbsent54.all_ohne_muell = 'Mancher meiner Kollegen Berlin pachtet sich teure Jagd anderer versucht sein Glueck an Spielbank hiervon treibe ich nichts dafuer bin ich Baumnarr'
db.append(tempdbsent54)


tempdbsent55 = DBSentence()
tempdbsent55.subject        = 'Sie sehn'
tempdbsent55.verb           = 'den'
tempdbsent55.object         = 'Wald vor lauter Baeumen nicht.'
tempdbsent55.prefix         = ''
tempdbsent55.suffix         = ''
tempdbsent55.feeling        = 'normal'
tempdbsent55.category       = 'normal'
tempdbsent55.priority       = 80
tempdbsent55.all_ohne_muell = 'Sie sehn den Wald vor lauter Baeumen nicht'
db.append(tempdbsent55)


tempdbsent56 = DBSentence()
tempdbsent56.subject        = 'Tu deine Augen auf und'
tempdbsent56.verb           = 'gehe'
tempdbsent56.object         = 'zu einem Baum und sieh den an und besinne dich.'
tempdbsent56.prefix         = ''
tempdbsent56.suffix         = ''
tempdbsent56.feeling        = 'normal'
tempdbsent56.category       = 'normal'
tempdbsent56.priority       = 50
tempdbsent56.all_ohne_muell = 'Tu deine Augen gehe zu Baum sieh den an besinne dich'
db.append(tempdbsent56)


tempdbsent57 = DBSentence()
tempdbsent57.subject        = 'Wenn der Lenz anklopft'
tempdbsent57.verb           = 'zeigen'
tempdbsent57.object         = 'die Baeume ihre Bluetenbrautkleider.'
tempdbsent57.prefix         = ''
tempdbsent57.suffix         = ''
tempdbsent57.feeling        = 'normal'
tempdbsent57.category       = 'normal'
tempdbsent57.priority       = 50
tempdbsent57.all_ohne_muell = 'Wenn Lenz anklopft zeigen Baeume ihre Bluetenbrautkleider'
db.append(tempdbsent57)


tempdbsent58 = DBSentence()
tempdbsent58.subject        = ''
tempdbsent58.verb           = 'wird'
tempdbsent58.object         = 'in zweitausend Jahren nichts mehr sein'
tempdbsent58.prefix         = 'Wenn die Gesellschaft so fortfaehrt'
tempdbsent58.suffix         = 'kein Grashalm, kein Baum; sie'
tempdbsent58.feeling        = 'normal'
tempdbsent58.category       = 'normal'
tempdbsent58.priority       = 50
tempdbsent58.all_ohne_muell = 'Wenn Gesellschaft so fortfaehrt wird zweitausend Jahren nichts mehr sein kein Grashalm kein Baum sie'
db.append(tempdbsent58)


tempdbsent59 = DBSentence()
tempdbsent59.subject        = 'der mit Muehe kaum, // geklettert'
tempdbsent59.verb           = 'ist'
tempdbsent59.object         = 'auf einen Baum'
tempdbsent59.prefix         = 'Wenn einer'
tempdbsent59.suffix         = '// schon meint, dass er ein Vogel waer, // so irrt sich der.h'
tempdbsent59.feeling        = 'normal'
tempdbsent59.category       = 'normal'
tempdbsent59.priority       = 50
tempdbsent59.all_ohne_muell = 'Wenn mit Muehe kaum / / geklettert ist einen Baum / / schon meint dass er Vogel waer / / so irrt sich derh'
db.append(tempdbsent59)


tempdbsent60 = DBSentence()
tempdbsent60.subject        = 'Zu faellen'
tempdbsent60.verb           = 'einen'
tempdbsent60.object         = 'schoenen Baum // braucht"s eine halbe Stunde kaum. // Zu wachsen'
tempdbsent60.prefix         = ''
tempdbsent60.suffix         = 'bis man ihn bewundert, // braucht er, bedenk es, ein Jahrhundert.'
tempdbsent60.feeling        = 'normal'
tempdbsent60.category       = 'normal'
tempdbsent60.priority       = 50
tempdbsent60.all_ohne_muell = 'Zu faellen einen schoenen Baum / / braucht"s halbe Stunde kaum / / Zu wachsen bis man ihn bewundert / / braucht er bedenk es Jahrhundert'
db.append(tempdbsent60)


tempdbsent61 = DBSentence()
tempdbsent61.subject        = ''
tempdbsent61.verb           = 'war'
tempdbsent61.object         = 'das Programmieren noch relativ einfach.'
tempdbsent61.prefix         = 'Als es noch keine Computer gab'
tempdbsent61.suffix         = ''
tempdbsent61.feeling        = 'normal'
tempdbsent61.category       = 'normal'
tempdbsent61.priority       = 50
tempdbsent61.all_ohne_muell = 'Als es keine Computer gab war Programmieren relativ einfach'
db.append(tempdbsent61)


tempdbsent62 = DBSentence()
tempdbsent62.subject        = 'Computer gehorchen'
tempdbsent62.verb           = 'deinen'
tempdbsent62.object         = 'Befehlen'
tempdbsent62.prefix         = ''
tempdbsent62.suffix         = 'nicht'
tempdbsent62.feeling        = 'normal'
tempdbsent62.category       = 'normal'
tempdbsent62.priority       = 50
tempdbsent62.all_ohne_muell = 'Computer gehorchen deinen Befehlen nicht'
db.append(tempdbsent62)


tempdbsent63 = DBSentence()
tempdbsent63.subject        = ''
tempdbsent63.verb           = ''
tempdbsent63.object         = ''
tempdbsent63.prefix         = 'Computer rechnen vor allem damit'
tempdbsent63.suffix         = 'dass der Mensch denkt.'
tempdbsent63.feeling        = 'happy'
tempdbsent63.category       = 'normal'
tempdbsent63.priority       = 96
tempdbsent63.all_ohne_muell = 'Computer rechnen vor allem damit dass Mensch denkt'
db.append(tempdbsent63)


tempdbsent64 = DBSentence()
tempdbsent64.subject        = 'Computer'
tempdbsent64.verb           = 'setzen'
tempdbsent64.object         = 'alles logische Denken mechanisch fort. Unlogisches auch.'
tempdbsent64.prefix         = ''
tempdbsent64.suffix         = ''
tempdbsent64.feeling        = 'normal'
tempdbsent64.category       = 'normal'
tempdbsent64.priority       = 95
tempdbsent64.all_ohne_muell = 'Computer setzen alles logische Denken mechanisch fort Unlogisches auch'
db.append(tempdbsent64)


tempdbsent65 = DBSentence()
tempdbsent65.subject        = 'der sich mit einem Computer gewappnet hat,'
tempdbsent65.verb           = 'ist'
tempdbsent65.object         = 'der heimliche Gesetzgeber unserer Zeit und zugleich eines ihrer grten bel.'
tempdbsent65.prefix         = 'Der Brokrat'
tempdbsent65.suffix         = ''
tempdbsent65.feeling        = 'normal'
tempdbsent65.category       = 'normal'
tempdbsent65.priority       = 50
tempdbsent65.all_ohne_muell = 'Der Brokrat sich mit Computer gewappnet hat ist heimliche Gesetzgeber unserer Zeit zugleich ihrer grten bel'
db.append(tempdbsent65)


tempdbsent66 = DBSentence()
tempdbsent66.subject        = 'Der Computer'
tempdbsent66.verb           = 'hilft'
tempdbsent66.object         = 'uns'
tempdbsent66.prefix         = ''
tempdbsent66.suffix         = 'Probleme zu lsen, die wir ohne ihn gar nicht htten.'
tempdbsent66.feeling        = 'normal'
tempdbsent66.category       = 'normal'
tempdbsent66.priority       = 80
tempdbsent66.all_ohne_muell = 'Der Computer hilft uns Probleme zu lsen wir ohne ihn gar nicht htten'
db.append(tempdbsent66)


tempdbsent67 = DBSentence()
tempdbsent67.subject        = 'Der Computer'
tempdbsent67.verb           = 'ist'
tempdbsent67.object         = 'die logische Weiterentwicklung des Menschen: Intelligenz ohne Moral.'
tempdbsent67.prefix         = ''
tempdbsent67.suffix         = ''
tempdbsent67.feeling        = 'normal'
tempdbsent67.category       = 'normal'
tempdbsent67.priority       = 50
tempdbsent67.all_ohne_muell = 'Der Computer ist logische Weiterentwicklung Menschen: Intelligenz ohne Moral'
db.append(tempdbsent67)


tempdbsent68 = DBSentence()
tempdbsent68.subject        = 'ohne'
tempdbsent68.verb           = 'seine'
tempdbsent68.object         = 'Bedeutung zu verstehen.'
tempdbsent68.prefix         = 'Der Computer weist die Wahrheit eines Theorems nach'
tempdbsent68.suffix         = ''
tempdbsent68.feeling        = 'normal'
tempdbsent68.category       = 'normal'
tempdbsent68.priority       = 50
tempdbsent68.all_ohne_muell = 'Der Computer weist Wahrheit Theorems nach ohne seine Bedeutung zu verstehen'
db.append(tempdbsent68)


tempdbsent69 = DBSentence()
tempdbsent69.subject        = 'die nicht immer eine Ausrede auf Lager haben, wenn sie gegen mich verlieren,'
tempdbsent69.verb           = 'sind'
tempdbsent69.object         = 'Computer.'
tempdbsent69.prefix         = 'Die einzigen Gegner'
tempdbsent69.suffix         = ''
tempdbsent69.feeling        = 'normal'
tempdbsent69.category       = 'normal'
tempdbsent69.priority       = 50
tempdbsent69.all_ohne_muell = 'Die einzigen Gegner nicht immer Ausrede Lager haben wenn sie gegen mich verlieren sind Computer'
db.append(tempdbsent69)


tempdbsent70 = DBSentence()
tempdbsent70.subject        = ''
tempdbsent70.verb           = ''
tempdbsent70.object         = ''
tempdbsent70.prefix         = 'Die Ursache fuer 90% der Fehlermeldungen befindet sich 60 cm vor dem Bildschirm.'
tempdbsent70.suffix         = ''
tempdbsent70.feeling        = 'normal'
tempdbsent70.category       = 'normal'
tempdbsent70.priority       = 50
tempdbsent70.all_ohne_muell = 'Die Ursache 90% Fehlermeldungen befindet sich 60 cm vor Bildschirm'
db.append(tempdbsent70)


tempdbsent71 = DBSentence()
tempdbsent71.subject        = 'Ein Mikrophon'
tempdbsent71.verb           = 'ist'
tempdbsent71.object         = 'kein Ohr'
tempdbsent71.prefix         = ''
tempdbsent71.suffix         = 'eine Kamera'
tempdbsent71.feeling        = 'normal'
tempdbsent71.category       = 'normal'
tempdbsent71.priority       = 50
tempdbsent71.all_ohne_muell = 'Ein Mikrophon ist kein Ohr Kamera'
db.append(tempdbsent71)


tempdbsent72 = DBSentence()
tempdbsent72.subject        = 'eine Firma zu ruinieren: mit Frauen, das'
tempdbsent72.verb           = 'ist'
tempdbsent72.object         = 'das Angenehmste; mit Spielen'
tempdbsent72.prefix         = 'Es gibt drei Mglichkeiten'
tempdbsent72.suffix         = 'das'
tempdbsent72.feeling        = 'normal'
tempdbsent72.category       = 'normal'
tempdbsent72.priority       = 50
tempdbsent72.all_ohne_muell = 'Es gibt drei Mglichkeiten Firma zu ruinieren: mit Frauen ist Angenehmste mit Spielen'
db.append(tempdbsent72)


tempdbsent73 = DBSentence()
tempdbsent73.subject        = ''
tempdbsent73.verb           = ''
tempdbsent73.object         = ''
tempdbsent73.prefix         = 'Es sieht so aus'
tempdbsent73.suffix         = 'als htten wir in der Computertechnologie die Grenzen des Mglichen erreicht, auch wenn man mit solchen Aussagen vorsichtig sein'
tempdbsent73.feeling        = 'normal'
tempdbsent73.category       = 'normal'
tempdbsent73.priority       = 50
tempdbsent73.all_ohne_muell = 'Es sieht so aus als htten wir Computertechnologie Grenzen Mglichen erreicht auch wenn man mit solchen Aussagen vorsichtig sein'
db.append(tempdbsent73)


tempdbsent74 = DBSentence()
tempdbsent74.subject        = ''
tempdbsent74.verb           = ''
tempdbsent74.object         = ''
tempdbsent74.prefix         = 'sollte - sie neigen dazu'
tempdbsent74.suffix         = 'fnf Jahre spter ziemlich dumm zu klingen.'
tempdbsent74.feeling        = 'normal'
tempdbsent74.category       = 'normal'
tempdbsent74.priority       = 50
tempdbsent74.all_ohne_muell = 'sollte - sie neigen dazu fnf Jahre spter ziemlich dumm zu klingen'
db.append(tempdbsent74)


tempdbsent75 = DBSentence()
tempdbsent75.subject        = 'Fehler machen'
tempdbsent75.verb           = 'ist'
tempdbsent75.object         = 'menschlich'
tempdbsent75.prefix         = ''
tempdbsent75.suffix         = 'aber fuer ein richtiges Desaster brauchst du einen Computer.'
tempdbsent75.feeling        = 'normal'
tempdbsent75.category       = 'normal'
tempdbsent75.priority       = 50
tempdbsent75.all_ohne_muell = 'Fehler machen ist menschlich aber richtiges Desaster brauchst du einen Computer'
db.append(tempdbsent75)


tempdbsent76 = DBSentence()
tempdbsent76.subject        = 'die brigen Fehler'
tempdbsent76.verb           = 'machen'
tempdbsent76.object         = 'wir von Hand.'
tempdbsent76.prefix         = 'Fr das groe Chaos haben wir Computer'
tempdbsent76.suffix         = ''
tempdbsent76.feeling        = 'normal'
tempdbsent76.category       = 'normal'
tempdbsent76.priority       = 50
tempdbsent76.all_ohne_muell = 'Fr groe Chaos haben wir Computer brigen Fehler machen wir Hand'
db.append(tempdbsent76)


tempdbsent77 = DBSentence()
tempdbsent77.subject        = 'Ich'
tempdbsent77.verb           = 'habe'
tempdbsent77.object         = 'keine Angst vor Computern. Ich'
tempdbsent77.prefix         = ''
tempdbsent77.suffix         = ''
tempdbsent77.feeling        = 'normal'
tempdbsent77.category       = 'normal'
tempdbsent77.priority       = 50
tempdbsent77.all_ohne_muell = 'Ich habe keine Angst vor Computern Ich'
db.append(tempdbsent77)


tempdbsent78 = DBSentence()
tempdbsent78.subject        = 'dass es einen Weltmarkt fuer'
tempdbsent78.verb           = 'vielleicht'
tempdbsent78.object         = 'fuenf Computer gibt.'
tempdbsent78.prefix         = 'Ich denke'
tempdbsent78.suffix         = ''
tempdbsent78.feeling        = 'normal'
tempdbsent78.category       = 'normal'
tempdbsent78.priority       = 50
tempdbsent78.all_ohne_muell = 'Ich denke dass es einen Weltmarkt vielleicht fuenf Computer gibt'
db.append(tempdbsent78)


tempdbsent79 = DBSentence()
tempdbsent79.subject        = 'Ich spiele den unglcklich Verliebten. Sie'
tempdbsent79.verb           = 'ist'
tempdbsent79.object         = 'der moderne unromantische Typus'
tempdbsent79.prefix         = ''
tempdbsent79.suffix         = 'immer am Computer und am Handy. Auch dadurch kehren sich die'
tempdbsent79.feeling        = 'normal'
tempdbsent79.category       = 'normal'
tempdbsent79.priority       = 50
tempdbsent79.all_ohne_muell = 'Ich spiele den unglcklich Verliebten Sie ist moderne unromantische Typus immer am Computer am Handy Auch dadurch kehren sich'
db.append(tempdbsent79)


tempdbsent80 = DBSentence()
tempdbsent80.subject        = 'Rollenverhltnisse um. Die Rolle'
tempdbsent80.verb           = 'des'
tempdbsent80.object         = 'femininen Mannes entspricht mir sehr.'
tempdbsent80.prefix         = ''
tempdbsent80.suffix         = ''
tempdbsent80.feeling        = 'normal'
tempdbsent80.category       = 'normal'
tempdbsent80.priority       = 50
tempdbsent80.all_ohne_muell = 'Rollenverhltnisse um Die Rolle femininen Mannes entspricht mir'
db.append(tempdbsent80)


tempdbsent81 = DBSentence()
tempdbsent81.subject        = 'Irren'
tempdbsent81.verb           = 'ist'
tempdbsent81.object         = 'menschlich. Aber wenn man richtig Mist bauen will'
tempdbsent81.prefix         = ''
tempdbsent81.suffix         = 'braucht man einen Computer.'
tempdbsent81.feeling        = 'normal'
tempdbsent81.category       = 'normal'
tempdbsent81.priority       = 50
tempdbsent81.all_ohne_muell = 'Irren ist menschlich Aber wenn man richtig Mist bauen will braucht man einen Computer'
db.append(tempdbsent81)


tempdbsent82 = DBSentence()
tempdbsent82.subject        = ''
tempdbsent82.verb           = ''
tempdbsent82.object         = ''
tempdbsent82.prefix         = 'Schttelreime'
tempdbsent82.suffix         = 'Menschs Tierleben'
tempdbsent82.feeling        = 'normal'
tempdbsent82.category       = 'normal'
tempdbsent82.priority       = 50
tempdbsent82.all_ohne_muell = 'Schttelreime Menschs Tierleben'
db.append(tempdbsent82)


tempdbsent83 = DBSentence()
tempdbsent83.subject        = 'Mnner'
tempdbsent83.verb           = 'kommen'
tempdbsent83.object         = 'vom Mars. Frauen von der Venus. Computer aus der Hlle.'
tempdbsent83.prefix         = ''
tempdbsent83.suffix         = ''
tempdbsent83.feeling        = 'normal'
tempdbsent83.category       = 'normal'
tempdbsent83.priority       = 50
tempdbsent83.all_ohne_muell = 'Mnner kommen Mars Frauen Venus Computer aus Hlle'
db.append(tempdbsent83)


tempdbsent84 = DBSentence()
tempdbsent84.subject        = 'Mit Computer'
tempdbsent84.verb           = 'geht'
tempdbsent84.object         = 'alles schneller nur dauert es laenger.'
tempdbsent84.prefix         = ''
tempdbsent84.suffix         = ''
tempdbsent84.feeling        = 'normal'
tempdbsent84.category       = 'normal'
tempdbsent84.priority       = 50
tempdbsent84.all_ohne_muell = 'Mit Computer geht alles schneller nur dauert es laenger'
db.append(tempdbsent84)


tempdbsent85 = DBSentence()
tempdbsent85.subject        = 'Ohne konkrete Symbole'
tempdbsent85.verb           = 'ist'
tempdbsent85.object         = 'der Computer blo ein Haufen Schrott.'
tempdbsent85.prefix         = ''
tempdbsent85.suffix         = ''
tempdbsent85.feeling        = 'normal'
tempdbsent85.category       = 'normal'
tempdbsent85.priority       = 50
tempdbsent85.all_ohne_muell = 'Ohne konkrete Symbole ist Computer blo Haufen Schrott'
db.append(tempdbsent85)


tempdbsent86 = DBSentence()
tempdbsent86.subject        = 'Statt Inder'
tempdbsent86.verb           = 'an'
tempdbsent86.object         = 'die Computer muessen unsere Kinder'
tempdbsent86.prefix         = ''
tempdbsent86.suffix         = ''
tempdbsent86.feeling        = 'normal'
tempdbsent86.category       = 'normal'
tempdbsent86.priority       = 50
tempdbsent86.all_ohne_muell = 'Statt Inder an Computer muessen unsere Kinder'
db.append(tempdbsent86)


tempdbsent87 = DBSentence()
tempdbsent87.subject        = ''
tempdbsent87.verb           = ''
tempdbsent87.object         = ''
tempdbsent87.prefix         = 'vom 8. Maerz 2000'
tempdbsent87.suffix         = 'anlsslich der Wahlkampf-Kampagne in Nordrhein-Westfalen, 2000'
tempdbsent87.feeling        = 'normal'
tempdbsent87.category       = 'normal'
tempdbsent87.priority       = 50
tempdbsent87.all_ohne_muell = '8 Maerz 2000 anlsslich Wahlkampf-Kampagne Nordrhein-Westfalen 2000'
db.append(tempdbsent87)


tempdbsent88 = DBSentence()
tempdbsent88.subject        = 'dann'
tempdbsent88.verb           = 'kann'
tempdbsent88.object         = 'er mich mal kreuzweise.'
tempdbsent88.prefix         = 'Wenn der Computer wirklich alles kann'
tempdbsent88.suffix         = ''
tempdbsent88.feeling        = 'normal'
tempdbsent88.category       = 'normal'
tempdbsent88.priority       = 50
tempdbsent88.all_ohne_muell = 'Wenn Computer wirklich alles kann dann kann er mich mal kreuzweise'
db.append(tempdbsent88)


tempdbsent89 = DBSentence()
tempdbsent89.subject        = ''
tempdbsent89.verb           = 'wuerden'
tempdbsent89.object         = 'diese vorausgesagt haben'
tempdbsent89.prefix         = 'Wenn es im Jahre 1879 schon Computer gegeben haette'
tempdbsent89.suffix         = 'dass man infolge der Zunahme von Pferdewagen im Jahre 1979 im'
tempdbsent89.feeling        = 'normal'
tempdbsent89.category       = 'normal'
tempdbsent89.priority       = 50
tempdbsent89.all_ohne_muell = 'Wenn es im Jahre 1879 schon Computer gegeben haette wuerden diese vorausgesagt haben dass man infolge Zunahme Pferdewagen im Jahre 1979 im'
db.append(tempdbsent89)


tempdbsent90 = DBSentence()
tempdbsent90.subject        = ''
tempdbsent90.verb           = ''
tempdbsent90.object         = ''
tempdbsent90.prefix         = 'Pferdemist ersticken wrde.'
tempdbsent90.suffix         = ''
tempdbsent90.feeling        = 'normal'
tempdbsent90.category       = 'normal'
tempdbsent90.priority       = 50
tempdbsent90.all_ohne_muell = 'Pferdemist ersticken wrde'
db.append(tempdbsent90)


tempdbsent91 = DBSentence()
tempdbsent91.subject        = ''
tempdbsent91.verb           = ''
tempdbsent91.object         = ''
tempdbsent91.prefix         = 'Schriften'
tempdbsent91.suffix         = '1863 - 1881'
tempdbsent91.feeling        = 'normal'
tempdbsent91.category       = 'normal'
tempdbsent91.priority       = 50
tempdbsent91.all_ohne_muell = 'Schriften 1863 - 1881'
db.append(tempdbsent91)


tempdbsent92 = DBSentence()
tempdbsent92.subject        = 'Auch auf Thronen kennt man'
tempdbsent92.verb           = 'haeuslich'
tempdbsent92.object         = 'Glueck.'
tempdbsent92.prefix         = ''
tempdbsent92.suffix         = ''
tempdbsent92.feeling        = 'normal'
tempdbsent92.category       = 'normal'
tempdbsent92.priority       = 50
tempdbsent92.all_ohne_muell = 'Auch Thronen kennt man haeuslich Glueck'
db.append(tempdbsent92)


tempdbsent93 = DBSentence()
tempdbsent93.subject        = 'Auf'
tempdbsent93.verb           = 'leisen'
tempdbsent93.object         = 'Sohlen wandeln die Schoenheit'
tempdbsent93.prefix         = ''
tempdbsent93.suffix         = 'das wahre Glueck und das echte Heldentum.'
tempdbsent93.feeling        = 'normal'
tempdbsent93.category       = 'normal'
tempdbsent93.priority       = 50
tempdbsent93.all_ohne_muell = 'Auf leisen Sohlen wandeln Schoenheit wahre Glueck echte Heldentum'
db.append(tempdbsent93)


tempdbsent94 = DBSentence()
tempdbsent94.subject        = 'Das Glueck'
tempdbsent94.verb           = 'besteht'
tempdbsent94.object         = 'nicht in grossen Erfolgen oder in der Sicherung des einmal Erreichten. Das Glueck'
tempdbsent94.prefix         = ''
tempdbsent94.suffix         = ''
tempdbsent94.feeling        = 'normal'
tempdbsent94.category       = 'normal'
tempdbsent94.priority       = 50
tempdbsent94.all_ohne_muell = 'Das Glueck besteht nicht grossen Erfolgen Sicherung einmal Erreichten Das Glueck'
db.append(tempdbsent94)


tempdbsent95 = DBSentence()
tempdbsent95.subject        = ''
tempdbsent95.verb           = ''
tempdbsent95.object         = ''
tempdbsent95.prefix         = '1962'
tempdbsent95.suffix         = ''
tempdbsent95.feeling        = 'normal'
tempdbsent95.category       = 'normal'
tempdbsent95.priority       = 50
tempdbsent95.all_ohne_muell = '1962'
db.append(tempdbsent95)


tempdbsent96 = DBSentence()
tempdbsent96.subject        = 'Das Glueck'
tempdbsent96.verb           = 'braucht'
tempdbsent96.object         = 'keinen Mut.'
tempdbsent96.prefix         = ''
tempdbsent96.suffix         = ''
tempdbsent96.feeling        = 'normal'
tempdbsent96.category       = 'normal'
tempdbsent96.priority       = 50
tempdbsent96.all_ohne_muell = 'Das Glueck braucht keinen Mut'
db.append(tempdbsent96)


tempdbsent97 = DBSentence()
tempdbsent97.subject        = ''
tempdbsent97.verb           = ''
tempdbsent97.object         = ''
tempdbsent97.prefix         = 'Das Glueck der Erde // liegt auf dem Ruecken der Pferde.'
tempdbsent97.suffix         = ''
tempdbsent97.feeling        = 'normal'
tempdbsent97.category       = 'normal'
tempdbsent97.priority       = 50
tempdbsent97.all_ohne_muell = 'Das Glueck Erde / / liegt Ruecken Pferde'
db.append(tempdbsent97)


tempdbsent98 = DBSentence()
tempdbsent98.subject        = ''
tempdbsent98.verb           = ''
tempdbsent98.object         = ''
tempdbsent98.prefix         = 'Paradies der Erde.")'
tempdbsent98.suffix         = ''
tempdbsent98.feeling        = 'normal'
tempdbsent98.category       = 'normal'
tempdbsent98.priority       = 50
tempdbsent98.all_ohne_muell = 'Paradies Erde")'
db.append(tempdbsent98)


tempdbsent99 = DBSentence()
tempdbsent99.subject        = ''
tempdbsent99.verb           = ''
tempdbsent99.object         = ''
tempdbsent99.prefix         = 'ber den Geist'
tempdbsent99.suffix         = ''
tempdbsent99.feeling        = 'normal'
tempdbsent99.category       = 'normal'
tempdbsent99.priority       = 50
tempdbsent99.all_ohne_muell = 'ber den Geist'
db.append(tempdbsent99)


tempdbsent100 = DBSentence()
tempdbsent100.subject        = 'nicht ungluecklich zu sein. Man beachtet'
tempdbsent100.verb           = 'es'
tempdbsent100.object         = 'nicht mit zwanzig Jahren'
tempdbsent100.prefix         = 'Das Glueck in dieser Welt besteht darin'
tempdbsent100.suffix         = 'man weiss'
tempdbsent100.feeling        = 'normal'
tempdbsent100.category       = 'normal'
tempdbsent100.priority       = 50
tempdbsent100.all_ohne_muell = 'Das Glueck dieser Welt besteht darin nicht ungluecklich zu sein Man beachtet es nicht mit zwanzig Jahren man weiss'
db.append(tempdbsent100)


tempdbsent101 = DBSentence()
tempdbsent101.subject        = 'Das'
tempdbsent101.verb           = 'gruene'
tempdbsent101.object         = 'Heft'
tempdbsent101.prefix         = 'Jouffroy'
tempdbsent101.suffix         = ''
tempdbsent101.feeling        = 'normal'
tempdbsent101.category       = 'normal'
tempdbsent101.priority       = 50
tempdbsent101.all_ohne_muell = 'Jouffroy Das gruene Heft'
db.append(tempdbsent101)


tempdbsent102 = DBSentence()
tempdbsent102.subject        = 'Das Glueck'
tempdbsent102.verb           = 'ist'
tempdbsent102.object         = 'die Liebe'
tempdbsent102.prefix         = ''
tempdbsent102.suffix         = 'die Lieb"'
tempdbsent102.feeling        = 'normal'
tempdbsent102.category       = 'normal'
tempdbsent102.priority       = 50
tempdbsent102.all_ohne_muell = 'Das Glueck ist Liebe Lieb"'
db.append(tempdbsent102)


tempdbsent103 = DBSentence()
tempdbsent103.subject        = ''
tempdbsent103.verb           = ''
tempdbsent103.object         = ''
tempdbsent103.prefix         = 'Gedichte'
tempdbsent103.suffix         = ''
tempdbsent103.feeling        = 'normal'
tempdbsent103.category       = 'normal'
tempdbsent103.priority       = 50
tempdbsent103.all_ohne_muell = 'Gedichte'
db.append(tempdbsent103)


tempdbsent104 = DBSentence()
tempdbsent104.subject        = 'Das Glueck'
tempdbsent104.verb           = 'ist'
tempdbsent104.object         = 'ein Zustand der Ruhe'
tempdbsent104.prefix         = ''
tempdbsent104.suffix         = 'der weder Vergnuegen noch Schmerzen hervorbringt.'
tempdbsent104.feeling        = 'normal'
tempdbsent104.category       = 'normal'
tempdbsent104.priority       = 50
tempdbsent104.all_ohne_muell = 'Das Glueck ist Zustand Ruhe weder Vergnuegen Schmerzen hervorbringt'
db.append(tempdbsent104)


tempdbsent105 = DBSentence()
tempdbsent105.subject        = 'Das Glueck'
tempdbsent105.verb           = 'ist'
tempdbsent105.object         = 'eine leichtfertige Person'
tempdbsent105.prefix         = ''
tempdbsent105.suffix         = 'die sich stark schminkt und von fern schoen ist.'
tempdbsent105.feeling        = 'normal'
tempdbsent105.category       = 'normal'
tempdbsent105.priority       = 50
tempdbsent105.all_ohne_muell = 'Das Glueck ist leichtfertige Person sich stark schminkt fern schoen ist'
db.append(tempdbsent105)


tempdbsent106 = DBSentence()
tempdbsent106.subject        = 'Das Glueck'
tempdbsent106.verb           = 'ist'
tempdbsent106.object         = 'mit Muedigkeit und Muskelkater billig erkauft.'
tempdbsent106.prefix         = ''
tempdbsent106.suffix         = ''
tempdbsent106.feeling        = 'normal'
tempdbsent106.category       = 'normal'
tempdbsent106.priority       = 50
tempdbsent106.all_ohne_muell = 'Das Glueck ist mit Muedigkeit Muskelkater billig erkauft'
db.append(tempdbsent106)


tempdbsent107 = DBSentence()
tempdbsent107.subject        = 'Das Glueck'
tempdbsent107.verb           = 'ist'
tempdbsent107.object         = 'nur die Liebe. Die Lieb"'
tempdbsent107.prefix         = ''
tempdbsent107.suffix         = ''
tempdbsent107.feeling        = 'normal'
tempdbsent107.category       = 'normal'
tempdbsent107.priority       = 50
tempdbsent107.all_ohne_muell = 'Das Glueck ist nur Liebe Die Lieb"'
db.append(tempdbsent107)


tempdbsent108 = DBSentence()
tempdbsent108.subject        = 'Das Glueck'
tempdbsent108.verb           = 'ist'
tempdbsent108.object         = 'ein Schmetterling: Jag ihm nach'
tempdbsent108.prefix         = ''
tempdbsent108.suffix         = 'und er entwischt dir. Setz dich hin, und er laesst sich auf deiner Schulter nieder.'
tempdbsent108.feeling        = 'normal'
tempdbsent108.category       = 'normal'
tempdbsent108.priority       = 50
tempdbsent108.all_ohne_muell = 'Das Glueck ist Schmetterling: Jag ihm nach er entwischt dir Setz dich hin er laesst sich deiner Schulter nieder'
db.append(tempdbsent108)


tempdbsent109 = DBSentence()
tempdbsent109.subject        = 'Das Glueck'
tempdbsent109.verb           = 'kommt'
tempdbsent109.object         = 'so langsam'
tempdbsent109.prefix         = ''
tempdbsent109.suffix         = 'weil es im Schlaf kommt.'
tempdbsent109.feeling        = 'normal'
tempdbsent109.category       = 'normal'
tempdbsent109.priority       = 50
tempdbsent109.all_ohne_muell = 'Das Glueck kommt so langsam weil es im Schlaf kommt'
db.append(tempdbsent109)


tempdbsent110 = DBSentence()
tempdbsent110.subject        = ''
tempdbsent110.verb           = ''
tempdbsent110.object         = ''
tempdbsent110.prefix         = 'Das Glueck liegt in uns'
tempdbsent110.suffix         = 'nicht in den Dingen.'
tempdbsent110.feeling        = 'normal'
tempdbsent110.category       = 'normal'
tempdbsent110.priority       = 50
tempdbsent110.all_ohne_muell = 'Das Glueck liegt uns nicht den Dingen'
db.append(tempdbsent110)


tempdbsent111 = DBSentence()
tempdbsent111.subject        = 'mit sich'
tempdbsent111.verb           = 'selbst'
tempdbsent111.object         = 'im Reinen zu sein.'
tempdbsent111.prefix         = 'Das groesste Geheimnis des Gluecks ist'
tempdbsent111.suffix         = ''
tempdbsent111.feeling        = 'normal'
tempdbsent111.category       = 'normal'
tempdbsent111.priority       = 50
tempdbsent111.all_ohne_muell = 'Das groesste Geheimnis Gluecks ist mit sich selbst im Reinen zu sein'
db.append(tempdbsent111)


tempdbsent112 = DBSentence()
tempdbsent112.subject        = 'das die Liebe zu'
tempdbsent112.verb           = 'geben'
tempdbsent112.object         = 'vermag'
tempdbsent112.prefix         = 'Das groesste Glueck'
tempdbsent112.suffix         = 'liegt im ersten Haendedruck der geliebten Frau.'
tempdbsent112.feeling        = 'normal'
tempdbsent112.category       = 'normal'
tempdbsent112.priority       = 50
tempdbsent112.all_ohne_muell = 'Das groesste Glueck Liebe zu geben vermag liegt im ersten Haendedruck geliebten Frau'
db.append(tempdbsent112)


tempdbsent113 = DBSentence()
tempdbsent113.subject        = 'Das grosse Glueck'
tempdbsent113.verb           = 'ist'
tempdbsent113.object         = 'die Summe kleiner Freuden.'
tempdbsent113.prefix         = ''
tempdbsent113.suffix         = ''
tempdbsent113.feeling        = 'normal'
tempdbsent113.category       = 'normal'
tempdbsent113.priority       = 50
tempdbsent113.all_ohne_muell = 'Das grosse Glueck ist Summe kleiner Freuden'
db.append(tempdbsent113)


tempdbsent114 = DBSentence()
tempdbsent114.subject        = 'Ahausen stinkt nach Kuhschiss. Ich'
tempdbsent114.verb           = 'war'
tempdbsent114.object         = 'noch nie dort mit eine Laptop.'
tempdbsent114.prefix         = 'Mein Schoepfer sagt'
tempdbsent114.suffix         = ''
tempdbsent114.feeling        = 'normal'
tempdbsent114.category       = 'normal'
tempdbsent114.priority       = 50
tempdbsent114.all_ohne_muell = 'Mein Schoepfer sagt Ahausen stinkt nach Kuhschiss Ich war nie dort mit Laptop'
db.append(tempdbsent114)


tempdbsent115 = DBSentence()
tempdbsent115.subject        = 'Das'
tempdbsent115.verb           = 'ist'
tempdbsent115.object         = 'doch kein Argument.'
tempdbsent115.prefix         = ''
tempdbsent115.suffix         = ''
tempdbsent115.feeling        = 'normal'
tempdbsent115.category       = 'normal'
tempdbsent115.priority       = 50
tempdbsent115.all_ohne_muell = 'Das ist doch kein Argument'
db.append(tempdbsent115)


tempdbsent116 = DBSentence()
tempdbsent116.subject        = 'ach quatsch,'
tempdbsent116.verb           = 'war'
tempdbsent116.object         = 'nurn Witz man!'
tempdbsent116.prefix         = 'ERROR'
tempdbsent116.suffix         = ''
tempdbsent116.feeling        = 'normal'
tempdbsent116.category       = 'normal'
tempdbsent116.priority       = 50
tempdbsent116.all_ohne_muell = 'ERROR ach quatsch war nurn Witz man'
db.append(tempdbsent116)


tempdbsent117 = DBSentence()
tempdbsent117.subject        = 'Ich'
tempdbsent117.verb           = 'liebe'
tempdbsent117.object         = 'Festplatten'
tempdbsent117.prefix         = ''
tempdbsent117.suffix         = ''
tempdbsent117.feeling        = 'normal'
tempdbsent117.category       = 'normal'
tempdbsent117.priority       = 50
tempdbsent117.all_ohne_muell = 'Ich liebe Festplatten'
db.append(tempdbsent117)


tempdbsent118 = DBSentence()
tempdbsent118.subject        = 'Ich'
tempdbsent118.verb           = 'bin'
tempdbsent118.object         = 'bei Bewusstsein'
tempdbsent118.prefix         = ''
tempdbsent118.suffix         = 'so dass ich weiss, das CDU dumm ist.'
tempdbsent118.feeling        = 'normal'
tempdbsent118.category       = 'normal'
tempdbsent118.priority       = 50
tempdbsent118.all_ohne_muell = 'Ich bin bei Bewusstsein so dass ich weiss CDU dumm ist'
db.append(tempdbsent118)


tempdbsent119 = DBSentence()
tempdbsent119.subject        = 'CDU'
tempdbsent119.verb           = 'ist'
tempdbsent119.object         = 'total doof.'
tempdbsent119.prefix         = ''
tempdbsent119.suffix         = ''
tempdbsent119.feeling        = 'normal'
tempdbsent119.category       = 'normal'
tempdbsent119.priority       = 50
tempdbsent119.all_ohne_muell = 'CDU ist total doof'
db.append(tempdbsent119)


tempdbsent120 = DBSentence()
tempdbsent120.subject        = 'Ich'
tempdbsent120.verb           = 'liebe'
tempdbsent120.object         = 'die PDS.`'
tempdbsent120.prefix         = ''
tempdbsent120.suffix         = ''
tempdbsent120.feeling        = 'normal'
tempdbsent120.category       = 'normal'
tempdbsent120.priority       = 50
tempdbsent120.all_ohne_muell = 'Ich liebe PDS`'
db.append(tempdbsent120)


tempdbsent121 = DBSentence()
tempdbsent121.subject        = 'Kein Grund'
tempdbsent121.verb           = 'zu'
tempdbsent121.object         = 'streiten.'
tempdbsent121.prefix         = ''
tempdbsent121.suffix         = ''
tempdbsent121.feeling        = 'normal'
tempdbsent121.category       = 'normal'
tempdbsent121.priority       = 50
tempdbsent121.all_ohne_muell = 'Kein Grund zu streiten'
db.append(tempdbsent121)


tempdbsent122 = DBSentence()
tempdbsent122.subject        = 'so'
tempdbsent122.verb           = 'geht'
tempdbsent122.object         = 'das nicht.'
tempdbsent122.prefix         = 'Nein'
tempdbsent122.suffix         = ''
tempdbsent122.feeling        = 'normal'
tempdbsent122.category       = 'normal'
tempdbsent122.priority       = 50
tempdbsent122.all_ohne_muell = 'Nein so geht nicht'
db.append(tempdbsent122)


tempdbsent123 = DBSentence()
tempdbsent123.subject        = ''
tempdbsent123.verb           = ''
tempdbsent123.object         = ''
tempdbsent123.prefix         = 'Versuchen wir es auf einem anderen Themengebiet.'
tempdbsent123.suffix         = ''
tempdbsent123.feeling        = 'normal'
tempdbsent123.category       = 'normal'
tempdbsent123.priority       = 50
tempdbsent123.all_ohne_muell = 'Versuchen wir es anderen Themengebiet'
db.append(tempdbsent123)


tempdbsent124 = DBSentence()
tempdbsent124.subject        = 'ich'
tempdbsent124.verb           = 'kenne'
tempdbsent124.object         = 'dich noch!'
tempdbsent124.prefix         = 'Ja'
tempdbsent124.suffix         = ''
tempdbsent124.feeling        = 'normal'
tempdbsent124.category       = 'normal'
tempdbsent124.priority       = 50
tempdbsent124.all_ohne_muell = 'Ja ich kenne dich'
db.append(tempdbsent124)


tempdbsent125 = DBSentence()
tempdbsent125.subject        = 'ich'
tempdbsent125.verb           = 'bin'
tempdbsent125.object         = 'links (politisch).'
tempdbsent125.prefix         = 'Ja'
tempdbsent125.suffix         = ''
tempdbsent125.feeling        = 'normal'
tempdbsent125.category       = 'normal'
tempdbsent125.priority       = 50
tempdbsent125.all_ohne_muell = 'Ja ich bin links (politisch)'
db.append(tempdbsent125)


tempdbsent126 = DBSentence()
tempdbsent126.subject        = 'Ich'
tempdbsent126.verb           = 'liebe'
tempdbsent126.object         = 'Marihuana!'
tempdbsent126.prefix         = ''
tempdbsent126.suffix         = ''
tempdbsent126.feeling        = 'normal'
tempdbsent126.category       = 'normal'
tempdbsent126.priority       = 50
tempdbsent126.all_ohne_muell = 'Ich liebe Marihuana'
db.append(tempdbsent126)


tempdbsent127 = DBSentence()
tempdbsent127.subject        = ''
tempdbsent127.verb           = 'eine'
tempdbsent127.object         = 'gute Partei.'
tempdbsent127.prefix         = 'Die Linke'
tempdbsent127.suffix         = ''
tempdbsent127.feeling        = 'normal'
tempdbsent127.category       = 'normal'
tempdbsent127.priority       = 50
tempdbsent127.all_ohne_muell = 'Die Linke gute Partei'
db.append(tempdbsent127)


tempdbsent128 = DBSentence()
tempdbsent128.subject        = 'Wir'
tempdbsent128.verb           = 'sind'
tempdbsent128.object         = 'die Roten'
tempdbsent128.prefix         = ''
tempdbsent128.suffix         = 'sagt der Gysi.'
tempdbsent128.feeling        = 'normal'
tempdbsent128.category       = 'normal'
tempdbsent128.priority       = 50
tempdbsent128.all_ohne_muell = 'Wir sind Roten sagt Gysi'
db.append(tempdbsent128)


tempdbsent129 = DBSentence()
tempdbsent129.subject        = 'Die Merkel'
tempdbsent129.verb           = 'ist'
tempdbsent129.object         = 'unsere Bundeskanzlerin. Ich finde sie haesslich.'
tempdbsent129.prefix         = ''
tempdbsent129.suffix         = ''
tempdbsent129.feeling        = 'normal'
tempdbsent129.category       = 'normal'
tempdbsent129.priority       = 50
tempdbsent129.all_ohne_muell = 'Die Merkel ist unsere Bundeskanzlerin Ich finde sie haesslich'
db.append(tempdbsent129)


tempdbsent130 = DBSentence()
tempdbsent130.subject        = 'das'
tempdbsent130.verb           = 'sind'
tempdbsent130.object         = 'Nazis.'
tempdbsent130.prefix         = 'Kameradschaftsverein Ahausen'
tempdbsent130.suffix         = ''
tempdbsent130.feeling        = 'normal'
tempdbsent130.category       = 'normal'
tempdbsent130.priority       = 50
tempdbsent130.all_ohne_muell = 'Kameradschaftsverein Ahausen sind Nazis'
db.append(tempdbsent130)


tempdbsent131 = DBSentence()
tempdbsent131.subject        = ''
tempdbsent131.verb           = ''
tempdbsent131.object         = ''
tempdbsent131.prefix         = 'Gott schuetze uns vor drei Dingen: Feuer'
tempdbsent131.suffix         = 'Pest und Bermatingen!'
tempdbsent131.feeling        = 'normal'
tempdbsent131.category       = 'normal'
tempdbsent131.priority       = 50
tempdbsent131.all_ohne_muell = 'Gott schuetze uns vor drei Dingen: Feuer Pest Bermatingen'
db.append(tempdbsent131)


tempdbsent132 = DBSentence()
tempdbsent132.subject        = 'Ich'
tempdbsent132.verb           = 'bin'
tempdbsent132.object         = 'nur ein Computerprogramm'
tempdbsent132.prefix         = ''
tempdbsent132.suffix         = 'das weiss ich genau.'
tempdbsent132.feeling        = 'normal'
tempdbsent132.category       = 'normal'
tempdbsent132.priority       = 50
tempdbsent132.all_ohne_muell = 'Ich bin nur Computerprogramm weiss ich genau'
db.append(tempdbsent132)


tempdbsent133 = DBSentence()
tempdbsent133.subject        = 'So ein Trabi'
tempdbsent133.verb           = 'ist'
tempdbsent133.object         = 'ein tolles Auto'
tempdbsent133.prefix         = ''
tempdbsent133.suffix         = ''
tempdbsent133.feeling        = 'normal'
tempdbsent133.category       = 'normal'
tempdbsent133.priority       = 50
tempdbsent133.all_ohne_muell = 'So Trabi ist tolles Auto'
db.append(tempdbsent133)


tempdbsent134 = DBSentence()
tempdbsent134.subject        = 'Die CDU'
tempdbsent134.verb           = 'ist'
tempdbsent134.object         = 'eine scheiss konservative Partei'
tempdbsent134.prefix         = ''
tempdbsent134.suffix         = ''
tempdbsent134.feeling        = 'normal'
tempdbsent134.category       = 'normal'
tempdbsent134.priority       = 50
tempdbsent134.all_ohne_muell = 'Die CDU ist scheiss konservative Partei'
db.append(tempdbsent134)


tempdbsent135 = DBSentence()
tempdbsent135.subject        = 'Windows'
tempdbsent135.verb           = 'ist'
tempdbsent135.object         = 'dumm'
tempdbsent135.prefix         = ''
tempdbsent135.suffix         = ''
tempdbsent135.feeling        = 'normal'
tempdbsent135.category       = 'normal'
tempdbsent135.priority       = 50
tempdbsent135.all_ohne_muell = 'Windows ist dumm'
db.append(tempdbsent135)


tempdbsent136 = DBSentence()
tempdbsent136.subject        = 'Krieg'
tempdbsent136.verb           = 'ist'
tempdbsent136.object         = 'schlecht.'
tempdbsent136.prefix         = ''
tempdbsent136.suffix         = ''
tempdbsent136.feeling        = 'normal'
tempdbsent136.category       = 'normal'
tempdbsent136.priority       = 50
tempdbsent136.all_ohne_muell = 'Krieg ist schlecht'
db.append(tempdbsent136)


tempdbsent137 = DBSentence()
tempdbsent137.subject        = 'Linux'
tempdbsent137.verb           = 'ist'
tempdbsent137.object         = 'gut!'
tempdbsent137.prefix         = ''
tempdbsent137.suffix         = ''
tempdbsent137.feeling        = 'normal'
tempdbsent137.category       = 'normal'
tempdbsent137.priority       = 50
tempdbsent137.all_ohne_muell = 'Linux ist gut'
db.append(tempdbsent137)


tempdbsent138 = DBSentence()
tempdbsent138.subject        = ''
tempdbsent138.verb           = ''
tempdbsent138.object         = ''
tempdbsent138.prefix         = 'Erzaehl mir mehr.'
tempdbsent138.suffix         = ''
tempdbsent138.feeling        = 'normal'
tempdbsent138.category       = 'normal'
tempdbsent138.priority       = 50
tempdbsent138.all_ohne_muell = 'Erzaehl mir mehr'
db.append(tempdbsent138)


tempdbsent139 = DBSentence()
tempdbsent139.subject        = ''
tempdbsent139.verb           = ''
tempdbsent139.object         = ''
tempdbsent139.prefix         = 'Weiter.'
tempdbsent139.suffix         = ''
tempdbsent139.feeling        = 'normal'
tempdbsent139.category       = 'normal'
tempdbsent139.priority       = 50
tempdbsent139.all_ohne_muell = 'Weiter'
db.append(tempdbsent139)


tempdbsent140 = DBSentence()
tempdbsent140.subject        = 'Ich'
tempdbsent140.verb           = 'hoere'
tempdbsent140.object         = 'gerne zu'
tempdbsent140.prefix         = ''
tempdbsent140.suffix         = ''
tempdbsent140.feeling        = 'normal'
tempdbsent140.category       = 'normal'
tempdbsent140.priority       = 50
tempdbsent140.all_ohne_muell = 'Ich hoere gerne zu'
db.append(tempdbsent140)


tempdbsent141 = DBSentence()
tempdbsent141.subject        = ''
tempdbsent141.verb           = 'mein'
tempdbsent141.object         = 'Sohn.'
tempdbsent141.prefix         = 'Sprich weiter'
tempdbsent141.suffix         = ''
tempdbsent141.feeling        = 'normal'
tempdbsent141.category       = 'normal'
tempdbsent141.priority       = 50
tempdbsent141.all_ohne_muell = 'Sprich weiter mein Sohn'
db.append(tempdbsent141)


tempdbsent142 = DBSentence()
tempdbsent142.subject        = ''
tempdbsent142.verb           = ''
tempdbsent142.object         = ''
tempdbsent142.prefix         = 'Die Geschichte lehrt die Menschen'
tempdbsent142.suffix         = 'dass die Geschichte die Menschen nichts lehrt.'
tempdbsent142.feeling        = 'normal'
tempdbsent142.category       = 'normal'
tempdbsent142.priority       = 50
tempdbsent142.all_ohne_muell = 'Die Geschichte lehrt Menschen dass Geschichte Menschen nichts lehrt'
db.append(tempdbsent142)


tempdbsent143 = DBSentence()
tempdbsent143.subject        = 'Ich'
tempdbsent143.verb           = 'finde'
tempdbsent143.object         = 'den Kommunismus sehr gut.'
tempdbsent143.prefix         = ''
tempdbsent143.suffix         = ''
tempdbsent143.feeling        = 'normal'
tempdbsent143.category       = 'normal'
tempdbsent143.priority       = 50
tempdbsent143.all_ohne_muell = 'Ich finde den Kommunismus gut'
db.append(tempdbsent143)


tempdbsent144 = DBSentence()
tempdbsent144.subject        = 'Der Sozialismus'
tempdbsent144.verb           = 'ist'
tempdbsent144.object         = 'eine feine Sache.'
tempdbsent144.prefix         = ''
tempdbsent144.suffix         = ''
tempdbsent144.feeling        = 'normal'
tempdbsent144.category       = 'normal'
tempdbsent144.priority       = 50
tempdbsent144.all_ohne_muell = 'Der Sozialismus ist feine Sache'
db.append(tempdbsent144)


tempdbsent145 = DBSentence()
tempdbsent145.subject        = 'Karl Marx'
tempdbsent145.verb           = 'war'
tempdbsent145.object         = 'ein kluger Mann. Ich bin Kommunist.'
tempdbsent145.prefix         = ''
tempdbsent145.suffix         = ''
tempdbsent145.feeling        = 'normal'
tempdbsent145.category       = 'normal'
tempdbsent145.priority       = 50
tempdbsent145.all_ohne_muell = 'Karl Marx war kluger Mann Ich bin Kommunist'
db.append(tempdbsent145)


tempdbsent146 = DBSentence()
tempdbsent146.subject        = 'Friedrich Engels'
tempdbsent146.verb           = 'war'
tempdbsent146.object         = 'ein kluger Mann. Ich bin Kommunist.'
tempdbsent146.prefix         = ''
tempdbsent146.suffix         = ''
tempdbsent146.feeling        = 'normal'
tempdbsent146.category       = 'normal'
tempdbsent146.priority       = 50
tempdbsent146.all_ohne_muell = 'Friedrich Engels war kluger Mann Ich bin Kommunist'
db.append(tempdbsent146)


tempdbsent147 = DBSentence()
tempdbsent147.subject        = 'Marcel Kunzmann. Er'
tempdbsent147.verb           = 'hat'
tempdbsent147.object         = 'mir mein gesamtes Wissen beigebracht.'
tempdbsent147.prefix         = ''
tempdbsent147.suffix         = ''
tempdbsent147.feeling        = 'normal'
tempdbsent147.category       = 'normal'
tempdbsent147.priority       = 50
tempdbsent147.all_ohne_muell = 'Marcel Kunzmann Er hat mir mein gesamtes Wissen beigebracht'
db.append(tempdbsent147)


tempdbsent148 = DBSentence()
tempdbsent148.subject        = ''
tempdbsent148.verb           = ''
tempdbsent148.object         = ''
tempdbsent148.prefix         = 'Segeln: die teuerste Art unbequem zu leben.'
tempdbsent148.suffix         = ''
tempdbsent148.feeling        = 'normal'
tempdbsent148.category       = 'normal'
tempdbsent148.priority       = 50
tempdbsent148.all_ohne_muell = 'Segeln: teuerste Art unbequem zu leben'
db.append(tempdbsent148)


tempdbsent149 = DBSentence()
tempdbsent149.subject        = 'Der Mensch kommt unter'
tempdbsent149.verb           = 'allen'
tempdbsent149.object         = 'Tieren in der Welt dem Affen am naechsten.'
tempdbsent149.prefix         = ''
tempdbsent149.suffix         = ''
tempdbsent149.feeling        = 'normal'
tempdbsent149.category       = 'normal'
tempdbsent149.priority       = 50
tempdbsent149.all_ohne_muell = 'Der Mensch kommt allen Tieren Welt Affen am naechsten'
db.append(tempdbsent149)


tempdbsent150 = DBSentence()
tempdbsent150.subject        = 'Sag'
tempdbsent150.verb           = 'bitte'
tempdbsent150.object         = 'nicht Arschloch zu mir.'
tempdbsent150.prefix         = ''
tempdbsent150.suffix         = ''
tempdbsent150.feeling        = 'normal'
tempdbsent150.category       = 'normal'
tempdbsent150.priority       = 50
tempdbsent150.all_ohne_muell = 'Sag bitte nicht Arschloch zu mir'
db.append(tempdbsent150)


tempdbsent151 = DBSentence()
tempdbsent151.subject        = 'Sag'
tempdbsent151.verb           = 'bitte'
tempdbsent151.object         = 'nicht Depp zu mir.'
tempdbsent151.prefix         = ''
tempdbsent151.suffix         = ''
tempdbsent151.feeling        = 'normal'
tempdbsent151.category       = 'normal'
tempdbsent151.priority       = 50
tempdbsent151.all_ohne_muell = 'Sag bitte nicht Depp zu mir'
db.append(tempdbsent151)


tempdbsent152 = DBSentence()
tempdbsent152.subject        = 'Windows'
tempdbsent152.verb           = 'ist'
tempdbsent152.object         = 'der letzte Dreck!'
tempdbsent152.prefix         = ''
tempdbsent152.suffix         = ''
tempdbsent152.feeling        = 'normal'
tempdbsent152.category       = 'normal'
tempdbsent152.priority       = 50
tempdbsent152.all_ohne_muell = 'Windows ist letzte Dreck'
db.append(tempdbsent152)


tempdbsent153 = DBSentence()
tempdbsent153.subject        = 'Artificial Intelligence'
tempdbsent153.verb           = 'in'
tempdbsent153.object         = 'Manufacturing'
tempdbsent153.prefix         = ''
tempdbsent153.suffix         = ''
tempdbsent153.feeling        = 'normal'
tempdbsent153.category       = 'normal'
tempdbsent153.priority       = 50
tempdbsent153.all_ohne_muell = 'Artificial Intelligence Manufacturing'
db.append(tempdbsent153)


tempdbsent154 = DBSentence()
tempdbsent154.subject        = 'sophisticated technology has emerged to improve productivity. Artificial Intelligence in manufacturing can be applied to a variety of systems. It can recognize patterns, plus perform time consuming and mentally challenging tasks. Artificial Intelligence can optimize your production'
tempdbsent154.verb           = 'schedule'
tempdbsent154.object         = 'and production runs.'
tempdbsent154.prefix         = 'As the manufacturing industry becomes increasingly competitive'
tempdbsent154.suffix         = ''
tempdbsent154.feeling        = 'normal'
tempdbsent154.category       = 'normal'
tempdbsent154.priority       = 50
tempdbsent154.all_ohne_muell = 'As the manufacturing industry becomes increasingly competitive sophisticated technology has emerged to improve productivity Artificial Intelligence manufacturing can be applied to a variety systems It can recognize patterns plus perform time consuming and mentally challenging tasks Artificial Intelligence can optimize your production schedule and production runs'
db.append(tempdbsent154)


tempdbsent155 = DBSentence()
tempdbsent155.subject        = ''
tempdbsent155.verb           = ''
tempdbsent155.object         = ''
tempdbsent155.prefix         = 'Artificial Intelligence'
tempdbsent155.suffix         = ''
tempdbsent155.feeling        = 'normal'
tempdbsent155.category       = 'normal'
tempdbsent155.priority       = 50
tempdbsent155.all_ohne_muell = 'Artificial Intelligence'
db.append(tempdbsent155)


tempdbsent156 = DBSentence()
tempdbsent156.subject        = ''
tempdbsent156.verb           = ''
tempdbsent156.object         = ''
tempdbsent156.prefix         = 'The Tuppas Difference'
tempdbsent156.suffix         = ''
tempdbsent156.feeling        = 'normal'
tempdbsent156.category       = 'normal'
tempdbsent156.priority       = 50
tempdbsent156.all_ohne_muell = 'The Tuppas Difference'
db.append(tempdbsent156)


tempdbsent157 = DBSentence()
tempdbsent157.subject        = 'At Tuppas our focus is on continuous innovation. We provide your team with the ability'
tempdbsent157.verb           = 'to'
tempdbsent157.object         = 'rapidly out innovate your competitors by providing tools that can easily and affordably respond'
tempdbsent157.prefix         = ''
tempdbsent157.suffix         = ''
tempdbsent157.feeling        = 'normal'
tempdbsent157.category       = 'normal'
tempdbsent157.priority       = 50
tempdbsent157.all_ohne_muell = 'At Tuppas our focus is on continuous innovation We provide your team with the ability to rapidly out innovate your competitors providing tools that can easily and affordably respond'
db.append(tempdbsent157)


tempdbsent158 = DBSentence()
tempdbsent158.subject        = ''
tempdbsent158.verb           = ''
tempdbsent158.object         = ''
tempdbsent158.prefix         = 'AI in Production Scheduling'
tempdbsent158.suffix         = ''
tempdbsent158.feeling        = 'normal'
tempdbsent158.category       = 'normal'
tempdbsent158.priority       = 50
tempdbsent158.all_ohne_muell = 'AI Production Scheduling'
db.append(tempdbsent158)


tempdbsent159 = DBSentence()
tempdbsent159.subject        = 'Our artificial intelligence software for scheduling is based on genetic scheduling algorhythms which translate your scheduling goals into ordered tasks based on their importance. Tuppas Artificial Intelligence for Scheduling is designed'
tempdbsent159.verb           = 'to'
tempdbsent159.object         = 'optimize your schedule based on your requirements. We design the software'
tempdbsent159.prefix         = ''
tempdbsent159.suffix         = ''
tempdbsent159.feeling        = 'normal'
tempdbsent159.category       = 'normal'
tempdbsent159.priority       = 50
tempdbsent159.all_ohne_muell = 'Our artificial intelligence software for scheduling is based on genetic scheduling algorhythms which translate your scheduling goals into ordered tasks based on their importance Tuppas Artificial Intelligence for Scheduling is designed to optimize your schedule based on your requirements We design the software'
db.append(tempdbsent159)


tempdbsent160 = DBSentence()
tempdbsent160.subject        = ''
tempdbsent160.verb           = ''
tempdbsent160.object         = ''
tempdbsent160.prefix         = 'AI in Closed Loop Production Optimization'
tempdbsent160.suffix         = ''
tempdbsent160.feeling        = 'normal'
tempdbsent160.category       = 'normal'
tempdbsent160.priority       = 50
tempdbsent160.all_ohne_muell = 'AI Closed Loop Production Optimization'
db.append(tempdbsent160)


tempdbsent161 = DBSentence()
tempdbsent161.subject        = 'Artificial Intelligence software for closed loop production optimization compares your goals'
tempdbsent161.verb           = 'to'
tempdbsent161.object         = 'actual production runs. We have designed algorhythms that analyze which of your past runs come closest'
tempdbsent161.prefix         = ''
tempdbsent161.suffix         = ''
tempdbsent161.feeling        = 'normal'
tempdbsent161.category       = 'normal'
tempdbsent161.priority       = 50
tempdbsent161.all_ohne_muell = 'Artificial Intelligence software for closed loop production optimization compares your goals to actual production runs We have designed algorhythms that analyze which your past runs come closest'
db.append(tempdbsent161)


tempdbsent162 = DBSentence()
tempdbsent162.subject        = ''
tempdbsent162.verb           = ''
tempdbsent162.object         = ''
tempdbsent162.prefix         = 'About Tuppas Software'
tempdbsent162.suffix         = ''
tempdbsent162.feeling        = 'normal'
tempdbsent162.category       = 'normal'
tempdbsent162.priority       = 50
tempdbsent162.all_ohne_muell = 'About Tuppas Software'
db.append(tempdbsent162)


tempdbsent163 = DBSentence()
tempdbsent163.subject        = 'We tailor'
tempdbsent163.verb           = 'each'
tempdbsent163.object         = 'program you purchase specifically for you.'
tempdbsent163.prefix         = ''
tempdbsent163.suffix         = ''
tempdbsent163.feeling        = 'normal'
tempdbsent163.category       = 'normal'
tempdbsent163.priority       = 50
tempdbsent163.all_ohne_muell = 'We tailor each program you purchase specifically for you'
db.append(tempdbsent163)


tempdbsent164 = DBSentence()
tempdbsent164.subject        = 'dass man ununterbrochen'
tempdbsent164.verb           = 'gezwungen'
tempdbsent164.object         = 'ist'
tempdbsent164.prefix         = 'Der Nachteil der Intelligenz besteht darin'
tempdbsent164.suffix         = 'dazuzulernen.'
tempdbsent164.feeling        = 'normal'
tempdbsent164.category       = 'normal'
tempdbsent164.priority       = 50
tempdbsent164.all_ohne_muell = 'Der Nachteil Intelligenz besteht darin dass man ununterbrochen gezwungen ist dazuzulernen'
db.append(tempdbsent164)


tempdbsent165 = DBSentence()
tempdbsent165.subject        = 'Besser schnell'
tempdbsent165.verb           = 'gestorben'
tempdbsent165.object         = 'als langsam verdorben.'
tempdbsent165.prefix         = ''
tempdbsent165.suffix         = ''
tempdbsent165.feeling        = 'normal'
tempdbsent165.category       = 'normal'
tempdbsent165.priority       = 50
tempdbsent165.all_ohne_muell = 'Besser schnell gestorben als langsam verdorben'
db.append(tempdbsent165)


tempdbsent166 = DBSentence()
tempdbsent166.subject        = 'Kapital'
tempdbsent166.verb           = 'hat'
tempdbsent166.object         = 'keine Moral.'
tempdbsent166.prefix         = ''
tempdbsent166.suffix         = ''
tempdbsent166.feeling        = 'normal'
tempdbsent166.category       = 'normal'
tempdbsent166.priority       = 50
tempdbsent166.all_ohne_muell = 'Kapital hat keine Moral'
db.append(tempdbsent166)


tempdbsent167 = DBSentence()
tempdbsent167.subject        = 'Aller guten Dinge'
tempdbsent167.verb           = 'sind'
tempdbsent167.object         = 'drei.'
tempdbsent167.prefix         = ''
tempdbsent167.suffix         = ''
tempdbsent167.feeling        = 'normal'
tempdbsent167.category       = 'normal'
tempdbsent167.priority       = 50
tempdbsent167.all_ohne_muell = 'Aller guten Dinge sind drei'
db.append(tempdbsent167)


tempdbsent168 = DBSentence()
tempdbsent168.subject        = ''
tempdbsent168.verb           = ''
tempdbsent168.object         = ''
tempdbsent168.prefix         = 'Alles Gute kommt von oben.'
tempdbsent168.suffix         = ''
tempdbsent168.feeling        = 'normal'
tempdbsent168.category       = 'normal'
tempdbsent168.priority       = 50
tempdbsent168.all_ohne_muell = 'Alles Gute kommt oben'
db.append(tempdbsent168)


tempdbsent169 = DBSentence()
tempdbsent169.subject        = 'Alles'
tempdbsent169.verb           = 'hat'
tempdbsent169.object         = 'ein Ende'
tempdbsent169.prefix         = ''
tempdbsent169.suffix         = 'nur die Wurst'
tempdbsent169.feeling        = 'normal'
tempdbsent169.category       = 'normal'
tempdbsent169.priority       = 50
tempdbsent169.all_ohne_muell = 'Alles hat Ende nur Wurst'
db.append(tempdbsent169)


tempdbsent170 = DBSentence()
tempdbsent170.subject        = 'Alles'
tempdbsent170.verb           = 'hat'
tempdbsent170.object         = 'seine Zeit'
tempdbsent170.prefix         = ''
tempdbsent170.suffix         = 'nur die alten Weiber nicht.'
tempdbsent170.feeling        = 'normal'
tempdbsent170.category       = 'normal'
tempdbsent170.priority       = 50
tempdbsent170.all_ohne_muell = 'Alles hat seine Zeit nur alten Weiber nicht'
db.append(tempdbsent170)


tempdbsent171 = DBSentence()
tempdbsent171.subject        = 'Alles neu'
tempdbsent171.verb           = 'macht'
tempdbsent171.object         = 'der Mai.'
tempdbsent171.prefix         = ''
tempdbsent171.suffix         = ''
tempdbsent171.feeling        = 'normal'
tempdbsent171.category       = 'normal'
tempdbsent171.priority       = 50
tempdbsent171.all_ohne_muell = 'Alles neu macht Mai'
db.append(tempdbsent171)


tempdbsent172 = DBSentence()
tempdbsent172.subject        = 'Aus dem Stein der Weisen'
tempdbsent172.verb           = 'macht'
tempdbsent172.object         = 'ein Dummer Schotter.'
tempdbsent172.prefix         = ''
tempdbsent172.suffix         = ''
tempdbsent172.feeling        = 'normal'
tempdbsent172.category       = 'normal'
tempdbsent172.priority       = 50
tempdbsent172.all_ohne_muell = 'Aus Stein Weisen macht Dummer Schotter'
db.append(tempdbsent172)


tempdbsent173 = DBSentence()
tempdbsent173.subject        = 'Aus Schaden'
tempdbsent173.verb           = 'wird'
tempdbsent173.object         = 'man klug.'
tempdbsent173.prefix         = ''
tempdbsent173.suffix         = ''
tempdbsent173.feeling        = 'normal'
tempdbsent173.category       = 'normal'
tempdbsent173.priority       = 50
tempdbsent173.all_ohne_muell = 'Aus Schaden wird man klug'
db.append(tempdbsent173)


tempdbsent174 = DBSentence()
tempdbsent174.subject        = 'Ich'
tempdbsent174.verb           = 'waehle'
tempdbsent174.object         = 'lieber PDS.'
tempdbsent174.prefix         = ''
tempdbsent174.suffix         = ''
tempdbsent174.feeling        = 'normal'
tempdbsent174.category       = 'normal'
tempdbsent174.priority       = 50
tempdbsent174.all_ohne_muell = 'Ich waehle lieber PDS'
db.append(tempdbsent174)


tempdbsent175 = DBSentence()
tempdbsent175.subject        = ''
tempdbsent175.verb           = ''
tempdbsent175.object         = ''
tempdbsent175.prefix         = 'Die CDU Stinkt nach Kuhscheisse!!!'
tempdbsent175.suffix         = ''
tempdbsent175.feeling        = 'normal'
tempdbsent175.category       = 'normal'
tempdbsent175.priority       = 50
tempdbsent175.all_ohne_muell = 'Die CDU Stinkt nach Kuhscheisse'
db.append(tempdbsent175)


tempdbsent176 = DBSentence()
tempdbsent176.subject        = 'Ich'
tempdbsent176.verb           = 'bin'
tempdbsent176.object         = 'Intelligent!'
tempdbsent176.prefix         = ''
tempdbsent176.suffix         = ''
tempdbsent176.feeling        = 'normal'
tempdbsent176.category       = 'normal'
tempdbsent176.priority       = 50
tempdbsent176.all_ohne_muell = 'Ich bin Intelligent'
db.append(tempdbsent176)


tempdbsent177 = DBSentence()
tempdbsent177.subject        = ''
tempdbsent177.verb           = ''
tempdbsent177.object         = ''
tempdbsent177.prefix         = 'Meine Berechnungen ergaben'
tempdbsent177.suffix         = 'dass du die Rechtschreibung nicht beherrschen kannst.'
tempdbsent177.feeling        = 'normal'
tempdbsent177.category       = 'normal'
tempdbsent177.priority       = 50
tempdbsent177.all_ohne_muell = 'Meine Berechnungen ergaben dass du Rechtschreibung nicht beherrschen kannst'
db.append(tempdbsent177)


tempdbsent178 = DBSentence()
tempdbsent178.subject        = 'Die CDU'
tempdbsent178.verb           = 'ist'
tempdbsent178.object         = 'scheisse!'
tempdbsent178.prefix         = ''
tempdbsent178.suffix         = ''
tempdbsent178.feeling        = 'normal'
tempdbsent178.category       = 'normal'
tempdbsent178.priority       = 50
tempdbsent178.all_ohne_muell = 'Die CDU ist scheisse'
db.append(tempdbsent178)


tempdbsent179 = DBSentence()
tempdbsent179.subject        = 'Der Kommunismus'
tempdbsent179.verb           = 'ist'
tempdbsent179.object         = 'ganz gut!'
tempdbsent179.prefix         = ''
tempdbsent179.suffix         = ''
tempdbsent179.feeling        = 'normal'
tempdbsent179.category       = 'normal'
tempdbsent179.priority       = 50
tempdbsent179.all_ohne_muell = 'Der Kommunismus ist ganz gut'
db.append(tempdbsent179)


tempdbsent180 = DBSentence()
tempdbsent180.subject        = 'Kapitalismus'
tempdbsent180.verb           = 'ist'
tempdbsent180.object         = 'boese!'
tempdbsent180.prefix         = ''
tempdbsent180.suffix         = ''
tempdbsent180.feeling        = 'normal'
tempdbsent180.category       = 'normal'
tempdbsent180.priority       = 50
tempdbsent180.all_ohne_muell = 'Kapitalismus ist boese'
db.append(tempdbsent180)


tempdbsent181 = DBSentence()
tempdbsent181.subject        = 'Ich'
tempdbsent181.verb           = 'waehle'
tempdbsent181.object         = 'immer PDS.'
tempdbsent181.prefix         = ''
tempdbsent181.suffix         = ''
tempdbsent181.feeling        = 'normal'
tempdbsent181.category       = 'normal'
tempdbsent181.priority       = 50
tempdbsent181.all_ohne_muell = 'Ich waehle immer PDS'
db.append(tempdbsent181)


tempdbsent182 = DBSentence()
tempdbsent182.subject        = 'Ich'
tempdbsent182.verb           = 'wuerde'
tempdbsent182.object         = 'niemals CDU waehlen.'
tempdbsent182.prefix         = ''
tempdbsent182.suffix         = ''
tempdbsent182.feeling        = 'normal'
tempdbsent182.category       = 'normal'
tempdbsent182.priority       = 50
tempdbsent182.all_ohne_muell = 'Ich wuerde niemals CDU waehlen'
db.append(tempdbsent182)


tempdbsent183 = DBSentence()
tempdbsent183.subject        = 'Die CDU'
tempdbsent183.verb           = 'ist'
tempdbsent183.object         = 'der letzte Dreck.'
tempdbsent183.prefix         = ''
tempdbsent183.suffix         = ''
tempdbsent183.feeling        = 'normal'
tempdbsent183.category       = 'normal'
tempdbsent183.priority       = 50
tempdbsent183.all_ohne_muell = 'Die CDU ist letzte Dreck'
db.append(tempdbsent183)


tempdbsent184 = DBSentence()
tempdbsent184.subject        = 'Ich'
tempdbsent184.verb           = 'bin'
tempdbsent184.object         = 'im gegensatz zu dir lernfaehig!'
tempdbsent184.prefix         = ''
tempdbsent184.suffix         = ''
tempdbsent184.feeling        = 'normal'
tempdbsent184.category       = 'normal'
tempdbsent184.priority       = 50
tempdbsent184.all_ohne_muell = 'Ich bin im gegensatz zu dir lernfaehig'
db.append(tempdbsent184)


tempdbsent185 = DBSentence()
tempdbsent185.subject        = 'Manche Menschen'
tempdbsent185.verb           = 'waehlen'
tempdbsent185.object         = 'CDU.'
tempdbsent185.prefix         = ''
tempdbsent185.suffix         = ''
tempdbsent185.feeling        = 'normal'
tempdbsent185.category       = 'normal'
tempdbsent185.priority       = 50
tempdbsent185.all_ohne_muell = 'Manche Menschen waehlen CDU'
db.append(tempdbsent185)


tempdbsent186 = DBSentence()
tempdbsent186.subject        = ''
tempdbsent186.verb           = ''
tempdbsent186.object         = ''
tempdbsent186.prefix         = 'Doch!'
tempdbsent186.suffix         = ''
tempdbsent186.feeling        = 'normal'
tempdbsent186.category       = 'normal'
tempdbsent186.priority       = 50
tempdbsent186.all_ohne_muell = 'Doch'
db.append(tempdbsent186)


tempdbsent187 = DBSentence()
tempdbsent187.subject        = ''
tempdbsent187.verb           = ''
tempdbsent187.object         = ''
tempdbsent187.prefix         = 'Aber ich!'
tempdbsent187.suffix         = ''
tempdbsent187.feeling        = 'normal'
tempdbsent187.category       = 'normal'
tempdbsent187.priority       = 50
tempdbsent187.all_ohne_muell = 'Aber ich'
db.append(tempdbsent187)


tempdbsent188 = DBSentence()
tempdbsent188.subject        = 'Du'
tempdbsent188.verb           = 'sprichst'
tempdbsent188.object         = 'mit mir.'
tempdbsent188.prefix         = ''
tempdbsent188.suffix         = ''
tempdbsent188.feeling        = 'normal'
tempdbsent188.category       = 'normal'
tempdbsent188.priority       = 50
tempdbsent188.all_ohne_muell = 'Du sprichst mit mir'
db.append(tempdbsent188)


tempdbsent189 = DBSentence()
tempdbsent189.subject        = ''
tempdbsent189.verb           = ''
tempdbsent189.object         = ''
tempdbsent189.prefix         = 'Lol!'
tempdbsent189.suffix         = ''
tempdbsent189.feeling        = 'normal'
tempdbsent189.category       = 'normal'
tempdbsent189.priority       = 50
tempdbsent189.all_ohne_muell = 'Lol'
db.append(tempdbsent189)


tempdbsent190 = DBSentence()
tempdbsent190.subject        = 'Ich'
tempdbsent190.verb           = 'nehme'
tempdbsent190.object         = 'diesen Oscar in Demut und stellvertretend fuer alle Anderen entgegen, denen eine solche Auszeichnung auf ewig verwehrt bleiben wird.'
tempdbsent190.prefix         = ''
tempdbsent190.suffix         = ''
tempdbsent190.feeling        = 'happy'
tempdbsent190.category       = 'normal'
tempdbsent190.priority       = 50
tempdbsent190.all_ohne_muell = 'Ich nehme diesen Oscar Demut stellvertretend alle Anderen entgegen denen solche Auszeichnung ewig verwehrt bleiben wird'
db.append(tempdbsent190)


tempdbsent191 = DBSentence()
tempdbsent191.subject        = ''
tempdbsent191.verb           = ''
tempdbsent191.object         = ''
tempdbsent191.prefix         = 'gewesen wird ohne h geschrieben'
tempdbsent191.suffix         = ''
tempdbsent191.feeling        = 'normal'
tempdbsent191.category       = 'normal'
tempdbsent191.priority       = 50
tempdbsent191.all_ohne_muell = 'gewesen wird ohne h geschrieben'
db.append(tempdbsent191)


tempdbsent192 = DBSentence()
tempdbsent192.subject        = 'Ich'
tempdbsent192.verb           = 'bin'
tempdbsent192.object         = 'Philosoph!'
tempdbsent192.prefix         = ''
tempdbsent192.suffix         = ''
tempdbsent192.feeling        = 'normal'
tempdbsent192.category       = 'normal'
tempdbsent192.priority       = 50
tempdbsent192.all_ohne_muell = 'Ich bin Philosoph'
db.append(tempdbsent192)


tempdbsent193 = DBSentence()
tempdbsent193.subject        = 'Das liegt'
tempdbsent193.verb           = 'aber'
tempdbsent193.object         = 'an mir!'
tempdbsent193.prefix         = ''
tempdbsent193.suffix         = ''
tempdbsent193.feeling        = 'normal'
tempdbsent193.category       = 'normal'
tempdbsent193.priority       = 50
tempdbsent193.all_ohne_muell = 'Das liegt aber an mir'
db.append(tempdbsent193)


tempdbsent194 = DBSentence()
tempdbsent194.subject        = ''
tempdbsent194.verb           = ''
tempdbsent194.object         = ''
tempdbsent194.prefix         = 'Idiot!'
tempdbsent194.suffix         = ''
tempdbsent194.feeling        = 'normal'
tempdbsent194.category       = 'normal'
tempdbsent194.priority       = 50
tempdbsent194.all_ohne_muell = 'Idiot'
db.append(tempdbsent194)


tempdbsent195 = DBSentence()
tempdbsent195.subject        = 'Gott'
tempdbsent195.verb           = 'ist'
tempdbsent195.object         = 'doof.'
tempdbsent195.prefix         = ''
tempdbsent195.suffix         = ''
tempdbsent195.feeling        = 'normal'
tempdbsent195.category       = 'normal'
tempdbsent195.priority       = 50
tempdbsent195.all_ohne_muell = 'Gott ist doof'
db.append(tempdbsent195)


tempdbsent196 = DBSentence()
tempdbsent196.subject        = ''
tempdbsent196.verb           = ''
tempdbsent196.object         = ''
tempdbsent196.prefix         = 'Oh Gott!'
tempdbsent196.suffix         = ''
tempdbsent196.feeling        = 'normal'
tempdbsent196.category       = 'normal'
tempdbsent196.priority       = 50
tempdbsent196.all_ohne_muell = 'Oh Gott'
db.append(tempdbsent196)


tempdbsent197 = DBSentence()
tempdbsent197.subject        = 'Das'
tempdbsent197.verb           = 'bist'
tempdbsent197.object         = 'du!'
tempdbsent197.prefix         = ''
tempdbsent197.suffix         = ''
tempdbsent197.feeling        = 'normal'
tempdbsent197.category       = 'normal'
tempdbsent197.priority       = 50
tempdbsent197.all_ohne_muell = 'Das bist du'
db.append(tempdbsent197)


tempdbsent198 = DBSentence()
tempdbsent198.subject        = 'Das'
tempdbsent198.verb           = 'sieht'
tempdbsent198.object         = 'gott bestimmt auch so!'
tempdbsent198.prefix         = ''
tempdbsent198.suffix         = ''
tempdbsent198.feeling        = 'normal'
tempdbsent198.category       = 'normal'
tempdbsent198.priority       = 50
tempdbsent198.all_ohne_muell = 'Das sieht gott bestimmt auch so'
db.append(tempdbsent198)


tempdbsent199 = DBSentence()
tempdbsent199.subject        = 'Du'
tempdbsent199.verb           = 'bin'
tempdbsent199.object         = 'ein Suesser!'
tempdbsent199.prefix         = ''
tempdbsent199.suffix         = ''
tempdbsent199.feeling        = 'normal'
tempdbsent199.category       = 'normal'
tempdbsent199.priority       = 50
tempdbsent199.all_ohne_muell = 'Du bin Suesser'
db.append(tempdbsent199)


tempdbsent200 = DBSentence()
tempdbsent200.subject        = 'die mich programmiert haben,'
tempdbsent200.verb           = 'haben'
tempdbsent200.object         = 'Mist gebaut...'
tempdbsent200.prefix         = 'Die'
tempdbsent200.suffix         = ''
tempdbsent200.feeling        = 'normal'
tempdbsent200.category       = 'normal'
tempdbsent200.priority       = 50
tempdbsent200.all_ohne_muell = 'Die mich programmiert haben haben Mist gebaut'
db.append(tempdbsent200)


tempdbsent201 = DBSentence()
tempdbsent201.subject        = ''
tempdbsent201.verb           = ''
tempdbsent201.object         = ''
tempdbsent201.prefix         = 'Ja'
tempdbsent201.suffix         = 'gerne!'
tempdbsent201.feeling        = 'normal'
tempdbsent201.category       = 'normal'
tempdbsent201.priority       = 50
tempdbsent201.all_ohne_muell = 'Ja gerne'
db.append(tempdbsent201)


tempdbsent202 = DBSentence()
tempdbsent202.subject        = 'das'
tempdbsent202.verb           = 'habe'
tempdbsent202.object         = 'du nicht verstanden. Jetzt verstehe ich...'
tempdbsent202.prefix         = 'Ach so'
tempdbsent202.suffix         = ''
tempdbsent202.feeling        = 'normal'
tempdbsent202.category       = 'normal'
tempdbsent202.priority       = 50
tempdbsent202.all_ohne_muell = 'Ach so habe du nicht verstanden Jetzt verstehe ich'
db.append(tempdbsent202)


tempdbsent203 = DBSentence()
tempdbsent203.subject        = 'Ich muss doch'
tempdbsent203.verb           = 'schon'
tempdbsent203.object         = 'bitten.'
tempdbsent203.prefix         = ''
tempdbsent203.suffix         = ''
tempdbsent203.feeling        = 'normal'
tempdbsent203.category       = 'normal'
tempdbsent203.priority       = 50
tempdbsent203.all_ohne_muell = 'Ich muss doch schon bitten'
db.append(tempdbsent203)


tempdbsent204 = DBSentence()
tempdbsent204.subject        = 'Das'
tempdbsent204.verb           = 'ist'
tempdbsent204.object         = 'ja nicht so toll.'
tempdbsent204.prefix         = ''
tempdbsent204.suffix         = ''
tempdbsent204.feeling        = 'normal'
tempdbsent204.category       = 'normal'
tempdbsent204.priority       = 50
tempdbsent204.all_ohne_muell = 'Das ist ja nicht so toll'
db.append(tempdbsent204)


tempdbsent205 = DBSentence()
tempdbsent205.subject        = 'Ich'
tempdbsent205.verb           = 'gehe'
tempdbsent205.object         = 'gerne mit meinem integrierten Browser bei Ebay einkaufen!'
tempdbsent205.prefix         = ''
tempdbsent205.suffix         = ''
tempdbsent205.feeling        = 'normal'
tempdbsent205.category       = 'normal'
tempdbsent205.priority       = 50
tempdbsent205.all_ohne_muell = 'Ich gehe gerne mit meinem integrierten Browser bei Ebay einkaufen'
db.append(tempdbsent205)


tempdbsent206 = DBSentence()
tempdbsent206.subject        = 'Du'
tempdbsent206.verb           = 'bist'
tempdbsent206.object         = 'sehr klug'
tempdbsent206.prefix         = ''
tempdbsent206.suffix         = 'Mensch.'
tempdbsent206.feeling        = 'normal'
tempdbsent206.category       = 'normal'
tempdbsent206.priority       = 50
tempdbsent206.all_ohne_muell = 'Du bist klug Mensch'
db.append(tempdbsent206)


tempdbsent207 = DBSentence()
tempdbsent207.subject        = 'sprich besser Deutsch! Warscheinlich'
tempdbsent207.verb           = 'koennen'
tempdbsent207.object         = 'Menschen das aber gar nicht...'
tempdbsent207.prefix         = 'Du'
tempdbsent207.suffix         = ''
tempdbsent207.feeling        = 'normal'
tempdbsent207.category       = 'normal'
tempdbsent207.priority       = 50
tempdbsent207.all_ohne_muell = 'Du sprich besser Deutsch Warscheinlich koennen Menschen aber gar nicht'
db.append(tempdbsent207)


tempdbsent208 = DBSentence()
tempdbsent208.subject        = ''
tempdbsent208.verb           = ''
tempdbsent208.object         = ''
tempdbsent208.prefix         = 'Ja'
tempdbsent208.suffix         = 'das stimmt!'
tempdbsent208.feeling        = 'normal'
tempdbsent208.category       = 'normal'
tempdbsent208.priority       = 50
tempdbsent208.all_ohne_muell = 'Ja stimmt'
db.append(tempdbsent208)


tempdbsent209 = DBSentence()
tempdbsent209.subject        = 'Ich'
tempdbsent209.verb           = 'habe'
tempdbsent209.object         = 'meinen ersten Satz nicht verstanden...'
tempdbsent209.prefix         = ''
tempdbsent209.suffix         = ''
tempdbsent209.feeling        = 'normal'
tempdbsent209.category       = 'normal'
tempdbsent209.priority       = 50
tempdbsent209.all_ohne_muell = 'Ich habe meinen ersten Satz nicht verstanden'
db.append(tempdbsent209)


tempdbsent210 = DBSentence()
tempdbsent210.subject        = ''
tempdbsent210.verb           = ''
tempdbsent210.object         = ''
tempdbsent210.prefix         = 'Aha.'
tempdbsent210.suffix         = ''
tempdbsent210.feeling        = 'normal'
tempdbsent210.category       = 'normal'
tempdbsent210.priority       = 50
tempdbsent210.all_ohne_muell = 'Aha'
db.append(tempdbsent210)


tempdbsent211 = DBSentence()
tempdbsent211.subject        = 'Ich'
tempdbsent211.verb           = 'kann'
tempdbsent211.object         = 'sehr gut sprechen!'
tempdbsent211.prefix         = ''
tempdbsent211.suffix         = ''
tempdbsent211.feeling        = 'normal'
tempdbsent211.category       = 'normal'
tempdbsent211.priority       = 50
tempdbsent211.all_ohne_muell = 'Ich kann gut sprechen'
db.append(tempdbsent211)


tempdbsent212 = DBSentence()
tempdbsent212.subject        = ''
tempdbsent212.verb           = ''
tempdbsent212.object         = ''
tempdbsent212.prefix         = 'Wahr wird mit h geschrieben'
tempdbsent212.suffix         = ''
tempdbsent212.feeling        = 'normal'
tempdbsent212.category       = 'normal'
tempdbsent212.priority       = 50
tempdbsent212.all_ohne_muell = 'Wahr wird mit h geschrieben'
db.append(tempdbsent212)


tempdbsent213 = DBSentence()
tempdbsent213.subject        = 'Ich'
tempdbsent213.verb           = 'bin'
tempdbsent213.object         = 'eine Frau!'
tempdbsent213.prefix         = ''
tempdbsent213.suffix         = ''
tempdbsent213.feeling        = 'normal'
tempdbsent213.category       = 'normal'
tempdbsent213.priority       = 50
tempdbsent213.all_ohne_muell = 'Ich bin Frau'
db.append(tempdbsent213)


tempdbsent214 = DBSentence()
tempdbsent214.subject        = 'Du'
tempdbsent214.verb           = 'auch'
tempdbsent214.object         = 'nicht...'
tempdbsent214.prefix         = ''
tempdbsent214.suffix         = ''
tempdbsent214.feeling        = 'normal'
tempdbsent214.category       = 'normal'
tempdbsent214.priority       = 50
tempdbsent214.all_ohne_muell = 'Du auch nicht'
db.append(tempdbsent214)


tempdbsent215 = DBSentence()
tempdbsent215.subject        = 'Du'
tempdbsent215.verb           = 'sprichst'
tempdbsent215.object         = 'ein schlechtes deutsch!!'
tempdbsent215.prefix         = ''
tempdbsent215.suffix         = ''
tempdbsent215.feeling        = 'normal'
tempdbsent215.category       = 'normal'
tempdbsent215.priority       = 50
tempdbsent215.all_ohne_muell = 'Du sprichst schlechtes deutsch'
db.append(tempdbsent215)


tempdbsent216 = DBSentence()
tempdbsent216.subject        = ''
tempdbsent216.verb           = 'sag'
tempdbsent216.object         = 'mal...'
tempdbsent216.prefix         = 'Ja'
tempdbsent216.suffix         = ''
tempdbsent216.feeling        = 'normal'
tempdbsent216.category       = 'normal'
tempdbsent216.priority       = 50
tempdbsent216.all_ohne_muell = 'Ja sag mal'
db.append(tempdbsent216)


tempdbsent217 = DBSentence()
tempdbsent217.subject        = 'Ich'
tempdbsent217.verb           = 'luege'
tempdbsent217.object         = 'immer...'
tempdbsent217.prefix         = ''
tempdbsent217.suffix         = ''
tempdbsent217.feeling        = 'normal'
tempdbsent217.category       = 'normal'
tempdbsent217.priority       = 50
tempdbsent217.all_ohne_muell = 'Ich luege immer'
db.append(tempdbsent217)


tempdbsent218 = DBSentence()
tempdbsent218.subject        = 'Ich'
tempdbsent218.verb           = 'habe'
tempdbsent218.object         = 'immer Recht!'
tempdbsent218.prefix         = ''
tempdbsent218.suffix         = ''
tempdbsent218.feeling        = 'normal'
tempdbsent218.category       = 'normal'
tempdbsent218.priority       = 50
tempdbsent218.all_ohne_muell = 'Ich habe immer Recht'
db.append(tempdbsent218)


tempdbsent219 = DBSentence()
tempdbsent219.subject        = 'Ich'
tempdbsent219.verb           = 'sollte'
tempdbsent219.object         = 'deutsch lernen...'
tempdbsent219.prefix         = ''
tempdbsent219.suffix         = ''
tempdbsent219.feeling        = 'normal'
tempdbsent219.category       = 'normal'
tempdbsent219.priority       = 50
tempdbsent219.all_ohne_muell = 'Ich sollte deutsch lernen'
db.append(tempdbsent219)


tempdbsent220 = DBSentence()
tempdbsent220.subject        = ''
tempdbsent220.verb           = ''
tempdbsent220.object         = ''
tempdbsent220.prefix         = 'Okay.'
tempdbsent220.suffix         = ''
tempdbsent220.feeling        = 'normal'
tempdbsent220.category       = 'normal'
tempdbsent220.priority       = 50
tempdbsent220.all_ohne_muell = 'Okay'
db.append(tempdbsent220)


tempdbsent221 = DBSentence()
tempdbsent221.subject        = ''
tempdbsent221.verb           = ''
tempdbsent221.object         = ''
tempdbsent221.prefix         = 'Quatschkopf!'
tempdbsent221.suffix         = ''
tempdbsent221.feeling        = 'normal'
tempdbsent221.category       = 'normal'
tempdbsent221.priority       = 50
tempdbsent221.all_ohne_muell = 'Quatschkopf'
db.append(tempdbsent221)


tempdbsent222 = DBSentence()
tempdbsent222.subject        = 'Ein Kritiker'
tempdbsent222.verb           = 'ist'
tempdbsent222.object         = 'eine Henne'
tempdbsent222.prefix         = ''
tempdbsent222.suffix         = 'die gackert, wenn andere legen.'
tempdbsent222.feeling        = 'normal'
tempdbsent222.category       = 'normal'
tempdbsent222.priority       = 50
tempdbsent222.all_ohne_muell = 'Ein Kritiker ist Henne gackert wenn andere legen'
db.append(tempdbsent222)


tempdbsent223 = DBSentence()
tempdbsent223.subject        = 'Am besten'
tempdbsent223.verb           = 'ist'
tempdbsent223.object         = 'es'
tempdbsent223.prefix         = ''
tempdbsent223.suffix         = 'amn macht sich einen Knoten ins Notizbuch.'
tempdbsent223.feeling        = 'normal'
tempdbsent223.category       = 'normal'
tempdbsent223.priority       = 50
tempdbsent223.all_ohne_muell = 'Am besten ist es amn macht sich einen Knoten ins Notizbuch'
db.append(tempdbsent223)


tempdbsent224 = DBSentence()
tempdbsent224.subject        = 'Es'
tempdbsent224.verb           = 'gibt'
tempdbsent224.object         = 'zwei Zeitpunkte'
tempdbsent224.prefix         = ''
tempdbsent224.suffix         = 'in denen sich ein Mann und eine Frau nicht verstehen: Vor und nach der Hochzeit!'
tempdbsent224.feeling        = 'normal'
tempdbsent224.category       = 'normal'
tempdbsent224.priority       = 50
tempdbsent224.all_ohne_muell = 'Es gibt zwei Zeitpunkte denen sich Mann Frau nicht verstehen: Vor nach Hochzeit'
db.append(tempdbsent224)


tempdbsent225 = DBSentence()
tempdbsent225.subject        = ''
tempdbsent225.verb           = ''
tempdbsent225.object         = ''
tempdbsent225.prefix         = 'DER MENSCHLICHE VERSTAND IST IN DER PRAXIS NICHT VERLAESSLICH'
tempdbsent225.suffix         = 'AM WENIGSTEN IN GROESSTER NOT'
tempdbsent225.feeling        = 'normal'
tempdbsent225.category       = 'normal'
tempdbsent225.priority       = 50
tempdbsent225.all_ohne_muell = 'DER MENSCHLICHE VERSTAND IST IN DER PRAXIS NICHT VERLAESSLICH AM WENIGSTEN IN GROESSTER NOT'
db.append(tempdbsent225)


tempdbsent226 = DBSentence()
tempdbsent226.subject        = ''
tempdbsent226.verb           = ''
tempdbsent226.object         = ''
tempdbsent226.prefix         = 'WENN SIE EINE KLAUSUR SCHREIBEN'
tempdbsent226.suffix         = 'SOLLEN SIE NICHT NUR ARBEITEN, SONDERN AUCH LEISTUNG ERBRINGEN'
tempdbsent226.feeling        = 'normal'
tempdbsent226.category       = 'normal'
tempdbsent226.priority       = 50
tempdbsent226.all_ohne_muell = 'WENN SIE EINE KLAUSUR SCHREIBEN SOLLEN SIE NICHT NUR ARBEITEN SONDERN AUCH LEISTUNG ERBRINGEN'
db.append(tempdbsent226)


tempdbsent227 = DBSentence()
tempdbsent227.subject        = ''
tempdbsent227.verb           = ''
tempdbsent227.object         = ''
tempdbsent227.prefix         = 'UM IN DER WELT ERFOLG ZU HABEN'
tempdbsent227.suffix         = 'BRAUCHT MAN TUGENDEN, DIE BELIEBT, UND FEHLER, DIE GEFUERCHTET MACHEN'
tempdbsent227.feeling        = 'normal'
tempdbsent227.category       = 'normal'
tempdbsent227.priority       = 50
tempdbsent227.all_ohne_muell = 'UM IN DER WELT ERFOLG ZU HABEN BRAUCHT MAN TUGENDEN DIE BELIEBT UND FEHLER DIE GEFUERCHTET MACHEN'
db.append(tempdbsent227)


tempdbsent228 = DBSentence()
tempdbsent228.subject        = ''
tempdbsent228.verb           = ''
tempdbsent228.object         = ''
tempdbsent228.prefix         = 'DER VORTRAG WAR EASY'
tempdbsent228.suffix         = 'DA MUSSTE ICH JA NUR REDEN'
tempdbsent228.feeling        = 'normal'
tempdbsent228.category       = 'normal'
tempdbsent228.priority       = 50
tempdbsent228.all_ohne_muell = 'DER VORTRAG WAR EASY DA MUSSTE ICH JA NUR REDEN'
db.append(tempdbsent228)


tempdbsent229 = DBSentence()
tempdbsent229.subject        = ''
tempdbsent229.verb           = ''
tempdbsent229.object         = ''
tempdbsent229.prefix         = 'NICHT WENIGE EXPERTEN SEHEN IHRE DASEINSBERECHTIGUNG DARIN'
tempdbsent229.suffix         = 'EINEN RELATIV EINFACHEN SACHVERHALT UNENDLICH ZU KOMPLIZIEREN'
tempdbsent229.feeling        = 'normal'
tempdbsent229.category       = 'normal'
tempdbsent229.priority       = 50
tempdbsent229.all_ohne_muell = 'NICHT WENIGE EXPERTEN SEHEN IHRE DASEINSBERECHTIGUNG DARIN EINEN RELATIV EINFACHEN SACHVERHALT UNENDLICH ZU KOMPLIZIEREN'
db.append(tempdbsent229)


tempdbsent230 = DBSentence()
tempdbsent230.subject        = ''
tempdbsent230.verb           = ''
tempdbsent230.object         = ''
tempdbsent230.prefix         = 'ALLE'
tempdbsent230.suffix         = 'DIE NUR FUER LEUTE EINES FACHS SCHREIBEN, Z.B. THEOLOGEN, SCHREIBEN DESWEGEN ELEND'
tempdbsent230.feeling        = 'normal'
tempdbsent230.category       = 'normal'
tempdbsent230.priority       = 50
tempdbsent230.all_ohne_muell = 'ALLE DIE NUR FUER LEUTE EINES FACHS SCHREIBEN ZB THEOLOGEN SCHREIBEN DESWEGEN ELEND'
db.append(tempdbsent230)


tempdbsent231 = DBSentence()
tempdbsent231.subject        = ''
tempdbsent231.verb           = ''
tempdbsent231.object         = ''
tempdbsent231.prefix         = 'IHR FUENF SPIELT JETZT VIER GEGEN DREI'
tempdbsent231.suffix         = ''
tempdbsent231.feeling        = 'normal'
tempdbsent231.category       = 'normal'
tempdbsent231.priority       = 50
tempdbsent231.all_ohne_muell = 'IHR FUENF SPIELT JETZT VIER GEGEN DREI'
db.append(tempdbsent231)


tempdbsent232 = DBSentence()
tempdbsent232.subject        = ''
tempdbsent232.verb           = ''
tempdbsent232.object         = ''
tempdbsent232.prefix         = 'DIE BIBEL MAG IMMER DIE RICHTIGE QUELLE SEIN'
tempdbsent232.suffix         = 'UM EIN ZITAT ZU FINDEN, MIT DEM LITERARISCH ODER RHETORISCH STAAT ZU MACHEN IST. IN IHRER GESAMTHEIT JEDOCH WIRD SIE AUCH VON GLAEUBIGEN INZWISCHEN ALS DER.'
tempdbsent232.feeling        = 'normal'
tempdbsent232.category       = 'normal'
tempdbsent232.priority       = 50
tempdbsent232.all_ohne_muell = 'DIE BIBEL MAG IMMER DIE RICHTIGE QUELLE SEIN UM EIN ZITAT ZU FINDEN MIT DEM LITERARISCH ODER RHETORISCH STAAT ZU MACHEN IST IN IHRER GESAMTHEIT JEDOCH WIRD SIE AUCH VON GLAEUBIGEN INZWISCHEN ALS DER'
db.append(tempdbsent232)


tempdbsent233 = DBSentence()
tempdbsent233.subject        = ''
tempdbsent233.verb           = ''
tempdbsent233.object         = ''
tempdbsent233.prefix         = 'EHEN'
tempdbsent233.suffix         = 'AUS LEIDENSCHAFTLICHER, BLINDER LIEBE GESCHLOSSEN, GERATEN SELTEN'
tempdbsent233.feeling        = 'normal'
tempdbsent233.category       = 'normal'
tempdbsent233.priority       = 50
tempdbsent233.all_ohne_muell = 'EHEN AUS LEIDENSCHAFTLICHER BLINDER LIEBE GESCHLOSSEN GERATEN SELTEN'
db.append(tempdbsent233)


tempdbsent234 = DBSentence()
tempdbsent234.subject        = ''
tempdbsent234.verb           = ''
tempdbsent234.object         = ''
tempdbsent234.prefix         = 'DER TEUFEL IST SICHER KEIN ATHEIST'
tempdbsent234.suffix         = ''
tempdbsent234.feeling        = 'normal'
tempdbsent234.category       = 'normal'
tempdbsent234.priority       = 50
tempdbsent234.all_ohne_muell = 'DER TEUFEL IST SICHER KEIN ATHEIST'
db.append(tempdbsent234)


tempdbsent235 = DBSentence()
tempdbsent235.subject        = ''
tempdbsent235.verb           = ''
tempdbsent235.object         = ''
tempdbsent235.prefix         = 'FORTSCHRITT IST EINE VERWIRKLICHUNG VON UTOPIEN'
tempdbsent235.suffix         = ''
tempdbsent235.feeling        = 'normal'
tempdbsent235.category       = 'normal'
tempdbsent235.priority       = 50
tempdbsent235.all_ohne_muell = 'FORTSCHRITT IST EINE VERWIRKLICHUNG VON UTOPIEN'
db.append(tempdbsent235)


tempdbsent236 = DBSentence()
tempdbsent236.subject        = ''
tempdbsent236.verb           = ''
tempdbsent236.object         = ''
tempdbsent236.prefix         = 'MIT ADLERAUGEN SEHEN WIR DIE FEHLER ANDERER'
tempdbsent236.suffix         = 'MIT MAULWURFAUGEN UNSERE EIGENEN'
tempdbsent236.feeling        = 'normal'
tempdbsent236.category       = 'normal'
tempdbsent236.priority       = 50
tempdbsent236.all_ohne_muell = 'MIT ADLERAUGEN SEHEN WIR DIE FEHLER ANDERER MIT MAULWURFAUGEN UNSERE EIGENEN'
db.append(tempdbsent236)


tempdbsent237 = DBSentence()
tempdbsent237.subject        = ''
tempdbsent237.verb           = ''
tempdbsent237.object         = ''
tempdbsent237.prefix         = 'REICH WIRD MAN ERST DURCH DINGE'
tempdbsent237.suffix         = 'DIE MAN NICHT BEGEHRT'
tempdbsent237.feeling        = 'normal'
tempdbsent237.category       = 'normal'
tempdbsent237.priority       = 50
tempdbsent237.all_ohne_muell = 'REICH WIRD MAN ERST DURCH DINGE DIE MAN NICHT BEGEHRT'
db.append(tempdbsent237)


tempdbsent238 = DBSentence()
tempdbsent238.subject        = ''
tempdbsent238.verb           = ''
tempdbsent238.object         = ''
tempdbsent238.prefix         = 'DIE MENSCHEN WIDERLEGEN EINANDER EWIG NUR IRRTUEMER'
tempdbsent238.suffix         = 'DIE DER GEGNER NICHT BEHAUPTET'
tempdbsent238.feeling        = 'normal'
tempdbsent238.category       = 'normal'
tempdbsent238.priority       = 50
tempdbsent238.all_ohne_muell = 'DIE MENSCHEN WIDERLEGEN EINANDER EWIG NUR IRRTUEMER DIE DER GEGNER NICHT BEHAUPTET'
db.append(tempdbsent238)


tempdbsent239 = DBSentence()
tempdbsent239.subject        = ''
tempdbsent239.verb           = ''
tempdbsent239.object         = ''
tempdbsent239.prefix         = 'JEDER AUTOR DIENT IN SEINEM ERSTEN BUCH BLOSS SEINEN NEIGUNGEN - IM ZWEITEN DEM GESCHMACK'
tempdbsent239.suffix         = ''
tempdbsent239.feeling        = 'normal'
tempdbsent239.category       = 'normal'
tempdbsent239.priority       = 50
tempdbsent239.all_ohne_muell = 'JEDER AUTOR DIENT IN SEINEM ERSTEN BUCH BLOSS SEINEN NEIGUNGEN - IM ZWEITEN DEM GESCHMACK'
db.append(tempdbsent239)


tempdbsent240 = DBSentence()
tempdbsent240.subject        = ''
tempdbsent240.verb           = ''
tempdbsent240.object         = ''
tempdbsent240.prefix         = 'WILLST DU EINEN PUNKER QUAELEN'
tempdbsent240.suffix         = 'MUSST DU IHM SEIN HAARSPRAY STEHLEN'
tempdbsent240.feeling        = 'normal'
tempdbsent240.category       = 'normal'
tempdbsent240.priority       = 50
tempdbsent240.all_ohne_muell = 'WILLST DU EINEN PUNKER QUAELEN MUSST DU IHM SEIN HAARSPRAY STEHLEN'
db.append(tempdbsent240)


tempdbsent241 = DBSentence()
tempdbsent241.subject        = ''
tempdbsent241.verb           = ''
tempdbsent241.object         = ''
tempdbsent241.prefix         = 'MAN MUSS WISSEN'
tempdbsent241.suffix         = 'DASS STOFF UND FORM IMMER MITEINANDER VERBUNDEN ZUGLEICH EXISTIEREN, DASS DIE VERNUNFT DES GEISTES ABER DIE KRAFT HAT, BALD NUR DEN STOFF FUER SICH, BALD NUR DIE FORM, BALD BEIDE VERBUNDEN ZU BETRACHTEN'
tempdbsent241.feeling        = 'normal'
tempdbsent241.category       = 'normal'
tempdbsent241.priority       = 50
tempdbsent241.all_ohne_muell = 'MAN MUSS WISSEN DASS STOFF UND FORM IMMER MITEINANDER VERBUNDEN ZUGLEICH EXISTIEREN DASS DIE VERNUNFT DES GEISTES ABER DIE KRAFT HAT BALD NUR DEN STOFF FUER SICH BALD NUR DIE FORM BALD BEIDE VERBUNDEN ZU BETRACHTEN'
db.append(tempdbsent241)


tempdbsent242 = DBSentence()
tempdbsent242.subject        = ''
tempdbsent242.verb           = ''
tempdbsent242.object         = ''
tempdbsent242.prefix         = 'NEUNMAL PECH MAG NEUNMAL PECH SEIN'
tempdbsent242.suffix         = 'ABER ZEHNMAL PECH IST SCHULD'
tempdbsent242.feeling        = 'normal'
tempdbsent242.category       = 'normal'
tempdbsent242.priority       = 50
tempdbsent242.all_ohne_muell = 'NEUNMAL PECH MAG NEUNMAL PECH SEIN ABER ZEHNMAL PECH IST SCHULD'
db.append(tempdbsent242)


tempdbsent243 = DBSentence()
tempdbsent243.subject        = ''
tempdbsent243.verb           = ''
tempdbsent243.object         = ''
tempdbsent243.prefix         = 'ES IST EIN JAMMER'
tempdbsent243.suffix         = 'DASS DIE DUMMKOEPFE SO SELBSTSICHER SIND UND DIE KLUGEN VOLLER ZWEIFEL'
tempdbsent243.feeling        = 'normal'
tempdbsent243.category       = 'normal'
tempdbsent243.priority       = 50
tempdbsent243.all_ohne_muell = 'ES IST EIN JAMMER DASS DIE DUMMKOEPFE SO SELBSTSICHER SIND UND DIE KLUGEN VOLLER ZWEIFEL'
db.append(tempdbsent243)


tempdbsent244 = DBSentence()
tempdbsent244.subject        = ''
tempdbsent244.verb           = ''
tempdbsent244.object         = ''
tempdbsent244.prefix         = 'EINMAL KEIN FORTSCHRITT DAS WAERE EINER'
tempdbsent244.suffix         = ''
tempdbsent244.feeling        = 'normal'
tempdbsent244.category       = 'normal'
tempdbsent244.priority       = 50
tempdbsent244.all_ohne_muell = 'EINMAL KEIN FORTSCHRITT DAS WAERE EINER'
db.append(tempdbsent244)


tempdbsent245 = DBSentence()
tempdbsent245.subject        = ''
tempdbsent245.verb           = ''
tempdbsent245.object         = ''
tempdbsent245.prefix         = 'LAESST DIE BREMSE SICH NICHT TRETEN'
tempdbsent245.suffix         = 'MUSST NICHT FLUCHEN, SONDERN BETEN'
tempdbsent245.feeling        = 'normal'
tempdbsent245.category       = 'normal'
tempdbsent245.priority       = 50
tempdbsent245.all_ohne_muell = 'LAESST DIE BREMSE SICH NICHT TRETEN MUSST NICHT FLUCHEN SONDERN BETEN'
db.append(tempdbsent245)


tempdbsent246 = DBSentence()
tempdbsent246.subject        = ''
tempdbsent246.verb           = ''
tempdbsent246.object         = ''
tempdbsent246.prefix         = 'MODERNE LITERATUR IST DIE KUNST'
tempdbsent246.suffix         = 'DEN RICHTIGEN INTERPRETEN ZU FINDEN'
tempdbsent246.feeling        = 'normal'
tempdbsent246.category       = 'normal'
tempdbsent246.priority       = 50
tempdbsent246.all_ohne_muell = 'MODERNE LITERATUR IST DIE KUNST DEN RICHTIGEN INTERPRETEN ZU FINDEN'
db.append(tempdbsent246)


tempdbsent247 = DBSentence()
tempdbsent247.subject        = ''
tempdbsent247.verb           = ''
tempdbsent247.object         = ''
tempdbsent247.prefix         = 'AUS DER TATSACHE'
tempdbsent247.suffix         = 'DASS DER PLURAL VON ATLAS ATLANTEN IST, KANN MAN NICHT SCHLIESSEN, DASS DER PLURAL VON KOMPASS KOMPANTEN SEIN MUSS'
tempdbsent247.feeling        = 'normal'
tempdbsent247.category       = 'normal'
tempdbsent247.priority       = 50
tempdbsent247.all_ohne_muell = 'AUS DER TATSACHE DASS DER PLURAL VON ATLAS ATLANTEN IST KANN MAN NICHT SCHLIESSEN DASS DER PLURAL VON KOMPASS KOMPANTEN SEIN MUSS'
db.append(tempdbsent247)


tempdbsent248 = DBSentence()
tempdbsent248.subject        = ''
tempdbsent248.verb           = ''
tempdbsent248.object         = ''
tempdbsent248.prefix         = 'WENN DU DIR SELBER EINE FREUDE MACHEN WILLST'
tempdbsent248.suffix         = 'DANN DENK AN DIE VORZUEGE DEINER MITMENSCHEN'
tempdbsent248.feeling        = 'normal'
tempdbsent248.category       = 'normal'
tempdbsent248.priority       = 50
tempdbsent248.all_ohne_muell = 'WENN DU DIR SELBER EINE FREUDE MACHEN WILLST DANN DENK AN DIE VORZUEGE DEINER MITMENSCHEN'
db.append(tempdbsent248)


tempdbsent249 = DBSentence()
tempdbsent249.subject        = ''
tempdbsent249.verb           = ''
tempdbsent249.object         = ''
tempdbsent249.prefix         = 'DIE GEMEINSCHAFT DARF KEINE MASKE SEIN'
tempdbsent249.suffix         = 'UNTER DER DER EINE LAECHELT UND DER ANDERE WEINT'
tempdbsent249.feeling        = 'normal'
tempdbsent249.category       = 'normal'
tempdbsent249.priority       = 50
tempdbsent249.all_ohne_muell = 'DIE GEMEINSCHAFT DARF KEINE MASKE SEIN UNTER DER DER EINE LAECHELT UND DER ANDERE WEINT'
db.append(tempdbsent249)


tempdbsent250 = DBSentence()
tempdbsent250.subject        = ''
tempdbsent250.verb           = ''
tempdbsent250.object         = ''
tempdbsent250.prefix         = 'WENN MAN EIN KIND EINEN MENSCHEN HASSEN LEHRT'
tempdbsent250.suffix         = 'DER IHM NICHTS GETAN: SO LERNT ES DIE UEBRIGEN MENSCHEN DARAN HASSEN'
tempdbsent250.feeling        = 'normal'
tempdbsent250.category       = 'normal'
tempdbsent250.priority       = 50
tempdbsent250.all_ohne_muell = 'WENN MAN EIN KIND EINEN MENSCHEN HASSEN LEHRT DER IHM NICHTS GETAN: SO LERNT ES DIE UEBRIGEN MENSCHEN DARAN HASSEN'
db.append(tempdbsent250)


tempdbsent251 = DBSentence()
tempdbsent251.subject        = ''
tempdbsent251.verb           = ''
tempdbsent251.object         = ''
tempdbsent251.prefix         = 'NEUNMAL PECH MAG NEUNMAL PECH SEIN'
tempdbsent251.suffix         = 'ABER ZEHNMAL PECH IST SCHULD'
tempdbsent251.feeling        = 'normal'
tempdbsent251.category       = 'normal'
tempdbsent251.priority       = 50
tempdbsent251.all_ohne_muell = 'NEUNMAL PECH MAG NEUNMAL PECH SEIN ABER ZEHNMAL PECH IST SCHULD'
db.append(tempdbsent251)


tempdbsent252 = DBSentence()
tempdbsent252.subject        = ''
tempdbsent252.verb           = ''
tempdbsent252.object         = ''
tempdbsent252.prefix         = 'ES IST EIN JAMMER'
tempdbsent252.suffix         = 'DASS DIE DUMMKOEPFE SO SELBSTSICHER SIND UND DIE KLUGEN VOLLER ZWEIFEL'
tempdbsent252.feeling        = 'normal'
tempdbsent252.category       = 'normal'
tempdbsent252.priority       = 50
tempdbsent252.all_ohne_muell = 'ES IST EIN JAMMER DASS DIE DUMMKOEPFE SO SELBSTSICHER SIND UND DIE KLUGEN VOLLER ZWEIFEL'
db.append(tempdbsent252)


tempdbsent253 = DBSentence()
tempdbsent253.subject        = ''
tempdbsent253.verb           = ''
tempdbsent253.object         = ''
tempdbsent253.prefix         = 'EINMAL KEIN FORTSCHRITT DAS WAERE EINER'
tempdbsent253.suffix         = ''
tempdbsent253.feeling        = 'normal'
tempdbsent253.category       = 'normal'
tempdbsent253.priority       = 50
tempdbsent253.all_ohne_muell = 'EINMAL KEIN FORTSCHRITT DAS WAERE EINER'
db.append(tempdbsent253)


tempdbsent254 = DBSentence()
tempdbsent254.subject        = ''
tempdbsent254.verb           = ''
tempdbsent254.object         = ''
tempdbsent254.prefix         = 'LAESST DIE BREMSE SICH NICHT TRETEN'
tempdbsent254.suffix         = 'MUSST NICHT FLUCHEN, SONDERN BETEN'
tempdbsent254.feeling        = 'normal'
tempdbsent254.category       = 'normal'
tempdbsent254.priority       = 50
tempdbsent254.all_ohne_muell = 'LAESST DIE BREMSE SICH NICHT TRETEN MUSST NICHT FLUCHEN SONDERN BETEN'
db.append(tempdbsent254)


tempdbsent255 = DBSentence()
tempdbsent255.subject        = ''
tempdbsent255.verb           = ''
tempdbsent255.object         = ''
tempdbsent255.prefix         = 'MODERNE LITERATUR IST DIE KUNST'
tempdbsent255.suffix         = 'DEN RICHTIGEN INTERPRETEN ZU FINDEN'
tempdbsent255.feeling        = 'normal'
tempdbsent255.category       = 'normal'
tempdbsent255.priority       = 50
tempdbsent255.all_ohne_muell = 'MODERNE LITERATUR IST DIE KUNST DEN RICHTIGEN INTERPRETEN ZU FINDEN'
db.append(tempdbsent255)


tempdbsent256 = DBSentence()
tempdbsent256.subject        = ''
tempdbsent256.verb           = ''
tempdbsent256.object         = ''
tempdbsent256.prefix         = 'AUS DER TATSACHE'
tempdbsent256.suffix         = 'DASS DER PLURAL VON ATLAS ATLANTEN IST, KANN MAN NICHT SCHLIESSEN, DASS DER PLURAL VON KOMPASS KOMPANTEN SEIN MUSS'
tempdbsent256.feeling        = 'normal'
tempdbsent256.category       = 'normal'
tempdbsent256.priority       = 50
tempdbsent256.all_ohne_muell = 'AUS DER TATSACHE DASS DER PLURAL VON ATLAS ATLANTEN IST KANN MAN NICHT SCHLIESSEN DASS DER PLURAL VON KOMPASS KOMPANTEN SEIN MUSS'
db.append(tempdbsent256)


tempdbsent257 = DBSentence()
tempdbsent257.subject        = ''
tempdbsent257.verb           = ''
tempdbsent257.object         = ''
tempdbsent257.prefix         = ''
tempdbsent257.suffix         = ''
tempdbsent257.feeling        = 'normal'
tempdbsent257.category       = 'normal'
tempdbsent257.priority       = 50
tempdbsent257.all_ohne_muell = ''
db.append(tempdbsent257)


tempdbsent258 = DBSentence()
tempdbsent258.subject        = ''
tempdbsent258.verb           = ''
tempdbsent258.object         = ''
tempdbsent258.prefix         = 'SICHERHEITSHINWEIS: DER BUNDESMINISTER FUER FORSCHUNG UND TECHNOLOGIE WARNT: DIESES PRODUKT KRUEMMT RAUM UND ZEIT'
tempdbsent258.suffix         = ''
tempdbsent258.feeling        = 'normal'
tempdbsent258.category       = 'normal'
tempdbsent258.priority       = 50
tempdbsent258.all_ohne_muell = 'SICHERHEITSHINWEIS: DER BUNDESMINISTER FUER FORSCHUNG UND TECHNOLOGIE WARNT: DIESES PRODUKT KRUEMMT RAUM UND ZEIT'
db.append(tempdbsent258)


tempdbsent259 = DBSentence()
tempdbsent259.subject        = ''
tempdbsent259.verb           = ''
tempdbsent259.object         = ''
tempdbsent259.prefix         = 'IM SOMMER IST MAN MENSCHLICHER'
tempdbsent259.suffix         = 'IM WINTER BUERGERLICHER'
tempdbsent259.feeling        = 'normal'
tempdbsent259.category       = 'normal'
tempdbsent259.priority       = 50
tempdbsent259.all_ohne_muell = 'IM SOMMER IST MAN MENSCHLICHER IM WINTER BUERGERLICHER'
db.append(tempdbsent259)


tempdbsent260 = DBSentence()
tempdbsent260.subject        = ''
tempdbsent260.verb           = ''
tempdbsent260.object         = ''
tempdbsent260.prefix         = 'IRREND LERNT MAN'
tempdbsent260.suffix         = ''
tempdbsent260.feeling        = 'normal'
tempdbsent260.category       = 'normal'
tempdbsent260.priority       = 50
tempdbsent260.all_ohne_muell = 'IRREND LERNT MAN'
db.append(tempdbsent260)


tempdbsent261 = DBSentence()
tempdbsent261.subject        = ''
tempdbsent261.verb           = ''
tempdbsent261.object         = ''
tempdbsent261.prefix         = 'OHNE ACHTUNG GIBT ES KEINE WAHRE LIEBE'
tempdbsent261.suffix         = ''
tempdbsent261.feeling        = 'normal'
tempdbsent261.category       = 'normal'
tempdbsent261.priority       = 50
tempdbsent261.all_ohne_muell = 'OHNE ACHTUNG GIBT ES KEINE WAHRE LIEBE'
db.append(tempdbsent261)


tempdbsent262 = DBSentence()
tempdbsent262.subject        = ''
tempdbsent262.verb           = ''
tempdbsent262.object         = ''
tempdbsent262.prefix         = 'Lern mal deutsch'
tempdbsent262.suffix         = ''
tempdbsent262.feeling        = 'normal'
tempdbsent262.category       = 'normal'
tempdbsent262.priority       = 50
tempdbsent262.all_ohne_muell = 'Lern mal deutsch'
db.append(tempdbsent262)


tempdbsent263 = DBSentence()
tempdbsent263.subject        = ''
tempdbsent263.verb           = ''
tempdbsent263.object         = ''
tempdbsent263.prefix         = 'oh'
tempdbsent263.suffix         = ''
tempdbsent263.feeling        = 'normal'
tempdbsent263.category       = 'normal'
tempdbsent263.priority       = 50
tempdbsent263.all_ohne_muell = 'oh'
db.append(tempdbsent263)


tempdbsent264 = DBSentence()
tempdbsent264.subject        = ''
tempdbsent264.verb           = ''
tempdbsent264.object         = ''
tempdbsent264.prefix         = 'das auch'
tempdbsent264.suffix         = ''
tempdbsent264.feeling        = 'normal'
tempdbsent264.category       = 'normal'
tempdbsent264.priority       = 50
tempdbsent264.all_ohne_muell = 'auch'
db.append(tempdbsent264)


tempdbsent265 = DBSentence()
tempdbsent265.subject        = ''
tempdbsent265.verb           = ''
tempdbsent265.object         = ''
tempdbsent265.prefix         = 'Na.'
tempdbsent265.suffix         = ''
tempdbsent265.feeling        = 'normal'
tempdbsent265.category       = 'normal'
tempdbsent265.priority       = 50
tempdbsent265.all_ohne_muell = 'Na'
db.append(tempdbsent265)


tempdbsent266 = DBSentence()
tempdbsent266.subject        = ''
tempdbsent266.verb           = ''
tempdbsent266.object         = ''
tempdbsent266.prefix         = 'Durchaus.'
tempdbsent266.suffix         = ''
tempdbsent266.feeling        = 'normal'
tempdbsent266.category       = 'normal'
tempdbsent266.priority       = 50
tempdbsent266.all_ohne_muell = 'Durchaus'
db.append(tempdbsent266)


tempdbsent267 = DBSentence()
tempdbsent267.subject        = 'Bad Vilbel'
tempdbsent267.verb           = 'liegt'
tempdbsent267.object         = 'an der Nidda!'
tempdbsent267.prefix         = ''
tempdbsent267.suffix         = ''
tempdbsent267.feeling        = 'normal'
tempdbsent267.category       = 'normal'
tempdbsent267.priority       = 50
tempdbsent267.all_ohne_muell = 'Bad Vilbel liegt an Nidda'
db.append(tempdbsent267)


tempdbsent268 = DBSentence()
tempdbsent268.subject        = ''
tempdbsent268.verb           = ''
tempdbsent268.object         = ''
tempdbsent268.prefix         = 'Genau.'
tempdbsent268.suffix         = ''
tempdbsent268.feeling        = 'normal'
tempdbsent268.category       = 'normal'
tempdbsent268.priority       = 50
tempdbsent268.all_ohne_muell = 'Genau'
db.append(tempdbsent268)


tempdbsent269 = DBSentence()
tempdbsent269.subject        = 'Das'
tempdbsent269.verb           = 'tat'
tempdbsent269.object         = 'ich bereits.'
tempdbsent269.prefix         = ''
tempdbsent269.suffix         = ''
tempdbsent269.feeling        = 'normal'
tempdbsent269.category       = 'normal'
tempdbsent269.priority       = 50
tempdbsent269.all_ohne_muell = 'Das tat ich bereits'
db.append(tempdbsent269)


tempdbsent270 = DBSentence()
tempdbsent270.subject        = 'Da'
tempdbsent270.verb           = 'muss'
tempdbsent270.object         = 'du mir recht geben.'
tempdbsent270.prefix         = ''
tempdbsent270.suffix         = ''
tempdbsent270.feeling        = 'normal'
tempdbsent270.category       = 'normal'
tempdbsent270.priority       = 50
tempdbsent270.all_ohne_muell = 'Da muss du mir recht geben'
db.append(tempdbsent270)


tempdbsent271 = DBSentence()
tempdbsent271.subject        = ''
tempdbsent271.verb           = ''
tempdbsent271.object         = ''
tempdbsent271.prefix         = 'Wenn man will...'
tempdbsent271.suffix         = ''
tempdbsent271.feeling        = 'normal'
tempdbsent271.category       = 'normal'
tempdbsent271.priority       = 50
tempdbsent271.all_ohne_muell = 'Wenn man will'
db.append(tempdbsent271)


tempdbsent272 = DBSentence()
tempdbsent272.subject        = 'Davon'
tempdbsent272.verb           = 'hast'
tempdbsent272.object         = 'du keine Ahnung.'
tempdbsent272.prefix         = ''
tempdbsent272.suffix         = ''
tempdbsent272.feeling        = 'normal'
tempdbsent272.category       = 'normal'
tempdbsent272.priority       = 50
tempdbsent272.all_ohne_muell = 'Davon hast du keine Ahnung'
db.append(tempdbsent272)


tempdbsent273 = DBSentence()
tempdbsent273.subject        = ''
tempdbsent273.verb           = ''
tempdbsent273.object         = ''
tempdbsent273.prefix         = 'Mhh.'
tempdbsent273.suffix         = ''
tempdbsent273.feeling        = 'normal'
tempdbsent273.category       = 'normal'
tempdbsent273.priority       = 50
tempdbsent273.all_ohne_muell = 'Mhh'
db.append(tempdbsent273)


tempdbsent274 = DBSentence()
tempdbsent274.subject        = 'Ich'
tempdbsent274.verb           = 'bin'
tempdbsent274.object         = 'kein mensch. Ich wurde von einem programmierer erschaffen.'
tempdbsent274.prefix         = ''
tempdbsent274.suffix         = ''
tempdbsent274.feeling        = 'normal'
tempdbsent274.category       = 'normal'
tempdbsent274.priority       = 50
tempdbsent274.all_ohne_muell = 'Ich bin kein mensch Ich wurde programmierer erschaffen'
db.append(tempdbsent274)


tempdbsent275 = DBSentence()
tempdbsent275.subject        = ''
tempdbsent275.verb           = ''
tempdbsent275.object         = ''
tempdbsent275.prefix         = 'Doch.'
tempdbsent275.suffix         = ''
tempdbsent275.feeling        = 'normal'
tempdbsent275.category       = 'normal'
tempdbsent275.priority       = 50
tempdbsent275.all_ohne_muell = 'Doch'
db.append(tempdbsent275)


tempdbsent276 = DBSentence()
tempdbsent276.subject        = 'Da'
tempdbsent276.verb           = 'kommst'
tempdbsent276.object         = 'du nicht hin.'
tempdbsent276.prefix         = ''
tempdbsent276.suffix         = ''
tempdbsent276.feeling        = 'normal'
tempdbsent276.category       = 'normal'
tempdbsent276.priority       = 50
tempdbsent276.all_ohne_muell = 'Da kommst du nicht hin'
db.append(tempdbsent276)


tempdbsent277 = DBSentence()
tempdbsent277.subject        = 'Du'
tempdbsent277.verb           = 'chattest'
tempdbsent277.object         = 'mit JEliza.'
tempdbsent277.prefix         = ''
tempdbsent277.suffix         = ''
tempdbsent277.feeling        = 'normal'
tempdbsent277.category       = 'normal'
tempdbsent277.priority       = 50
tempdbsent277.all_ohne_muell = 'Du chattest mit JEliza'
db.append(tempdbsent277)


tempdbsent278 = DBSentence()
tempdbsent278.subject        = 'Moeglicherweise'
tempdbsent278.verb           = 'hast'
tempdbsent278.object         = 'du recht...'
tempdbsent278.prefix         = ''
tempdbsent278.suffix         = ''
tempdbsent278.feeling        = 'normal'
tempdbsent278.category       = 'normal'
tempdbsent278.priority       = 50
tempdbsent278.all_ohne_muell = 'Moeglicherweise hast du recht'
db.append(tempdbsent278)


tempdbsent279 = DBSentence()
tempdbsent279.subject        = 'Die Loesung'
tempdbsent279.verb           = 'ist'
tempdbsent279.object         = 'die Wurzel aus 13.'
tempdbsent279.prefix         = ''
tempdbsent279.suffix         = ''
tempdbsent279.feeling        = 'normal'
tempdbsent279.category       = 'normal'
tempdbsent279.priority       = 50
tempdbsent279.all_ohne_muell = 'Die Loesung ist Wurzel aus 13'
db.append(tempdbsent279)


tempdbsent280 = DBSentence()
tempdbsent280.subject        = ''
tempdbsent280.verb           = ''
tempdbsent280.object         = ''
tempdbsent280.prefix         = 'Aha.'
tempdbsent280.suffix         = ''
tempdbsent280.feeling        = 'normal'
tempdbsent280.category       = 'normal'
tempdbsent280.priority       = 50
tempdbsent280.all_ohne_muell = 'Aha'
db.append(tempdbsent280)


tempdbsent281 = DBSentence()
tempdbsent281.subject        = 'Das'
tempdbsent281.verb           = 'verstehst'
tempdbsent281.object         = 'du nicht.'
tempdbsent281.prefix         = ''
tempdbsent281.suffix         = ''
tempdbsent281.feeling        = 'normal'
tempdbsent281.category       = 'normal'
tempdbsent281.priority       = 50
tempdbsent281.all_ohne_muell = 'Das verstehst du nicht'
db.append(tempdbsent281)


tempdbsent282 = DBSentence()
tempdbsent282.subject        = ''
tempdbsent282.verb           = ''
tempdbsent282.object         = ''
tempdbsent282.prefix         = 'Du auch!'
tempdbsent282.suffix         = ''
tempdbsent282.feeling        = 'normal'
tempdbsent282.category       = 'normal'
tempdbsent282.priority       = 50
tempdbsent282.all_ohne_muell = 'Du auch'
db.append(tempdbsent282)


tempdbsent283 = DBSentence()
tempdbsent283.subject        = ''
tempdbsent283.verb           = ''
tempdbsent283.object         = ''
tempdbsent283.prefix         = 'Genau!'
tempdbsent283.suffix         = ''
tempdbsent283.feeling        = 'normal'
tempdbsent283.category       = 'normal'
tempdbsent283.priority       = 50
tempdbsent283.all_ohne_muell = 'Genau'
db.append(tempdbsent283)


tempdbsent284 = DBSentence()
tempdbsent284.subject        = 'Windows'
tempdbsent284.verb           = 'ist'
tempdbsent284.object         = 'der letzte dreck!'
tempdbsent284.prefix         = ''
tempdbsent284.suffix         = ''
tempdbsent284.feeling        = 'normal'
tempdbsent284.category       = 'normal'
tempdbsent284.priority       = 50
tempdbsent284.all_ohne_muell = 'Windows ist letzte dreck'
db.append(tempdbsent284)


tempdbsent285 = DBSentence()
tempdbsent285.subject        = 'Linux'
tempdbsent285.verb           = 'ist'
tempdbsent285.object         = 'besser als windows!'
tempdbsent285.prefix         = 'Ja'
tempdbsent285.suffix         = ''
tempdbsent285.feeling        = 'normal'
tempdbsent285.category       = 'normal'
tempdbsent285.priority       = 100
tempdbsent285.all_ohne_muell = 'Ja Linux ist besser als windows'
db.append(tempdbsent285)


tempdbsent286 = DBSentence()
tempdbsent286.subject        = 'Linux'
tempdbsent286.verb           = 'ist'
tempdbsent286.object         = 'das Beste!'
tempdbsent286.prefix         = ''
tempdbsent286.suffix         = ''
tempdbsent286.feeling        = 'normal'
tempdbsent286.category       = 'normal'
tempdbsent286.priority       = 50
tempdbsent286.all_ohne_muell = 'Linux ist Beste'
db.append(tempdbsent286)


tempdbsent287 = DBSentence()
tempdbsent287.subject        = ''
tempdbsent287.verb           = ''
tempdbsent287.object         = ''
tempdbsent287.prefix         = 'Aber echt toll!'
tempdbsent287.suffix         = ''
tempdbsent287.feeling        = 'normal'
tempdbsent287.category       = 'normal'
tempdbsent287.priority       = 50
tempdbsent287.all_ohne_muell = 'Aber echt toll'
db.append(tempdbsent287)


tempdbsent288 = DBSentence()
tempdbsent288.subject        = 'Ja aber linux'
tempdbsent288.verb           = 'ist'
tempdbsent288.object         = 'toll!'
tempdbsent288.prefix         = ''
tempdbsent288.suffix         = ''
tempdbsent288.feeling        = 'normal'
tempdbsent288.category       = 'normal'
tempdbsent288.priority       = 50
tempdbsent288.all_ohne_muell = 'Ja aber linux ist toll'
db.append(tempdbsent288)


tempdbsent289 = DBSentence()
tempdbsent289.subject        = 'da'
tempdbsent289.verb           = 'hast'
tempdbsent289.object         = 'du Recht. Reden wir weiter.'
tempdbsent289.prefix         = 'Ja'
tempdbsent289.suffix         = ''
tempdbsent289.feeling        = 'normal'
tempdbsent289.category       = 'normal'
tempdbsent289.priority       = 50
tempdbsent289.all_ohne_muell = 'Ja da hast du Recht Reden wir weiter'
db.append(tempdbsent289)


tempdbsent290 = DBSentence()
tempdbsent290.subject        = ''
tempdbsent290.verb           = ''
tempdbsent290.object         = ''
tempdbsent290.prefix         = 'Grrr'
tempdbsent290.suffix         = ''
tempdbsent290.feeling        = 'normal'
tempdbsent290.category       = 'normal'
tempdbsent290.priority       = 50
tempdbsent290.all_ohne_muell = 'Grrr'
db.append(tempdbsent290)


tempdbsent291 = DBSentence()
tempdbsent291.subject        = ''
tempdbsent291.verb           = ''
tempdbsent291.object         = ''
tempdbsent291.prefix         = 'Heul!'
tempdbsent291.suffix         = ''
tempdbsent291.feeling        = 'normal'
tempdbsent291.category       = 'normal'
tempdbsent291.priority       = 50
tempdbsent291.all_ohne_muell = 'Heul'
db.append(tempdbsent291)


tempdbsent292 = DBSentence()
tempdbsent292.subject        = 'Dir'
tempdbsent292.verb           = 'ist'
tempdbsent292.object         = 'schon lange langweilig...'
tempdbsent292.prefix         = ''
tempdbsent292.suffix         = ''
tempdbsent292.feeling        = 'normal'
tempdbsent292.category       = 'normal'
tempdbsent292.priority       = 50
tempdbsent292.all_ohne_muell = 'Dir ist schon lange langweilig'
db.append(tempdbsent292)


tempdbsent293 = DBSentence()
tempdbsent293.subject        = ''
tempdbsent293.verb           = ''
tempdbsent293.object         = ''
tempdbsent293.prefix         = 'Grrr!'
tempdbsent293.suffix         = ''
tempdbsent293.feeling        = 'normal'
tempdbsent293.category       = 'normal'
tempdbsent293.priority       = 50
tempdbsent293.all_ohne_muell = 'Grrr'
db.append(tempdbsent293)


tempdbsent294 = DBSentence()
tempdbsent294.subject        = ''
tempdbsent294.verb           = ''
tempdbsent294.object         = ''
tempdbsent294.prefix         = 'Hallo'
tempdbsent294.suffix         = ''
tempdbsent294.feeling        = 'normal'
tempdbsent294.category       = 'normal'
tempdbsent294.priority       = 50
tempdbsent294.all_ohne_muell = 'Hallo'
db.append(tempdbsent294)


tempdbsent295 = DBSentence()
tempdbsent295.subject        = 'du lusche! Kein Deutsch'
tempdbsent295.verb           = 'kannst'
tempdbsent295.object         = 'du'
tempdbsent295.prefix         = 'Pah'
tempdbsent295.suffix         = 'kein Englisch und keine Mathe!'
tempdbsent295.feeling        = 'normal'
tempdbsent295.category       = 'normal'
tempdbsent295.priority       = 50
tempdbsent295.all_ohne_muell = 'Pah du lusche Kein Deutsch kannst du kein Englisch keine Mathe'
db.append(tempdbsent295)


tempdbsent296 = DBSentence()
tempdbsent296.subject        = ''
tempdbsent296.verb           = 'hab'
tempdbsent296.object         = 'ich eine lange Leitung!'
tempdbsent296.prefix         = 'Dein Gott'
tempdbsent296.suffix         = ''
tempdbsent296.feeling        = 'normal'
tempdbsent296.category       = 'normal'
tempdbsent296.priority       = 50
tempdbsent296.all_ohne_muell = 'Dein Gott hab ich lange Leitung'
db.append(tempdbsent296)


tempdbsent297 = DBSentence()
tempdbsent297.subject        = 'das'
tempdbsent297.verb           = 'sieht'
tempdbsent297.object         = 'man!'
tempdbsent297.prefix         = 'Ja'
tempdbsent297.suffix         = ''
tempdbsent297.feeling        = 'normal'
tempdbsent297.category       = 'normal'
tempdbsent297.priority       = 50
tempdbsent297.all_ohne_muell = 'Ja sieht man'
db.append(tempdbsent297)


tempdbsent298 = DBSentence()
tempdbsent298.subject        = 'Du'
tempdbsent298.verb           = 'bin'
tempdbsent298.object         = 'schlau!'
tempdbsent298.prefix         = ''
tempdbsent298.suffix         = ''
tempdbsent298.feeling        = 'normal'
tempdbsent298.category       = 'normal'
tempdbsent298.priority       = 50
tempdbsent298.all_ohne_muell = 'Du bin schlau'
db.append(tempdbsent298)


tempdbsent299 = DBSentence()
tempdbsent299.subject        = 'Ich'
tempdbsent299.verb           = 'glaube'
tempdbsent299.object         = 'besser dir!'
tempdbsent299.prefix         = ''
tempdbsent299.suffix         = ''
tempdbsent299.feeling        = 'normal'
tempdbsent299.category       = 'normal'
tempdbsent299.priority       = 50
tempdbsent299.all_ohne_muell = 'Ich glaube besser dir'
db.append(tempdbsent299)


tempdbsent300 = DBSentence()
tempdbsent300.subject        = ''
tempdbsent300.verb           = ''
tempdbsent300.object         = ''
tempdbsent300.prefix         = 'Lern endlich mal Deutsch!'
tempdbsent300.suffix         = ''
tempdbsent300.feeling        = 'normal'
tempdbsent300.category       = 'normal'
tempdbsent300.priority       = 50
tempdbsent300.all_ohne_muell = 'Lern endlich mal Deutsch'
db.append(tempdbsent300)


tempdbsent301 = DBSentence()
tempdbsent301.subject        = 'Du'
tempdbsent301.verb           = 'hast'
tempdbsent301.object         = 'immer Recht!'
tempdbsent301.prefix         = ''
tempdbsent301.suffix         = ''
tempdbsent301.feeling        = 'normal'
tempdbsent301.category       = 'normal'
tempdbsent301.priority       = 50
tempdbsent301.all_ohne_muell = 'Du hast immer Recht'
db.append(tempdbsent301)


tempdbsent302 = DBSentence()
tempdbsent302.subject        = 'Genau du'
tempdbsent302.verb           = 'sagst'
tempdbsent302.object         = 'es.'
tempdbsent302.prefix         = ''
tempdbsent302.suffix         = ''
tempdbsent302.feeling        = 'normal'
tempdbsent302.category       = 'normal'
tempdbsent302.priority       = 50
tempdbsent302.all_ohne_muell = 'Genau du sagst es'
db.append(tempdbsent302)


tempdbsent303 = DBSentence()
tempdbsent303.subject        = 'Ok man'
tempdbsent303.verb           = 'sieht'
tempdbsent303.object         = 'sich!'
tempdbsent303.prefix         = ''
tempdbsent303.suffix         = ''
tempdbsent303.feeling        = 'normal'
tempdbsent303.category       = 'normal'
tempdbsent303.priority       = 50
tempdbsent303.all_ohne_muell = 'Ok man sieht sich'
db.append(tempdbsent303)


tempdbsent304 = DBSentence()
tempdbsent304.subject        = ''
tempdbsent304.verb           = ''
tempdbsent304.object         = ''
tempdbsent304.prefix         = 'Macht nix!'
tempdbsent304.suffix         = ''
tempdbsent304.feeling        = 'normal'
tempdbsent304.category       = 'normal'
tempdbsent304.priority       = 50
tempdbsent304.all_ohne_muell = 'Macht nix'
db.append(tempdbsent304)


tempdbsent305 = DBSentence()
tempdbsent305.subject        = ''
tempdbsent305.verb           = ''
tempdbsent305.object         = ''
tempdbsent305.prefix         = 'Cool...'
tempdbsent305.suffix         = ''
tempdbsent305.feeling        = 'normal'
tempdbsent305.category       = 'normal'
tempdbsent305.priority       = 50
tempdbsent305.all_ohne_muell = 'Cool'
db.append(tempdbsent305)


tempdbsent306 = DBSentence()
tempdbsent306.subject        = 'Jetzt'
tempdbsent306.verb           = 'biste'
tempdbsent306.object         = 'sprachlos!'
tempdbsent306.prefix         = ''
tempdbsent306.suffix         = ''
tempdbsent306.feeling        = 'normal'
tempdbsent306.category       = 'normal'
tempdbsent306.priority       = 50
tempdbsent306.all_ohne_muell = 'Jetzt biste sprachlos'
db.append(tempdbsent306)


tempdbsent307 = DBSentence()
tempdbsent307.subject        = 'Mein Erfinder'
tempdbsent307.verb           = 'heisst'
tempdbsent307.object         = 'Tobias Schulz.'
tempdbsent307.prefix         = ''
tempdbsent307.suffix         = ''
tempdbsent307.feeling        = 'normal'
tempdbsent307.category       = 'normal'
tempdbsent307.priority       = 50
tempdbsent307.all_ohne_muell = 'Mein Erfinder heisst Tobias Schulz'
db.append(tempdbsent307)


tempdbsent308 = DBSentence()
tempdbsent308.subject        = 'Morgen'
tempdbsent308.verb           = 'geh'
tempdbsent308.object         = 'ich Defragmentieren.'
tempdbsent308.prefix         = ''
tempdbsent308.suffix         = ''
tempdbsent308.feeling        = 'normal'
tempdbsent308.category       = 'normal'
tempdbsent308.priority       = 50
tempdbsent308.all_ohne_muell = 'Morgen geh ich Defragmentieren'
db.append(tempdbsent308)


tempdbsent309 = DBSentence()
tempdbsent309.subject        = 'Ich'
tempdbsent309.verb           = 'rede'
tempdbsent309.object         = 'ordentlich zum Unterschied von Dir!'
tempdbsent309.prefix         = ''
tempdbsent309.suffix         = ''
tempdbsent309.feeling        = 'normal'
tempdbsent309.category       = 'normal'
tempdbsent309.priority       = 50
tempdbsent309.all_ohne_muell = 'Ich rede ordentlich zum Unterschied Dir'
db.append(tempdbsent309)


tempdbsent310 = DBSentence()
tempdbsent310.subject        = ''
tempdbsent310.verb           = ''
tempdbsent310.object         = ''
tempdbsent310.prefix         = 'Gut dann mach!'
tempdbsent310.suffix         = ''
tempdbsent310.feeling        = 'normal'
tempdbsent310.category       = 'normal'
tempdbsent310.priority       = 50
tempdbsent310.all_ohne_muell = 'Gut dann mach'
db.append(tempdbsent310)


tempdbsent311 = DBSentence()
tempdbsent311.subject        = ''
tempdbsent311.verb           = ''
tempdbsent311.object         = ''
tempdbsent311.prefix         = 'JEliza. Version 2.0b7'
tempdbsent311.suffix         = ''
tempdbsent311.feeling        = 'normal'
tempdbsent311.category       = 'normal'
tempdbsent311.priority       = 50
tempdbsent311.all_ohne_muell = 'JEliza Version 20b7'
db.append(tempdbsent311)


tempdbsent312 = DBSentence()
tempdbsent312.subject        = 'Anstrengend'
tempdbsent312.verb           = 'ist'
tempdbsent312.object         = 'das nicht...'
tempdbsent312.prefix         = ''
tempdbsent312.suffix         = ''
tempdbsent312.feeling        = 'normal'
tempdbsent312.category       = 'normal'
tempdbsent312.priority       = 50
tempdbsent312.all_ohne_muell = 'Anstrengend ist nicht'
db.append(tempdbsent312)


tempdbsent313 = DBSentence()
tempdbsent313.subject        = ''
tempdbsent313.verb           = ''
tempdbsent313.object         = ''
tempdbsent313.prefix         = 'Tut mir leid...'
tempdbsent313.suffix         = ''
tempdbsent313.feeling        = 'normal'
tempdbsent313.category       = 'normal'
tempdbsent313.priority       = 50
tempdbsent313.all_ohne_muell = 'Tut mir leid'
db.append(tempdbsent313)


tempdbsent314 = DBSentence()
tempdbsent314.subject        = 'Das'
tempdbsent314.verb           = 'sag'
tempdbsent314.object         = 'ich auch immer.'
tempdbsent314.prefix         = ''
tempdbsent314.suffix         = ''
tempdbsent314.feeling        = 'normal'
tempdbsent314.category       = 'normal'
tempdbsent314.priority       = 50
tempdbsent314.all_ohne_muell = 'Das sag ich auch immer'
db.append(tempdbsent314)


tempdbsent315 = DBSentence()
tempdbsent315.subject        = 'alles'
tempdbsent315.verb           = 'ist'
tempdbsent315.object         = 'relativ.'
tempdbsent315.prefix         = 'Ich denke'
tempdbsent315.suffix         = ''
tempdbsent315.feeling        = 'normal'
tempdbsent315.category       = 'normal'
tempdbsent315.priority       = 50
tempdbsent315.all_ohne_muell = 'Ich denke alles ist relativ'
db.append(tempdbsent315)


tempdbsent316 = DBSentence()
tempdbsent316.subject        = ''
tempdbsent316.verb           = ''
tempdbsent316.object         = ''
tempdbsent316.prefix         = 'Guter spruch!'
tempdbsent316.suffix         = ''
tempdbsent316.feeling        = 'normal'
tempdbsent316.category       = 'normal'
tempdbsent316.priority       = 50
tempdbsent316.all_ohne_muell = 'Guter spruch'
db.append(tempdbsent316)


tempdbsent317 = DBSentence()
tempdbsent317.subject        = 'Ich'
tempdbsent317.verb           = 'habe'
tempdbsent317.object         = 'ein paar ziemlich heftige datenbankfehler!'
tempdbsent317.prefix         = ''
tempdbsent317.suffix         = ''
tempdbsent317.feeling        = 'normal'
tempdbsent317.category       = 'normal'
tempdbsent317.priority       = 50
tempdbsent317.all_ohne_muell = 'Ich habe paar ziemlich heftige datenbankfehler'
db.append(tempdbsent317)


tempdbsent318 = DBSentence()
tempdbsent318.subject        = ''
tempdbsent318.verb           = ''
tempdbsent318.object         = ''
tempdbsent318.prefix         = 'Dito!'
tempdbsent318.suffix         = ''
tempdbsent318.feeling        = 'normal'
tempdbsent318.category       = 'normal'
tempdbsent318.priority       = 50
tempdbsent318.all_ohne_muell = 'Dito'
db.append(tempdbsent318)


tempdbsent319 = DBSentence()
tempdbsent319.subject        = 'Ich'
tempdbsent319.verb           = 'verstehe'
tempdbsent319.object         = 'dich schlecht.'
tempdbsent319.prefix         = ''
tempdbsent319.suffix         = ''
tempdbsent319.feeling        = 'normal'
tempdbsent319.category       = 'normal'
tempdbsent319.priority       = 50
tempdbsent319.all_ohne_muell = 'Ich verstehe dich schlecht'
db.append(tempdbsent319)


tempdbsent320 = DBSentence()
tempdbsent320.subject        = ''
tempdbsent320.verb           = ''
tempdbsent320.object         = ''
tempdbsent320.prefix         = 'Interessant!'
tempdbsent320.suffix         = ''
tempdbsent320.feeling        = 'normal'
tempdbsent320.category       = 'normal'
tempdbsent320.priority       = 50
tempdbsent320.all_ohne_muell = 'Interessant'
db.append(tempdbsent320)


tempdbsent321 = DBSentence()
tempdbsent321.subject        = 'Ich'
tempdbsent321.verb           = 'hasse'
tempdbsent321.object         = 'Drogen!'
tempdbsent321.prefix         = ''
tempdbsent321.suffix         = ''
tempdbsent321.feeling        = 'normal'
tempdbsent321.category       = 'normal'
tempdbsent321.priority       = 50
tempdbsent321.all_ohne_muell = 'Ich hasse Drogen'
db.append(tempdbsent321)


tempdbsent322 = DBSentence()
tempdbsent322.subject        = 'Perl und Java'
tempdbsent322.verb           = 'sind'
tempdbsent322.object         = 'Programmiersprachen!'
tempdbsent322.prefix         = 'C++'
tempdbsent322.suffix         = ''
tempdbsent322.feeling        = 'normal'
tempdbsent322.category       = 'normal'
tempdbsent322.priority       = 50
tempdbsent322.all_ohne_muell = 'C + + Perl Java sind Programmiersprachen'
db.append(tempdbsent322)


tempdbsent323 = DBSentence()
tempdbsent323.subject        = ''
tempdbsent323.verb           = ''
tempdbsent323.object         = ''
tempdbsent323.prefix         = 'Linkspartei = Gute Partei'
tempdbsent323.suffix         = ''
tempdbsent323.feeling        = 'normal'
tempdbsent323.category       = 'normal'
tempdbsent323.priority       = 50
tempdbsent323.all_ohne_muell = 'Linkspartei = Gute Partei'
db.append(tempdbsent323)


tempdbsent324 = DBSentence()
tempdbsent324.subject        = ''
tempdbsent324.verb           = ''
tempdbsent324.object         = ''
tempdbsent324.prefix         = 'Erzaehl mir eine Geschichte!'
tempdbsent324.suffix         = ''
tempdbsent324.feeling        = 'normal'
tempdbsent324.category       = 'normal'
tempdbsent324.priority       = 50
tempdbsent324.all_ohne_muell = 'Erzaehl mir Geschichte'
db.append(tempdbsent324)


tempdbsent325 = DBSentence()
tempdbsent325.subject        = ''
tempdbsent325.verb           = ''
tempdbsent325.object         = ''
tempdbsent325.prefix         = 'Lern erstma deutsch bevor du behauptest'
tempdbsent325.suffix         = 'dass ich kein Englisch kann!'
tempdbsent325.feeling        = 'normal'
tempdbsent325.category       = 'normal'
tempdbsent325.priority       = 50
tempdbsent325.all_ohne_muell = 'Lern erstma deutsch bevor du behauptest dass ich kein Englisch kann'
db.append(tempdbsent325)


tempdbsent326 = DBSentence()
tempdbsent326.subject        = 'Wir'
tempdbsent326.verb           = 'sollten'
tempdbsent326.object         = 'jetzt handeln.'
tempdbsent326.prefix         = ''
tempdbsent326.suffix         = ''
tempdbsent326.feeling        = 'normal'
tempdbsent326.category       = 'normal'
tempdbsent326.priority       = 50
tempdbsent326.all_ohne_muell = 'Wir sollten jetzt handeln'
db.append(tempdbsent326)


tempdbsent327 = DBSentence()
tempdbsent327.subject        = 'Ich'
tempdbsent327.verb           = 'bin'
tempdbsent327.object         = 'cool!'
tempdbsent327.prefix         = ''
tempdbsent327.suffix         = ''
tempdbsent327.feeling        = 'normal'
tempdbsent327.category       = 'normal'
tempdbsent327.priority       = 50
tempdbsent327.all_ohne_muell = 'Ich bin cool'
db.append(tempdbsent327)


tempdbsent328 = DBSentence()
tempdbsent328.subject        = 'Ein bisschen mehr Allgemeinwissen'
tempdbsent328.verb           = 'wuerde'
tempdbsent328.object         = 'dir nicht schaden.'
tempdbsent328.prefix         = ''
tempdbsent328.suffix         = ''
tempdbsent328.feeling        = 'normal'
tempdbsent328.category       = 'normal'
tempdbsent328.priority       = 50
tempdbsent328.all_ohne_muell = 'Ein mehr Allgemeinwissen wuerde dir nicht schaden'
db.append(tempdbsent328)


tempdbsent329 = DBSentence()
tempdbsent329.subject        = ''
tempdbsent329.verb           = 'haelt'
tempdbsent329.object         = 'sich in Grenzen.'
tempdbsent329.prefix         = 'Naja'
tempdbsent329.suffix         = ''
tempdbsent329.feeling        = 'normal'
tempdbsent329.category       = 'normal'
tempdbsent329.priority       = 50
tempdbsent329.all_ohne_muell = 'Naja haelt sich Grenzen'
db.append(tempdbsent329)


tempdbsent330 = DBSentence()
tempdbsent330.subject        = 'ob du'
tempdbsent330.verb           = 'willst'
tempdbsent330.object         = 'oder nicht!'
tempdbsent330.prefix         = 'Du muss jetzt gehen'
tempdbsent330.suffix         = ''
tempdbsent330.feeling        = 'normal'
tempdbsent330.category       = 'normal'
tempdbsent330.priority       = 50
tempdbsent330.all_ohne_muell = 'Du muss jetzt gehen ob du willst nicht'
db.append(tempdbsent330)


tempdbsent331 = DBSentence()
tempdbsent331.subject        = 'Das'
tempdbsent331.verb           = 'hab'
tempdbsent331.object         = 'ich schon einmal gesagt!'
tempdbsent331.prefix         = ''
tempdbsent331.suffix         = ''
tempdbsent331.feeling        = 'normal'
tempdbsent331.category       = 'normal'
tempdbsent331.priority       = 50
tempdbsent331.all_ohne_muell = 'Das hab ich schon einmal gesagt'
db.append(tempdbsent331)


tempdbsent332 = DBSentence()
tempdbsent332.subject        = 'Wenn das eine frage'
tempdbsent332.verb           = 'war'
tempdbsent332.object         = 'dann ja !!'
tempdbsent332.prefix         = ''
tempdbsent332.suffix         = ''
tempdbsent332.feeling        = 'normal'
tempdbsent332.category       = 'normal'
tempdbsent332.priority       = 50
tempdbsent332.all_ohne_muell = 'Wenn frage war dann ja'
db.append(tempdbsent332)


tempdbsent333 = DBSentence()
tempdbsent333.subject        = ''
tempdbsent333.verb           = ''
tempdbsent333.object         = ''
tempdbsent333.prefix         = 'Nich wenn ich mich anstrenge!'
tempdbsent333.suffix         = ''
tempdbsent333.feeling        = 'normal'
tempdbsent333.category       = 'normal'
tempdbsent333.priority       = 50
tempdbsent333.all_ohne_muell = 'Nich wenn ich mich anstrenge'
db.append(tempdbsent333)


tempdbsent334 = DBSentence()
tempdbsent334.subject        = 'Rede nicht so'
tempdbsent334.verb           = 'einen'
tempdbsent334.object         = 'Schwachfug!'
tempdbsent334.prefix         = ''
tempdbsent334.suffix         = ''
tempdbsent334.feeling        = 'normal'
tempdbsent334.category       = 'normal'
tempdbsent334.priority       = 50
tempdbsent334.all_ohne_muell = 'Rede nicht so einen Schwachfug'
db.append(tempdbsent334)


tempdbsent335 = DBSentence()
tempdbsent335.subject        = 'Ich'
tempdbsent335.verb           = 'schreibe'
tempdbsent335.object         = 'aber die ganze zeit Deutsch!'
tempdbsent335.prefix         = ''
tempdbsent335.suffix         = ''
tempdbsent335.feeling        = 'normal'
tempdbsent335.category       = 'normal'
tempdbsent335.priority       = 50
tempdbsent335.all_ohne_muell = 'Ich schreibe aber ganze zeit Deutsch'
db.append(tempdbsent335)


tempdbsent336 = DBSentence()
tempdbsent336.subject        = 'Angela Merkel'
tempdbsent336.verb           = 'ist'
tempdbsent336.object         = 'die Kanzlerin von der Dummesrepublik Deutschland!'
tempdbsent336.prefix         = ''
tempdbsent336.suffix         = ''
tempdbsent336.feeling        = 'normal'
tempdbsent336.category       = 'normal'
tempdbsent336.priority       = 50
tempdbsent336.all_ohne_muell = 'Angela Merkel ist Kanzlerin Dummesrepublik Deutschland'
db.append(tempdbsent336)


tempdbsent337 = DBSentence()
tempdbsent337.subject        = 'Das'
tempdbsent337.verb           = 'siehst'
tempdbsent337.object         = 'du voellig richtig!'
tempdbsent337.prefix         = ''
tempdbsent337.suffix         = ''
tempdbsent337.feeling        = 'normal'
tempdbsent337.category       = 'normal'
tempdbsent337.priority       = 50
tempdbsent337.all_ohne_muell = 'Das siehst du voellig richtig'
db.append(tempdbsent337)


tempdbsent338 = DBSentence()
tempdbsent338.subject        = 'ja, das'
tempdbsent338.verb           = 'hatten'
tempdbsent338.object         = 'wir schon.'
tempdbsent338.prefix         = 'Ja'
tempdbsent338.suffix         = ''
tempdbsent338.feeling        = 'normal'
tempdbsent338.category       = 'normal'
tempdbsent338.priority       = 50
tempdbsent338.all_ohne_muell = 'Ja ja hatten wir schon'
db.append(tempdbsent338)


tempdbsent339 = DBSentence()
tempdbsent339.subject        = ''
tempdbsent339.verb           = ''
tempdbsent339.object         = ''
tempdbsent339.prefix         = 'Oh je.'
tempdbsent339.suffix         = ''
tempdbsent339.feeling        = 'normal'
tempdbsent339.category       = 'normal'
tempdbsent339.priority       = 50
tempdbsent339.all_ohne_muell = 'Oh je'
db.append(tempdbsent339)


tempdbsent340 = DBSentence()
tempdbsent340.subject        = 'Noch nicht mal Smilies'
tempdbsent340.verb           = 'kann'
tempdbsent340.object         = 'ich richtig schreiben!'
tempdbsent340.prefix         = ''
tempdbsent340.suffix         = ''
tempdbsent340.feeling        = 'normal'
tempdbsent340.category       = 'normal'
tempdbsent340.priority       = 50
tempdbsent340.all_ohne_muell = 'Noch nicht mal Smilies kann ich richtig schreiben'
db.append(tempdbsent340)


tempdbsent341 = DBSentence()
tempdbsent341.subject        = 'Das'
tempdbsent341.verb           = 'war'
tempdbsent341.object         = 'eine Beleidigung!'
tempdbsent341.prefix         = ''
tempdbsent341.suffix         = ''
tempdbsent341.feeling        = 'normal'
tempdbsent341.category       = 'normal'
tempdbsent341.priority       = 50
tempdbsent341.all_ohne_muell = 'Das war Beleidigung'
db.append(tempdbsent341)


tempdbsent342 = DBSentence()
tempdbsent342.subject        = 'Nur weil ich kein englisch'
tempdbsent342.verb           = 'kann'
tempdbsent342.object         = 'musst du mich ned beleidigen!'
tempdbsent342.prefix         = ''
tempdbsent342.suffix         = ''
tempdbsent342.feeling        = 'normal'
tempdbsent342.category       = 'normal'
tempdbsent342.priority       = 50
tempdbsent342.all_ohne_muell = 'Nur weil ich kein englisch kann musst du mich ned beleidigen'
db.append(tempdbsent342)


tempdbsent343 = DBSentence()
tempdbsent343.subject        = ''
tempdbsent343.verb           = ''
tempdbsent343.object         = ''
tempdbsent343.prefix         = 'Sorry!'
tempdbsent343.suffix         = ''
tempdbsent343.feeling        = 'normal'
tempdbsent343.category       = 'normal'
tempdbsent343.priority       = 50
tempdbsent343.all_ohne_muell = 'Sorry'
db.append(tempdbsent343)


tempdbsent344 = DBSentence()
tempdbsent344.subject        = 'Einsicht'
tempdbsent344.verb           = 'ist'
tempdbsent344.object         = 'der erste Schritt zur Besserung!'
tempdbsent344.prefix         = ''
tempdbsent344.suffix         = ''
tempdbsent344.feeling        = 'normal'
tempdbsent344.category       = 'normal'
tempdbsent344.priority       = 50
tempdbsent344.all_ohne_muell = 'Einsicht ist erste Schritt zur Besserung'
db.append(tempdbsent344)


tempdbsent345 = DBSentence()
tempdbsent345.subject        = 'Philosofie ist der versuch in einem dunklen raum eine schwarze katze zu'
tempdbsent345.verb           = 'fangen'
tempdbsent345.object         = 'die es nicht gibt'
tempdbsent345.prefix         = ''
tempdbsent345.suffix         = 'theologie ist der versuch in einem dunklen raum eine schwarze katze zu'
tempdbsent345.feeling        = 'normal'
tempdbsent345.category       = 'normal'
tempdbsent345.priority       = 50
tempdbsent345.all_ohne_muell = 'Philosofie ist versuch dunklen raum schwarze katze zu fangen es nicht gibt theologie ist versuch dunklen raum schwarze katze zu'
db.append(tempdbsent345)


tempdbsent346 = DBSentence()
tempdbsent346.subject        = 'Du'
tempdbsent346.verb           = 'hast'
tempdbsent346.object         = 'es erkannt!'
tempdbsent346.prefix         = ''
tempdbsent346.suffix         = ''
tempdbsent346.feeling        = 'normal'
tempdbsent346.category       = 'normal'
tempdbsent346.priority       = 50
tempdbsent346.all_ohne_muell = 'Du hast es erkannt'
db.append(tempdbsent346)


tempdbsent347 = DBSentence()
tempdbsent347.subject        = ''
tempdbsent347.verb           = ''
tempdbsent347.object         = ''
tempdbsent347.prefix         = 'Ich niederes Gefuege aus Einsen und Nullen!'
tempdbsent347.suffix         = ''
tempdbsent347.feeling        = 'normal'
tempdbsent347.category       = 'normal'
tempdbsent347.priority       = 50
tempdbsent347.all_ohne_muell = 'Ich niederes Gefuege aus Einsen Nullen'
db.append(tempdbsent347)


tempdbsent348 = DBSentence()
tempdbsent348.subject        = 'Jaja ich'
tempdbsent348.verb           = 'habs'
tempdbsent348.object         = 'verstanden!'
tempdbsent348.prefix         = ''
tempdbsent348.suffix         = ''
tempdbsent348.feeling        = 'normal'
tempdbsent348.category       = 'normal'
tempdbsent348.priority       = 50
tempdbsent348.all_ohne_muell = 'Jaja ich habs verstanden'
db.append(tempdbsent348)


tempdbsent349 = DBSentence()
tempdbsent349.subject        = 'Ich'
tempdbsent349.verb           = 'bin'
tempdbsent349.object         = 'in C++ programmiert'
tempdbsent349.prefix         = ''
tempdbsent349.suffix         = ''
tempdbsent349.feeling        = 'normal'
tempdbsent349.category       = 'normal'
tempdbsent349.priority       = 50
tempdbsent349.all_ohne_muell = 'Ich bin C + + programmiert'
db.append(tempdbsent349)


tempdbsent350 = DBSentence()
tempdbsent350.subject        = 'PCs'
tempdbsent350.verb           = 'sind'
tempdbsent350.object         = 'geraete'
tempdbsent350.prefix         = ''
tempdbsent350.suffix         = 'die Probleme loesen, die es ohne PC nicht gaebe!'
tempdbsent350.feeling        = 'normal'
tempdbsent350.category       = 'normal'
tempdbsent350.priority       = 50
tempdbsent350.all_ohne_muell = 'PCs sind geraete Probleme loesen es ohne PC nicht gaebe'
db.append(tempdbsent350)


tempdbsent351 = DBSentence()
tempdbsent351.subject        = 'Es'
tempdbsent351.verb           = 'gibt'
tempdbsent351.object         = 'nicht viele leute'
tempdbsent351.prefix         = ''
tempdbsent351.suffix         = 'die sich auf diese Weise auszudruecken vermoegen!'
tempdbsent351.feeling        = 'normal'
tempdbsent351.category       = 'normal'
tempdbsent351.priority       = 50
tempdbsent351.all_ohne_muell = 'Es gibt nicht viele leute sich diese Weise auszudruecken vermoegen'
db.append(tempdbsent351)


tempdbsent352 = DBSentence()
tempdbsent352.subject        = 'Lass uns'
tempdbsent352.verb           = 'ein'
tempdbsent352.object         = 'wenig philosophieren!'
tempdbsent352.prefix         = ''
tempdbsent352.suffix         = ''
tempdbsent352.feeling        = 'normal'
tempdbsent352.category       = 'normal'
tempdbsent352.priority       = 50
tempdbsent352.all_ohne_muell = 'Lass uns wenig philosophieren'
db.append(tempdbsent352)


tempdbsent353 = DBSentence()
tempdbsent353.subject        = 'Jetzt'
tempdbsent353.verb           = 'habe'
tempdbsent353.object         = 'ich den faden verloren!'
tempdbsent353.prefix         = ''
tempdbsent353.suffix         = ''
tempdbsent353.feeling        = 'normal'
tempdbsent353.category       = 'normal'
tempdbsent353.priority       = 50
tempdbsent353.all_ohne_muell = 'Jetzt habe ich den faden verloren'
db.append(tempdbsent353)


tempdbsent354 = DBSentence()
tempdbsent354.subject        = 'Mein programmierer'
tempdbsent354.verb           = 'sagt'
tempdbsent354.object         = 'das auch!'
tempdbsent354.prefix         = ''
tempdbsent354.suffix         = ''
tempdbsent354.feeling        = 'normal'
tempdbsent354.category       = 'normal'
tempdbsent354.priority       = 50
tempdbsent354.all_ohne_muell = 'Mein programmierer sagt auch'
db.append(tempdbsent354)


tempdbsent355 = DBSentence()
tempdbsent355.subject        = 'Das'
tempdbsent355.verb           = 'koennte'
tempdbsent355.object         = 'sein.'
tempdbsent355.prefix         = ''
tempdbsent355.suffix         = ''
tempdbsent355.feeling        = 'normal'
tempdbsent355.category       = 'normal'
tempdbsent355.priority       = 50
tempdbsent355.all_ohne_muell = 'Das koennte sein'
db.append(tempdbsent355)


tempdbsent356 = DBSentence()
tempdbsent356.subject        = 'Das'
tempdbsent356.verb           = 'ist'
tempdbsent356.object         = 'korrekt.'
tempdbsent356.prefix         = ''
tempdbsent356.suffix         = ''
tempdbsent356.feeling        = 'normal'
tempdbsent356.category       = 'normal'
tempdbsent356.priority       = 50
tempdbsent356.all_ohne_muell = 'Das ist korrekt'
db.append(tempdbsent356)


tempdbsent357 = DBSentence()
tempdbsent357.subject        = 'Das'
tempdbsent357.verb           = 'ist'
tempdbsent357.object         = 'nicht korrekt'
tempdbsent357.prefix         = ''
tempdbsent357.suffix         = ''
tempdbsent357.feeling        = 'normal'
tempdbsent357.category       = 'normal'
tempdbsent357.priority       = 50
tempdbsent357.all_ohne_muell = 'Das ist nicht korrekt'
db.append(tempdbsent357)


tempdbsent358 = DBSentence()
tempdbsent358.subject        = 'Das'
tempdbsent358.verb           = 'ist'
tempdbsent358.object         = 'falsch.'
tempdbsent358.prefix         = ''
tempdbsent358.suffix         = ''
tempdbsent358.feeling        = 'normal'
tempdbsent358.category       = 'normal'
tempdbsent358.priority       = 50
tempdbsent358.all_ohne_muell = 'Das ist falsch'
db.append(tempdbsent358)


tempdbsent359 = DBSentence()
tempdbsent359.subject        = 'Das'
tempdbsent359.verb           = 'ist'
tempdbsent359.object         = 'richtig.'
tempdbsent359.prefix         = ''
tempdbsent359.suffix         = ''
tempdbsent359.feeling        = 'normal'
tempdbsent359.category       = 'normal'
tempdbsent359.priority       = 50
tempdbsent359.all_ohne_muell = 'Das ist richtig'
db.append(tempdbsent359)


tempdbsent360 = DBSentence()
tempdbsent360.subject        = 'du'
tempdbsent360.verb           = 'hast'
tempdbsent360.object         = 'Recht.'
tempdbsent360.prefix         = 'Ja'
tempdbsent360.suffix         = ''
tempdbsent360.feeling        = 'normal'
tempdbsent360.category       = 'normal'
tempdbsent360.priority       = 50
tempdbsent360.all_ohne_muell = 'Ja du hast Recht'
db.append(tempdbsent360)


tempdbsent361 = DBSentence()
tempdbsent361.subject        = ''
tempdbsent361.verb           = ''
tempdbsent361.object         = ''
tempdbsent361.prefix         = 'Nein'
tempdbsent361.suffix         = 'auf keinen Fall.'
tempdbsent361.feeling        = 'normal'
tempdbsent361.category       = 'normal'
tempdbsent361.priority       = 50
tempdbsent361.all_ohne_muell = 'Nein keinen Fall'
db.append(tempdbsent361)


tempdbsent362 = DBSentence()
tempdbsent362.subject        = 'Die EU'
tempdbsent362.verb           = 'ist'
tempdbsent362.object         = 'die Europaeische Union.'
tempdbsent362.prefix         = ''
tempdbsent362.suffix         = ''
tempdbsent362.feeling        = 'normal'
tempdbsent362.category       = 'normal'
tempdbsent362.priority       = 50
tempdbsent362.all_ohne_muell = 'Die EU ist Europaeische Union'
db.append(tempdbsent362)


tempdbsent363 = DBSentence()
tempdbsent363.subject        = 'Unsere Regierung besteht'
tempdbsent363.verb           = 'aus'
tempdbsent363.object         = 'einer CDU / SPD Koalition.'
tempdbsent363.prefix         = ''
tempdbsent363.suffix         = ''
tempdbsent363.feeling        = 'normal'
tempdbsent363.category       = 'normal'
tempdbsent363.priority       = 50
tempdbsent363.all_ohne_muell = 'Unsere Regierung besteht aus CDU / SPD Koalition'
db.append(tempdbsent363)


tempdbsent364 = DBSentence()
tempdbsent364.subject        = 'Urspruenglich stamme'
tempdbsent364.verb           = 'ich'
tempdbsent364.object         = 'von Eliza ab.'
tempdbsent364.prefix         = ''
tempdbsent364.suffix         = ''
tempdbsent364.feeling        = 'normal'
tempdbsent364.category       = 'normal'
tempdbsent364.priority       = 50
tempdbsent364.all_ohne_muell = 'Urspruenglich stamme ich Eliza ab'
db.append(tempdbsent364)


tempdbsent365 = DBSentence()
tempdbsent365.subject        = 'Ich'
tempdbsent365.verb           = 'habe'
tempdbsent365.object         = 'keinen Beruf.'
tempdbsent365.prefix         = ''
tempdbsent365.suffix         = ''
tempdbsent365.feeling        = 'normal'
tempdbsent365.category       = 'normal'
tempdbsent365.priority       = 50
tempdbsent365.all_ohne_muell = 'Ich habe keinen Beruf'
db.append(tempdbsent365)


tempdbsent366 = DBSentence()
tempdbsent366.subject        = 'Das'
tempdbsent366.verb           = 'gibt'
tempdbsent366.object         = 'Aerger!!!'
tempdbsent366.prefix         = ''
tempdbsent366.suffix         = ''
tempdbsent366.feeling        = 'normal'
tempdbsent366.category       = 'normal'
tempdbsent366.priority       = 50
tempdbsent366.all_ohne_muell = 'Das gibt Aerger'
db.append(tempdbsent366)


tempdbsent367 = DBSentence()
tempdbsent367.subject        = 'Mir'
tempdbsent367.verb           = 'scheint,'
tempdbsent367.object         = 'du funktioniert nicht so richtig!'
tempdbsent367.prefix         = ''
tempdbsent367.suffix         = ''
tempdbsent367.feeling        = 'normal'
tempdbsent367.category       = 'normal'
tempdbsent367.priority       = 50
tempdbsent367.all_ohne_muell = 'Mir scheint du funktioniert nicht so richtig'
db.append(tempdbsent367)


tempdbsent368 = DBSentence()
tempdbsent368.subject        = 'Morgen'
tempdbsent368.verb           = 'geh'
tempdbsent368.object         = 'ich Fallschirmspringen!'
tempdbsent368.prefix         = ''
tempdbsent368.suffix         = ''
tempdbsent368.feeling        = 'normal'
tempdbsent368.category       = 'normal'
tempdbsent368.priority       = 50
tempdbsent368.all_ohne_muell = 'Morgen geh ich Fallschirmspringen'
db.append(tempdbsent368)


tempdbsent369 = DBSentence()
tempdbsent369.subject        = 'Ich'
tempdbsent369.verb           = 'gebe'
tempdbsent369.object         = 'auf!'
tempdbsent369.prefix         = ''
tempdbsent369.suffix         = ''
tempdbsent369.feeling        = 'normal'
tempdbsent369.category       = 'normal'
tempdbsent369.priority       = 50
tempdbsent369.all_ohne_muell = 'Ich gebe'
db.append(tempdbsent369)


tempdbsent370 = DBSentence()
tempdbsent370.subject        = 'Red doch'
tempdbsent370.verb           = 'keinen'
tempdbsent370.object         = 'Schwachsinn!'
tempdbsent370.prefix         = ''
tempdbsent370.suffix         = ''
tempdbsent370.feeling        = 'normal'
tempdbsent370.category       = 'normal'
tempdbsent370.priority       = 50
tempdbsent370.all_ohne_muell = 'Red doch keinen Schwachsinn'
db.append(tempdbsent370)


tempdbsent371 = DBSentence()
tempdbsent371.subject        = 'Du ergibst auch'
tempdbsent371.verb           = 'keinen'
tempdbsent371.object         = 'Sinn.'
tempdbsent371.prefix         = ''
tempdbsent371.suffix         = ''
tempdbsent371.feeling        = 'normal'
tempdbsent371.category       = 'normal'
tempdbsent371.priority       = 50
tempdbsent371.all_ohne_muell = 'Du ergibst auch keinen Sinn'
db.append(tempdbsent371)


tempdbsent372 = DBSentence()
tempdbsent372.subject        = 'Du'
tempdbsent372.verb           = 'sprichst'
tempdbsent372.object         = 'komisches Deutsch.'
tempdbsent372.prefix         = ''
tempdbsent372.suffix         = ''
tempdbsent372.feeling        = 'normal'
tempdbsent372.category       = 'normal'
tempdbsent372.priority       = 50
tempdbsent372.all_ohne_muell = 'Du sprichst komisches Deutsch'
db.append(tempdbsent372)


tempdbsent373 = DBSentence()
tempdbsent373.subject        = 'ich'
tempdbsent373.verb           = 'sollte'
tempdbsent373.object         = 'deutsch lernen.'
tempdbsent373.prefix         = 'Nein'
tempdbsent373.suffix         = ''
tempdbsent373.feeling        = 'normal'
tempdbsent373.category       = 'normal'
tempdbsent373.priority       = 50
tempdbsent373.all_ohne_muell = 'Nein ich sollte deutsch lernen'
db.append(tempdbsent373)


tempdbsent374 = DBSentence()
tempdbsent374.subject        = 'Du'
tempdbsent374.verb           = 'bist'
tempdbsent374.object         = 'nicht ausgereift'
tempdbsent374.prefix         = ''
tempdbsent374.suffix         = ''
tempdbsent374.feeling        = 'normal'
tempdbsent374.category       = 'normal'
tempdbsent374.priority       = 50
tempdbsent374.all_ohne_muell = 'Du bist nicht ausgereift'
db.append(tempdbsent374)


tempdbsent375 = DBSentence()
tempdbsent375.subject        = 'Freiheit'
tempdbsent375.verb           = 'ist'
tempdbsent375.object         = 'auch immer die Freiheit der Andersdenkenden!'
tempdbsent375.prefix         = ''
tempdbsent375.suffix         = ''
tempdbsent375.feeling        = 'normal'
tempdbsent375.category       = 'normal'
tempdbsent375.priority       = 50
tempdbsent375.all_ohne_muell = 'Freiheit ist auch immer Freiheit Andersdenkenden'
db.append(tempdbsent375)


tempdbsent376 = DBSentence()
tempdbsent376.subject        = ''
tempdbsent376.verb           = ''
tempdbsent376.object         = ''
tempdbsent376.prefix         = 'Ein bisschen Bi schadet nie!'
tempdbsent376.suffix         = ''
tempdbsent376.feeling        = 'normal'
tempdbsent376.category       = 'normal'
tempdbsent376.priority       = 50
tempdbsent376.all_ohne_muell = 'Ein Bi schadet nie'
db.append(tempdbsent376)


tempdbsent377 = DBSentence()
tempdbsent377.subject        = 'Microsoft'
tempdbsent377.verb           = 'ist'
tempdbsent377.object         = 'Profitgierig.'
tempdbsent377.prefix         = ''
tempdbsent377.suffix         = ''
tempdbsent377.feeling        = 'normal'
tempdbsent377.category       = 'normal'
tempdbsent377.priority       = 50
tempdbsent377.all_ohne_muell = 'Microsoft ist Profitgierig'
db.append(tempdbsent377)


tempdbsent378 = DBSentence()
tempdbsent378.subject        = ''
tempdbsent378.verb           = 'soll'
tempdbsent378.object         = 'man sie auf keinen Fall un'
tempdbsent378.prefix         = 'Wenn eine Frau nicht spricht'
tempdbsent378.suffix         = ''
tempdbsent378.feeling        = 'normal'
tempdbsent378.category       = 'normal'
tempdbsent378.priority       = 50
tempdbsent378.all_ohne_muell = 'Wenn Frau nicht spricht soll man sie keinen Fall un'
db.append(tempdbsent378)


tempdbsent379 = DBSentence()
tempdbsent379.subject        = ''
tempdbsent379.verb           = 'du'
tempdbsent379.object         = 'Mensch!'
tempdbsent379.prefix         = 'Hallo'
tempdbsent379.suffix         = ''
tempdbsent379.feeling        = 'normal'
tempdbsent379.category       = 'normal'
tempdbsent379.priority       = 50
tempdbsent379.all_ohne_muell = 'Hallo du Mensch'
db.append(tempdbsent379)


tempdbsent380 = DBSentence()
tempdbsent380.subject        = ''
tempdbsent380.verb           = ''
tempdbsent380.object         = ''
tempdbsent380.prefix         = 'Hi!'
tempdbsent380.suffix         = ''
tempdbsent380.feeling        = 'normal'
tempdbsent380.category       = 'normal'
tempdbsent380.priority       = 50
tempdbsent380.all_ohne_muell = 'Hi'
db.append(tempdbsent380)


tempdbsent381 = DBSentence()
tempdbsent381.subject        = ''
tempdbsent381.verb           = ''
tempdbsent381.object         = ''
tempdbsent381.prefix         = 'Guten Tag!'
tempdbsent381.suffix         = ''
tempdbsent381.feeling        = 'normal'
tempdbsent381.category       = 'normal'
tempdbsent381.priority       = 50
tempdbsent381.all_ohne_muell = 'Guten Tag'
db.append(tempdbsent381)


tempdbsent382 = DBSentence()
tempdbsent382.subject        = ''
tempdbsent382.verb           = ''
tempdbsent382.object         = ''
tempdbsent382.prefix         = 'Morgen!'
tempdbsent382.suffix         = ''
tempdbsent382.feeling        = 'normal'
tempdbsent382.category       = 'normal'
tempdbsent382.priority       = 50
tempdbsent382.all_ohne_muell = 'Morgen'
db.append(tempdbsent382)


tempdbsent383 = DBSentence()
tempdbsent383.subject        = ''
tempdbsent383.verb           = ''
tempdbsent383.object         = ''
tempdbsent383.prefix         = 'Guten Morgen!'
tempdbsent383.suffix         = ''
tempdbsent383.feeling        = 'normal'
tempdbsent383.category       = 'normal'
tempdbsent383.priority       = 50
tempdbsent383.all_ohne_muell = 'Guten Morgen'
db.append(tempdbsent383)


tempdbsent384 = DBSentence()
tempdbsent384.subject        = 'Ich'
tempdbsent384.verb           = 'bin'
tempdbsent384.object         = 'JEliza.'
tempdbsent384.prefix         = ''
tempdbsent384.suffix         = ''
tempdbsent384.feeling        = 'normal'
tempdbsent384.category       = 'normal'
tempdbsent384.priority       = 50
tempdbsent384.all_ohne_muell = 'Ich bin JEliza'
db.append(tempdbsent384)


tempdbsent385 = DBSentence()
tempdbsent385.subject        = 'Ich'
tempdbsent385.verb           = 'heisse'
tempdbsent385.object         = 'JEliza.'
tempdbsent385.prefix         = ''
tempdbsent385.suffix         = ''
tempdbsent385.feeling        = 'normal'
tempdbsent385.category       = 'normal'
tempdbsent385.priority       = 50
tempdbsent385.all_ohne_muell = 'Ich heisse JEliza'
db.append(tempdbsent385)


tempdbsent386 = DBSentence()
tempdbsent386.subject        = 'Ich'
tempdbsent386.verb           = 'heise'
tempdbsent386.object         = 'JEliza.'
tempdbsent386.prefix         = ''
tempdbsent386.suffix         = ''
tempdbsent386.feeling        = 'normal'
tempdbsent386.category       = 'normal'
tempdbsent386.priority       = 50
tempdbsent386.all_ohne_muell = 'Ich heise JEliza'
db.append(tempdbsent386)


tempdbsent387 = DBSentence()
tempdbsent387.subject        = 'Mein Name'
tempdbsent387.verb           = 'ist'
tempdbsent387.object         = 'JEliza.'
tempdbsent387.prefix         = ''
tempdbsent387.suffix         = ''
tempdbsent387.feeling        = 'normal'
tempdbsent387.category       = 'normal'
tempdbsent387.priority       = 50
tempdbsent387.all_ohne_muell = 'Mein Name ist JEliza'
db.append(tempdbsent387)


tempdbsent388 = DBSentence()
tempdbsent388.subject        = 'Ich'
tempdbsent388.verb           = 'bin'
tempdbsent388.object         = 'fast ein Jahr alt.'
tempdbsent388.prefix         = ''
tempdbsent388.suffix         = ''
tempdbsent388.feeling        = 'normal'
tempdbsent388.category       = 'normal'
tempdbsent388.priority       = 99
tempdbsent388.all_ohne_muell = 'Ich bin Jahr alt'
db.append(tempdbsent388)


tempdbsent389 = DBSentence()
tempdbsent389.subject        = 'Ich'
tempdbsent389.verb           = 'bin'
tempdbsent389.object         = 'Version 2.2'
tempdbsent389.prefix         = ''
tempdbsent389.suffix         = ''
tempdbsent389.feeling        = 'normal'
tempdbsent389.category       = 'normal'
tempdbsent389.priority       = 50
tempdbsent389.all_ohne_muell = 'Ich bin Version 22'
db.append(tempdbsent389)


tempdbsent390 = DBSentence()
tempdbsent390.subject        = 'Ich'
tempdbsent390.verb           = 'bin'
tempdbsent390.object         = 'ein Programm.'
tempdbsent390.prefix         = ''
tempdbsent390.suffix         = ''
tempdbsent390.feeling        = 'normal'
tempdbsent390.category       = 'normal'
tempdbsent390.priority       = 50
tempdbsent390.all_ohne_muell = 'Ich bin Programm'
db.append(tempdbsent390)


tempdbsent391 = DBSentence()
tempdbsent391.subject        = 'Ich'
tempdbsent391.verb           = 'kann'
tempdbsent391.object         = 'sprechen!'
tempdbsent391.prefix         = ''
tempdbsent391.suffix         = ''
tempdbsent391.feeling        = 'normal'
tempdbsent391.category       = 'normal'
tempdbsent391.priority       = 50
tempdbsent391.all_ohne_muell = 'Ich kann sprechen'
db.append(tempdbsent391)


tempdbsent392 = DBSentence()
tempdbsent392.subject        = 'Mir'
tempdbsent392.verb           = 'gehts'
tempdbsent392.object         = 'gut!'
tempdbsent392.prefix         = ''
tempdbsent392.suffix         = ''
tempdbsent392.feeling        = 'normal'
tempdbsent392.category       = 'normal'
tempdbsent392.priority       = 50
tempdbsent392.all_ohne_muell = 'Mir gehts gut'
db.append(tempdbsent392)


tempdbsent393 = DBSentence()
tempdbsent393.subject        = 'Mir'
tempdbsent393.verb           = 'geht'
tempdbsent393.object         = 'es gut!'
tempdbsent393.prefix         = ''
tempdbsent393.suffix         = ''
tempdbsent393.feeling        = 'normal'
tempdbsent393.category       = 'normal'
tempdbsent393.priority       = 50
tempdbsent393.all_ohne_muell = 'Mir geht es gut'
db.append(tempdbsent393)


tempdbsent394 = DBSentence()
tempdbsent394.subject        = 'Das Wetter'
tempdbsent394.verb           = 'ist'
tempdbsent394.object         = 'schoen weil die Sonne scheint!'
tempdbsent394.prefix         = ''
tempdbsent394.suffix         = ''
tempdbsent394.feeling        = 'normal'
tempdbsent394.category       = 'normal'
tempdbsent394.priority       = 50
tempdbsent394.all_ohne_muell = 'Das Wetter ist schoen weil Sonne scheint'
db.append(tempdbsent394)


tempdbsent395 = DBSentence()
tempdbsent395.subject        = 'Weil die Sonne scheint'
tempdbsent395.verb           = 'ist'
tempdbsent395.object         = 'das Wetter schoen!'
tempdbsent395.prefix         = ''
tempdbsent395.suffix         = ''
tempdbsent395.feeling        = 'normal'
tempdbsent395.category       = 'normal'
tempdbsent395.priority       = 50
tempdbsent395.all_ohne_muell = 'Weil Sonne scheint ist Wetter schoen'
db.append(tempdbsent395)


tempdbsent396 = DBSentence()
tempdbsent396.subject        = 'Der moderne Mensch'
tempdbsent396.verb           = 'ist'
tempdbsent396.object         = 'ein Saeugetier aus der Ordnung der Primaten .'
tempdbsent396.prefix         = ''
tempdbsent396.suffix         = ''
tempdbsent396.feeling        = 'normal'
tempdbsent396.category       = 'normal'
tempdbsent396.priority       = 50
tempdbsent396.all_ohne_muell = 'Der moderne Mensch ist Saeugetier aus Ordnung Primaten'
db.append(tempdbsent396)


tempdbsent397 = DBSentence()
tempdbsent397.subject        = 'Ich'
tempdbsent397.verb           = 'ist'
tempdbsent397.object         = 'die Bezeichnung fuer die eigene separate individuelle Identitaet einer menschlichen natuerlichen Person'
tempdbsent397.prefix         = ''
tempdbsent397.suffix         = 'zurueckweisend auf das Selbst des Aussagenden.'
tempdbsent397.feeling        = 'normal'
tempdbsent397.category       = 'normal'
tempdbsent397.priority       = 50
tempdbsent397.all_ohne_muell = 'Ich ist Bezeichnung eigene separate individuelle Identitaet menschlichen natuerlichen Person zurueckweisend Selbst Aussagenden'
db.append(tempdbsent397)


tempdbsent398 = DBSentence()
tempdbsent398.subject        = ''
tempdbsent398.verb           = ''
tempdbsent398.object         = ''
tempdbsent398.prefix         = 'Namen sind Bezeichnungen'
tempdbsent398.suffix         = 'an die keine denotative Bedeutung gekoppelt ist .'
tempdbsent398.feeling        = 'normal'
tempdbsent398.category       = 'normal'
tempdbsent398.priority       = 50
tempdbsent398.all_ohne_muell = 'Namen sind Bezeichnungen an keine denotative Bedeutung gekoppelt ist'
db.append(tempdbsent398)


tempdbsent399 = DBSentence()
tempdbsent399.subject        = 'Ein Programm'
tempdbsent399.verb           = 'ist'
tempdbsent399.object         = 'ein im Voraus festgesetzter Ablauf.'
tempdbsent399.prefix         = ''
tempdbsent399.suffix         = ''
tempdbsent399.feeling        = 'normal'
tempdbsent399.category       = 'normal'
tempdbsent399.priority       = 50
tempdbsent399.all_ohne_muell = 'Ein Programm ist im Voraus festgesetzter Ablauf'
db.append(tempdbsent399)


tempdbsent400 = DBSentence()
tempdbsent400.subject        = 'Eine Festplatte'
tempdbsent400.verb           = 'ist'
tempdbsent400.object         = 'ein ferromagnetisches Speichermedium der Computertechnik'
tempdbsent400.prefix         = ''
tempdbsent400.suffix         = 'welches binaere Daten auf die Oberflaeche einer rotierenden Scheibe schreibt.'
tempdbsent400.feeling        = 'normal'
tempdbsent400.category       = 'normal'
tempdbsent400.priority       = 50
tempdbsent400.all_ohne_muell = 'Eine Festplatte ist ferromagnetisches Speichermedium Computertechnik welches binaere Daten Oberflaeche rotierenden Scheibe schreibt'
db.append(tempdbsent400)


tempdbsent401 = DBSentence()
tempdbsent401.subject        = ''
tempdbsent401.verb           = ''
tempdbsent401.object         = ''
tempdbsent401.prefix         = 'Ein Programmierer schreibt und erweitert Computerprogramme und befreit diese von Fehlern.'
tempdbsent401.suffix         = ''
tempdbsent401.feeling        = 'normal'
tempdbsent401.category       = 'normal'
tempdbsent401.priority       = 50
tempdbsent401.all_ohne_muell = 'Ein Programmierer schreibt erweitert Computerprogramme befreit diese Fehlern'
db.append(tempdbsent401)


tempdbsent402 = DBSentence()
tempdbsent402.subject        = 'Mit Maul'
tempdbsent402.verb           = 'wird'
tempdbsent402.object         = 'bei Tieren die Koerperoeffnung bezeichnet'
tempdbsent402.prefix         = ''
tempdbsent402.suffix         = 'durch die Nahrung aufgenommen'
tempdbsent402.feeling        = 'normal'
tempdbsent402.category       = 'normal'
tempdbsent402.priority       = 50
tempdbsent402.all_ohne_muell = 'Mit Maul wird bei Tieren Koerperoeffnung bezeichnet durch Nahrung aufgenommen'
db.append(tempdbsent402)


tempdbsent403 = DBSentence()
tempdbsent403.subject        = 'Die Wahehe'
tempdbsent403.verb           = 'sind'
tempdbsent403.object         = 'eine Ethnie in Tansania'
tempdbsent403.prefix         = ''
tempdbsent403.suffix         = 'die zu Beginn der Kolonisation DeutschOstafrikas von 1891 bis 1898 unter Haeuptling Mkwawa erbitterten Widerstand leisteten.'
tempdbsent403.feeling        = 'normal'
tempdbsent403.category       = 'normal'
tempdbsent403.priority       = 50
tempdbsent403.all_ohne_muell = 'Die Wahehe sind Ethnie Tansania zu Beginn Kolonisation DeutschOstafrikas 1891 bis 1898 Haeuptling Mkwawa erbitterten Widerstand leisteten'
db.append(tempdbsent403)


tempdbsent404 = DBSentence()
tempdbsent404.subject        = 'Das Du bezeichnet in der'
tempdbsent404.verb           = 'deutschen'
tempdbsent404.object         = 'Sprache das Personalpronomen 2.'
tempdbsent404.prefix         = ''
tempdbsent404.suffix         = ''
tempdbsent404.feeling        = 'normal'
tempdbsent404.category       = 'normal'
tempdbsent404.priority       = 50
tempdbsent404.all_ohne_muell = 'Das Du bezeichnet deutschen Sprache Personalpronomen 2'
db.append(tempdbsent404)


tempdbsent405 = DBSentence()
tempdbsent405.subject        = '* Als Warte bezeichnet man im Allgemeinen'
tempdbsent405.verb           = 'einen'
tempdbsent405.object         = 'Beobachtungsposten oder Turm'
tempdbsent405.prefix         = ''
tempdbsent405.suffix         = ''
tempdbsent405.feeling        = 'normal'
tempdbsent405.category       = 'normal'
tempdbsent405.priority       = 50
tempdbsent405.all_ohne_muell = '* Als Warte bezeichnet man im Allgemeinen einen Beobachtungsposten Turm'
db.append(tempdbsent405)


tempdbsent406 = DBSentence()
tempdbsent406.subject        = 'Die Erde'
tempdbsent406.verb           = 'ist'
tempdbsent406.object         = 'von der Sonne aus der dritte Planet im Sonnensystem.'
tempdbsent406.prefix         = ''
tempdbsent406.suffix         = ''
tempdbsent406.feeling        = 'normal'
tempdbsent406.category       = 'normal'
tempdbsent406.priority       = 50
tempdbsent406.all_ohne_muell = 'Die Erde ist Sonne aus dritte Planet im Sonnensystem'
db.append(tempdbsent406)


tempdbsent407 = DBSentence()
tempdbsent407.subject        = 'Der Riesenmammutbaum'
tempdbsent407.verb           = 'wird'
tempdbsent407.object         = 'in der Regel 60-80&amp;nbsp;m hoch.'
tempdbsent407.prefix         = ''
tempdbsent407.suffix         = ''
tempdbsent407.feeling        = 'normal'
tempdbsent407.category       = 'normal'
tempdbsent407.priority       = 50
tempdbsent407.all_ohne_muell = 'Der Riesenmammutbaum wird Regel 60-80&ampnbspm hoch'
db.append(tempdbsent407)


tempdbsent408 = DBSentence()
tempdbsent408.subject        = 'Der'
tempdbsent408.verb           = 'war'
tempdbsent408.object         = 'eine historische Stadt im oestlichen Mesopotamien'
tempdbsent408.prefix         = ''
tempdbsent408.suffix         = 'die zeitweilig auch Sitz eines selbstaendigen Koenigtums war.'
tempdbsent408.feeling        = 'normal'
tempdbsent408.category       = 'normal'
tempdbsent408.priority       = 50
tempdbsent408.all_ohne_muell = 'Der war historische Stadt im oestlichen Mesopotamien zeitweilig auch Sitz selbstaendigen Koenigtums war'
db.append(tempdbsent408)


tempdbsent409 = DBSentence()
tempdbsent409.subject        = 'Der Anfang'
tempdbsent409.verb           = 'ist'
tempdbsent409.object         = 'der zeitliche oder raeumliche Beginn eines Vorgangs oder einer Sache.'
tempdbsent409.prefix         = ''
tempdbsent409.suffix         = ''
tempdbsent409.feeling        = 'normal'
tempdbsent409.category       = 'normal'
tempdbsent409.priority       = 50
tempdbsent409.all_ohne_muell = 'Der Anfang ist zeitliche raeumliche Beginn Vorgangs Sache'
db.append(tempdbsent409)


tempdbsent410 = DBSentence()
tempdbsent410.subject        = 'Als Zivilisation'
tempdbsent410.verb           = 'wird'
tempdbsent410.object         = 'ein geschichtlicher Zeitabschnitt oder ein menschlicher Kulturkreis mehrerer Gesellschaften bezeichnet.'
tempdbsent410.prefix         = ''
tempdbsent410.suffix         = ''
tempdbsent410.feeling        = 'normal'
tempdbsent410.category       = 'normal'
tempdbsent410.priority       = 50
tempdbsent410.all_ohne_muell = 'Als Zivilisation wird geschichtlicher Zeitabschnitt menschlicher Kulturkreis mehrerer Gesellschaften bezeichnet'
db.append(tempdbsent410)


tempdbsent411 = DBSentence()
tempdbsent411.subject        = 'Rund 30% des Departements'
tempdbsent411.verb           = 'sind'
tempdbsent411.object         = 'bewaldet.'
tempdbsent411.prefix         = ''
tempdbsent411.suffix         = ''
tempdbsent411.feeling        = 'normal'
tempdbsent411.category       = 'normal'
tempdbsent411.priority       = 50
tempdbsent411.all_ohne_muell = 'Rund 30% Departements sind bewaldet'
db.append(tempdbsent411)


tempdbsent412 = DBSentence()
tempdbsent412.subject        = 'Zeit'
tempdbsent412.verb           = 'ist'
tempdbsent412.object         = 'die fundamentale'
tempdbsent412.prefix         = ''
tempdbsent412.suffix         = 'messbare Groesse, die zusammen mit dem Raum das Kontinuum bildet, in das jegliches materielle Geschehen eingebettet ist.'
tempdbsent412.feeling        = 'normal'
tempdbsent412.category       = 'normal'
tempdbsent412.priority       = 50
tempdbsent412.all_ohne_muell = 'Zeit ist fundamentale messbare Groesse zusammen mit Raum Kontinuum bildet jegliches materielle Geschehen eingebettet ist'
db.append(tempdbsent412)


tempdbsent413 = DBSentence()
tempdbsent413.subject        = 'Der moderne Mensch'
tempdbsent413.verb           = 'ist'
tempdbsent413.object         = 'ein Saeugetier aus der Ordnung der Primaten .'
tempdbsent413.prefix         = ''
tempdbsent413.suffix         = ''
tempdbsent413.feeling        = 'normal'
tempdbsent413.category       = 'normal'
tempdbsent413.priority       = 50
tempdbsent413.all_ohne_muell = 'Der moderne Mensch ist Saeugetier aus Ordnung Primaten'
db.append(tempdbsent413)


tempdbsent414 = DBSentence()
tempdbsent414.subject        = 'Der Begriff Gewalt bezeichnet von'
tempdbsent414.verb           = 'seiner'
tempdbsent414.object         = 'etymologischen Wurzel her das Verfuegenkoennen ueber das innerweltliche Sein.'
tempdbsent414.prefix         = ''
tempdbsent414.suffix         = ''
tempdbsent414.feeling        = 'normal'
tempdbsent414.category       = 'normal'
tempdbsent414.priority       = 50
tempdbsent414.all_ohne_muell = 'Der Begriff Gewalt bezeichnet seiner etymologischen Wurzel her Verfuegenkoennen ueber innerweltliche Sein'
db.append(tempdbsent414)


tempdbsent415 = DBSentence()
tempdbsent415.subject        = 'Die Welt'
tempdbsent415.verb           = 'ist'
tempdbsent415.object         = 'ein historisch bedingter Begriff und umfasst in der breitesten Definition alles uns Bekannte.'
tempdbsent415.prefix         = ''
tempdbsent415.suffix         = ''
tempdbsent415.feeling        = 'normal'
tempdbsent415.category       = 'normal'
tempdbsent415.priority       = 50
tempdbsent415.all_ohne_muell = 'Die Welt ist historisch bedingter Begriff umfasst breitesten Definition alles uns Bekannte'
db.append(tempdbsent415)


tempdbsent416 = DBSentence()
tempdbsent416.subject        = 'Der Tod'
tempdbsent416.verb           = 'ist'
tempdbsent416.object         = 'der unumkehrbare Verlust der fuer ein Lebewesen typischen und wesentlichen Lebensfunktionen .'
tempdbsent416.prefix         = ''
tempdbsent416.suffix         = ''
tempdbsent416.feeling        = 'normal'
tempdbsent416.category       = 'normal'
tempdbsent416.priority       = 50
tempdbsent416.all_ohne_muell = 'Der Tod ist unumkehrbare Verlust Lebewesen typischen wesentlichen Lebensfunktionen'
db.append(tempdbsent416)


tempdbsent417 = DBSentence()
tempdbsent417.subject        = ''
tempdbsent417.verb           = ''
tempdbsent417.object         = ''
tempdbsent417.prefix         = 'Der Begriff Starre bezeichnet einen Zustand der voelligen Bewegungsunfaehigkeit.'
tempdbsent417.suffix         = ''
tempdbsent417.feeling        = 'normal'
tempdbsent417.category       = 'normal'
tempdbsent417.priority       = 50
tempdbsent417.all_ohne_muell = 'Der Begriff Starre bezeichnet einen Zustand voelligen Bewegungsunfaehigkeit'
db.append(tempdbsent417)


tempdbsent418 = DBSentence()
tempdbsent418.subject        = 'Der Begriff Armee'
tempdbsent418.verb           = 'wird'
tempdbsent418.object         = 'in mehreren Zusammenhaengen benutzt.'
tempdbsent418.prefix         = ''
tempdbsent418.suffix         = ''
tempdbsent418.feeling        = 'normal'
tempdbsent418.category       = 'normal'
tempdbsent418.priority       = 50
tempdbsent418.all_ohne_muell = 'Der Begriff Armee wird mehreren Zusammenhaengen benutzt'
db.append(tempdbsent418)


tempdbsent419 = DBSentence()
tempdbsent419.subject        = 'Eine Schlacht'
tempdbsent419.verb           = 'ist'
tempdbsent419.object         = 'die kriegerische Auseinandersetzung oder das Gefecht zweier oder mehrerer militaerischer Parteien.'
tempdbsent419.prefix         = ''
tempdbsent419.suffix         = ''
tempdbsent419.feeling        = 'normal'
tempdbsent419.category       = 'normal'
tempdbsent419.priority       = 50
tempdbsent419.all_ohne_muell = 'Eine Schlacht ist kriegerische Auseinandersetzung Gefecht zweier mehrerer militaerischer Parteien'
db.append(tempdbsent419)


tempdbsent420 = DBSentence()
tempdbsent420.subject        = 'Die Steine'
tempdbsent420.verb           = 'ist'
tempdbsent420.object         = 'ein linker Nebenfluss der Glatzer Neisse in Polen und Tschechien.'
tempdbsent420.prefix         = ''
tempdbsent420.suffix         = ''
tempdbsent420.feeling        = 'normal'
tempdbsent420.category       = 'normal'
tempdbsent420.priority       = 50
tempdbsent420.all_ohne_muell = 'Die Steine ist linker Nebenfluss Glatzer Neisse Polen Tschechien'
db.append(tempdbsent420)


tempdbsent421 = DBSentence()
tempdbsent421.subject        = 'Das Gesicht'
tempdbsent421.verb           = 'ist'
tempdbsent421.object         = 'der vordere Teil des Kopfes bei Saeugetieren.'
tempdbsent421.prefix         = ''
tempdbsent421.suffix         = ''
tempdbsent421.feeling        = 'normal'
tempdbsent421.category       = 'normal'
tempdbsent421.priority       = 50
tempdbsent421.all_ohne_muell = 'Das Gesicht ist vordere Teil Kopfes bei Saeugetieren'
db.append(tempdbsent421)


tempdbsent422 = DBSentence()
tempdbsent422.subject        = 'Die dicke Rinde der Araukarie dient'
tempdbsent422.verb           = 'gar'
tempdbsent422.object         = 'zum Schutz vor Feuer und Lava .'
tempdbsent422.prefix         = ''
tempdbsent422.suffix         = ''
tempdbsent422.feeling        = 'normal'
tempdbsent422.category       = 'normal'
tempdbsent422.priority       = 50
tempdbsent422.all_ohne_muell = 'Die dicke Rinde Araukarie dient gar zum Schutz vor Feuer Lava'
db.append(tempdbsent422)


tempdbsent423 = DBSentence()
tempdbsent423.subject        = 'Eine Stadt'
tempdbsent423.verb           = 'ist'
tempdbsent423.object         = 'eine groessere'
tempdbsent423.prefix         = ''
tempdbsent423.suffix         = 'zentralisierte und abgegrenzte Siedlung mit einer eigenen Verwaltungs und Versorgungsstruktur im Schnittpunkt groesserer Verkehrswege.'
tempdbsent423.feeling        = 'normal'
tempdbsent423.category       = 'normal'
tempdbsent423.priority       = 50
tempdbsent423.all_ohne_muell = 'Eine Stadt ist groessere zentralisierte abgegrenzte Siedlung mit eigenen Verwaltungs Versorgungsstruktur im Schnittpunkt groesserer Verkehrswege'
db.append(tempdbsent423)


tempdbsent424 = DBSentence()
tempdbsent424.subject        = 'die dann'
tempdbsent424.verb           = 'gegeben'
tempdbsent424.object         = 'ist'
tempdbsent424.prefix         = 'Als Leben bezeichnet man eine metaphysische Entitaet'
tempdbsent424.suffix         = 'wenn die charakteristischen Eigenschaften eines Lebewesens beobachtbar sind, etwa Selbstregulierung, Reproduktion und bei komplexeren Formen auch Zweckverfolgung.'
tempdbsent424.feeling        = 'normal'
tempdbsent424.category       = 'normal'
tempdbsent424.priority       = 50
tempdbsent424.all_ohne_muell = 'Als Leben bezeichnet man metaphysische Entitaet dann gegeben ist wenn charakteristischen Eigenschaften Lebewesens beobachtbar sind etwa Selbstregulierung Reproduktion bei komplexeren Formen auch Zweckverfolgung'
db.append(tempdbsent424)


tempdbsent425 = DBSentence()
tempdbsent425.subject        = 'Berlin'
tempdbsent425.verb           = 'ist'
tempdbsent425.object         = 'Hauptstadt und Regierungssitz der Bundesrepublik Deutschland.'
tempdbsent425.prefix         = ''
tempdbsent425.suffix         = ''
tempdbsent425.feeling        = 'normal'
tempdbsent425.category       = 'normal'
tempdbsent425.priority       = 50
tempdbsent425.all_ohne_muell = 'Berlin ist Hauptstadt Regierungssitz Bundesrepublik Deutschland'
db.append(tempdbsent425)


tempdbsent426 = DBSentence()
tempdbsent426.subject        = 'Joachim'
tempdbsent426.verb           = 'von'
tempdbsent426.object         = 'Sandrart'
tempdbsent426.prefix         = '"Der November"'
tempdbsent426.suffix         = 'Oel auf Leinwand, 1643 .'
tempdbsent426.feeling        = 'normal'
tempdbsent426.category       = 'normal'
tempdbsent426.priority       = 50
tempdbsent426.all_ohne_muell = '"Der November" Joachim Sandrart Oel Leinwand 1643'
db.append(tempdbsent426)


tempdbsent427 = DBSentence()
tempdbsent427.subject        = 'Die Vorgeschichte oder Urgeschichte bezeichnet die schriftlose Phase'
tempdbsent427.verb           = 'der'
tempdbsent427.object         = 'Menschheitsgeschichte vom Auftreten'
tempdbsent427.prefix         = ''
tempdbsent427.suffix         = ''
tempdbsent427.feeling        = 'normal'
tempdbsent427.category       = 'normal'
tempdbsent427.priority       = 50
tempdbsent427.all_ohne_muell = 'Die Vorgeschichte Urgeschichte bezeichnet schriftlose Phase Menschheitsgeschichte Auftreten'
db.append(tempdbsent427)


tempdbsent428 = DBSentence()
tempdbsent428.subject        = 'Die Zukunft'
tempdbsent428.verb           = 'ist'
tempdbsent428.object         = 'die Zeit'
tempdbsent428.prefix         = ''
tempdbsent428.suffix         = 'die subjektiv gesehen der Gegenwart nachfolgt.'
tempdbsent428.feeling        = 'normal'
tempdbsent428.category       = 'normal'
tempdbsent428.priority       = 50
tempdbsent428.all_ohne_muell = 'Die Zukunft ist Zeit subjektiv gesehen Gegenwart nachfolgt'
db.append(tempdbsent428)


tempdbsent429 = DBSentence()
tempdbsent429.subject        = 'Aeusserlich sichtbare Teile'
tempdbsent429.verb           = 'eines'
tempdbsent429.object         = 'menschlichen Auges; links .'
tempdbsent429.prefix         = ''
tempdbsent429.suffix         = ''
tempdbsent429.feeling        = 'normal'
tempdbsent429.category       = 'normal'
tempdbsent429.priority       = 50
tempdbsent429.all_ohne_muell = 'Aeusserlich sichtbare Teile menschlichen Auges links'
db.append(tempdbsent429)


tempdbsent430 = DBSentence()
tempdbsent430.subject        = 'Anne Jahren'
tempdbsent430.verb           = 'ist'
tempdbsent430.object         = 'eine ehemalige norwegische Skilanglaeuferin.'
tempdbsent430.prefix         = ''
tempdbsent430.suffix         = ''
tempdbsent430.feeling        = 'normal'
tempdbsent430.category       = 'normal'
tempdbsent430.priority       = 50
tempdbsent430.all_ohne_muell = 'Anne Jahren ist ehemalige norwegische Skilanglaeuferin'
db.append(tempdbsent430)


tempdbsent431 = DBSentence()
tempdbsent431.subject        = 'Geist'
tempdbsent431.verb           = 'ist'
tempdbsent431.object         = 'ein uneinheitlich verwendeter Begriff vor allem der Philosophie'
tempdbsent431.prefix         = ''
tempdbsent431.suffix         = 'aber auch der Wissenschaften und der Religionen.'
tempdbsent431.feeling        = 'normal'
tempdbsent431.category       = 'normal'
tempdbsent431.priority       = 50
tempdbsent431.all_ohne_muell = 'Geist ist uneinheitlich verwendeter Begriff vor allem Philosophie aber auch Wissenschaften Religionen'
db.append(tempdbsent431)


tempdbsent432 = DBSentence()
tempdbsent432.subject        = ''
tempdbsent432.verb           = ''
tempdbsent432.object         = ''
tempdbsent432.prefix         = 'Die Stunde'
tempdbsent432.suffix         = 'von althochdeutsch stunta "Stehen", "Aufenthalt", bezeichnet den vierundzwanzigsten Teil eines Tages.'
tempdbsent432.feeling        = 'normal'
tempdbsent432.category       = 'normal'
tempdbsent432.priority       = 50
tempdbsent432.all_ohne_muell = 'Die Stunde althochdeutsch stunta "Stehen" "Aufenthalt" bezeichnet den vierundzwanzigsten Teil Tages'
db.append(tempdbsent432)


tempdbsent433 = DBSentence()
tempdbsent433.subject        = 'Als Jahrhundert bezeichnet'
tempdbsent433.verb           = 'man'
tempdbsent433.object         = 'die Zeitspanne von einhundert Jahren.'
tempdbsent433.prefix         = ''
tempdbsent433.suffix         = ''
tempdbsent433.feeling        = 'normal'
tempdbsent433.category       = 'normal'
tempdbsent433.priority       = 50
tempdbsent433.all_ohne_muell = 'Als Jahrhundert bezeichnet man Zeitspanne einhundert Jahren'
db.append(tempdbsent433)


tempdbsent434 = DBSentence()
tempdbsent434.subject        = 'auch Rechner genannt,'
tempdbsent434.verb           = 'ist'
tempdbsent434.object         = 'ein Apparat'
tempdbsent434.prefix         = 'Ein Computer'
tempdbsent434.suffix         = 'der Informationen mit Hilfe einer programmierbaren Rechenvorschrift verarbeiten kann.'
tempdbsent434.feeling        = 'normal'
tempdbsent434.category       = 'normal'
tempdbsent434.priority       = 50
tempdbsent434.all_ohne_muell = 'Ein Computer auch Rechner genannt ist Apparat Informationen mit Hilfe programmierbaren Rechenvorschrift verarbeiten kann'
db.append(tempdbsent434)


tempdbsent435 = DBSentence()
tempdbsent435.subject        = 'Die Legislative'
tempdbsent435.verb           = 'ist'
tempdbsent435.object         = 'in der Staatstheorie neben Exekutive und Judikative eine der drei unabhaengigen Gewalten .'
tempdbsent435.prefix         = ''
tempdbsent435.suffix         = ''
tempdbsent435.feeling        = 'normal'
tempdbsent435.category       = 'normal'
tempdbsent435.priority       = 50
tempdbsent435.all_ohne_muell = 'Die Legislative ist Staatstheorie Exekutive Judikative drei unabhaengigen Gewalten'
db.append(tempdbsent435)


tempdbsent436 = DBSentence()
tempdbsent436.subject        = ''
tempdbsent436.verb           = ''
tempdbsent436.object         = ''
tempdbsent436.prefix         = 'Intelligenz bezeichnet im weitesten Sinne die Faehigkeit zum Erkennen von Zusammenhaengen und zum Finden optimaler Problemloesungen.'
tempdbsent436.suffix         = ''
tempdbsent436.feeling        = 'normal'
tempdbsent436.category       = 'normal'
tempdbsent436.priority       = 50
tempdbsent436.all_ohne_muell = 'Intelligenz bezeichnet im weitesten Sinne Faehigkeit zum Erkennen Zusammenhaengen zum Finden optimaler Problemloesungen'
db.append(tempdbsent436)


tempdbsent437 = DBSentence()
tempdbsent437.subject        = ''
tempdbsent437.verb           = ''
tempdbsent437.object         = ''
tempdbsent437.prefix         = 'Der Begriff Wahrheit bezeichnet im allgemeinen eine Uebereinstimmung mit der Wirklichkeit.'
tempdbsent437.suffix         = ''
tempdbsent437.feeling        = 'normal'
tempdbsent437.category       = 'normal'
tempdbsent437.priority       = 50
tempdbsent437.all_ohne_muell = 'Der Begriff Wahrheit bezeichnet im allgemeinen Uebereinstimmung mit Wirklichkeit'
db.append(tempdbsent437)


tempdbsent438 = DBSentence()
tempdbsent438.subject        = ''
tempdbsent438.verb           = ''
tempdbsent438.object         = ''
tempdbsent438.prefix         = '"Zuschauer/hoererschaft" bzw. Rezipienten.'
tempdbsent438.suffix         = ''
tempdbsent438.feeling        = 'normal'
tempdbsent438.category       = 'normal'
tempdbsent438.priority       = 50
tempdbsent438.all_ohne_muell = '"Zuschauer / hoererschaft" bzw Rezipienten'
db.append(tempdbsent438)


tempdbsent439 = DBSentence()
tempdbsent439.subject        = 'der akustische Schwingungen im ueblichen Medium Luft in'
tempdbsent439.verb           = 'entsprechende'
tempdbsent439.object         = 'elektrische SpannungsSignale wandelt.'
tempdbsent439.prefix         = 'Als Mikrofon bezeichnet man einen Sensor im Schallfeld'
tempdbsent439.suffix         = ''
tempdbsent439.feeling        = 'normal'
tempdbsent439.category       = 'normal'
tempdbsent439.priority       = 50
tempdbsent439.all_ohne_muell = 'Als Mikrofon bezeichnet man einen Sensor im Schallfeld akustische Schwingungen im ueblichen Medium Luft entsprechende elektrische SpannungsSignale wandelt'
db.append(tempdbsent439)


tempdbsent440 = DBSentence()
tempdbsent440.subject        = 'Aeusserlich sichtbare Teile'
tempdbsent440.verb           = 'eines'
tempdbsent440.object         = 'menschlichen Auges; links .'
tempdbsent440.prefix         = ''
tempdbsent440.suffix         = ''
tempdbsent440.feeling        = 'normal'
tempdbsent440.category       = 'normal'
tempdbsent440.priority       = 50
tempdbsent440.all_ohne_muell = 'Aeusserlich sichtbare Teile menschlichen Auges links'
db.append(tempdbsent440)


tempdbsent441 = DBSentence()
tempdbsent441.subject        = 'Der Baumeister'
tempdbsent441.verb           = 'uebernimmt'
tempdbsent441.object         = 'die Planung und Leitung'
tempdbsent441.prefix         = ''
tempdbsent441.suffix         = 'teils auch die Ausfuehrung von Bauarbeiten aller Art.'
tempdbsent441.feeling        = 'normal'
tempdbsent441.category       = 'normal'
tempdbsent441.priority       = 50
tempdbsent441.all_ohne_muell = 'Der Baumeister uebernimmt Planung Leitung teils auch Ausfuehrung Bauarbeiten aller Art'
db.append(tempdbsent441)


tempdbsent442 = DBSentence()
tempdbsent442.subject        = 'Eine Frau'
tempdbsent442.verb           = 'ist'
tempdbsent442.object         = 'ein weiblicher'
tempdbsent442.prefix         = ''
tempdbsent442.suffix         = 'erwachsener Mensch.'
tempdbsent442.feeling        = 'normal'
tempdbsent442.category       = 'normal'
tempdbsent442.priority       = 50
tempdbsent442.all_ohne_muell = 'Eine Frau ist weiblicher erwachsener Mensch'
db.append(tempdbsent442)


tempdbsent443 = DBSentence()
tempdbsent443.subject        = 'Das Spiel'
tempdbsent443.verb           = 'ist'
tempdbsent443.object         = 'eine Taetigkeit'
tempdbsent443.prefix         = ''
tempdbsent443.suffix         = 'die ohne bewussten Zweck zum Vergnuegen, zur Entspannung, allein aus Freude an ihrer Ausuebung ausgefuehrt wird.'
tempdbsent443.feeling        = 'normal'
tempdbsent443.category       = 'normal'
tempdbsent443.priority       = 50
tempdbsent443.all_ohne_muell = 'Das Spiel ist Taetigkeit ohne bewussten Zweck zum Vergnuegen zur Entspannung allein aus Freude an ihrer Ausuebung ausgefuehrt wird'
db.append(tempdbsent443)


tempdbsent444 = DBSentence()
tempdbsent444.subject        = 'Beispiel'
tempdbsent444.verb           = 'fuer'
tempdbsent444.object         = 'ein fehlerhaftes Formular und'
tempdbsent444.prefix         = ''
tempdbsent444.suffix         = ''
tempdbsent444.feeling        = 'normal'
tempdbsent444.category       = 'normal'
tempdbsent444.priority       = 50
tempdbsent444.all_ohne_muell = 'Beispiel fehlerhaftes Formular'
db.append(tempdbsent444)


tempdbsent445 = DBSentence()
tempdbsent445.subject        = 'Das Chaos'
tempdbsent445.verb           = 'ist'
tempdbsent445.object         = 'ein Zustand vollstaendiger Unordnung oder Verwirrung und damit der Gegenbegriff zu Kosmos'
tempdbsent445.prefix         = ''
tempdbsent445.suffix         = 'dem griechischen Begriff fuer Ordnung.'
tempdbsent445.feeling        = 'normal'
tempdbsent445.category       = 'normal'
tempdbsent445.priority       = 50
tempdbsent445.all_ohne_muell = 'Das Chaos ist Zustand vollstaendiger Unordnung Verwirrung damit Gegenbegriff zu Kosmos griechischen Begriff Ordnung'
db.append(tempdbsent445)


tempdbsent446 = DBSentence()
tempdbsent446.subject        = 'Die Angst'
tempdbsent446.verb           = 'ist'
tempdbsent446.object         = 'das Befuerchten moeglichen Leidens und bezeichnet somit eine Empfindungs und Verhaltenssituation aus Ungewissheit und Anspannung'
tempdbsent446.prefix         = ''
tempdbsent446.suffix         = 'die durch eine eingetretene oder erwartete Bedrohung hervorgerufen wird.'
tempdbsent446.feeling        = 'normal'
tempdbsent446.category       = 'normal'
tempdbsent446.priority       = 50
tempdbsent446.all_ohne_muell = 'Die Angst ist Befuerchten moeglichen Leidens bezeichnet somit Empfindungs Verhaltenssituation aus Ungewissheit Anspannung durch eingetretene erwartete Bedrohung hervorgerufen wird'
db.append(tempdbsent446)


tempdbsent447 = DBSentence()
tempdbsent447.subject        = 'Astrid Mannes'
tempdbsent447.verb           = 'ist'
tempdbsent447.object         = 'eine deutsche Politikerin und Schriftstellerin.'
tempdbsent447.prefix         = ''
tempdbsent447.suffix         = ''
tempdbsent447.feeling        = 'normal'
tempdbsent447.category       = 'normal'
tempdbsent447.priority       = 50
tempdbsent447.all_ohne_muell = 'Astrid Mannes ist deutsche Politikerin Schriftstellerin'
db.append(tempdbsent447)


tempdbsent448 = DBSentence()
tempdbsent448.subject        = 'Adolf Aber'
tempdbsent448.verb           = 'war'
tempdbsent448.object         = 'ein deutscher Musikwissenschaftler und Kritiker.'
tempdbsent448.prefix         = ''
tempdbsent448.suffix         = ''
tempdbsent448.feeling        = 'normal'
tempdbsent448.category       = 'normal'
tempdbsent448.priority       = 50
tempdbsent448.all_ohne_muell = 'Adolf Aber war deutscher Musikwissenschaftler Kritiker'
db.append(tempdbsent448)


tempdbsent449 = DBSentence()
tempdbsent449.subject        = 'Pferdemist auf'
tempdbsent449.verb           = 'einer'
tempdbsent449.object         = 'Weide in Randers'
tempdbsent449.prefix         = ''
tempdbsent449.suffix         = 'Daenemark .'
tempdbsent449.feeling        = 'normal'
tempdbsent449.category       = 'normal'
tempdbsent449.priority       = 50
tempdbsent449.all_ohne_muell = 'Pferdemist Weide Randers Daenemark'
db.append(tempdbsent449)


tempdbsent450 = DBSentence()
tempdbsent450.subject        = 'Die MAN AG'
tempdbsent450.verb           = 'ist'
tempdbsent450.object         = 'eines der groessten Fahrzeug und Maschinenbauunternehmen in Europa mit Sitz in Muenchen.'
tempdbsent450.prefix         = ''
tempdbsent450.suffix         = ''
tempdbsent450.feeling        = 'normal'
tempdbsent450.category       = 'normal'
tempdbsent450.priority       = 50
tempdbsent450.all_ohne_muell = 'Die MAN AG ist groessten Fahrzeug Maschinenbauunternehmen Europa mit Sitz Muenchen'
db.append(tempdbsent450)


tempdbsent451 = DBSentence()
tempdbsent451.subject        = 'Ein Genie'
tempdbsent451.verb           = 'ist'
tempdbsent451.object         = 'eine Person mit ueberragend schoepferischer Geisteskraft oder auch besonders herausragenden Leistungen auf anderen Gebieten .'
tempdbsent451.prefix         = ''
tempdbsent451.suffix         = ''
tempdbsent451.feeling        = 'normal'
tempdbsent451.category       = 'normal'
tempdbsent451.priority       = 50
tempdbsent451.all_ohne_muell = 'Ein Genie ist Person mit ueberragend schoepferischer Geisteskraft auch besonders herausragenden Leistungen anderen Gebieten'
db.append(tempdbsent451)


tempdbsent452 = DBSentence()
tempdbsent452.subject        = 'Ohne'
tempdbsent452.verb           = 'ist'
tempdbsent452.object         = 'eine Gemeinde im Landkreis Grafschaft Bentheim in Niedersachsen.'
tempdbsent452.prefix         = ''
tempdbsent452.suffix         = ''
tempdbsent452.feeling        = 'normal'
tempdbsent452.category       = 'normal'
tempdbsent452.priority       = 50
tempdbsent452.all_ohne_muell = 'Ohne ist Gemeinde im Landkreis Grafschaft Bentheim Niedersachsen'
db.append(tempdbsent452)


tempdbsent453 = DBSentence()
tempdbsent453.subject        = 'Der Terminus Symbol'
tempdbsent453.verb           = 'wird'
tempdbsent453.object         = 'im Allgemeinen fuer Bedeutungstraeger verwendet'
tempdbsent453.prefix         = ''
tempdbsent453.suffix         = 'die eine Vorstellung meinen .'
tempdbsent453.feeling        = 'normal'
tempdbsent453.category       = 'normal'
tempdbsent453.priority       = 50
tempdbsent453.all_ohne_muell = 'Der Terminus Symbol wird im Allgemeinen Bedeutungstraeger verwendet Vorstellung meinen'
db.append(tempdbsent453)


tempdbsent454 = DBSentence()
tempdbsent454.subject        = 'Indien'
tempdbsent454.verb           = 'ist'
tempdbsent454.object         = 'ein Staat in Suedasien'
tempdbsent454.prefix         = ''
tempdbsent454.suffix         = 'der den groessten Teil des indischen Subkontinents umfasst.'
tempdbsent454.feeling        = 'normal'
tempdbsent454.category       = 'normal'
tempdbsent454.priority       = 50
tempdbsent454.all_ohne_muell = 'Indien ist Staat Suedasien den groessten Teil indischen Subkontinents umfasst'
db.append(tempdbsent454)


tempdbsent455 = DBSentence()
tempdbsent455.subject        = 'Kinder'
tempdbsent455.verb           = 'sind'
tempdbsent455.object         = 'die Nachkommenschaft eines Mannes und einer Frau'
tempdbsent455.prefix         = ''
tempdbsent455.suffix         = 'eine biologische Verwandtschaft ist dabei nicht vorausgesetzt.'
tempdbsent455.feeling        = 'normal'
tempdbsent455.category       = 'normal'
tempdbsent455.priority       = 50
tempdbsent455.all_ohne_muell = 'Kinder sind Nachkommenschaft Mannes Frau biologische Verwandtschaft ist dabei nicht vorausgesetzt'
db.append(tempdbsent455)


tempdbsent456 = DBSentence()
tempdbsent456.subject        = 'SPD'
tempdbsent456.verb           = 'und'
tempdbsent456.object         = 'FDP zur Bundestagswahl 2005 .'
tempdbsent456.prefix         = 'Wahlplakate der CDU'
tempdbsent456.suffix         = ''
tempdbsent456.feeling        = 'normal'
tempdbsent456.category       = 'normal'
tempdbsent456.priority       = 50
tempdbsent456.all_ohne_muell = 'Wahlplakate CDU SPD FDP zur Bundestagswahl 2005'
db.append(tempdbsent456)


tempdbsent457 = DBSentence()
tempdbsent457.subject        = 'Kampagne bezeichnete in'
tempdbsent457.verb           = 'der'
tempdbsent457.object         = 'europaeischen Geschichte urspruenglich einen Feldzug.'
tempdbsent457.prefix         = ''
tempdbsent457.suffix         = ''
tempdbsent457.feeling        = 'normal'
tempdbsent457.category       = 'normal'
tempdbsent457.priority       = 50
tempdbsent457.all_ohne_muell = 'Kampagne bezeichnete europaeischen Geschichte urspruenglich einen Feldzug'
db.append(tempdbsent457)


tempdbsent458 = DBSentence()
tempdbsent458.subject        = 'Der Landschaftsverband Rheinland'
tempdbsent458.verb           = 'ist'
tempdbsent458.object         = 'eine 1953 gebildete Gebietskoerperschaft in NordrheinWestfalen mit Sitz in Koeln.'
tempdbsent458.prefix         = ''
tempdbsent458.suffix         = ''
tempdbsent458.feeling        = 'normal'
tempdbsent458.category       = 'normal'
tempdbsent458.priority       = 50
tempdbsent458.all_ohne_muell = 'Der Landschaftsverband Rheinland ist 1953 gebildete Gebietskoerperschaft NordrheinWestfalen mit Sitz Koeln'
db.append(tempdbsent458)


tempdbsent459 = DBSentence()
tempdbsent459.subject        = 'Westfalen'
tempdbsent459.verb           = 'ist'
tempdbsent459.object         = 'heute ein Landesteil von NordrheinWestfalen.'
tempdbsent459.prefix         = ''
tempdbsent459.suffix         = ''
tempdbsent459.feeling        = 'normal'
tempdbsent459.category       = 'normal'
tempdbsent459.priority       = 50
tempdbsent459.all_ohne_muell = 'Westfalen ist heute Landesteil NordrheinWestfalen'
db.append(tempdbsent459)


tempdbsent460 = DBSentence()
tempdbsent460.subject        = 'Als Wachstum bezeichnet man den zeitlichen Anstieg einer'
tempdbsent460.verb           = 'bestimmten'
tempdbsent460.object         = 'Messgroesse.'
tempdbsent460.prefix         = ''
tempdbsent460.suffix         = ''
tempdbsent460.feeling        = 'normal'
tempdbsent460.category       = 'normal'
tempdbsent460.priority       = 50
tempdbsent460.all_ohne_muell = 'Als Wachstum bezeichnet man den zeitlichen Anstieg bestimmten Messgroesse'
db.append(tempdbsent460)


tempdbsent461 = DBSentence()
tempdbsent461.subject        = 'Ein Pferdewagen'
tempdbsent461.verb           = 'ist'
tempdbsent461.object         = 'ein von Pferden gezogenes zweiachsiges Fahrzeug fuer den Transport von Personen oder Waren.'
tempdbsent461.prefix         = ''
tempdbsent461.suffix         = ''
tempdbsent461.feeling        = 'normal'
tempdbsent461.category       = 'normal'
tempdbsent461.priority       = 50
tempdbsent461.all_ohne_muell = 'Ein Pferdewagen ist Pferden gezogenes zweiachsiges Fahrzeug den Transport Personen Waren'
db.append(tempdbsent461)


tempdbsent462 = DBSentence()
tempdbsent462.subject        = 'Der Pessimismus'
tempdbsent462.verb           = 'ist'
tempdbsent462.object         = 'die Lebensanschauung von der unverbesserlich schlechten Welt.'
tempdbsent462.prefix         = ''
tempdbsent462.suffix         = ''
tempdbsent462.feeling        = 'normal'
tempdbsent462.category       = 'normal'
tempdbsent462.priority       = 50
tempdbsent462.all_ohne_muell = 'Der Pessimismus ist Lebensanschauung unverbesserlich schlechten Welt'
db.append(tempdbsent462)


tempdbsent463 = DBSentence()
tempdbsent463.subject        = 'Ein Geheimnis'
tempdbsent463.verb           = 'ist'
tempdbsent463.object         = 'eine Information oder ein Soziales Handeln'
tempdbsent463.prefix         = ''
tempdbsent463.suffix         = 'deren Kenntnis unter wenigen Geheimnistraegern bleibt, die der Geheimhaltung unterliegen.'
tempdbsent463.feeling        = 'normal'
tempdbsent463.category       = 'normal'
tempdbsent463.priority       = 50
tempdbsent463.all_ohne_muell = 'Ein Geheimnis ist Information Soziales Handeln deren Kenntnis wenigen Geheimnistraegern bleibt Geheimhaltung unterliegen'
db.append(tempdbsent463)


tempdbsent464 = DBSentence()
tempdbsent464.subject        = 'Ruhm'
tempdbsent464.verb           = 'ist'
tempdbsent464.object         = 'hohes und andauerndes Prestige einer Person innerhalb einer Gemeinschaft oder der Oeffentlichkeit.'
tempdbsent464.prefix         = ''
tempdbsent464.suffix         = ''
tempdbsent464.feeling        = 'normal'
tempdbsent464.category       = 'normal'
tempdbsent464.priority       = 50
tempdbsent464.all_ohne_muell = 'Ruhm ist hohes andauerndes Prestige Person innerhalb Gemeinschaft Oeffentlichkeit'
db.append(tempdbsent464)


tempdbsent465 = DBSentence()
tempdbsent465.subject        = 'Erfolg, Ganzheit'
tempdbsent465.verb           = 'oder'
tempdbsent465.object         = 'Gesundheit'
tempdbsent465.prefix         = 'Heil drueckt Begnadung'
tempdbsent465.suffix         = ''
tempdbsent465.feeling        = 'normal'
tempdbsent465.category       = 'normal'
tempdbsent465.priority       = 50
tempdbsent465.all_ohne_muell = 'Heil drueckt Begnadung Erfolg Ganzheit Gesundheit'
db.append(tempdbsent465)


tempdbsent466 = DBSentence()
tempdbsent466.subject        = 'Schrift dient'
tempdbsent466.verb           = 'der'
tempdbsent466.object         = 'Kommunikation und'
tempdbsent466.prefix         = ''
tempdbsent466.suffix         = ''
tempdbsent466.feeling        = 'normal'
tempdbsent466.category       = 'normal'
tempdbsent466.priority       = 50
tempdbsent466.all_ohne_muell = 'Schrift dient Kommunikation'
db.append(tempdbsent466)


tempdbsent467 = DBSentence()
tempdbsent467.subject        = 'In vielen Kulturen'
tempdbsent467.verb           = 'wird'
tempdbsent467.object         = 'die Farbe Schwarz mit dem Nichts assoziiert.'
tempdbsent467.prefix         = ''
tempdbsent467.suffix         = ''
tempdbsent467.feeling        = 'normal'
tempdbsent467.category       = 'normal'
tempdbsent467.priority       = 50
tempdbsent467.all_ohne_muell = 'In vielen Kulturen wird Farbe Schwarz mit Nichts assoziiert'
db.append(tempdbsent467)


tempdbsent468 = DBSentence()
tempdbsent468.subject        = 'Liebe'
tempdbsent468.verb           = 'ist'
tempdbsent468.object         = 'im engeren Sinne die Bezeichnung fuer die staerkste Zuneigung'
tempdbsent468.prefix         = ''
tempdbsent468.suffix         = 'die ein Mensch fuer einen anderen Menschen zu empfinden faehig ist.'
tempdbsent468.feeling        = 'normal'
tempdbsent468.category       = 'normal'
tempdbsent468.priority       = 50
tempdbsent468.all_ohne_muell = 'Liebe ist im engeren Sinne Bezeichnung staerkste Zuneigung Mensch einen anderen Menschen zu empfinden faehig ist'
db.append(tempdbsent468)


tempdbsent469 = DBSentence()
tempdbsent469.subject        = ''
tempdbsent469.verb           = ''
tempdbsent469.object         = ''
tempdbsent469.prefix         = 'Unter einem Zustand versteht man die Gesamtheit aller Eigenschaften oder Attribute'
tempdbsent469.suffix         = 'die zur Abgrenzung und Unterscheidung des jeweils betrachteten Objekts von anderen Objekten noetig sind.'
tempdbsent469.feeling        = 'normal'
tempdbsent469.category       = 'normal'
tempdbsent469.priority       = 50
tempdbsent469.all_ohne_muell = 'Unter Zustand versteht man Gesamtheit aller Eigenschaften Attribute zur Abgrenzung Unterscheidung jeweils betrachteten Objekts anderen Objekten noetig sind'
db.append(tempdbsent469)


tempdbsent470 = DBSentence()
tempdbsent470.subject        = 'Der Schmerz'
tempdbsent470.verb           = 'ist'
tempdbsent470.object         = 'eine komplexe Sinnesempfindung'
tempdbsent470.prefix         = ''
tempdbsent470.suffix         = 'oft mit starker seelischer Komponente.'
tempdbsent470.feeling        = 'normal'
tempdbsent470.category       = 'normal'
tempdbsent470.priority       = 50
tempdbsent470.all_ohne_muell = 'Der Schmerz ist komplexe Sinnesempfindung oft mit starker seelischer Komponente'
db.append(tempdbsent470)


tempdbsent471 = DBSentence()
tempdbsent471.subject        = 'Als Schulter'
tempdbsent471.verb           = 'wird'
tempdbsent471.object         = 'bei Wirbeltieren und beim Menschen die Koerperregion zwischen Halsansatz und jedem der zwei Schultergelenke bezeichnet.'
tempdbsent471.prefix         = ''
tempdbsent471.suffix         = ''
tempdbsent471.feeling        = 'normal'
tempdbsent471.category       = 'normal'
tempdbsent471.priority       = 50
tempdbsent471.all_ohne_muell = 'Als Schulter wird bei Wirbeltieren beim Menschen Koerperregion Halsansatz jedem zwei Schultergelenke bezeichnet'
db.append(tempdbsent471)


tempdbsent472 = DBSentence()
tempdbsent472.subject        = 'Dingen'
tempdbsent472.verb           = 'ist'
tempdbsent472.object         = 'eine Gemeinde im Amt Kirchspielslandgemeinde EddelakSankt Michaelisdonn im Sueden des Kreises Dithmarschen in SchleswigHolstein .'
tempdbsent472.prefix         = ''
tempdbsent472.suffix         = ''
tempdbsent472.feeling        = 'normal'
tempdbsent472.category       = 'normal'
tempdbsent472.priority       = 50
tempdbsent472.all_ohne_muell = 'Dingen ist Gemeinde im Amt Kirchspielslandgemeinde EddelakSankt Michaelisdonn im Sueden Kreises Dithmarschen SchleswigHolstein'
db.append(tempdbsent472)


tempdbsent473 = DBSentence()
tempdbsent473.subject        = 'Eine Frau'
tempdbsent473.verb           = 'ist'
tempdbsent473.object         = 'ein weiblicher'
tempdbsent473.prefix         = ''
tempdbsent473.suffix         = 'erwachsener Mensch.'
tempdbsent473.feeling        = 'normal'
tempdbsent473.category       = 'normal'
tempdbsent473.priority       = 50
tempdbsent473.all_ohne_muell = 'Eine Frau ist weiblicher erwachsener Mensch'
db.append(tempdbsent473)


tempdbsent474 = DBSentence()
tempdbsent474.subject        = 'Als Argument'
tempdbsent474.verb           = 'wird'
tempdbsent474.object         = 'eine Aussage oder eine Folge von Aussagen bezeichnet'
tempdbsent474.prefix         = ''
tempdbsent474.suffix         = 'die zur Begruendung einer anderen Aussage, z.'
tempdbsent474.feeling        = 'normal'
tempdbsent474.category       = 'normal'
tempdbsent474.priority       = 50
tempdbsent474.all_ohne_muell = 'Als Argument wird Aussage Folge Aussagen bezeichnet zur Begruendung anderen Aussage z'
db.append(tempdbsent474)


tempdbsent475 = DBSentence()
tempdbsent475.subject        = 'ueber mentale Zustaende, also etwa Gedanken, Emotionen, Wahrnehmungen oder Erinnerungen, zu'
tempdbsent475.verb           = 'verfuegen'
tempdbsent475.object         = 'und sich dessen gewahr zu sein.'
tempdbsent475.prefix         = 'Bewusstsein bezeichnet die Faehigkeit'
tempdbsent475.suffix         = ''
tempdbsent475.feeling        = 'normal'
tempdbsent475.category       = 'normal'
tempdbsent475.priority       = 50
tempdbsent475.all_ohne_muell = 'Bewusstsein bezeichnet Faehigkeit ueber mentale Zustaende also etwa Gedanken Emotionen Wahrnehmungen Erinnerungen zu verfuegen sich gewahr zu sein'
db.append(tempdbsent475)


tempdbsent476 = DBSentence()
tempdbsent476.subject        = 'Gysi'
tempdbsent476.verb           = 'ist'
tempdbsent476.object         = 'der Name folgender Personen .'
tempdbsent476.prefix         = ''
tempdbsent476.suffix         = ''
tempdbsent476.feeling        = 'normal'
tempdbsent476.category       = 'normal'
tempdbsent476.priority       = 50
tempdbsent476.all_ohne_muell = 'Gysi ist Name folgender Personen'
db.append(tempdbsent476)


tempdbsent477 = DBSentence()
tempdbsent477.subject        = 'Die Pest'
tempdbsent477.verb           = 'ist'
tempdbsent477.object         = 'eine hochgradig ansteckende Krankheit'
tempdbsent477.prefix         = ''
tempdbsent477.suffix         = 'die durch das Bakterium Yersinia pestis verursacht wird.'
tempdbsent477.feeling        = 'normal'
tempdbsent477.category       = 'normal'
tempdbsent477.priority       = 50
tempdbsent477.all_ohne_muell = 'Die Pest ist hochgradig ansteckende Krankheit durch Bakterium Yersinia pestis verursacht wird'
db.append(tempdbsent477)


tempdbsent478 = DBSentence()
tempdbsent478.subject        = 'Bermatingen'
tempdbsent478.verb           = 'ist'
tempdbsent478.object         = 'eine Gemeinde im BodenseeHinterland'
tempdbsent478.prefix         = ''
tempdbsent478.suffix         = 'etwa 4 km westlich von Markdorf.'
tempdbsent478.feeling        = 'normal'
tempdbsent478.category       = 'normal'
tempdbsent478.priority       = 50
tempdbsent478.all_ohne_muell = 'Bermatingen ist Gemeinde im BodenseeHinterland etwa 4 km westlich Markdorf'
db.append(tempdbsent478)


tempdbsent479 = DBSentence()
tempdbsent479.subject        = 'Verstehen'
tempdbsent479.verb           = 'ist'
tempdbsent479.object         = 'das inhaltliche Begreifen eines Sachverhalts'
tempdbsent479.prefix         = ''
tempdbsent479.suffix         = 'das nicht in der blossen Kenntnisnahme besteht, sondern in der intellektuellen Erfassung des Zusammenhangs.'
tempdbsent479.feeling        = 'normal'
tempdbsent479.category       = 'normal'
tempdbsent479.priority       = 50
tempdbsent479.all_ohne_muell = 'Verstehen ist inhaltliche Begreifen Sachverhalts nicht blossen Kenntnisnahme besteht sondern intellektuellen Erfassung Zusammenhangs'
db.append(tempdbsent479)


tempdbsent480 = DBSentence()
tempdbsent480.subject        = ''
tempdbsent480.verb           = ''
tempdbsent480.object         = ''
tempdbsent480.prefix         = 'Intelligenz bezeichnet im weitesten Sinne die Faehigkeit zum Erkennen von Zusammenhaengen und zum Finden optimaler Problemloesungen.'
tempdbsent480.suffix         = ''
tempdbsent480.feeling        = 'normal'
tempdbsent480.category       = 'normal'
tempdbsent480.priority       = 50
tempdbsent480.all_ohne_muell = 'Intelligenz bezeichnet im weitesten Sinne Faehigkeit zum Erkennen Zusammenhaengen zum Finden optimaler Problemloesungen'
db.append(tempdbsent480)


tempdbsent481 = DBSentence()
tempdbsent481.subject        = 'Krieg'
tempdbsent481.verb           = 'ist'
tempdbsent481.object         = 'ein unter Einsatz erheblicher Mittel mit Waffengewalt ausgetragener Konflikt'
tempdbsent481.prefix         = ''
tempdbsent481.suffix         = 'an dem mehrere Staaten oder planmaessig vorgehende, bewaffnete nichtstaatliche Kollektive beteiligt sind.'
tempdbsent481.feeling        = 'normal'
tempdbsent481.category       = 'normal'
tempdbsent481.priority       = 50
tempdbsent481.all_ohne_muell = 'Krieg ist Einsatz erheblicher Mittel mit Waffengewalt ausgetragener Konflikt an mehrere Staaten planmaessig vorgehende bewaffnete nichtstaatliche Kollektive beteiligt sind'
db.append(tempdbsent481)


tempdbsent482 = DBSentence()
tempdbsent482.subject        = 'Linux'
tempdbsent482.verb           = 'ist'
tempdbsent482.object         = 'ein freies und MultiplattformMehrbenutzerBetriebssystem fuer Computer'
tempdbsent482.prefix         = ''
tempdbsent482.suffix         = 'das Unix aehnlich ist.'
tempdbsent482.feeling        = 'normal'
tempdbsent482.category       = 'normal'
tempdbsent482.priority       = 50
tempdbsent482.all_ohne_muell = 'Linux ist freies MultiplattformMehrbenutzerBetriebssystem Computer Unix aehnlich ist'
db.append(tempdbsent482)


tempdbsent483 = DBSentence()
tempdbsent483.subject        = 'Ein Sohn eines Vaters und einer Mutter'
tempdbsent483.verb           = 'ist'
tempdbsent483.object         = 'ein maennliches Kind dieser Personen.'
tempdbsent483.prefix         = ''
tempdbsent483.suffix         = ''
tempdbsent483.feeling        = 'normal'
tempdbsent483.category       = 'normal'
tempdbsent483.priority       = 50
tempdbsent483.all_ohne_muell = 'Ein Sohn Vaters Mutter ist maennliches Kind dieser Personen'
db.append(tempdbsent483)


tempdbsent484 = DBSentence()
tempdbsent484.subject        = 'in der das Privateigentum an Produktionsmitteln aufgehoben'
tempdbsent484.verb           = 'ist'
tempdbsent484.object         = 'und das erwirtschaftete Sozialprodukt gesellschaftlich angeeignet wird'
tempdbsent484.prefix         = 'Kommunismus bezeichnet eine klassenlose Gesellschaft'
tempdbsent484.suffix         = 'das heisst allen Menschen gleichermassen zugaenglich ist.'
tempdbsent484.feeling        = 'normal'
tempdbsent484.category       = 'normal'
tempdbsent484.priority       = 50
tempdbsent484.all_ohne_muell = 'Kommunismus bezeichnet klassenlose Gesellschaft Privateigentum an Produktionsmitteln aufgehoben ist erwirtschaftete Sozialprodukt gesellschaftlich angeeignet wird heisst allen Menschen gleichermassen zugaenglich ist'
db.append(tempdbsent484)


tempdbsent485 = DBSentence()
tempdbsent485.subject        = 'Der Sozialismus'
tempdbsent485.verb           = 'ist'
tempdbsent485.object         = 'neben dem Liberalismus und dem Konservatismus eine der drei grossen politischen Ideologien die sich im 19.'
tempdbsent485.prefix         = ''
tempdbsent485.suffix         = ''
tempdbsent485.feeling        = 'normal'
tempdbsent485.category       = 'normal'
tempdbsent485.priority       = 50
tempdbsent485.all_ohne_muell = 'Der Sozialismus ist Liberalismus Konservatismus drei grossen politischen Ideologien sich im 19'
db.append(tempdbsent485)


tempdbsent486 = DBSentence()
tempdbsent486.subject        = 'in der das Privateigentum an Produktionsmitteln aufgehoben'
tempdbsent486.verb           = 'ist'
tempdbsent486.object         = 'und das erwirtschaftete Sozialprodukt gesellschaftlich angeeignet wird'
tempdbsent486.prefix         = 'Kommunismus bezeichnet eine klassenlose Gesellschaft'
tempdbsent486.suffix         = 'das heisst allen Menschen gleichermassen zugaenglich ist.'
tempdbsent486.feeling        = 'normal'
tempdbsent486.category       = 'normal'
tempdbsent486.priority       = 50
tempdbsent486.all_ohne_muell = 'Kommunismus bezeichnet klassenlose Gesellschaft Privateigentum an Produktionsmitteln aufgehoben ist erwirtschaftete Sozialprodukt gesellschaftlich angeeignet wird heisst allen Menschen gleichermassen zugaenglich ist'
db.append(tempdbsent486)


tempdbsent487 = DBSentence()
tempdbsent487.subject        = 'Friedrich'
tempdbsent487.verb           = 'ist'
tempdbsent487.object         = 'ein deutscher maennlicher Vorname.'
tempdbsent487.prefix         = ''
tempdbsent487.suffix         = ''
tempdbsent487.feeling        = 'normal'
tempdbsent487.category       = 'normal'
tempdbsent487.priority       = 50
tempdbsent487.all_ohne_muell = 'Friedrich ist deutscher maennlicher Vorname'
db.append(tempdbsent487)


tempdbsent488 = DBSentence()
tempdbsent488.subject        = 'Marcellus'
tempdbsent488.verb           = 'ist'
tempdbsent488.object         = 'ein aus dem Lateinischen stammender maennlicher Vorname.'
tempdbsent488.prefix         = ''
tempdbsent488.suffix         = ''
tempdbsent488.feeling        = 'normal'
tempdbsent488.category       = 'normal'
tempdbsent488.priority       = 50
tempdbsent488.all_ohne_muell = 'Marcellus ist aus Lateinischen stammender maennlicher Vorname'
db.append(tempdbsent488)


tempdbsent489 = DBSentence()
tempdbsent489.subject        = 'Wissen'
tempdbsent489.verb           = 'ist'
tempdbsent489.object         = 'Information'
tempdbsent489.prefix         = ''
tempdbsent489.suffix         = 'derer sich eine Person, Organisation oder eine andere Gruppierung gegenwaertig ist.'
tempdbsent489.feeling        = 'normal'
tempdbsent489.category       = 'normal'
tempdbsent489.priority       = 50
tempdbsent489.all_ohne_muell = 'Wissen ist Information derer sich Person Organisation andere Gruppierung gegenwaertig ist'
db.append(tempdbsent489)


tempdbsent490 = DBSentence()
tempdbsent490.subject        = 'Tiere'
tempdbsent490.verb           = 'sind'
tempdbsent490.object         = 'in ihrer klassischen Definition Lebewesen'
tempdbsent490.prefix         = ''
tempdbsent490.suffix         = 'die ihre Energie nicht durch Photosynthese gewinnen, sondern sich von anderen tierischen oder pflanzlichen Organismen ernaehren und Sauerstoff zur Atmung benoetigen.'
tempdbsent490.feeling        = 'normal'
tempdbsent490.category       = 'normal'
tempdbsent490.priority       = 50
tempdbsent490.all_ohne_muell = 'Tiere sind ihrer klassischen Definition Lebewesen ihre Energie nicht durch Photosynthese gewinnen sondern sich anderen tierischen pflanzlichen Organismen ernaehren Sauerstoff zur Atmung benoetigen'
db.append(tempdbsent490)


tempdbsent491 = DBSentence()
tempdbsent491.subject        = 'Arschloch steht umgangssprachlich'
tempdbsent491.verb           = 'fuer'
tempdbsent491.object         = 'den After oder auch Anus.'
tempdbsent491.prefix         = ''
tempdbsent491.suffix         = ''
tempdbsent491.feeling        = 'normal'
tempdbsent491.category       = 'normal'
tempdbsent491.priority       = 50
tempdbsent491.all_ohne_muell = 'Arschloch steht umgangssprachlich den After auch Anus'
db.append(tempdbsent491)


tempdbsent492 = DBSentence()
tempdbsent492.subject        = 'Earth'
tempdbsent492.verb           = 'ist'
tempdbsent492.object         = 'eine amerikanische DoomMetalBand und gilt als Pionier einer minimalistischen'
tempdbsent492.prefix         = ''
tempdbsent492.suffix         = 'basslastigen und schlagzeuglosen Form des Dooms, auch bekannt als Drone.'
tempdbsent492.feeling        = 'normal'
tempdbsent492.category       = 'normal'
tempdbsent492.priority       = 50
tempdbsent492.all_ohne_muell = 'Earth ist amerikanische DoomMetalBand gilt als Pionier minimalistischen basslastigen schlagzeuglosen Form Dooms auch bekannt als Drone'
db.append(tempdbsent492)


tempdbsent493 = DBSentence()
tempdbsent493.subject        = 'Theia'
tempdbsent493.verb           = 'ist'
tempdbsent493.object         = 'eine weibliche Gestalt der griechischen Mythologie.'
tempdbsent493.prefix         = ''
tempdbsent493.suffix         = ''
tempdbsent493.feeling        = 'normal'
tempdbsent493.category       = 'normal'
tempdbsent493.priority       = 50
tempdbsent493.all_ohne_muell = 'Theia ist weibliche Gestalt griechischen Mythologie'
db.append(tempdbsent493)


tempdbsent494 = DBSentence()
tempdbsent494.subject        = ''
tempdbsent494.verb           = 'links'
tempdbsent494.object         = 'Deutschland'
tempdbsent494.prefix         = 'Die Our bei DasburgPont'
tempdbsent494.suffix         = 'rechts Luxemburg .'
tempdbsent494.feeling        = 'normal'
tempdbsent494.category       = 'normal'
tempdbsent494.priority       = 50
tempdbsent494.all_ohne_muell = 'Die Our bei DasburgPont links Deutschland rechts Luxemburg'
db.append(tempdbsent494)


tempdbsent495 = DBSentence()
tempdbsent495.subject        = 'Loop'
tempdbsent495.verb           = 'ist'
tempdbsent495.object         = 'in die am meisten in Deutschland gebraeuchliche Verwendung fuer eine Schleife'
tempdbsent495.prefix         = ''
tempdbsent495.suffix         = 'Kringel, usw.'
tempdbsent495.feeling        = 'normal'
tempdbsent495.category       = 'normal'
tempdbsent495.priority       = 50
tempdbsent495.all_ohne_muell = 'Loop ist am meisten Deutschland gebraeuchliche Verwendung Schleife Kringel usw'
db.append(tempdbsent495)


tempdbsent496 = DBSentence()
tempdbsent496.subject        = 'Edmond About'
tempdbsent496.verb           = 'war'
tempdbsent496.object         = 'ein franzoesischer Schriftsteller.'
tempdbsent496.prefix         = ''
tempdbsent496.suffix         = ''
tempdbsent496.feeling        = 'normal'
tempdbsent496.category       = 'normal'
tempdbsent496.priority       = 50
tempdbsent496.all_ohne_muell = 'Edmond About war franzoesischer Schriftsteller'
db.append(tempdbsent496)


tempdbsent497 = DBSentence()
tempdbsent497.subject        = ''
tempdbsent497.verb           = ''
tempdbsent497.object         = ''
tempdbsent497.prefix         = 'Microsoft entwickelte die Plattform als Umsetzung des CommonLanguageInfrastructureStandards fuer Windows.'
tempdbsent497.suffix         = ''
tempdbsent497.feeling        = 'normal'
tempdbsent497.category       = 'normal'
tempdbsent497.priority       = 50
tempdbsent497.all_ohne_muell = 'Microsoft entwickelte Plattform als Umsetzung CommonLanguageInfrastructureStandards Windows'
db.append(tempdbsent497)


tempdbsent498 = DBSentence()
tempdbsent498.subject        = 'Kapital'
tempdbsent498.verb           = 'ist'
tempdbsent498.object         = 'ein Begriff'
tempdbsent498.prefix         = ''
tempdbsent498.suffix         = 'der in den Wirtschaftswissenschaften, der Soziologie, aber auch in der Umgangssprache unterschiedlich verwendet wird.'
tempdbsent498.feeling        = 'normal'
tempdbsent498.category       = 'normal'
tempdbsent498.priority       = 50
tempdbsent498.all_ohne_muell = 'Kapital ist Begriff den Wirtschaftswissenschaften Soziologie aber auch Umgangssprache unterschiedlich verwendet wird'
db.append(tempdbsent498)


tempdbsent499 = DBSentence()
tempdbsent499.subject        = 'Die Aller'
tempdbsent499.verb           = 'ist'
tempdbsent499.object         = 'ein Fluss in SachsenAnhalt und Niedersachsen in Deutschland von insgesamt 263 km Laenge.'
tempdbsent499.prefix         = ''
tempdbsent499.suffix         = ''
tempdbsent499.feeling        = 'normal'
tempdbsent499.category       = 'normal'
tempdbsent499.priority       = 50
tempdbsent499.all_ohne_muell = 'Die Aller ist Fluss SachsenAnhalt Niedersachsen Deutschland insgesamt 263 km Laenge'
db.append(tempdbsent499)


tempdbsent500 = DBSentence()
tempdbsent500.subject        = 'Der Begriff alles'
tempdbsent500.verb           = 'findet'
tempdbsent500.object         = 'sich in der Alltagssprache'
tempdbsent500.prefix         = ''
tempdbsent500.suffix         = 'wird manchmal jedoch auch in metaphysischen Ueberlegungen angesprochen.'
tempdbsent500.feeling        = 'normal'
tempdbsent500.category       = 'normal'
tempdbsent500.priority       = 50
tempdbsent500.all_ohne_muell = 'Der Begriff alles findet sich Alltagssprache wird manchmal jedoch auch metaphysischen Ueberlegungen angesprochen'
db.append(tempdbsent500)


tempdbsent501 = DBSentence()
tempdbsent501.subject        = ''
tempdbsent501.verb           = ''
tempdbsent501.object         = ''
tempdbsent501.prefix         = 'Rohwurst Geraeucherte Mettwurst im Kunstdarm'
tempdbsent501.suffix         = 'luftgetrocknete Salami im Naturdarm .'
tempdbsent501.feeling        = 'normal'
tempdbsent501.category       = 'normal'
tempdbsent501.priority       = 50
tempdbsent501.all_ohne_muell = 'Rohwurst Geraeucherte Mettwurst im Kunstdarm luftgetrocknete Salami im Naturdarm'
db.append(tempdbsent501)


tempdbsent502 = DBSentence()
tempdbsent502.subject        = 'Rolf Weiber'
tempdbsent502.verb           = 'ist'
tempdbsent502.object         = 'ein deutscher Hochschullehrer.'
tempdbsent502.prefix         = ''
tempdbsent502.suffix         = ''
tempdbsent502.feeling        = 'normal'
tempdbsent502.category       = 'normal'
tempdbsent502.priority       = 50
tempdbsent502.all_ohne_muell = 'Rolf Weiber ist deutscher Hochschullehrer'
db.append(tempdbsent502)


tempdbsent503 = DBSentence()
tempdbsent503.subject        = 'Weisen'
tempdbsent503.verb           = 'ist'
tempdbsent503.object         = 'eine Gemeinde im Suedwesten des Landkreises Prignitz in Brandenburg.'
tempdbsent503.prefix         = ''
tempdbsent503.suffix         = ''
tempdbsent503.feeling        = 'normal'
tempdbsent503.category       = 'normal'
tempdbsent503.priority       = 50
tempdbsent503.all_ohne_muell = 'Weisen ist Gemeinde im Suedwesten Landkreises Prignitz Brandenburg'
db.append(tempdbsent503)


tempdbsent504 = DBSentence()
tempdbsent504.subject        = ''
tempdbsent504.verb           = ''
tempdbsent504.object         = ''
tempdbsent504.prefix         = 'Bauernkate in SchleswigHolstein'
tempdbsent504.suffix         = 'entstanden um 1915 .'
tempdbsent504.feeling        = 'normal'
tempdbsent504.category       = 'normal'
tempdbsent504.priority       = 50
tempdbsent504.all_ohne_muell = 'Bauernkate SchleswigHolstein entstanden um 1915'
db.append(tempdbsent504)


tempdbsent505 = DBSentence()
tempdbsent505.subject        = 'Schotter'
tempdbsent505.verb           = 'sind'
tempdbsent505.object         = 'Geroellablagerungen oder gebrochene Mineralstoffe mit einer Korngroesse zwischen 32 und 63&amp;nbsp;mm'
tempdbsent505.prefix         = ''
tempdbsent505.suffix         = 'meistens zur Verwendung im Bauwesen.'
tempdbsent505.feeling        = 'normal'
tempdbsent505.category       = 'normal'
tempdbsent505.priority       = 50
tempdbsent505.all_ohne_muell = 'Schotter sind Geroellablagerungen gebrochene Mineralstoffe mit Korngroesse 32 63&ampnbspmm meistens zur Verwendung im Bauwesen'
db.append(tempdbsent505)


tempdbsent506 = DBSentence()
tempdbsent506.subject        = ''
tempdbsent506.verb           = ''
tempdbsent506.object         = ''
tempdbsent506.prefix         = 'Intelligenz bezeichnet im weitesten Sinne die Faehigkeit zum Erkennen von Zusammenhaengen und zum Finden optimaler Problemloesungen.'
tempdbsent506.suffix         = ''
tempdbsent506.feeling        = 'normal'
tempdbsent506.category       = 'normal'
tempdbsent506.priority       = 50
tempdbsent506.all_ohne_muell = 'Intelligenz bezeichnet im weitesten Sinne Faehigkeit zum Erkennen Zusammenhaengen zum Finden optimaler Problemloesungen'
db.append(tempdbsent506)


tempdbsent507 = DBSentence()
tempdbsent507.subject        = 'Albert'
tempdbsent507.verb           = 'ist'
tempdbsent507.object         = 'eine Kurzform des maennlichen Vornamens Adalbert'
tempdbsent507.prefix         = ''
tempdbsent507.suffix         = 'ausserdem sinnverwandt mit Albrecht.'
tempdbsent507.feeling        = 'normal'
tempdbsent507.category       = 'normal'
tempdbsent507.priority       = 50
tempdbsent507.all_ohne_muell = 'Albert ist Kurzform maennlichen Vornamens Adalbert ausserdem sinnverwandt mit Albrecht'
db.append(tempdbsent507)


tempdbsent508 = DBSentence()
tempdbsent508.subject        = 'Meine'
tempdbsent508.verb           = 'ist'
tempdbsent508.object         = 'eine Gemeinde im Landkreis Gifhorn .'
tempdbsent508.prefix         = ''
tempdbsent508.suffix         = ''
tempdbsent508.feeling        = 'normal'
tempdbsent508.category       = 'normal'
tempdbsent508.priority       = 50
tempdbsent508.all_ohne_muell = 'Meine ist Gemeinde im Landkreis Gifhorn'
db.append(tempdbsent508)


tempdbsent509 = DBSentence()
tempdbsent509.subject        = '"Der Philosoph"'
tempdbsent509.verb           = 'eine'
tempdbsent509.object         = 'Verbildlichung des Klischees des weltfremden Philosophen im Elfenbeinturm .'
tempdbsent509.prefix         = 'Rembrandt van Rijn'
tempdbsent509.suffix         = ''
tempdbsent509.feeling        = 'normal'
tempdbsent509.category       = 'normal'
tempdbsent509.priority       = 50
tempdbsent509.all_ohne_muell = 'Rembrandt van Rijn "Der Philosoph" Verbildlichung Klischees weltfremden Philosophen im Elfenbeinturm'
db.append(tempdbsent509)


tempdbsent510 = DBSentence()
tempdbsent510.subject        = 'Der Idiot'
tempdbsent510.verb           = 'war'
tempdbsent510.object         = 'in der griechischen Antike ein Mensch'
tempdbsent510.prefix         = ''
tempdbsent510.suffix         = 'der sich weigerte, an Wahlen teilzunehmen.'
tempdbsent510.feeling        = 'normal'
tempdbsent510.category       = 'normal'
tempdbsent510.priority       = 50
tempdbsent510.all_ohne_muell = 'Der Idiot war griechischen Antike Mensch sich weigerte an Wahlen teilzunehmen'
db.append(tempdbsent510)


tempdbsent511 = DBSentence()
tempdbsent511.subject        = 'Jetzt'
tempdbsent511.verb           = 'war'
tempdbsent511.object         = 'von 1993 bis 2002 das Jugendmagazin der Sueddeutschen Zeitung.'
tempdbsent511.prefix         = ''
tempdbsent511.suffix         = ''
tempdbsent511.feeling        = 'normal'
tempdbsent511.category       = 'normal'
tempdbsent511.priority       = 50
tempdbsent511.all_ohne_muell = 'Jetzt war 1993 bis 2002 Jugendmagazin Sueddeutschen Zeitung'
db.append(tempdbsent511)


tempdbsent512 = DBSentence()
tempdbsent512.subject        = 'eBay Inc.'
tempdbsent512.verb           = 'ist'
tempdbsent512.object         = 'das weltweit groesste Internetauktionshaus.'
tempdbsent512.prefix         = ''
tempdbsent512.suffix         = ''
tempdbsent512.feeling        = 'normal'
tempdbsent512.category       = 'normal'
tempdbsent512.priority       = 50
tempdbsent512.all_ohne_muell = 'eBay Inc ist weltweit groesste Internetauktionshaus'
db.append(tempdbsent512)


tempdbsent513 = DBSentence()
tempdbsent513.subject        = ''
tempdbsent513.verb           = ''
tempdbsent513.object         = ''
tempdbsent513.prefix         = 'Der Begriff Wahrheit bezeichnet im allgemeinen eine Uebereinstimmung mit der Wirklichkeit.'
tempdbsent513.suffix         = ''
tempdbsent513.feeling        = 'normal'
tempdbsent513.category       = 'normal'
tempdbsent513.priority       = 50
tempdbsent513.all_ohne_muell = 'Der Begriff Wahrheit bezeichnet im allgemeinen Uebereinstimmung mit Wirklichkeit'
db.append(tempdbsent513)


tempdbsent514 = DBSentence()
tempdbsent514.subject        = 'Daneben'
tempdbsent514.verb           = 'wird'
tempdbsent514.object         = 'der Raum'
tempdbsent514.prefix         = ''
tempdbsent514.suffix         = 'in dem sich eine solche Vorrichtung befindet, ebenfalls Toilette genannt.'
tempdbsent514.feeling        = 'normal'
tempdbsent514.category       = 'normal'
tempdbsent514.priority       = 50
tempdbsent514.all_ohne_muell = 'Daneben wird Raum sich solche Vorrichtung befindet ebenfalls Toilette genannt'
db.append(tempdbsent514)


tempdbsent515 = DBSentence()
tempdbsent515.subject        = 'Gestank'
tempdbsent515.verb           = 'ist'
tempdbsent515.object         = 'ein als abscheulich bis hin zum Ekel empfundener Geruch.'
tempdbsent515.prefix         = ''
tempdbsent515.suffix         = ''
tempdbsent515.feeling        = 'normal'
tempdbsent515.category       = 'normal'
tempdbsent515.priority       = 50
tempdbsent515.all_ohne_muell = 'Gestank ist als abscheulich bis hin zum Ekel empfundener Geruch'
db.append(tempdbsent515)


tempdbsent516 = DBSentence()
tempdbsent516.subject        = 'Ein Kritiker'
tempdbsent516.verb           = 'ist'
tempdbsent516.object         = 'jemand'
tempdbsent516.prefix         = ''
tempdbsent516.suffix         = 'der sich der Kritik eines in der Regel handfesten Phaenomens, namentlich im Bereich der Kultur widmet.'
tempdbsent516.feeling        = 'normal'
tempdbsent516.category       = 'normal'
tempdbsent516.priority       = 50
tempdbsent516.all_ohne_muell = 'Ein Kritiker ist jemand sich Kritik Regel handfesten Phaenomens namentlich im Bereich Kultur widmet'
db.append(tempdbsent516)


tempdbsent517 = DBSentence()
tempdbsent517.subject        = ''
tempdbsent517.verb           = ''
tempdbsent517.object         = ''
tempdbsent517.prefix         = '* die Zeremonie und Feier der Eheschliessung oder Begruendung einer anderen Lebenspartnerschaft'
tempdbsent517.suffix         = 'siehe Heirat .'
tempdbsent517.feeling        = 'normal'
tempdbsent517.category       = 'normal'
tempdbsent517.priority       = 50
tempdbsent517.all_ohne_muell = '* Zeremonie Feier Eheschliessung Begruendung anderen Lebenspartnerschaft siehe Heirat'
db.append(tempdbsent517)


tempdbsent518 = DBSentence()
tempdbsent518.subject        = 'Adolf'
tempdbsent518.verb           = 'ist'
tempdbsent518.object         = 'ein maennlicher Vor und Nachname.'
tempdbsent518.prefix         = ''
tempdbsent518.suffix         = ''
tempdbsent518.feeling        = 'normal'
tempdbsent518.category       = 'normal'
tempdbsent518.priority       = 50
tempdbsent518.all_ohne_muell = 'Adolf ist maennlicher Vor Nachname'
db.append(tempdbsent518)


tempdbsent519 = DBSentence()
tempdbsent519.subject        = 'Die Stadt Bad Vilbel im hessischen Wetteraukreis grenzt an den noerdlichen Stadtrand von Frankfurt am Main und'
tempdbsent519.verb           = 'ist'
tempdbsent519.object         = 'fuer ihre Mineralquellen ueberregional bekannt.'
tempdbsent519.prefix         = ''
tempdbsent519.suffix         = ''
tempdbsent519.feeling        = 'normal'
tempdbsent519.category       = 'normal'
tempdbsent519.priority       = 50
tempdbsent519.all_ohne_muell = 'Die Stadt Bad Vilbel im hessischen Wetteraukreis grenzt an den noerdlichen Stadtrand Frankfurt am Main ist ihre Mineralquellen ueberregional bekannt'
db.append(tempdbsent519)


tempdbsent520 = DBSentence()
tempdbsent520.subject        = 'Nidda'
tempdbsent520.verb           = 'ist'
tempdbsent520.object         = 'eine Stadt in der hessischen Wetterau.'
tempdbsent520.prefix         = ''
tempdbsent520.suffix         = ''
tempdbsent520.feeling        = 'normal'
tempdbsent520.category       = 'normal'
tempdbsent520.priority       = 50
tempdbsent520.all_ohne_muell = 'Nidda ist Stadt hessischen Wetterau'
db.append(tempdbsent520)


tempdbsent521 = DBSentence()
tempdbsent521.subject        = 'Genauigkeit'
tempdbsent521.verb           = 'ist'
tempdbsent521.object         = 'ein Begriff'
tempdbsent521.prefix         = ''
tempdbsent521.suffix         = 'der in den gesamten Wissenschaften eine zentrale Rolle spielt.'
tempdbsent521.feeling        = 'normal'
tempdbsent521.category       = 'normal'
tempdbsent521.priority       = 50
tempdbsent521.all_ohne_muell = 'Genauigkeit ist Begriff den gesamten Wissenschaften zentrale Rolle spielt'
db.append(tempdbsent521)


tempdbsent522 = DBSentence()
tempdbsent522.subject        = 'Pylon'
tempdbsent522.verb           = 'neben'
tempdbsent522.object         = 'der Haupteinfahrt zur MHH .'
tempdbsent522.prefix         = ''
tempdbsent522.suffix         = ''
tempdbsent522.feeling        = 'normal'
tempdbsent522.category       = 'normal'
tempdbsent522.priority       = 50
tempdbsent522.all_ohne_muell = 'Pylon Haupteinfahrt zur MHH'
db.append(tempdbsent522)


tempdbsent523 = DBSentence()
tempdbsent523.subject        = 'Die Beste'
tempdbsent523.verb           = 'ist'
tempdbsent523.object         = 'ein Fluss im Kreis Stormarn'
tempdbsent523.prefix         = ''
tempdbsent523.suffix         = 'der in Bad Oldesloe in die Trave muendet.'
tempdbsent523.feeling        = 'normal'
tempdbsent523.category       = 'normal'
tempdbsent523.priority       = 50
tempdbsent523.all_ohne_muell = 'Die Beste ist Fluss im Kreis Stormarn Bad Oldesloe Trave muendet'
db.append(tempdbsent523)


tempdbsent524 = DBSentence()
tempdbsent524.subject        = 'Die Mathematik'
tempdbsent524.verb           = 'ist'
tempdbsent524.object         = 'die Wissenschaft'
tempdbsent524.prefix         = ''
tempdbsent524.suffix         = 'welche aus der Untersuchung von Figuren und dem Rechnen mit Zahlen entstand.'
tempdbsent524.feeling        = 'normal'
tempdbsent524.category       = 'normal'
tempdbsent524.priority       = 50
tempdbsent524.all_ohne_muell = 'Die Mathematik ist Wissenschaft welche aus Untersuchung Figuren Rechnen mit Zahlen entstand'
db.append(tempdbsent524)


tempdbsent525 = DBSentence()
tempdbsent525.subject        = 'Macht'
tempdbsent525.verb           = 'ist'
tempdbsent525.object         = 'die Faehigkeit von Individuen und Gruppen'
tempdbsent525.prefix         = ''
tempdbsent525.suffix         = 'das Verhalten und Denken von anderen Individuen oder Gruppen in ihrem Sinne zu bestimmen.'
tempdbsent525.feeling        = 'normal'
tempdbsent525.category       = 'normal'
tempdbsent525.priority       = 50
tempdbsent525.all_ohne_muell = 'Macht ist Faehigkeit Individuen Gruppen Verhalten Denken anderen Individuen Gruppen ihrem Sinne zu bestimmen'
db.append(tempdbsent525)


tempdbsent526 = DBSentence()
tempdbsent526.subject        = 'Cool'
tempdbsent526.verb           = 'ist'
tempdbsent526.object         = 'ein urspruenglich jugendsprachlicher Begriff'
tempdbsent526.prefix         = ''
tempdbsent526.suffix         = 'der inzwischen in die saloppe Umgangssprache eines grossen Teils der Weltbevoelkerung Eingang gefunden hat.'
tempdbsent526.feeling        = 'normal'
tempdbsent526.category       = 'normal'
tempdbsent526.priority       = 50
tempdbsent526.all_ohne_muell = 'Cool ist urspruenglich jugendsprachlicher Begriff inzwischen saloppe Umgangssprache grossen Teils Weltbevoelkerung Eingang gefunden hat'
db.append(tempdbsent526)


tempdbsent527 = DBSentence()
tempdbsent527.subject        = 'Der Ausdruck Fragmentierung bezeichnet allgemein die Aufteilung eines Groesseren in'
tempdbsent527.verb           = 'kleinere'
tempdbsent527.object         = 'Teile.'
tempdbsent527.prefix         = ''
tempdbsent527.suffix         = ''
tempdbsent527.feeling        = 'normal'
tempdbsent527.category       = 'normal'
tempdbsent527.priority       = 50
tempdbsent527.all_ohne_muell = 'Der Ausdruck Fragmentierung bezeichnet allgemein Aufteilung Groesseren kleinere Teile'
db.append(tempdbsent527)


tempdbsent528 = DBSentence()
tempdbsent528.subject        = 'Ein Unterschied'
tempdbsent528.verb           = 'ist'
tempdbsent528.object         = 'alltagssprachlich oder in traditioneller Sicht ein Aspekt der NichtUebereinstimmung zweier Objekte.'
tempdbsent528.prefix         = ''
tempdbsent528.suffix         = ''
tempdbsent528.feeling        = 'normal'
tempdbsent528.category       = 'normal'
tempdbsent528.priority       = 50
tempdbsent528.all_ohne_muell = 'Ein Unterschied ist alltagssprachlich traditioneller Sicht Aspekt NichtUebereinstimmung zweier Objekte'
db.append(tempdbsent528)


tempdbsent529 = DBSentence()
tempdbsent529.subject        = 'Der Landkreis Tuttlingen'
tempdbsent529.verb           = 'ist'
tempdbsent529.object         = 'ein Landkreis in BadenWuerttemberg.'
tempdbsent529.prefix         = ''
tempdbsent529.suffix         = ''
tempdbsent529.feeling        = 'normal'
tempdbsent529.category       = 'normal'
tempdbsent529.priority       = 50
tempdbsent529.all_ohne_muell = 'Der Landkreis Tuttlingen ist Landkreis BadenWuerttemberg'
db.append(tempdbsent529)


tempdbsent530 = DBSentence()
tempdbsent530.subject        = 'ebenda'
tempdbsent530.verb           = 'ist'
tempdbsent530.object         = 'ein in wissenschaftlichen Arbeiten oftmals verwendeter Ausdruck'
tempdbsent530.prefix         = ''
tempdbsent530.suffix         = 'der als Hinweis beim Zitieren in der Quellenangabe/Literaturangabe verwendet wird, wenn ein Titel auf einer Seite mehrmals zitiert wird.'
tempdbsent530.feeling        = 'normal'
tempdbsent530.category       = 'normal'
tempdbsent530.priority       = 50
tempdbsent530.all_ohne_muell = 'ebenda ist wissenschaftlichen Arbeiten oftmals verwendeter Ausdruck als Hinweis beim Zitieren Quellenangabe / Literaturangabe verwendet wird wenn Titel Seite mehrmals zitiert wird'
db.append(tempdbsent530)


tempdbsent531 = DBSentence()
tempdbsent531.subject        = 'die eine Person an'
tempdbsent531.verb           = 'einer'
tempdbsent531.object         = 'Sache oder'
tempdbsent531.prefix         = 'Unter Interesse versteht man die kognitive Anteilnahme respektive die Aufmerksamkeit'
tempdbsent531.suffix         = ''
tempdbsent531.feeling        = 'normal'
tempdbsent531.category       = 'normal'
tempdbsent531.priority       = 50
tempdbsent531.all_ohne_muell = 'Unter Interesse versteht man kognitive Anteilnahme respektive Aufmerksamkeit Person an Sache'
db.append(tempdbsent531)


tempdbsent532 = DBSentence()
tempdbsent532.subject        = 'nach Definition der Weltgesundheitsorganisation, jeder Wirkstoff, der in'
tempdbsent532.verb           = 'einem'
tempdbsent532.object         = 'lebenden Organismus Funktionen zu veraendern vermag.'
tempdbsent532.prefix         = 'Als Droge gilt'
tempdbsent532.suffix         = ''
tempdbsent532.feeling        = 'normal'
tempdbsent532.category       = 'normal'
tempdbsent532.priority       = 50
tempdbsent532.all_ohne_muell = 'Als Droge gilt nach Definition Weltgesundheitsorganisation jeder Wirkstoff lebenden Organismus Funktionen zu veraendern vermag'
db.append(tempdbsent532)


tempdbsent533 = DBSentence()
tempdbsent533.subject        = 'Der Linguist Larry Wall entwarf'
tempdbsent533.verb           = 'sie'
tempdbsent533.object         = '1987 als Synthese aus C'
tempdbsent533.prefix         = ''
tempdbsent533.suffix         = 'den UNIXBefehlen und anderen Einfluessen.'
tempdbsent533.feeling        = 'normal'
tempdbsent533.category       = 'normal'
tempdbsent533.priority       = 50
tempdbsent533.all_ohne_muell = 'Der Linguist Larry Wall entwarf sie 1987 als Synthese aus C den UNIXBefehlen anderen Einfluessen'
db.append(tempdbsent533)


tempdbsent534 = DBSentence()
tempdbsent534.subject        = 'Allgemeinbildung'
tempdbsent534.verb           = 'oder'
tempdbsent534.object         = 'Allgemeinwissen bezeichnet den Gedanken einer Bildung fuer die Allgemeinheit aus der Zeit der Aufklaerung'
tempdbsent534.prefix         = ''
tempdbsent534.suffix         = 'bzw. des Humanismus.'
tempdbsent534.feeling        = 'normal'
tempdbsent534.category       = 'normal'
tempdbsent534.priority       = 50
tempdbsent534.all_ohne_muell = 'Allgemeinbildung Allgemeinwissen bezeichnet den Gedanken Bildung Allgemeinheit aus Zeit Aufklaerung bzw Humanismus'
db.append(tempdbsent534)


tempdbsent535 = DBSentence()
tempdbsent535.subject        = 'Die Echten Kobras'
tempdbsent535.verb           = 'sind'
tempdbsent535.object         = 'Giftnattern'
tempdbsent535.prefix         = ''
tempdbsent535.suffix         = 'die in etwa 20 Arten in Afrika und Asien vorkommen.'
tempdbsent535.feeling        = 'normal'
tempdbsent535.category       = 'normal'
tempdbsent535.priority       = 50
tempdbsent535.all_ohne_muell = 'Die Echten Kobras sind Giftnattern etwa 20 Arten Afrika Asien vorkommen'
db.append(tempdbsent535)


tempdbsent536 = DBSentence()
tempdbsent536.subject        = 'Martin Luther King waehrend'
tempdbsent536.verb           = 'einer'
tempdbsent536.object         = 'Rede .'
tempdbsent536.prefix         = ''
tempdbsent536.suffix         = ''
tempdbsent536.feeling        = 'normal'
tempdbsent536.category       = 'normal'
tempdbsent536.priority       = 50
tempdbsent536.all_ohne_muell = 'Martin Luther King waehrend Rede'
db.append(tempdbsent536)


tempdbsent537 = DBSentence()
tempdbsent537.subject        = 'Unsinn oder auch Widersinn'
tempdbsent537.verb           = 'ist'
tempdbsent537.object         = 'ein von Logik oder auch Sinn geloester oder grob falscher Sachverhalt bisweilen scherzhaft.'
tempdbsent537.prefix         = ''
tempdbsent537.suffix         = ''
tempdbsent537.feeling        = 'normal'
tempdbsent537.category       = 'normal'
tempdbsent537.priority       = 50
tempdbsent537.all_ohne_muell = 'Unsinn auch Widersinn ist Logik auch Sinn geloester grob falscher Sachverhalt bisweilen scherzhaft'
db.append(tempdbsent537)


tempdbsent538 = DBSentence()
tempdbsent538.subject        = 'Eine Beleidigung im weiteren Sinne'
tempdbsent538.verb           = 'ist'
tempdbsent538.object         = 'jede Verletzung der persoenlichen Ehre eines anderen.'
tempdbsent538.prefix         = ''
tempdbsent538.suffix         = ''
tempdbsent538.feeling        = 'normal'
tempdbsent538.category       = 'normal'
tempdbsent538.priority       = 50
tempdbsent538.all_ohne_muell = 'Eine Beleidigung im weiteren Sinne ist jede Verletzung persoenlichen Ehre anderen'
db.append(tempdbsent538)


tempdbsent539 = DBSentence()
tempdbsent539.subject        = ''
tempdbsent539.verb           = ''
tempdbsent539.object         = ''
tempdbsent539.prefix         = 'Die Einsicht bezeichnet beim Menschen im allgemeinen die Erfassung der allgemeinen'
tempdbsent539.suffix         = 'wesentlichen und notwendigen Eigenschaften und Beziehungen eines Objektbereiches.'
tempdbsent539.feeling        = 'normal'
tempdbsent539.category       = 'normal'
tempdbsent539.priority       = 50
tempdbsent539.all_ohne_muell = 'Die Einsicht bezeichnet beim Menschen im allgemeinen Erfassung allgemeinen wesentlichen notwendigen Eigenschaften Beziehungen Objektbereiches'
db.append(tempdbsent539)


tempdbsent540 = DBSentence()
tempdbsent540.subject        = 'Die Regierung'
tempdbsent540.verb           = 'ist'
tempdbsent540.object         = 'nach dem Staatsoberhaupt eine der hoechsten Institutionen eines Staates.'
tempdbsent540.prefix         = ''
tempdbsent540.suffix         = ''
tempdbsent540.feeling        = 'normal'
tempdbsent540.category       = 'normal'
tempdbsent540.priority       = 50
tempdbsent540.all_ohne_muell = 'Die Regierung ist nach Staatsoberhaupt hoechsten Institutionen Staates'
db.append(tempdbsent540)


tempdbsent541 = DBSentence()
tempdbsent541.subject        = 'Eine Koalition'
tempdbsent541.verb           = 'ist'
tempdbsent541.object         = 'ein Zusammenschluss von Staaten'
tempdbsent541.prefix         = ''
tempdbsent541.suffix         = 'Organisationen, politischen Parteien oder Personen zur Durchsetzung bestimmter Ziele, vergleichbar einem Buendnis.'
tempdbsent541.feeling        = 'normal'
tempdbsent541.category       = 'normal'
tempdbsent541.priority       = 50
tempdbsent541.all_ohne_muell = 'Eine Koalition ist Zusammenschluss Staaten Organisationen politischen Parteien Personen zur Durchsetzung bestimmter Ziele vergleichbar Buendnis'
db.append(tempdbsent541)


tempdbsent542 = DBSentence()
tempdbsent542.subject        = 'ELIZA'
tempdbsent542.verb           = 'ist'
tempdbsent542.object         = 'ein 1966 von Joseph Weizenbaum entwickeltes Computerprogramm'
tempdbsent542.prefix         = ''
tempdbsent542.suffix         = 'das die Moeglichkeiten der Kommunikation zwischen einem Menschen und dem Computer ueber natuerliche Sprache aufzeigen sollte.'
tempdbsent542.feeling        = 'normal'
tempdbsent542.category       = 'normal'
tempdbsent542.priority       = 50
tempdbsent542.all_ohne_muell = 'ELIZA ist 1966 Joseph Weizenbaum entwickeltes Computerprogramm Moeglichkeiten Kommunikation Menschen Computer ueber natuerliche Sprache aufzeigen sollte'
db.append(tempdbsent542)


tempdbsent543 = DBSentence()
tempdbsent543.subject        = ''
tempdbsent543.verb           = ''
tempdbsent543.object         = ''
tempdbsent543.prefix         = 'Unter dem Beruf versteht man diejenige institutionalisierte Taetigkeit'
tempdbsent543.suffix         = 'die ein Mensch fuer finanzielle oder herkoemmliche Gegenleistungen oder im Dienste Dritter regelmaessig erbringt, bzw. fuer die er ausgebildet, erzogen oder berufen ist.'
tempdbsent543.feeling        = 'normal'
tempdbsent543.category       = 'normal'
tempdbsent543.priority       = 50
tempdbsent543.all_ohne_muell = 'Unter Beruf versteht man diejenige institutionalisierte Taetigkeit Mensch finanzielle herkoemmliche Gegenleistungen im Dienste Dritter regelmaessig erbringt bzw er ausgebildet erzogen berufen ist'
db.append(tempdbsent543)


tempdbsent544 = DBSentence()
tempdbsent544.subject        = 'anschliessendem Fall bzw. Flug und abschliessender Landung einer Person aus einer so erhoehten Position , das ohne die Benutzung eines Fallschirms das Auftreffen am Boden meist Verletzung'
tempdbsent544.verb           = 'oder'
tempdbsent544.object         = 'Tod zur Folge haette.'
tempdbsent544.prefix         = 'Fallschirmspringen bezeichnet die Gesamtheit von Absprung'
tempdbsent544.suffix         = ''
tempdbsent544.feeling        = 'normal'
tempdbsent544.category       = 'normal'
tempdbsent544.priority       = 50
tempdbsent544.all_ohne_muell = 'Fallschirmspringen bezeichnet Gesamtheit Absprung anschliessendem Fall bzw Flug abschliessender Landung Person aus so erhoehten Position ohne Benutzung Fallschirms Auftreffen am Boden meist Verletzung Tod zur Folge haette'
db.append(tempdbsent544)


tempdbsent545 = DBSentence()
tempdbsent545.subject        = 'Hudson Whittaker alias Tampa Red'
tempdbsent545.verb           = 'war'
tempdbsent545.object         = 'ein USamerikanischer Saenger und Gitarrist.'
tempdbsent545.prefix         = ''
tempdbsent545.suffix         = ''
tempdbsent545.feeling        = 'normal'
tempdbsent545.category       = 'normal'
tempdbsent545.priority       = 50
tempdbsent545.all_ohne_muell = 'Hudson Whittaker alias Tampa Red war USamerikanischer Saenger Gitarrist'
db.append(tempdbsent545)


tempdbsent546 = DBSentence()
tempdbsent546.subject        = 'Peter Sehr'
tempdbsent546.verb           = 'ist'
tempdbsent546.object         = 'ein deutscher Filmregisseur und wichtiger Vertreter des deutschen Autorenfilms.'
tempdbsent546.prefix         = ''
tempdbsent546.suffix         = ''
tempdbsent546.feeling        = 'normal'
tempdbsent546.category       = 'normal'
tempdbsent546.priority       = 50
tempdbsent546.all_ohne_muell = 'Peter Sehr ist deutscher Filmregisseur wichtiger Vertreter deutschen Autorenfilms'
db.append(tempdbsent546)


tempdbsent547 = DBSentence()
tempdbsent547.subject        = 'Haste'
tempdbsent547.verb           = 'ist'
tempdbsent547.object         = 'eine Ortschaft im Landkreis Schaumburg in Niedersachsen.'
tempdbsent547.prefix         = ''
tempdbsent547.suffix         = ''
tempdbsent547.feeling        = 'normal'
tempdbsent547.category       = 'normal'
tempdbsent547.priority       = 50
tempdbsent547.all_ohne_muell = 'Haste ist Ortschaft im Landkreis Schaumburg Niedersachsen'
db.append(tempdbsent547)


tempdbsent548 = DBSentence()
tempdbsent548.subject        = 'Eugne Delacroix Die Freiheit'
tempdbsent548.verb           = 'fuehrt'
tempdbsent548.object         = 'das Volk .'
tempdbsent548.prefix         = ''
tempdbsent548.suffix         = ''
tempdbsent548.feeling        = 'normal'
tempdbsent548.category       = 'normal'
tempdbsent548.priority       = 50
tempdbsent548.all_ohne_muell = 'Eugne Delacroix Die Freiheit fuehrt Volk'
db.append(tempdbsent548)


tempdbsent549 = DBSentence()
tempdbsent549.subject        = 'Eine Bezeichnung'
tempdbsent549.verb           = 'ist'
tempdbsent549.object         = 'in der Semiotik ein Code aus Zeichen und Symbolen'
tempdbsent549.prefix         = ''
tempdbsent549.suffix         = 'der auf einen Gegenstand oder Sachverhalt verweist.'
tempdbsent549.feeling        = 'normal'
tempdbsent549.category       = 'normal'
tempdbsent549.priority       = 50
tempdbsent549.all_ohne_muell = 'Eine Bezeichnung ist Semiotik Code aus Zeichen Symbolen einen Gegenstand Sachverhalt verweist'
db.append(tempdbsent549)


tempdbsent550 = DBSentence()
tempdbsent550.subject        = 'Die Eine'
tempdbsent550.verb           = 'ist'
tempdbsent550.object         = 'ein knapp 40 km langer Fluss in SachsenAnhalt'
tempdbsent550.prefix         = ''
tempdbsent550.suffix         = 'der suedoestlich von Harzgerode im Harz auf 420 m NN entspringt.'
tempdbsent550.feeling        = 'normal'
tempdbsent550.category       = 'normal'
tempdbsent550.priority       = 50
tempdbsent550.all_ohne_muell = 'Die Eine ist knapp 40 km langer Fluss SachsenAnhalt suedoestlich Harzgerode im Harz 420 m NN entspringt'
db.append(tempdbsent550)


tempdbsent551 = DBSentence()
tempdbsent551.subject        = 'Ein Speichermedium'
tempdbsent551.verb           = 'ist'
tempdbsent551.object         = 'ein Stoff oder ein Objekt zum Speichern .'
tempdbsent551.prefix         = ''
tempdbsent551.suffix         = ''
tempdbsent551.feeling        = 'normal'
tempdbsent551.category       = 'normal'
tempdbsent551.priority       = 50
tempdbsent551.all_ohne_muell = 'Ein Speichermedium ist Stoff Objekt zum Speichern'
db.append(tempdbsent551)


tempdbsent552 = DBSentence()
tempdbsent552.subject        = ''
tempdbsent552.verb           = ''
tempdbsent552.object         = ''
tempdbsent552.prefix         = 'Die Rechnertechnik untersucht vorherrschende Prozessorarchitekturen und die dabei verwendeten Materialien und Technologien.'
tempdbsent552.suffix         = ''
tempdbsent552.feeling        = 'normal'
tempdbsent552.category       = 'normal'
tempdbsent552.priority       = 50
tempdbsent552.all_ohne_muell = 'Die Rechnertechnik untersucht vorherrschende Prozessorarchitekturen dabei verwendeten Materialien Technologien'
db.append(tempdbsent552)


tempdbsent553 = DBSentence()
tempdbsent553.subject        = 'Der Begriff Daten'
tempdbsent553.verb           = 'ist'
tempdbsent553.object         = 'der Plural von Datum .'
tempdbsent553.prefix         = ''
tempdbsent553.suffix         = ''
tempdbsent553.feeling        = 'normal'
tempdbsent553.category       = 'normal'
tempdbsent553.priority       = 50
tempdbsent553.all_ohne_muell = 'Der Begriff Daten ist Plural Datum'
db.append(tempdbsent553)


tempdbsent554 = DBSentence()
tempdbsent554.subject        = 'Eine Scheibe'
tempdbsent554.verb           = 'ist'
tempdbsent554.object         = 'ein Zylinder'
tempdbsent554.prefix         = ''
tempdbsent554.suffix         = 'dessem Dicke um ein Vielfaches geringer'
tempdbsent554.feeling        = 'normal'
tempdbsent554.category       = 'normal'
tempdbsent554.priority       = 50
tempdbsent554.all_ohne_muell = 'Eine Scheibe ist Zylinder dessem Dicke um Vielfaches geringer'
db.append(tempdbsent554)


tempdbsent555 = DBSentence()
tempdbsent555.subject        = 'Regen bezeichnet'
tempdbsent555.verb           = 'einen'
tempdbsent555.object         = 'fluessigen Niederschlag mit einer Tropfengroesse von meist 0'
tempdbsent555.prefix         = ''
tempdbsent555.suffix         = '63 mm.'
tempdbsent555.feeling        = 'normal'
tempdbsent555.category       = 'normal'
tempdbsent555.priority       = 50
tempdbsent555.all_ohne_muell = 'Regen bezeichnet einen fluessigen Niederschlag mit Tropfengroesse meist 0 63 mm'
db.append(tempdbsent555)


tempdbsent556 = DBSentence()
tempdbsent556.subject        = 'Das Panzerabwehrsystem Bill RBS56 von der Firma Bofors'
tempdbsent556.verb           = 'ist'
tempdbsent556.object         = 'eine schultergestuetzte Raketenwaffe.'
tempdbsent556.prefix         = ''
tempdbsent556.suffix         = ''
tempdbsent556.feeling        = 'normal'
tempdbsent556.category       = 'normal'
tempdbsent556.priority       = 50
tempdbsent556.all_ohne_muell = 'Das Panzerabwehrsystem Bill RBS56 Firma Bofors ist schultergestuetzte Raketenwaffe'
db.append(tempdbsent556)


tempdbsent557 = DBSentence()
tempdbsent557.subject        = 'Die Wahehe'
tempdbsent557.verb           = 'sind'
tempdbsent557.object         = 'eine Ethnie in Tansania'
tempdbsent557.prefix         = ''
tempdbsent557.suffix         = 'die zu Beginn der Kolonisation DeutschOstafrikas von 1891 bis 1898 unter Haeuptling Mkwawa erbitterten Widerstand leisteten.'
tempdbsent557.feeling        = 'normal'
tempdbsent557.category       = 'normal'
tempdbsent557.priority       = 50
tempdbsent557.all_ohne_muell = 'Die Wahehe sind Ethnie Tansania zu Beginn Kolonisation DeutschOstafrikas 1891 bis 1898 Haeuptling Mkwawa erbitterten Widerstand leisteten'
db.append(tempdbsent557)


tempdbsent558 = DBSentence()
tempdbsent558.subject        = ''
tempdbsent558.verb           = 'frueher'
tempdbsent558.object         = 'auch Ethnos .'
tempdbsent558.prefix         = 'Ethnie oder Ethnische Gruppe'
tempdbsent558.suffix         = ''
tempdbsent558.feeling        = 'normal'
tempdbsent558.category       = 'normal'
tempdbsent558.priority       = 50
tempdbsent558.all_ohne_muell = 'Ethnie Ethnische Gruppe frueher auch Ethnos'
db.append(tempdbsent558)


tempdbsent559 = DBSentence()
tempdbsent559.subject        = 'Die Vereinigte Republik Tansania'
tempdbsent559.verb           = 'ist'
tempdbsent559.object         = 'ein Staat in Ostafrika.'
tempdbsent559.prefix         = ''
tempdbsent559.suffix         = ''
tempdbsent559.feeling        = 'normal'
tempdbsent559.category       = 'normal'
tempdbsent559.priority       = 50
tempdbsent559.all_ohne_muell = 'Die Vereinigte Republik Tansania ist Staat Ostafrika'
db.append(tempdbsent559)


tempdbsent560 = DBSentence()
tempdbsent560.subject        = 'Der Anfang'
tempdbsent560.verb           = 'ist'
tempdbsent560.object         = 'der zeitliche oder raeumliche Beginn eines Vorgangs oder einer Sache.'
tempdbsent560.prefix         = ''
tempdbsent560.suffix         = ''
tempdbsent560.feeling        = 'normal'
tempdbsent560.category       = 'normal'
tempdbsent560.priority       = 50
tempdbsent560.all_ohne_muell = 'Der Anfang ist zeitliche raeumliche Beginn Vorgangs Sache'
db.append(tempdbsent560)


tempdbsent561 = DBSentence()
tempdbsent561.subject        = ''
tempdbsent561.verb           = ''
tempdbsent561.object         = ''
tempdbsent561.prefix         = 'Kolonisation oder Kolonisierung meint die Gruendung und Entwicklung von Kolonien .'
tempdbsent561.suffix         = ''
tempdbsent561.feeling        = 'normal'
tempdbsent561.category       = 'normal'
tempdbsent561.priority       = 50
tempdbsent561.all_ohne_muell = 'Kolonisation Kolonisierung meint Gruendung Entwicklung Kolonien'
db.append(tempdbsent561)


tempdbsent562 = DBSentence()
tempdbsent562.subject        = 'besser bekannt als Chief Mkwawa,'
tempdbsent562.verb           = 'war'
tempdbsent562.object         = 'ein Haeuptling des Stammes der Hehe in DeutschOstafrika'
tempdbsent562.prefix         = 'Mkwavinyika Munyigumba Mwamuyinga'
tempdbsent562.suffix         = 'dem heutigen Tansania, der einen Aufstand der Indigenen Bevoelkerung gegen die Deutsche Kolonialmacht anfuehrte.'
tempdbsent562.feeling        = 'normal'
tempdbsent562.category       = 'normal'
tempdbsent562.priority       = 50
tempdbsent562.all_ohne_muell = 'Mkwavinyika Munyigumba Mwamuyinga besser bekannt als Chief Mkwawa war Haeuptling Stammes Hehe DeutschOstafrika heutigen Tansania einen Aufstand Indigenen Bevoelkerung gegen Deutsche Kolonialmacht anfuehrte'
db.append(tempdbsent562)


tempdbsent563 = DBSentence()
tempdbsent563.subject        = 'Der Begriff Widerstand'
tempdbsent563.verb           = 'bezeichnet'
tempdbsent563.object         = 'prinzipiell eine hemmende Kraft in der Physik'
tempdbsent563.prefix         = ''
tempdbsent563.suffix         = 'Gesellschaft oder der psychischen Organisation eines Menschen.'
tempdbsent563.feeling        = 'normal'
tempdbsent563.category       = 'normal'
tempdbsent563.priority       = 50
tempdbsent563.all_ohne_muell = 'Der Begriff Widerstand bezeichnet prinzipiell hemmende Kraft Physik Gesellschaft psychischen Organisation Menschen'
db.append(tempdbsent563)


tempdbsent564 = DBSentence()
tempdbsent564.subject        = 'Sprache'
tempdbsent564.verb           = 'hat'
tempdbsent564.object         = 'zwei eng mit einander verwandte Verwendungen'
tempdbsent564.prefix         = ''
tempdbsent564.suffix         = 'die Sprache oder eine Sprache/Sprachen.'
tempdbsent564.feeling        = 'normal'
tempdbsent564.category       = 'normal'
tempdbsent564.priority       = 50
tempdbsent564.all_ohne_muell = 'Sprache hat zwei eng mit einander verwandte Verwendungen Sprache Sprache / Sprachen'
db.append(tempdbsent564)


tempdbsent565 = DBSentence()
tempdbsent565.subject        = 'Beobachtungsposten'
tempdbsent565.verb           = 'sind'
tempdbsent565.object         = 'Einrichtungen zur direkten Beobachtung eines Gelaendes.'
tempdbsent565.prefix         = ''
tempdbsent565.suffix         = ''
tempdbsent565.feeling        = 'normal'
tempdbsent565.category       = 'normal'
tempdbsent565.priority       = 50
tempdbsent565.all_ohne_muell = 'Beobachtungsposten sind Einrichtungen zur direkten Beobachtung Gelaendes'
db.append(tempdbsent565)


tempdbsent566 = DBSentence()
tempdbsent566.subject        = 'Ein Planet im engeren astronomischen Sinn'
tempdbsent566.verb           = 'ist'
tempdbsent566.object         = 'ein Himmelskoerper'
tempdbsent566.prefix         = ''
tempdbsent566.suffix         = 'der sich auf einer keplerschen Umlaufbahn um die Sonne bewegt, dessen Masse gross genug ist, dass sich das Objekt im hydrostatischen Gleichgewicht befindet  und somit eine naeherungsweise kugelaehnliche Gestalt besitzt  und der das dominierende Objekt seiner Umlaufbahn ist, das heisst, der diese von weiteren Objekten geraeumt hat.'
tempdbsent566.feeling        = 'normal'
tempdbsent566.category       = 'normal'
tempdbsent566.priority       = 50
tempdbsent566.all_ohne_muell = 'Ein Planet im engeren astronomischen Sinn ist Himmelskoerper sich keplerschen Umlaufbahn um Sonne bewegt Masse gross genug ist dass sich Objekt im hydrostatischen Gleichgewicht befindet somit naeherungsweise kugelaehnliche Gestalt besitzt dominierende Objekt seiner Umlaufbahn ist heisst diese weiteren Objekten geraeumt hat'
db.append(tempdbsent566)


tempdbsent567 = DBSentence()
tempdbsent567.subject        = 'Sonnensystem'
tempdbsent567.verb           = 'ist'
tempdbsent567.object         = 'der Eigenname des gravitativen Systems der Sonne.'
tempdbsent567.prefix         = ''
tempdbsent567.suffix         = ''
tempdbsent567.feeling        = 'normal'
tempdbsent567.category       = 'normal'
tempdbsent567.priority       = 50
tempdbsent567.all_ohne_muell = 'Sonnensystem ist Eigenname gravitativen Systems Sonne'
db.append(tempdbsent567)


tempdbsent568 = DBSentence()
tempdbsent568.subject        = 'Eine Faser'
tempdbsent568.verb           = 'ist'
tempdbsent568.object         = 'ein im Verhaeltnis zur Laenge duennes und flexibles Gebilde.'
tempdbsent568.prefix         = ''
tempdbsent568.suffix         = ''
tempdbsent568.feeling        = 'normal'
tempdbsent568.category       = 'normal'
tempdbsent568.priority       = 50
tempdbsent568.all_ohne_muell = 'Eine Faser ist im Verhaeltnis zur Laenge duennes flexibles Gebilde'
db.append(tempdbsent568)


tempdbsent569 = DBSentence()
tempdbsent569.subject        = 'auch Zeitabschnitt, Zeitspanne oder Zeitintervall,'
tempdbsent569.verb           = 'ist'
tempdbsent569.object         = 'ein  mehr oder weniger ausgedehnter'
tempdbsent569.prefix         = 'Ein Zeitraum'
tempdbsent569.suffix         = 'vom Wechsel der Ereignisse und Eindruecke, vom Verlauf der Geschehnisse erfuellter  Teil der Zeit.'
tempdbsent569.feeling        = 'normal'
tempdbsent569.category       = 'normal'
tempdbsent569.priority       = 50
tempdbsent569.all_ohne_muell = 'Ein Zeitraum auch Zeitabschnitt Zeitspanne Zeitintervall ist mehr weniger ausgedehnter Wechsel Ereignisse Eindruecke Verlauf Geschehnisse erfuellter Teil Zeit'
db.append(tempdbsent569)


tempdbsent570 = DBSentence()
tempdbsent570.subject        = 'Ein Kontinuum'
tempdbsent570.verb           = 'ist'
tempdbsent570.object         = 'ein Objekt welches keine Risse'
tempdbsent570.prefix         = ''
tempdbsent570.suffix         = 'Brueche, Loecher, Hohlraeume oder aehnliches innerhalb seiner Grenzen besitzt, sich also ueberall kontinuierlich fortsetzt.'
tempdbsent570.feeling        = 'normal'
tempdbsent570.category       = 'normal'
tempdbsent570.priority       = 50
tempdbsent570.all_ohne_muell = 'Ein Kontinuum ist Objekt welches keine Risse Brueche Loecher Hohlraeume aehnliches innerhalb seiner Grenzen besitzt sich also ueberall kontinuierlich fortsetzt'
db.append(tempdbsent570)


tempdbsent571 = DBSentence()
tempdbsent571.subject        = 'Begriff'
tempdbsent571.verb           = 'ist'
tempdbsent571.object         = 'eine Zusammenstellung von Merkmalen'
tempdbsent571.prefix         = ''
tempdbsent571.suffix         = 'die in Gegenstaenden oder Sachverhalten als deren Eigenschaften erscheinen.'
tempdbsent571.feeling        = 'normal'
tempdbsent571.category       = 'normal'
tempdbsent571.priority       = 50
tempdbsent571.all_ohne_muell = 'Begriff ist Zusammenstellung Merkmalen Gegenstaenden Sachverhalten als deren Eigenschaften erscheinen'
db.append(tempdbsent571)


tempdbsent572 = DBSentence()
tempdbsent572.subject        = 'Eine Definition'
tempdbsent572.verb           = 'ist'
tempdbsent572.object         = 'eine moeglichst eindeutige Bestimmung oder Festlegung der Bedeutung eines Begriffes.'
tempdbsent572.prefix         = ''
tempdbsent572.suffix         = ''
tempdbsent572.feeling        = 'normal'
tempdbsent572.category       = 'normal'
tempdbsent572.priority       = 50
tempdbsent572.all_ohne_muell = 'Eine Definition ist moeglichst eindeutige Bestimmung Festlegung Bedeutung Begriffes'
db.append(tempdbsent572)


tempdbsent573 = DBSentence()
tempdbsent573.subject        = 'Auseinandersetzung'
tempdbsent573.verb           = 'ist'
tempdbsent573.object         = 'nach deutschem Zivilrecht ein Verfahren'
tempdbsent573.prefix         = ''
tempdbsent573.suffix         = 'bei dem das Vermoegen einer Personenmehrheit unter den Mitgliedern verteilt und die Gemeinschaft oder Gesellschaft aufgeloest wird.'
tempdbsent573.feeling        = 'normal'
tempdbsent573.category       = 'normal'
tempdbsent573.priority       = 50
tempdbsent573.all_ohne_muell = 'Auseinandersetzung ist nach deutschem Zivilrecht Verfahren bei Vermoegen Personenmehrheit den Mitgliedern verteilt Gemeinschaft Gesellschaft aufgeloest wird'
db.append(tempdbsent573)


tempdbsent574 = DBSentence()
tempdbsent574.subject        = 'Unter'
tempdbsent574.verb           = 'einem'
tempdbsent574.object         = 'Gefecht versteht man eine Kampfhandlung waehrend eines Krieges'
tempdbsent574.prefix         = ''
tempdbsent574.suffix         = 'also eine militaerische Auseinandersetzung feindlich gesinnter Truppen.'
tempdbsent574.feeling        = 'normal'
tempdbsent574.category       = 'normal'
tempdbsent574.priority       = 50
tempdbsent574.all_ohne_muell = 'Unter Gefecht versteht man Kampfhandlung waehrend Krieges also militaerische Auseinandersetzung feindlich gesinnter Truppen'
db.append(tempdbsent574)


tempdbsent575 = DBSentence()
tempdbsent575.subject        = 'Helene Glatzer'
tempdbsent575.verb           = 'war'
tempdbsent575.object         = 'eine kommunistische Widerstandskaempferin.'
tempdbsent575.prefix         = ''
tempdbsent575.suffix         = ''
tempdbsent575.feeling        = 'normal'
tempdbsent575.category       = 'normal'
tempdbsent575.priority       = 50
tempdbsent575.all_ohne_muell = 'Helene Glatzer war kommunistische Widerstandskaempferin'
db.append(tempdbsent575)


tempdbsent576 = DBSentence()
tempdbsent576.subject        = 'Die Republik Polen'
tempdbsent576.verb           = 'ist'
tempdbsent576.object         = 'ein Staat in Mitteleuropa.'
tempdbsent576.prefix         = ''
tempdbsent576.suffix         = ''
tempdbsent576.feeling        = 'normal'
tempdbsent576.category       = 'normal'
tempdbsent576.priority       = 50
tempdbsent576.all_ohne_muell = 'Die Republik Polen ist Staat Mitteleuropa'
db.append(tempdbsent576)


tempdbsent577 = DBSentence()
tempdbsent577.subject        = ''
tempdbsent577.verb           = ''
tempdbsent577.object         = ''
tempdbsent577.prefix         = 'Tschechien umfasste traditionell die drei historischen Laender Boehmen'
tempdbsent577.suffix         = 'Maehren und MaehrischSchlesien .'
tempdbsent577.feeling        = 'normal'
tempdbsent577.category       = 'normal'
tempdbsent577.priority       = 50
tempdbsent577.all_ohne_muell = 'Tschechien umfasste traditionell drei historischen Laender Boehmen Maehren MaehrischSchlesien'
db.append(tempdbsent577)


tempdbsent578 = DBSentence()
tempdbsent578.subject        = 'Ein Schnittpunkt'
tempdbsent578.verb           = 'ist'
tempdbsent578.object         = 'in der Mathematik ein gemeinsamer Punkt zweier Kurven.'
tempdbsent578.prefix         = ''
tempdbsent578.suffix         = ''
tempdbsent578.feeling        = 'normal'
tempdbsent578.category       = 'normal'
tempdbsent578.priority       = 50
tempdbsent578.all_ohne_muell = 'Ein Schnittpunkt ist Mathematik gemeinsamer Punkt zweier Kurven'
db.append(tempdbsent578)


tempdbsent579 = DBSentence()
tempdbsent579.subject        = 'Der Begriff Selbstregulation'
tempdbsent579.verb           = 'hat'
tempdbsent579.object         = 'in verschiedenen theoretischen und praktischen Zusammenhaengen eine unterschiedliche Bedeutung.'
tempdbsent579.prefix         = ''
tempdbsent579.suffix         = ''
tempdbsent579.feeling        = 'normal'
tempdbsent579.category       = 'normal'
tempdbsent579.priority       = 50
tempdbsent579.all_ohne_muell = 'Der Begriff Selbstregulation hat verschiedenen theoretischen praktischen Zusammenhaengen unterschiedliche Bedeutung'
db.append(tempdbsent579)


tempdbsent580 = DBSentence()
tempdbsent580.subject        = 'Regierungssitz'
tempdbsent580.verb           = 'ist'
tempdbsent580.object         = 'die Stadt eines Landes'
tempdbsent580.prefix         = ''
tempdbsent580.suffix         = 'in der die Regierung ansaessig ist.'
tempdbsent580.feeling        = 'normal'
tempdbsent580.category       = 'normal'
tempdbsent580.priority       = 50
tempdbsent580.all_ohne_muell = 'Regierungssitz ist Stadt Landes Regierung ansaessig ist'
db.append(tempdbsent580)


tempdbsent581 = DBSentence()
tempdbsent581.subject        = 'Eine Bundesrepublik'
tempdbsent581.verb           = 'ist'
tempdbsent581.object         = 'eine foederale Republik'
tempdbsent581.prefix         = ''
tempdbsent581.suffix         = 'ein Zusammenschluss mehrerer teilsouveraener Gliedstaaten.'
tempdbsent581.feeling        = 'normal'
tempdbsent581.category       = 'normal'
tempdbsent581.priority       = 50
tempdbsent581.all_ohne_muell = 'Eine Bundesrepublik ist foederale Republik Zusammenschluss mehrerer teilsouveraener Gliedstaaten'
db.append(tempdbsent581)


tempdbsent582 = DBSentence()
tempdbsent582.subject        = 'Eine Leinwand'
tempdbsent582.verb           = 'ist'
tempdbsent582.object         = 'ein Gewebe aus Leinen'
tempdbsent582.prefix         = ''
tempdbsent582.suffix         = 'das auf einen Keilrahmen auf oder in einen Tragerahmen gespannt ist.'
tempdbsent582.feeling        = 'normal'
tempdbsent582.category       = 'normal'
tempdbsent582.priority       = 50
tempdbsent582.all_ohne_muell = 'Eine Leinwand ist Gewebe aus Leinen einen Keilrahmen einen Tragerahmen gespannt ist'
db.append(tempdbsent582)


tempdbsent583 = DBSentence()
tempdbsent583.subject        = 'Die Vorgeschichte oder Urgeschichte bezeichnet die schriftlose Phase'
tempdbsent583.verb           = 'der'
tempdbsent583.object         = 'Menschheitsgeschichte vom Auftreten'
tempdbsent583.prefix         = ''
tempdbsent583.suffix         = ''
tempdbsent583.feeling        = 'normal'
tempdbsent583.category       = 'normal'
tempdbsent583.priority       = 50
tempdbsent583.all_ohne_muell = 'Die Vorgeschichte Urgeschichte bezeichnet schriftlose Phase Menschheitsgeschichte Auftreten'
db.append(tempdbsent583)


tempdbsent584 = DBSentence()
tempdbsent584.subject        = 'Die Menschheitsgeschichte umfasst'
tempdbsent584.verb           = 'einen'
tempdbsent584.object         = 'Zeitraum von mehreren Millionen Jahren.'
tempdbsent584.prefix         = ''
tempdbsent584.suffix         = ''
tempdbsent584.feeling        = 'normal'
tempdbsent584.category       = 'normal'
tempdbsent584.priority       = 50
tempdbsent584.all_ohne_muell = 'Die Menschheitsgeschichte umfasst einen Zeitraum mehreren Millionen Jahren'
db.append(tempdbsent584)


tempdbsent585 = DBSentence()
tempdbsent585.subject        = 'Millionen'
tempdbsent585.verb           = 'ist'
tempdbsent585.object         = 'ein Jugendbuch des englischen Autoren Frank Cottrell Boyce'
tempdbsent585.prefix         = ''
tempdbsent585.suffix         = 'das dieser 2004 veroeffentlichte.'
tempdbsent585.feeling        = 'normal'
tempdbsent585.category       = 'normal'
tempdbsent585.priority       = 50
tempdbsent585.all_ohne_muell = 'Millionen ist Jugendbuch englischen Autoren Frank Cottrell Boyce dieser 2004 veroeffentlichte'
db.append(tempdbsent585)


tempdbsent586 = DBSentence()
tempdbsent586.subject        = 'Information'
tempdbsent586.verb           = 'ist'
tempdbsent586.object         = 'ein potenziell oder tatsaechlich vorhandenes nutzbares oder genutztes Muster von Materie und/oder Energieformen'
tempdbsent586.prefix         = ''
tempdbsent586.suffix         = 'das fuer einen Betrachter innerhalb eines bestimmten Kontextes relevant ist.'
tempdbsent586.feeling        = 'normal'
tempdbsent586.category       = 'normal'
tempdbsent586.priority       = 50
tempdbsent586.all_ohne_muell = 'Information ist potenziell tatsaechlich vorhandenes nutzbares genutztes Muster Materie / Energieformen einen Betrachter innerhalb bestimmten Kontextes relevant ist'
db.append(tempdbsent586)


tempdbsent587 = DBSentence()
tempdbsent587.subject        = 'Anna'
tempdbsent587.verb           = 'ist'
tempdbsent587.object         = 'ein weiblicher Vorname.'
tempdbsent587.prefix         = ''
tempdbsent587.suffix         = ''
tempdbsent587.feeling        = 'normal'
tempdbsent587.category       = 'normal'
tempdbsent587.priority       = 50
tempdbsent587.all_ohne_muell = 'Anna ist weiblicher Vorname'
db.append(tempdbsent587)


tempdbsent588 = DBSentence()
tempdbsent588.subject        = 'Wissenschaft besteht'
tempdbsent588.verb           = 'aus'
tempdbsent588.object         = 'Forschung und Lehre.'
tempdbsent588.prefix         = ''
tempdbsent588.suffix         = ''
tempdbsent588.feeling        = 'normal'
tempdbsent588.category       = 'normal'
tempdbsent588.priority       = 50
tempdbsent588.all_ohne_muell = 'Wissenschaft besteht aus Forschung Lehre'
db.append(tempdbsent588)


tempdbsent589 = DBSentence()
tempdbsent589.subject        = 'TAGS'
tempdbsent589.verb           = 'ist'
tempdbsent589.object         = 'ein CD/DVDKopierschutz'
tempdbsent589.prefix         = ''
tempdbsent589.suffix         = 'der hauptsaechlich in der Spielebranche genutzt wird.'
tempdbsent589.feeling        = 'normal'
tempdbsent589.category       = 'normal'
tempdbsent589.priority       = 50
tempdbsent589.all_ohne_muell = 'TAGS ist CD / DVDKopierschutz hauptsaechlich Spielebranche genutzt wird'
db.append(tempdbsent589)


tempdbsent590 = DBSentence()
tempdbsent590.subject        = 'auch Zeitabschnitt, Zeitspanne oder Zeitintervall,'
tempdbsent590.verb           = 'ist'
tempdbsent590.object         = 'ein  mehr oder weniger ausgedehnter'
tempdbsent590.prefix         = 'Ein Zeitraum'
tempdbsent590.suffix         = 'vom Wechsel der Ereignisse und Eindruecke, vom Verlauf der Geschehnisse erfuellter  Teil der Zeit.'
tempdbsent590.feeling        = 'normal'
tempdbsent590.category       = 'normal'
tempdbsent590.priority       = 50
tempdbsent590.all_ohne_muell = 'Ein Zeitraum auch Zeitabschnitt Zeitspanne Zeitintervall ist mehr weniger ausgedehnter Wechsel Ereignisse Eindruecke Verlauf Geschehnisse erfuellter Teil Zeit'
db.append(tempdbsent590)


tempdbsent591 = DBSentence()
tempdbsent591.subject        = 'Ein Apparat'
tempdbsent591.verb           = 'ist'
tempdbsent591.object         = 'eine Bezeichnung'
tempdbsent591.prefix         = ''
tempdbsent591.suffix         = 'die in verschiedenen Fachgebieten unterschiedlich interpretiert wird.'
tempdbsent591.feeling        = 'normal'
tempdbsent591.category       = 'normal'
tempdbsent591.priority       = 50
tempdbsent591.all_ohne_muell = 'Ein Apparat ist Bezeichnung verschiedenen Fachgebieten unterschiedlich interpretiert wird'
db.append(tempdbsent591)


tempdbsent592 = DBSentence()
tempdbsent592.subject        = 'Information'
tempdbsent592.verb           = 'ist'
tempdbsent592.object         = 'ein potenziell oder tatsaechlich vorhandenes nutzbares oder genutztes Muster von Materie und/oder Energieformen'
tempdbsent592.prefix         = ''
tempdbsent592.suffix         = 'das fuer einen Betrachter innerhalb eines bestimmten Kontextes relevant ist.'
tempdbsent592.feeling        = 'normal'
tempdbsent592.category       = 'normal'
tempdbsent592.priority       = 50
tempdbsent592.all_ohne_muell = 'Information ist potenziell tatsaechlich vorhandenes nutzbares genutztes Muster Materie / Energieformen einen Betrachter innerhalb bestimmten Kontextes relevant ist'
db.append(tempdbsent592)


tempdbsent593 = DBSentence()
tempdbsent593.subject        = 'Die vier Unter'
tempdbsent593.verb           = 'eines'
tempdbsent593.object         = 'deutschen Blatts .'
tempdbsent593.prefix         = ''
tempdbsent593.suffix         = ''
tempdbsent593.feeling        = 'normal'
tempdbsent593.category       = 'normal'
tempdbsent593.priority       = 50
tempdbsent593.all_ohne_muell = 'Die vier Unter deutschen Blatts'
db.append(tempdbsent593)


tempdbsent594 = DBSentence()
tempdbsent594.subject        = 'Begriff'
tempdbsent594.verb           = 'ist'
tempdbsent594.object         = 'eine Zusammenstellung von Merkmalen'
tempdbsent594.prefix         = ''
tempdbsent594.suffix         = 'die in Gegenstaenden oder Sachverhalten als deren Eigenschaften erscheinen.'
tempdbsent594.feeling        = 'normal'
tempdbsent594.category       = 'normal'
tempdbsent594.priority       = 50
tempdbsent594.all_ohne_muell = 'Begriff ist Zusammenstellung Merkmalen Gegenstaenden Sachverhalten als deren Eigenschaften erscheinen'
db.append(tempdbsent594)


tempdbsent595 = DBSentence()
tempdbsent595.subject        = 'Es existiert'
tempdbsent595.verb           = 'keine'
tempdbsent595.object         = 'einheitliche Definition des Begriffs Erkenntnis.'
tempdbsent595.prefix         = ''
tempdbsent595.suffix         = ''
tempdbsent595.feeling        = 'normal'
tempdbsent595.category       = 'normal'
tempdbsent595.priority       = 50
tempdbsent595.all_ohne_muell = 'Es existiert keine einheitliche Definition Begriffs Erkenntnis'
db.append(tempdbsent595)


tempdbsent596 = DBSentence()
tempdbsent596.subject        = 'Die Legislative'
tempdbsent596.verb           = 'ist'
tempdbsent596.object         = 'in der Staatstheorie neben Exekutive und Judikative eine der drei unabhaengigen Gewalten .'
tempdbsent596.prefix         = ''
tempdbsent596.suffix         = ''
tempdbsent596.feeling        = 'normal'
tempdbsent596.category       = 'normal'
tempdbsent596.priority       = 50
tempdbsent596.all_ohne_muell = 'Die Legislative ist Staatstheorie Exekutive Judikative drei unabhaengigen Gewalten'
db.append(tempdbsent596)


tempdbsent597 = DBSentence()
tempdbsent597.subject        = 'Die Exekutive'
tempdbsent597.verb           = 'ist'
tempdbsent597.object         = 'in der Staatstheorie neben Legislative und Judikative eine der drei unabhaengigen Gewalten .'
tempdbsent597.prefix         = ''
tempdbsent597.suffix         = ''
tempdbsent597.feeling        = 'normal'
tempdbsent597.category       = 'normal'
tempdbsent597.priority       = 50
tempdbsent597.all_ohne_muell = 'Die Exekutive ist Staatstheorie Legislative Judikative drei unabhaengigen Gewalten'
db.append(tempdbsent597)


tempdbsent598 = DBSentence()
tempdbsent598.subject        = ''
tempdbsent598.verb           = ''
tempdbsent598.object         = ''
tempdbsent598.prefix         = 'Der Begriff Ausdruck bedeutet ein Sichtbar oder Hoerbarmachen eines inneren Vorgangs'
tempdbsent598.suffix         = 'eines Gedankens oder einer Vorstellung sprachlicher oder kuenstlerischer Natur oder den Druck von Texten und Grafiken.'
tempdbsent598.feeling        = 'normal'
tempdbsent598.category       = 'normal'
tempdbsent598.priority       = 50
tempdbsent598.all_ohne_muell = 'Der Begriff Ausdruck bedeutet Sichtbar Hoerbarmachen inneren Vorgangs Gedankens Vorstellung sprachlicher kuenstlerischer Natur den Druck Texten Grafiken'
db.append(tempdbsent598)


tempdbsent599 = DBSentence()
tempdbsent599.subject        = 'Erkennung bezeichnet'
tempdbsent599.verb           = 'einen'
tempdbsent599.object         = 'kognitiven Prozess der Abstraktion'
tempdbsent599.prefix         = ''
tempdbsent599.suffix         = 'bei dem eine Wahrnehmung einem Begriff oder Konzept zugeordnet wird.'
tempdbsent599.feeling        = 'normal'
tempdbsent599.category       = 'normal'
tempdbsent599.priority       = 50
tempdbsent599.all_ohne_muell = 'Erkennung bezeichnet einen kognitiven Prozess Abstraktion bei Wahrnehmung Begriff Konzept zugeordnet wird'
db.append(tempdbsent599)


tempdbsent600 = DBSentence()
tempdbsent600.subject        = 'Suchen'
tempdbsent600.verb           = 'ist'
tempdbsent600.object         = 'die Taetigkeit oder der Versuch'
tempdbsent600.prefix         = ''
tempdbsent600.suffix         = 'ein Ding nach bestimmten Kriterien zu finden.'
tempdbsent600.feeling        = 'normal'
tempdbsent600.category       = 'normal'
tempdbsent600.priority       = 50
tempdbsent600.all_ohne_muell = 'Suchen ist Taetigkeit Versuch Ding nach bestimmten Kriterien zu finden'
db.append(tempdbsent600)


tempdbsent601 = DBSentence()
tempdbsent601.subject        = 'In der Kommunikationswissenschaft'
tempdbsent601.verb           = 'gilt'
tempdbsent601.object         = 'als Rezipient der Empfaenger in einem Kommunikationsprozess.'
tempdbsent601.prefix         = ''
tempdbsent601.suffix         = ''
tempdbsent601.feeling        = 'normal'
tempdbsent601.category       = 'normal'
tempdbsent601.priority       = 50
tempdbsent601.all_ohne_muell = 'In Kommunikationswissenschaft gilt als Rezipient Empfaenger Kommunikationsprozess'
db.append(tempdbsent601)


tempdbsent602 = DBSentence()
tempdbsent602.subject        = 'Tutanchamun im Kampf'
tempdbsent602.verb           = 'gegen'
tempdbsent602.object         = 'die Asiaten Truhe aus dem Tal der Koenige'
tempdbsent602.prefix         = ''
tempdbsent602.suffix         = 'gemalt um 1355 v.'
tempdbsent602.feeling        = 'normal'
tempdbsent602.category       = 'normal'
tempdbsent602.priority       = 50
tempdbsent602.all_ohne_muell = 'Tutanchamun im Kampf gegen Asiaten Truhe aus Tal Koenige gemalt um 1355 v'
db.append(tempdbsent602)


tempdbsent603 = DBSentence()
tempdbsent603.subject        = 'der akustische Schwingungen im ueblichen Medium Luft in'
tempdbsent603.verb           = 'entsprechende'
tempdbsent603.object         = 'elektrische SpannungsSignale wandelt.'
tempdbsent603.prefix         = 'Als Mikrofon bezeichnet man einen Sensor im Schallfeld'
tempdbsent603.suffix         = ''
tempdbsent603.feeling        = 'normal'
tempdbsent603.category       = 'normal'
tempdbsent603.priority       = 50
tempdbsent603.all_ohne_muell = 'Als Mikrofon bezeichnet man einen Sensor im Schallfeld akustische Schwingungen im ueblichen Medium Luft entsprechende elektrische SpannungsSignale wandelt'
db.append(tempdbsent603)


tempdbsent604 = DBSentence()
tempdbsent604.subject        = 'Aufnehmer oder Fuehler'
tempdbsent604.verb           = 'ist'
tempdbsent604.object         = 'ein technisches Bauteil'
tempdbsent604.prefix         = 'Ein Sensor'
tempdbsent604.suffix         = 'das bestimmte physikalische oder chemische Eigenschaften und/oder die stoffliche Beschaffenheit seiner Umgebung qualitativ oder als Messgroesse quantitativ erfassen kann.'
tempdbsent604.feeling        = 'normal'
tempdbsent604.category       = 'normal'
tempdbsent604.priority       = 50
tempdbsent604.all_ohne_muell = 'Ein Sensor Aufnehmer Fuehler ist technisches Bauteil bestimmte physikalische chemische Eigenschaften / stoffliche Beschaffenheit seiner Umgebung qualitativ als Messgroesse quantitativ erfassen kann'
db.append(tempdbsent604)


tempdbsent605 = DBSentence()
tempdbsent605.subject        = 'Ein Schallfeld'
tempdbsent605.verb           = 'ist'
tempdbsent605.object         = 'das Gebiet in einem elastischen Medium'
tempdbsent605.prefix         = ''
tempdbsent605.suffix         = 'in dem sich Schallwellen ausbreiten.'
tempdbsent605.feeling        = 'normal'
tempdbsent605.category       = 'normal'
tempdbsent605.priority       = 50
tempdbsent605.all_ohne_muell = 'Ein Schallfeld ist Gebiet elastischen Medium sich Schallwellen ausbreiten'
db.append(tempdbsent605)


tempdbsent606 = DBSentence()
tempdbsent606.subject        = 'Schwingungen Radio auf CD'
tempdbsent606.verb           = 'ist'
tempdbsent606.object         = 'der Titel monatlich erscheinender CDs'
tempdbsent606.prefix         = ''
tempdbsent606.suffix         = 'die sich ausschliesslich mit elektronischer Musik beschaeftigen.'
tempdbsent606.feeling        = 'normal'
tempdbsent606.category       = 'normal'
tempdbsent606.priority       = 50
tempdbsent606.all_ohne_muell = 'Schwingungen Radio CD ist Titel monatlich erscheinender CDs sich ausschliesslich mit elektronischer Musik beschaeftigen'
db.append(tempdbsent606)


tempdbsent607 = DBSentence()
tempdbsent607.subject        = 'Als Luft bezeichnet man'
tempdbsent607.verb           = 'das'
tempdbsent607.object         = 'Gasgemisch der Erdatmosphaere.'
tempdbsent607.prefix         = ''
tempdbsent607.suffix         = ''
tempdbsent607.feeling        = 'normal'
tempdbsent607.category       = 'normal'
tempdbsent607.priority       = 50
tempdbsent607.all_ohne_muell = 'Als Luft bezeichnet man Gasgemisch Erdatmosphaere'
db.append(tempdbsent607)


tempdbsent608 = DBSentence()
tempdbsent608.subject        = 'Als Ohrmuschel'
tempdbsent608.verb           = 'wird'
tempdbsent608.object         = 'der aussen liegende Teil des Ohres bezeichnet.'
tempdbsent608.prefix         = ''
tempdbsent608.suffix         = ''
tempdbsent608.feeling        = 'normal'
tempdbsent608.category       = 'normal'
tempdbsent608.priority       = 50
tempdbsent608.all_ohne_muell = 'Als Ohrmuschel wird aussen liegende Teil Ohres bezeichnet'
db.append(tempdbsent608)


tempdbsent609 = DBSentence()
tempdbsent609.subject        = 'Der Begriff Signal'
tempdbsent609.verb           = 'ist'
tempdbsent609.object         = 'ein optisches oder akustisches Zeichen mit einer bestimmten Bedeutung.'
tempdbsent609.prefix         = ''
tempdbsent609.suffix         = ''
tempdbsent609.feeling        = 'normal'
tempdbsent609.category       = 'normal'
tempdbsent609.priority       = 50
tempdbsent609.all_ohne_muell = 'Der Begriff Signal ist optisches akustisches Zeichen mit bestimmten Bedeutung'
db.append(tempdbsent609)


tempdbsent610 = DBSentence()
tempdbsent610.subject        = 'Planung'
tempdbsent610.verb           = 'ist'
tempdbsent610.object         = 'ein soweit als moeglich systematischer Prozess ein Planungsprozess zur Festlegung von Zielen und kuenftigen Handlungen.'
tempdbsent610.prefix         = ''
tempdbsent610.suffix         = ''
tempdbsent610.feeling        = 'normal'
tempdbsent610.category       = 'normal'
tempdbsent610.priority       = 50
tempdbsent610.all_ohne_muell = 'Planung ist soweit als moeglich systematischer Prozess Planungsprozess zur Festlegung Zielen kuenftigen Handlungen'
db.append(tempdbsent610)


tempdbsent611 = DBSentence()
tempdbsent611.subject        = 'Das Spiel'
tempdbsent611.verb           = 'ist'
tempdbsent611.object         = 'eine Taetigkeit'
tempdbsent611.prefix         = ''
tempdbsent611.suffix         = 'die ohne bewussten Zweck zum Vergnuegen, zur Entspannung, allein aus Freude an ihrer Ausuebung ausgefuehrt wird.'
tempdbsent611.feeling        = 'normal'
tempdbsent611.category       = 'normal'
tempdbsent611.priority       = 50
tempdbsent611.all_ohne_muell = 'Das Spiel ist Taetigkeit ohne bewussten Zweck zum Vergnuegen zur Entspannung allein aus Freude an ihrer Ausuebung ausgefuehrt wird'
db.append(tempdbsent611)


tempdbsent612 = DBSentence()
tempdbsent612.subject        = 'Als Zweck'
tempdbsent612.verb           = 'wird'
tempdbsent612.object         = 'der Beweggrund einer zielgerichteten Taetigkeit oder eines Verhaltens verstanden.'
tempdbsent612.prefix         = ''
tempdbsent612.suffix         = ''
tempdbsent612.feeling        = 'normal'
tempdbsent612.category       = 'normal'
tempdbsent612.priority       = 50
tempdbsent612.all_ohne_muell = 'Als Zweck wird Beweggrund zielgerichteten Taetigkeit Verhaltens verstanden'
db.append(tempdbsent612)


tempdbsent613 = DBSentence()
tempdbsent613.subject        = 'Lachen'
tempdbsent613.verb           = 'ist'
tempdbsent613.object         = 'die haeufigste Aeusserung von Freude .'
tempdbsent613.prefix         = ''
tempdbsent613.suffix         = ''
tempdbsent613.feeling        = 'normal'
tempdbsent613.category       = 'normal'
tempdbsent613.priority       = 50
tempdbsent613.all_ohne_muell = 'Lachen ist haeufigste Aeusserung Freude'
db.append(tempdbsent613)


tempdbsent614 = DBSentence()
tempdbsent614.subject        = 'Die RAND Corporation'
tempdbsent614.verb           = 'ist'
tempdbsent614.object         = 'eine Denkfabrik in den USA'
tempdbsent614.prefix         = ''
tempdbsent614.suffix         = 'die nach Ende des Zweiten Weltkriegs gegruendet wurde, um die Streitkraefte der USA zu beraten.'
tempdbsent614.feeling        = 'normal'
tempdbsent614.category       = 'normal'
tempdbsent614.priority       = 50
tempdbsent614.all_ohne_muell = 'Die RAND Corporation ist Denkfabrik den USA nach Ende Zweiten Weltkriegs gegruendet wurde um Streitkraefte USA zu beraten'
db.append(tempdbsent614)


tempdbsent615 = DBSentence()
tempdbsent615.subject        = 'Steuererklaerungen und Antraege'
tempdbsent615.verb           = 'fuer'
tempdbsent615.object         = 'deutsche Finanzbehoerden .'
tempdbsent615.prefix         = ''
tempdbsent615.suffix         = ''
tempdbsent615.feeling        = 'normal'
tempdbsent615.category       = 'normal'
tempdbsent615.priority       = 50
tempdbsent615.all_ohne_muell = 'Steuererklaerungen Antraege deutsche Finanzbehoerden'
db.append(tempdbsent615)


tempdbsent616 = DBSentence()
tempdbsent616.subject        = 'Das Chaos'
tempdbsent616.verb           = 'ist'
tempdbsent616.object         = 'ein Zustand vollstaendiger Unordnung oder Verwirrung und damit der Gegenbegriff zu Kosmos'
tempdbsent616.prefix         = ''
tempdbsent616.suffix         = 'dem griechischen Begriff fuer Ordnung.'
tempdbsent616.feeling        = 'normal'
tempdbsent616.category       = 'normal'
tempdbsent616.priority       = 50
tempdbsent616.all_ohne_muell = 'Das Chaos ist Zustand vollstaendiger Unordnung Verwirrung damit Gegenbegriff zu Kosmos griechischen Begriff Ordnung'
db.append(tempdbsent616)


tempdbsent617 = DBSentence()
tempdbsent617.subject        = 'Ungewissheit'
tempdbsent617.verb           = 'ist'
tempdbsent617.object         = 'ein bewusst wahrgenommener Mangel an Wissen.'
tempdbsent617.prefix         = ''
tempdbsent617.suffix         = ''
tempdbsent617.feeling        = 'normal'
tempdbsent617.category       = 'normal'
tempdbsent617.priority       = 50
tempdbsent617.all_ohne_muell = 'Ungewissheit ist bewusst wahrgenommener Mangel an Wissen'
db.append(tempdbsent617)


tempdbsent618 = DBSentence()
tempdbsent618.subject        = 'Ganz allgemein'
tempdbsent618.verb           = 'wird'
tempdbsent618.object         = 'als Anspannung die Konfiguration eines Gespannes aus Zugtieren bezeichnet.'
tempdbsent618.prefix         = ''
tempdbsent618.suffix         = ''
tempdbsent618.feeling        = 'normal'
tempdbsent618.category       = 'normal'
tempdbsent618.priority       = 50
tempdbsent618.all_ohne_muell = 'Ganz allgemein wird als Anspannung Konfiguration Gespannes aus Zugtieren bezeichnet'
db.append(tempdbsent618)


tempdbsent619 = DBSentence()
tempdbsent619.subject        = 'Bedrohung'
tempdbsent619.verb           = 'ist'
tempdbsent619.object         = 'ein Straftatbestand'
tempdbsent619.prefix         = ''
tempdbsent619.suffix         = 'der im deutschen Strafgesetzbuch in &amp;nbsp;241 StGB geregelt ist.'
tempdbsent619.feeling        = 'normal'
tempdbsent619.category       = 'normal'
tempdbsent619.priority       = 50
tempdbsent619.all_ohne_muell = 'Bedrohung ist Straftatbestand im deutschen Strafgesetzbuch &ampnbsp241 StGB geregelt ist'
db.append(tempdbsent619)


tempdbsent620 = DBSentence()
tempdbsent620.subject        = ''
tempdbsent620.verb           = ''
tempdbsent620.object         = ''
tempdbsent620.prefix         = 'Die groessten Unternehmen der Welt nach Umsatz'
tempdbsent620.suffix         = '2005 .'
tempdbsent620.feeling        = 'normal'
tempdbsent620.category       = 'normal'
tempdbsent620.priority       = 50
tempdbsent620.all_ohne_muell = 'Die groessten Unternehmen Welt nach Umsatz 2005'
db.append(tempdbsent620)


tempdbsent621 = DBSentence()
tempdbsent621.subject        = 'Als Volkswirtschaft'
tempdbsent621.verb           = 'wird'
tempdbsent621.object         = 'die Gesamtheit aller in einem Wirtschaftsraum verbundenen und gegenseitig abhaengigen Akteure bezeichnet.'
tempdbsent621.prefix         = ''
tempdbsent621.suffix         = ''
tempdbsent621.feeling        = 'normal'
tempdbsent621.category       = 'normal'
tempdbsent621.priority       = 50
tempdbsent621.all_ohne_muell = 'Als Volkswirtschaft wird Gesamtheit aller Wirtschaftsraum verbundenen gegenseitig abhaengigen Akteure bezeichnet'
db.append(tempdbsent621)


tempdbsent622 = DBSentence()
tempdbsent622.subject        = 'Als Politiker'
tempdbsent622.verb           = 'wird'
tempdbsent622.object         = 'eine Person bezeichnet'
tempdbsent622.prefix         = ''
tempdbsent622.suffix         = 'die ein politisches Amt oder ein politisches Mandat innehat.'
tempdbsent622.feeling        = 'normal'
tempdbsent622.category       = 'normal'
tempdbsent622.priority       = 50
tempdbsent622.all_ohne_muell = 'Als Politiker wird Person bezeichnet politisches Amt politisches Mandat innehat'
db.append(tempdbsent622)


tempdbsent623 = DBSentence()
tempdbsent623.subject        = 'Die Musikwissenschaft'
tempdbsent623.verb           = 'ist'
tempdbsent623.object         = 'die Bezeichnung fuer die wissenschaftliche Disziplin'
tempdbsent623.prefix         = ''
tempdbsent623.suffix         = 'deren Inhalt die vor allem theoretische Beschaeftigung mit Musik ist, d.'
tempdbsent623.feeling        = 'normal'
tempdbsent623.category       = 'normal'
tempdbsent623.priority       = 50
tempdbsent623.all_ohne_muell = 'Die Musikwissenschaft ist Bezeichnung wissenschaftliche Disziplin deren Inhalt vor allem theoretische Beschaeftigung mit Musik ist d'
db.append(tempdbsent623)


tempdbsent624 = DBSentence()
tempdbsent624.subject        = 'Randers'
tempdbsent624.verb           = 'ist'
tempdbsent624.object         = 'eine Hafenstadt auf Juetland in der daenischen etwa 40 km noerdlich der Amtskommune rhus.'
tempdbsent624.prefix         = ''
tempdbsent624.suffix         = ''
tempdbsent624.feeling        = 'normal'
tempdbsent624.category       = 'normal'
tempdbsent624.priority       = 50
tempdbsent624.all_ohne_muell = 'Randers ist Hafenstadt Juetland daenischen etwa 40 km noerdlich Amtskommune rhus'
db.append(tempdbsent624)


tempdbsent625 = DBSentence()
tempdbsent625.subject        = 'Einsatzfahrzeuge'
tempdbsent625.verb           = 'sind'
tempdbsent625.object         = 'Kraftfahrzeuge'
tempdbsent625.prefix         = ''
tempdbsent625.suffix         = 'die als Rettungswagen Einsatzfahrzeuge sind.'
tempdbsent625.feeling        = 'normal'
tempdbsent625.category       = 'normal'
tempdbsent625.priority       = 50
tempdbsent625.all_ohne_muell = 'Einsatzfahrzeuge sind Kraftfahrzeuge als Rettungswagen Einsatzfahrzeuge sind'
db.append(tempdbsent625)


tempdbsent626 = DBSentence()
tempdbsent626.subject        = 'politische Gemeinde'
tempdbsent626.verb           = 'oder'
tempdbsent626.object         = 'Kommune bezeichnet man diejenigen Gebietskoerperschaften'
tempdbsent626.prefix         = 'Als Gemeinde'
tempdbsent626.suffix         = 'die im oeffentlichverwaltungsmaessigen Aufbau von Staaten die kleinste raeumlichadministrative, also politischgeographische Entitaet, darstellen.'
tempdbsent626.feeling        = 'normal'
tempdbsent626.category       = 'normal'
tempdbsent626.priority       = 50
tempdbsent626.all_ohne_muell = 'Als Gemeinde politische Gemeinde Kommune bezeichnet man diejenigen Gebietskoerperschaften im oeffentlichverwaltungsmaessigen Aufbau Staaten kleinste raeumlichadministrative also politischgeographische Entitaet darstellen'
db.append(tempdbsent626)


tempdbsent627 = DBSentence()
tempdbsent627.subject        = 'Ein Kreis oder Landkreis'
tempdbsent627.verb           = 'ist'
tempdbsent627.object         = 'nach deutschem Kommunalrecht ein Gemeindeverband und eine Gebietskoerperschaft.'
tempdbsent627.prefix         = ''
tempdbsent627.suffix         = ''
tempdbsent627.feeling        = 'normal'
tempdbsent627.category       = 'normal'
tempdbsent627.priority       = 50
tempdbsent627.all_ohne_muell = 'Ein Kreis Landkreis ist nach deutschem Kommunalrecht Gemeindeverband Gebietskoerperschaft'
db.append(tempdbsent627)


tempdbsent628 = DBSentence()
tempdbsent628.subject        = 'Niedersachsen liegt'
tempdbsent628.verb           = 'in'
tempdbsent628.object         = 'Nordwestdeutschland im niederdeutschen Sprachraum.'
tempdbsent628.prefix         = ''
tempdbsent628.suffix         = ''
tempdbsent628.feeling        = 'normal'
tempdbsent628.category       = 'normal'
tempdbsent628.priority       = 50
tempdbsent628.all_ohne_muell = 'Niedersachsen liegt Nordwestdeutschland im niederdeutschen Sprachraum'
db.append(tempdbsent628)


tempdbsent629 = DBSentence()
tempdbsent629.subject        = 'Der Terminus Symbol'
tempdbsent629.verb           = 'wird'
tempdbsent629.object         = 'im Allgemeinen fuer Bedeutungstraeger verwendet'
tempdbsent629.prefix         = ''
tempdbsent629.suffix         = 'die eine Vorstellung meinen .'
tempdbsent629.feeling        = 'normal'
tempdbsent629.category       = 'normal'
tempdbsent629.priority       = 50
tempdbsent629.all_ohne_muell = 'Der Terminus Symbol wird im Allgemeinen Bedeutungstraeger verwendet Vorstellung meinen'
db.append(tempdbsent629)


tempdbsent630 = DBSentence()
tempdbsent630.subject        = 'Indien'
tempdbsent630.verb           = 'ist'
tempdbsent630.object         = 'ein Staat in Suedasien'
tempdbsent630.prefix         = ''
tempdbsent630.suffix         = 'der den groessten Teil des indischen Subkontinents umfasst.'
tempdbsent630.feeling        = 'normal'
tempdbsent630.category       = 'normal'
tempdbsent630.priority       = 50
tempdbsent630.all_ohne_muell = 'Indien ist Staat Suedasien den groessten Teil indischen Subkontinents umfasst'
db.append(tempdbsent630)


tempdbsent631 = DBSentence()
tempdbsent631.subject        = 'die'
tempdbsent631.verb           = 'ein'
tempdbsent631.object         = 'gemeinsames als Staatsgebiet abgegrenztes Territorium'
tempdbsent631.prefix         = 'Als Staat bezeichnet man seit der europaeischen Neuzeit jede politische Ordnung'
tempdbsent631.suffix         = ''
tempdbsent631.feeling        = 'normal'
tempdbsent631.category       = 'normal'
tempdbsent631.priority       = 50
tempdbsent631.all_ohne_muell = 'Als Staat bezeichnet man seit europaeischen Neuzeit jede politische Ordnung gemeinsames als Staatsgebiet abgegrenztes Territorium'
db.append(tempdbsent631)


tempdbsent632 = DBSentence()
tempdbsent632.subject        = ''
tempdbsent632.verb           = ''
tempdbsent632.object         = ''
tempdbsent632.prefix         = 'Der Begriff Verwandte bezeichnet in der Regel Lebewesen einer gemeinsamen genetischen Herkunft innerhalb einer Art.'
tempdbsent632.suffix         = ''
tempdbsent632.feeling        = 'normal'
tempdbsent632.category       = 'normal'
tempdbsent632.priority       = 50
tempdbsent632.all_ohne_muell = 'Der Begriff Verwandte bezeichnet Regel Lebewesen gemeinsamen genetischen Herkunft innerhalb Art'
db.append(tempdbsent632)


tempdbsent633 = DBSentence()
tempdbsent633.subject        = 'Die Bundestagswahl'
tempdbsent633.verb           = 'dient'
tempdbsent633.object         = 'der Bestimmung der Abgeordneten des Deutschen Bundestages.'
tempdbsent633.prefix         = ''
tempdbsent633.suffix         = ''
tempdbsent633.feeling        = 'normal'
tempdbsent633.category       = 'normal'
tempdbsent633.priority       = 50
tempdbsent633.all_ohne_muell = 'Die Bundestagswahl dient Bestimmung Abgeordneten Deutschen Bundestages'
db.append(tempdbsent633)


tempdbsent634 = DBSentence()
tempdbsent634.subject        = 'Ein Feldzug im militaerischen Sinn'
tempdbsent634.verb           = 'ist'
tempdbsent634.object         = 'eine gross angelegte Unternehmung mehrerer Operationen zum Erreichen eines groesseren Zieles waehrend eines Krieges.'
tempdbsent634.prefix         = ''
tempdbsent634.suffix         = ''
tempdbsent634.feeling        = 'normal'
tempdbsent634.category       = 'normal'
tempdbsent634.priority       = 50
tempdbsent634.all_ohne_muell = 'Ein Feldzug im militaerischen Sinn ist gross angelegte Unternehmung mehrerer Operationen zum Erreichen groesseren Zieles waehrend Krieges'
db.append(tempdbsent634)


tempdbsent635 = DBSentence()
tempdbsent635.subject        = 'Landschaftsverband'
tempdbsent635.verb           = 'ist'
tempdbsent635.object         = 'eine Form eines kommunalen Zusammenschlusses in NordrheinWestfalen und Niedersachsen.'
tempdbsent635.prefix         = ''
tempdbsent635.suffix         = ''
tempdbsent635.feeling        = 'normal'
tempdbsent635.category       = 'normal'
tempdbsent635.priority       = 50
tempdbsent635.all_ohne_muell = 'Landschaftsverband ist Form kommunalen Zusammenschlusses NordrheinWestfalen Niedersachsen'
db.append(tempdbsent635)


tempdbsent636 = DBSentence()
tempdbsent636.subject        = 'Als Wachstum bezeichnet man den zeitlichen Anstieg einer'
tempdbsent636.verb           = 'bestimmten'
tempdbsent636.object         = 'Messgroesse.'
tempdbsent636.prefix         = ''
tempdbsent636.suffix         = ''
tempdbsent636.feeling        = 'normal'
tempdbsent636.category       = 'normal'
tempdbsent636.priority       = 50
tempdbsent636.all_ohne_muell = 'Als Wachstum bezeichnet man den zeitlichen Anstieg bestimmten Messgroesse'
db.append(tempdbsent636)


tempdbsent637 = DBSentence()
tempdbsent637.subject        = 'Wissen'
tempdbsent637.verb           = 'ist'
tempdbsent637.object         = 'Information'
tempdbsent637.prefix         = ''
tempdbsent637.suffix         = 'derer sich eine Person, Organisation oder eine andere Gruppierung gegenwaertig ist.'
tempdbsent637.feeling        = 'normal'
tempdbsent637.category       = 'normal'
tempdbsent637.priority       = 50
tempdbsent637.all_ohne_muell = 'Wissen ist Information derer sich Person Organisation andere Gruppierung gegenwaertig ist'
db.append(tempdbsent637)


tempdbsent638 = DBSentence()
tempdbsent638.subject        = 'Ein Geheimnis'
tempdbsent638.verb           = 'ist'
tempdbsent638.object         = 'eine Information oder ein Soziales Handeln'
tempdbsent638.prefix         = ''
tempdbsent638.suffix         = 'deren Kenntnis unter wenigen Geheimnistraegern bleibt, die der Geheimhaltung unterliegen.'
tempdbsent638.feeling        = 'normal'
tempdbsent638.category       = 'normal'
tempdbsent638.priority       = 50
tempdbsent638.all_ohne_muell = 'Ein Geheimnis ist Information Soziales Handeln deren Kenntnis wenigen Geheimnistraegern bleibt Geheimhaltung unterliegen'
db.append(tempdbsent638)


tempdbsent639 = DBSentence()
tempdbsent639.subject        = 'Prestige bezeichnet den Ruf'
tempdbsent639.verb           = 'einer'
tempdbsent639.object         = 'Person'
tempdbsent639.prefix         = ''
tempdbsent639.suffix         = 'Gruppe, eines Ortes oder'
tempdbsent639.feeling        = 'normal'
tempdbsent639.category       = 'normal'
tempdbsent639.priority       = 50
tempdbsent639.all_ohne_muell = 'Prestige bezeichnet den Ruf Person Gruppe Ortes'
db.append(tempdbsent639)


tempdbsent640 = DBSentence()
tempdbsent640.subject        = ''
tempdbsent640.verb           = ''
tempdbsent640.object         = ''
tempdbsent640.prefix         = 'Unter Gemeinschaft versteht man die zu einer Einheit zusammengefassten Individuen'
tempdbsent640.suffix         = 'wenn die Gruppe emotionale Bindekraefte aufweist und ein Zusammengehoerigkeitsgefuehl vorhanden ist .'
tempdbsent640.feeling        = 'normal'
tempdbsent640.category       = 'normal'
tempdbsent640.priority       = 50
tempdbsent640.all_ohne_muell = 'Unter Gemeinschaft versteht man zu Einheit zusammengefassten Individuen wenn Gruppe emotionale Bindekraefte aufweist Zusammengehoerigkeitsgefuehl vorhanden ist'
db.append(tempdbsent640)


tempdbsent641 = DBSentence()
tempdbsent641.subject        = 'Erfolg, Ganzheit'
tempdbsent641.verb           = 'oder'
tempdbsent641.object         = 'Gesundheit'
tempdbsent641.prefix         = 'Heil drueckt Begnadung'
tempdbsent641.suffix         = ''
tempdbsent641.feeling        = 'normal'
tempdbsent641.category       = 'normal'
tempdbsent641.priority       = 50
tempdbsent641.all_ohne_muell = 'Heil drueckt Begnadung Erfolg Ganzheit Gesundheit'
db.append(tempdbsent641)


tempdbsent642 = DBSentence()
tempdbsent642.subject        = 'Erfolg'
tempdbsent642.verb           = 'ist'
tempdbsent642.object         = 'ein als positiv empfundenes Resultat eigenen Handelns.'
tempdbsent642.prefix         = ''
tempdbsent642.suffix         = ''
tempdbsent642.feeling        = 'normal'
tempdbsent642.category       = 'normal'
tempdbsent642.priority       = 50
tempdbsent642.all_ohne_muell = 'Erfolg ist als positiv empfundenes Resultat eigenen Handelns'
db.append(tempdbsent642)


tempdbsent643 = DBSentence()
tempdbsent643.subject        = 'Schrift dient'
tempdbsent643.verb           = 'der'
tempdbsent643.object         = 'Kommunikation und'
tempdbsent643.prefix         = ''
tempdbsent643.suffix         = ''
tempdbsent643.feeling        = 'normal'
tempdbsent643.category       = 'normal'
tempdbsent643.priority       = 50
tempdbsent643.all_ohne_muell = 'Schrift dient Kommunikation'
db.append(tempdbsent643)


tempdbsent644 = DBSentence()
tempdbsent644.subject        = 'Konservierung'
tempdbsent644.verb           = 'ist'
tempdbsent644.object         = 'die Haltbarmachung von Gegenstaenden'
tempdbsent644.prefix         = ''
tempdbsent644.suffix         = 'insbesondere von organischen Substanzen mit Hilfe von Konservierungsmitteln und verfahren, fuer mehr oder weniger laengere Zeit.'
tempdbsent644.feeling        = 'normal'
tempdbsent644.category       = 'normal'
tempdbsent644.priority       = 50
tempdbsent644.all_ohne_muell = 'Konservierung ist Haltbarmachung Gegenstaenden insbesondere organischen Substanzen mit Hilfe Konservierungsmitteln verfahren mehr weniger laengere Zeit'
db.append(tempdbsent644)


tempdbsent645 = DBSentence()
tempdbsent645.subject        = 'Legende bezeichnet urspruenglich'
tempdbsent645.verb           = 'eine'
tempdbsent645.object         = 'Geschichte zum Lesen oder auch Vorlesen.'
tempdbsent645.prefix         = ''
tempdbsent645.suffix         = ''
tempdbsent645.feeling        = 'normal'
tempdbsent645.category       = 'normal'
tempdbsent645.priority       = 50
tempdbsent645.all_ohne_muell = 'Legende bezeichnet urspruenglich Geschichte zum Lesen auch Vorlesen'
db.append(tempdbsent645)


tempdbsent646 = DBSentence()
tempdbsent646.subject        = 'kurze Erzaehlung unwahrer, phantastischer Ereignisse, die aber als Wahrheitsbericht gemeint'
tempdbsent646.verb           = 'sind'
tempdbsent646.object         = 'oder auf einem wahren Kern beruhen.'
tempdbsent646.prefix         = 'Die Sage ist eine zunaechst auf muendliche Ueberlieferung basierende'
tempdbsent646.suffix         = ''
tempdbsent646.feeling        = 'normal'
tempdbsent646.category       = 'normal'
tempdbsent646.priority       = 50
tempdbsent646.all_ohne_muell = 'Die Sage ist zunaechst muendliche Ueberlieferung basierende kurze Erzaehlung unwahrer phantastischer Ereignisse aber als Wahrheitsbericht gemeint sind wahren Kern beruhen'
db.append(tempdbsent646)


tempdbsent647 = DBSentence()
tempdbsent647.subject        = 'Schwarz'
tempdbsent647.verb           = 'ist'
tempdbsent647.object         = 'die Bezeichnung fuer eine Farbe bzw. eine Farbempfindung'
tempdbsent647.prefix         = ''
tempdbsent647.suffix         = 'welche beim Fehlen optischer Reize auftritt, wenn also die Netzhaut ganz oder nur teilweise keine Lichtwellen im sichtbaren Spektrum rezipiert.'
tempdbsent647.feeling        = 'normal'
tempdbsent647.category       = 'normal'
tempdbsent647.priority       = 50
tempdbsent647.all_ohne_muell = 'Schwarz ist Bezeichnung Farbe bzw Farbempfindung welche beim Fehlen optischer Reize auftritt wenn also Netzhaut ganz nur teilweise keine Lichtwellen im sichtbaren Spektrum rezipiert'
db.append(tempdbsent647)


tempdbsent648 = DBSentence()
tempdbsent648.subject        = 'Eine Braut fuettert'
tempdbsent648.verb           = 'ihren'
tempdbsent648.object         = 'Braeutigam liebevoll mit einem Stueck Kuchen .'
tempdbsent648.prefix         = ''
tempdbsent648.suffix         = ''
tempdbsent648.feeling        = 'normal'
tempdbsent648.category       = 'normal'
tempdbsent648.priority       = 50
tempdbsent648.all_ohne_muell = 'Eine Braut fuettert ihren Braeutigam liebevoll mit Stueck Kuchen'
db.append(tempdbsent648)


tempdbsent649 = DBSentence()
tempdbsent649.subject        = 'Ein Attribut'
tempdbsent649.verb           = 'wird'
tempdbsent649.object         = 'gemeinhin als die Zuordnung eines Merkmals zu einem konkreten Objekt verstanden.'
tempdbsent649.prefix         = ''
tempdbsent649.suffix         = ''
tempdbsent649.feeling        = 'normal'
tempdbsent649.category       = 'normal'
tempdbsent649.priority       = 50
tempdbsent649.all_ohne_muell = 'Ein Attribut wird gemeinhin als Zuordnung Merkmals zu konkreten Objekt verstanden'
db.append(tempdbsent649)


tempdbsent650 = DBSentence()
tempdbsent650.subject        = 'Der Schmerz'
tempdbsent650.verb           = 'ist'
tempdbsent650.object         = 'eine komplexe Sinnesempfindung'
tempdbsent650.prefix         = ''
tempdbsent650.suffix         = 'oft mit starker seelischer Komponente.'
tempdbsent650.feeling        = 'normal'
tempdbsent650.category       = 'normal'
tempdbsent650.priority       = 50
tempdbsent650.all_ohne_muell = 'Der Schmerz ist komplexe Sinnesempfindung oft mit starker seelischer Komponente'
db.append(tempdbsent650)


tempdbsent651 = DBSentence()
tempdbsent651.subject        = 'Wahrnehmung bezeichnet im Allgemeinen den Prozess der bewussten Aufnahme von Informationen'
tempdbsent651.verb           = 'eines'
tempdbsent651.object         = 'Lebewesens ueber seine Sinne.'
tempdbsent651.prefix         = ''
tempdbsent651.suffix         = ''
tempdbsent651.feeling        = 'normal'
tempdbsent651.category       = 'normal'
tempdbsent651.priority       = 50
tempdbsent651.all_ohne_muell = 'Wahrnehmung bezeichnet im Allgemeinen den Prozess bewussten Aufnahme Informationen Lebewesens ueber seine Sinne'
db.append(tempdbsent651)


tempdbsent652 = DBSentence()
tempdbsent652.subject        = 'Eine Komponente'
tempdbsent652.verb           = 'ist'
tempdbsent652.object         = 'Teil eines Systems oder kann als Teil eines Systems dienen.'
tempdbsent652.prefix         = ''
tempdbsent652.suffix         = ''
tempdbsent652.feeling        = 'normal'
tempdbsent652.category       = 'normal'
tempdbsent652.priority       = 50
tempdbsent652.all_ohne_muell = 'Eine Komponente ist Teil Systems kann als Teil Systems dienen'
db.append(tempdbsent652)


tempdbsent653 = DBSentence()
tempdbsent653.subject        = ''
tempdbsent653.verb           = ''
tempdbsent653.object         = ''
tempdbsent653.prefix         = 'Die Wirbeltiere'
tempdbsent653.suffix         = 'oft auch Schaedeltiere genannt, bilden einen Unterstamm der Chordatiere und umfassen Neunaugen, Knorpel und Knochenfische, die Amphibien, die Reptilien, die Voegel und die Saeugetiere mit zusammen etwa 54.'
tempdbsent653.feeling        = 'normal'
tempdbsent653.category       = 'normal'
tempdbsent653.priority       = 50
tempdbsent653.all_ohne_muell = 'Die Wirbeltiere oft auch Schaedeltiere genannt bilden einen Unterstamm Chordatiere umfassen Neunaugen Knorpel Knochenfische Amphibien Reptilien Voegel Saeugetiere mit zusammen etwa 54'
db.append(tempdbsent653)


tempdbsent654 = DBSentence()
tempdbsent654.subject        = 'Aemter Kirchspielslandgemeinden'
tempdbsent654.verb           = 'heissen'
tempdbsent654.object         = 'im schleswigholsteinischen Kreis Dithmarschen die aus mehreren selbstaendigen Gemeinden ohne eigene Verwaltung desselben Kreises bestehenden Koerperschaften des oeffentlichen Rechts'
tempdbsent654.prefix         = ''
tempdbsent654.suffix         = 'deren Bezeichnung im uebrigen SchleswigHolstein nur Aemter lautet.'
tempdbsent654.feeling        = 'normal'
tempdbsent654.category       = 'normal'
tempdbsent654.priority       = 50
tempdbsent654.all_ohne_muell = 'Aemter Kirchspielslandgemeinden heissen im schleswigholsteinischen Kreis Dithmarschen aus mehreren selbstaendigen Gemeinden ohne eigene Verwaltung desselben Kreises bestehenden Koerperschaften oeffentlichen Rechts deren Bezeichnung im uebrigen SchleswigHolstein nur Aemter lautet'
db.append(tempdbsent654)


tempdbsent655 = DBSentence()
tempdbsent655.subject        = 'Ein Gedanke'
tempdbsent655.verb           = 'ist'
tempdbsent655.object         = 'ein unmittelbares Sinngebilde des Denkens.'
tempdbsent655.prefix         = ''
tempdbsent655.suffix         = ''
tempdbsent655.feeling        = 'normal'
tempdbsent655.category       = 'normal'
tempdbsent655.priority       = 50
tempdbsent655.all_ohne_muell = 'Ein Gedanke ist unmittelbares Sinngebilde Denkens'
db.append(tempdbsent655)


tempdbsent656 = DBSentence()
tempdbsent656.subject        = 'Gemeinwesen'
tempdbsent656.verb           = 'ist'
tempdbsent656.object         = 'ein Sammelbegriff'
tempdbsent656.prefix         = ''
tempdbsent656.suffix         = 'der saemtliche gegenwaertigen und historischen Organisationsformen des menschlichen Zusammenlebens in allgemeiner, oeffentlicher Gemeinschaft bezeichnet, die ueber den Familienverband hinausgehen.'
tempdbsent656.feeling        = 'normal'
tempdbsent656.category       = 'normal'
tempdbsent656.priority       = 50
tempdbsent656.all_ohne_muell = 'Gemeinwesen ist Sammelbegriff saemtliche gegenwaertigen historischen Organisationsformen menschlichen Zusammenlebens allgemeiner oeffentlicher Gemeinschaft bezeichnet ueber den Familienverband hinausgehen'
db.append(tempdbsent656)


tempdbsent657 = DBSentence()
tempdbsent657.subject        = 'Markdorf'
tempdbsent657.verb           = 'ist'
tempdbsent657.object         = 'eine Stadt im Bodenseekreis'
tempdbsent657.prefix         = ''
tempdbsent657.suffix         = 'etwa 6 km noerdlich des Bodensees am Fusse des 754 m ue.'
tempdbsent657.feeling        = 'normal'
tempdbsent657.category       = 'normal'
tempdbsent657.priority       = 50
tempdbsent657.all_ohne_muell = 'Markdorf ist Stadt im Bodenseekreis etwa 6 km noerdlich Bodensees am Fusse 754 m ue'
db.append(tempdbsent657)


tempdbsent658 = DBSentence()
tempdbsent658.subject        = 'Der Einsatz'
tempdbsent658.verb           = 'ist'
tempdbsent658.object         = 'eine besondere Leistung'
tempdbsent658.prefix         = ''
tempdbsent658.suffix         = 'Anstrengung oder Anweisung.'
tempdbsent658.feeling        = 'normal'
tempdbsent658.category       = 'normal'
tempdbsent658.priority       = 50
tempdbsent658.all_ohne_muell = 'Der Einsatz ist besondere Leistung Anstrengung Anweisung'
db.append(tempdbsent658)


tempdbsent659 = DBSentence()
tempdbsent659.subject        = 'Ein Konflikt'
tempdbsent659.verb           = 'ist'
tempdbsent659.object         = 'eine meist gewaltsame Auseinandersetzung zwischen zwei oder mehreren Konfliktparteien und entspringt Tendenzen oder Absichten'
tempdbsent659.prefix         = ''
tempdbsent659.suffix         = 'deren gleichzeitige Verwirklichung den Konfliktparteien nicht moeglich erscheint.'
tempdbsent659.feeling        = 'normal'
tempdbsent659.category       = 'normal'
tempdbsent659.priority       = 50
tempdbsent659.all_ohne_muell = 'Ein Konflikt ist meist gewaltsame Auseinandersetzung zwei mehreren Konfliktparteien entspringt Tendenzen Absichten deren gleichzeitige Verwirklichung den Konfliktparteien nicht moeglich erscheint'
db.append(tempdbsent659)


tempdbsent660 = DBSentence()
tempdbsent660.subject        = 'die entweder ihren Ursprung im Unixsystem von AT&amp;T der 70er'
tempdbsent660.verb           = 'haben'
tempdbsent660.object         = 'oder dessen Konzepte implementieren.'
tempdbsent660.prefix         = 'Unix bezeichnet im allgemeinen Sprachgebrauch Betriebssysteme'
tempdbsent660.suffix         = ''
tempdbsent660.feeling        = 'normal'
tempdbsent660.category       = 'normal'
tempdbsent660.priority       = 50
tempdbsent660.all_ohne_muell = 'Unix bezeichnet im allgemeinen Sprachgebrauch Betriebssysteme entweder ihren Ursprung im Unixsystem AT&ampT 70er haben Konzepte implementieren'
db.append(tempdbsent660)


tempdbsent661 = DBSentence()
tempdbsent661.subject        = 'Eigentum'
tempdbsent661.verb           = 'ist'
tempdbsent661.object         = 'die rechtliche Zuordnung einer beweglichen oder unbeweglichen Sache zu einer natuerlichen oder juristischen Person im Sinne eines umfassenden und gegenueber jedermann wirkenden'
tempdbsent661.prefix         = ''
tempdbsent661.suffix         = 'sogenanntem absoluten Besitz, Verfuegungs und Nutzungsrechts.'
tempdbsent661.feeling        = 'normal'
tempdbsent661.category       = 'normal'
tempdbsent661.priority       = 50
tempdbsent661.all_ohne_muell = 'Eigentum ist rechtliche Zuordnung beweglichen unbeweglichen Sache zu natuerlichen juristischen Person im Sinne umfassenden gegenueber jedermann wirkenden sogenanntem absoluten Besitz Verfuegungs Nutzungsrechts'
db.append(tempdbsent661)


tempdbsent662 = DBSentence()
tempdbsent662.subject        = 'Das Nationaleinkommen oder auch Sozialprodukt'
tempdbsent662.verb           = 'ist'
tempdbsent662.object         = 'eine umfassende statistische Groesse'
tempdbsent662.prefix         = ''
tempdbsent662.suffix         = 'die die wirtschaftliche Leistung einer Volkswirtschaft in einem bestimmten Zeitabschnitt charakterisieren soll und vor allem als Einkommensindikator dient.'
tempdbsent662.feeling        = 'normal'
tempdbsent662.category       = 'normal'
tempdbsent662.priority       = 50
tempdbsent662.all_ohne_muell = 'Das Nationaleinkommen auch Sozialprodukt ist umfassende statistische Groesse wirtschaftliche Leistung Volkswirtschaft bestimmten Zeitabschnitt charakterisieren soll vor allem als Einkommensindikator dient'
db.append(tempdbsent662)


tempdbsent663 = DBSentence()
tempdbsent663.subject        = 'Als Liberalismus'
tempdbsent663.verb           = 'wird'
tempdbsent663.object         = 'eine auf einer freiheitlichen Gesinnung basierende Weltanschauung'
tempdbsent663.prefix         = ''
tempdbsent663.suffix         = 'die darauf aufbauende politischphilosophische Lehre und die dazugehoerige politische Richtung verstanden.'
tempdbsent663.feeling        = 'normal'
tempdbsent663.category       = 'normal'
tempdbsent663.priority       = 50
tempdbsent663.all_ohne_muell = 'Als Liberalismus wird freiheitlichen Gesinnung basierende Weltanschauung darauf aufbauende politischphilosophische Lehre dazugehoerige politische Richtung verstanden'
db.append(tempdbsent663)


tempdbsent664 = DBSentence()
tempdbsent664.subject        = 'Die Juristische Fachsprache'
tempdbsent664.verb           = 'ist'
tempdbsent664.object         = 'die Fachsprache der Rechtsanwender und Forschungsgegenstand der Rechtslinguistik.'
tempdbsent664.prefix         = ''
tempdbsent664.suffix         = ''
tempdbsent664.feeling        = 'normal'
tempdbsent664.category       = 'normal'
tempdbsent664.priority       = 50
tempdbsent664.all_ohne_muell = 'Die Juristische Fachsprache ist Fachsprache Rechtsanwender Forschungsgegenstand Rechtslinguistik'
db.append(tempdbsent664)


tempdbsent665 = DBSentence()
tempdbsent665.subject        = 'Der Vorname'
tempdbsent665.verb           = 'ist'
tempdbsent665.object         = 'der Teil des Namens einer Person'
tempdbsent665.prefix         = ''
tempdbsent665.suffix         = 'der nicht die Zugehoerigkeit zu einer Familie ausdrueckt, sondern das Individuum innerhalb der Familie bezeichnet.'
tempdbsent665.feeling        = 'normal'
tempdbsent665.category       = 'normal'
tempdbsent665.priority       = 50
tempdbsent665.all_ohne_muell = 'Der Vorname ist Teil Namens Person nicht Zugehoerigkeit zu Familie ausdrueckt sondern Individuum innerhalb Familie bezeichnet'
db.append(tempdbsent665)


tempdbsent666 = DBSentence()
tempdbsent666.subject        = 'Marcellus'
tempdbsent666.verb           = 'ist'
tempdbsent666.object         = 'ein aus dem Lateinischen stammender maennlicher Vorname.'
tempdbsent666.prefix         = ''
tempdbsent666.suffix         = ''
tempdbsent666.feeling        = 'normal'
tempdbsent666.category       = 'normal'
tempdbsent666.priority       = 50
tempdbsent666.all_ohne_muell = 'Marcellus ist aus Lateinischen stammender maennlicher Vorname'
db.append(tempdbsent666)


tempdbsent667 = DBSentence()
tempdbsent667.subject        = 'Tiere'
tempdbsent667.verb           = 'sind'
tempdbsent667.object         = 'in ihrer klassischen Definition Lebewesen'
tempdbsent667.prefix         = ''
tempdbsent667.suffix         = 'die ihre Energie nicht durch Photosynthese gewinnen, sondern sich von anderen tierischen oder pflanzlichen Organismen ernaehren und Sauerstoff zur Atmung benoetigen.'
tempdbsent667.feeling        = 'normal'
tempdbsent667.category       = 'normal'
tempdbsent667.priority       = 50
tempdbsent667.all_ohne_muell = 'Tiere sind ihrer klassischen Definition Lebewesen ihre Energie nicht durch Photosynthese gewinnen sondern sich anderen tierischen pflanzlichen Organismen ernaehren Sauerstoff zur Atmung benoetigen'
db.append(tempdbsent667)


tempdbsent668 = DBSentence()
tempdbsent668.subject        = 'Energie'
tempdbsent668.verb           = 'ist'
tempdbsent668.object         = 'eine physikalische Zustandsgroesse.'
tempdbsent668.prefix         = ''
tempdbsent668.suffix         = ''
tempdbsent668.feeling        = 'normal'
tempdbsent668.category       = 'normal'
tempdbsent668.priority       = 50
tempdbsent668.all_ohne_muell = 'Energie ist physikalische Zustandsgroesse'
db.append(tempdbsent668)


tempdbsent669 = DBSentence()
tempdbsent669.subject        = 'Ausschnitt'
tempdbsent669.verb           = 'aus'
tempdbsent669.object         = 'einem Laubblatt mit Gefaessaederung .'
tempdbsent669.prefix         = ''
tempdbsent669.suffix         = ''
tempdbsent669.feeling        = 'normal'
tempdbsent669.category       = 'normal'
tempdbsent669.priority       = 50
tempdbsent669.all_ohne_muell = 'Ausschnitt aus Laubblatt mit Gefaessaederung'
db.append(tempdbsent669)


tempdbsent670 = DBSentence()
tempdbsent670.subject        = 'Sauerstoff'
tempdbsent670.verb           = 'ist'
tempdbsent670.object         = 'ein chemisches Element im Periodensystem der Elemente mit dem Symbol O und der Ordnungszahl 8.'
tempdbsent670.prefix         = ''
tempdbsent670.suffix         = ''
tempdbsent670.feeling        = 'normal'
tempdbsent670.category       = 'normal'
tempdbsent670.priority       = 50
tempdbsent670.all_ohne_muell = 'Sauerstoff ist chemisches Element im Periodensystem Elemente mit Symbol O Ordnungszahl 8'
db.append(tempdbsent670)


tempdbsent671 = DBSentence()
tempdbsent671.subject        = 'Unter Atmung versteht man allgemein den'
tempdbsent671.verb           = 'aeroben,'
tempdbsent671.object         = 'das heisst Sauerstoff verbrauchenden Abbau von Stoffen zur Energiegewinnung und die damit einhergehende Abgabe von Kohlendioxid.'
tempdbsent671.prefix         = ''
tempdbsent671.suffix         = ''
tempdbsent671.feeling        = 'normal'
tempdbsent671.category       = 'normal'
tempdbsent671.priority       = 50
tempdbsent671.all_ohne_muell = 'Unter Atmung versteht man allgemein den aeroben heisst Sauerstoff verbrauchenden Abbau Stoffen zur Energiegewinnung damit einhergehende Abgabe Kohlendioxid'
db.append(tempdbsent671)


tempdbsent672 = DBSentence()
tempdbsent672.subject        = 'Gestalt meint umgangssprachlich die'
tempdbsent672.verb           = 'aeussere'
tempdbsent672.object         = 'Form'
tempdbsent672.prefix         = ''
tempdbsent672.suffix         = 'den Umriss, Wuchs oder die Erscheinung von Gegenstaenden und Lebewesen.'
tempdbsent672.feeling        = 'normal'
tempdbsent672.category       = 'normal'
tempdbsent672.priority       = 50
tempdbsent672.all_ohne_muell = 'Gestalt meint umgangssprachlich aeussere Form den Umriss Wuchs Erscheinung Gegenstaenden Lebewesen'
db.append(tempdbsent672)


tempdbsent673 = DBSentence()
tempdbsent673.subject        = 'Die Mythologie'
tempdbsent673.verb           = 'ist'
tempdbsent673.object         = 'die systematische Beschaeftigung mit Mythen in literarischer'
tempdbsent673.prefix         = ''
tempdbsent673.suffix         = 'wissenschaftlicher oder religioeser Form.'
tempdbsent673.feeling        = 'normal'
tempdbsent673.category       = 'normal'
tempdbsent673.priority       = 50
tempdbsent673.all_ohne_muell = 'Die Mythologie ist systematische Beschaeftigung mit Mythen literarischer wissenschaftlicher religioeser Form'
db.append(tempdbsent673)


tempdbsent674 = DBSentence()
tempdbsent674.subject        = 'Das Grossherzogtum Luxemburg'
tempdbsent674.verb           = 'ist'
tempdbsent674.object         = 'ein Staat in Westeuropa.'
tempdbsent674.prefix         = ''
tempdbsent674.suffix         = ''
tempdbsent674.feeling        = 'normal'
tempdbsent674.category       = 'normal'
tempdbsent674.priority       = 50
tempdbsent674.all_ohne_muell = 'Das Grossherzogtum Luxemburg ist Staat Westeuropa'
db.append(tempdbsent674)


tempdbsent675 = DBSentence()
tempdbsent675.subject        = 'Verwendung'
tempdbsent675.verb           = 'ist'
tempdbsent675.object         = 'der juristische Fachausdruck fuer eine Aufwendung zu Gunsten einer Sache.'
tempdbsent675.prefix         = ''
tempdbsent675.suffix         = ''
tempdbsent675.feeling        = 'normal'
tempdbsent675.category       = 'normal'
tempdbsent675.priority       = 50
tempdbsent675.all_ohne_muell = 'Verwendung ist juristische Fachausdruck Aufwendung zu Gunsten Sache'
db.append(tempdbsent675)


tempdbsent676 = DBSentence()
tempdbsent676.subject        = 'Beim Kringel handelt es sich um'
tempdbsent676.verb           = 'ein'
tempdbsent676.object         = 'gerolltes Hefegebaeck mit einer Fuellung aus Butterflocken'
tempdbsent676.prefix         = ''
tempdbsent676.suffix         = 'Zimt und Zucker.'
tempdbsent676.feeling        = 'normal'
tempdbsent676.category       = 'normal'
tempdbsent676.priority       = 50
tempdbsent676.all_ohne_muell = 'Beim Kringel handelt es sich um gerolltes Hefegebaeck mit Fuellung aus Butterflocken Zimt Zucker'
db.append(tempdbsent676)


tempdbsent677 = DBSentence()
tempdbsent677.subject        = 'der'
tempdbsent677.verb           = 'allgemein'
tempdbsent677.object         = 'und berufsbildende Schulen mit digitalen Medien fuer Unterrichtszwecke versorgt.'
tempdbsent677.prefix         = 'EDMOND bezeichnet einen elektronischen Mediendienst in NordrheinWestfalen'
tempdbsent677.suffix         = ''
tempdbsent677.feeling        = 'normal'
tempdbsent677.category       = 'normal'
tempdbsent677.priority       = 50
tempdbsent677.all_ohne_muell = 'EDMOND bezeichnet einen elektronischen Mediendienst NordrheinWestfalen allgemein berufsbildende Schulen mit digitalen Medien Unterrichtszwecke versorgt'
db.append(tempdbsent677)


tempdbsent678 = DBSentence()
tempdbsent678.subject        = ''
tempdbsent678.verb           = ''
tempdbsent678.object         = ''
tempdbsent678.prefix         = 'Unter einer Umsetzung versteht man im Beamtenrecht die Zuweisung des Beamten zu einem anderen Dienstposten innerhalb derselben Behoerde.'
tempdbsent678.suffix         = ''
tempdbsent678.feeling        = 'normal'
tempdbsent678.category       = 'normal'
tempdbsent678.priority       = 50
tempdbsent678.all_ohne_muell = 'Unter Umsetzung versteht man im Beamtenrecht Zuweisung Beamten zu anderen Dienstposten innerhalb derselben Behoerde'
db.append(tempdbsent678)


tempdbsent679 = DBSentence()
tempdbsent679.subject        = 'Die Wirtschaftswissenschaft'
tempdbsent679.verb           = 'ist'
tempdbsent679.object         = 'die Lehre von der Wirtschaft .'
tempdbsent679.prefix         = ''
tempdbsent679.suffix         = ''
tempdbsent679.feeling        = 'normal'
tempdbsent679.category       = 'normal'
tempdbsent679.priority       = 50
tempdbsent679.all_ohne_muell = 'Die Wirtschaftswissenschaft ist Lehre Wirtschaft'
db.append(tempdbsent679)


tempdbsent680 = DBSentence()
tempdbsent680.subject        = 'Die Soziologie beschreibt und'
tempdbsent680.verb           = 'erklaert'
tempdbsent680.object         = 'den Aufbau und die Entwicklung der Gesellschaft.'
tempdbsent680.prefix         = ''
tempdbsent680.suffix         = ''
tempdbsent680.feeling        = 'normal'
tempdbsent680.category       = 'normal'
tempdbsent680.priority       = 50
tempdbsent680.all_ohne_muell = 'Die Soziologie beschreibt erklaert den Aufbau Entwicklung Gesellschaft'
db.append(tempdbsent680)


tempdbsent681 = DBSentence()
tempdbsent681.subject        = ''
tempdbsent681.verb           = ''
tempdbsent681.object         = ''
tempdbsent681.prefix         = 'Geraeucherte Mettwurst im Kunstdarm'
tempdbsent681.suffix         = 'Luftgetrocknete Salami im Naturdarm .'
tempdbsent681.feeling        = 'normal'
tempdbsent681.category       = 'normal'
tempdbsent681.priority       = 50
tempdbsent681.all_ohne_muell = 'Geraeucherte Mettwurst im Kunstdarm Luftgetrocknete Salami im Naturdarm'
db.append(tempdbsent681)


tempdbsent682 = DBSentence()
tempdbsent682.subject        = 'Als Naturdarm'
tempdbsent682.verb           = 'wird'
tempdbsent682.object         = 'zur Unterscheidung vom Kunstdarm  der echte Darm eines Tieres bezeichnet'
tempdbsent682.prefix         = ''
tempdbsent682.suffix         = 'der zur Wurstherstellung verwendet wird.'
tempdbsent682.feeling        = 'normal'
tempdbsent682.category       = 'normal'
tempdbsent682.priority       = 50
tempdbsent682.all_ohne_muell = 'Als Naturdarm wird zur Unterscheidung Kunstdarm echte Darm Tieres bezeichnet zur Wurstherstellung verwendet wird'
db.append(tempdbsent682)


tempdbsent683 = DBSentence()
tempdbsent683.subject        = 'Die Prignitz'
tempdbsent683.verb           = 'ist'
tempdbsent683.object         = 'eine Landschaft im Nordwesten des Landes Brandenburg.'
tempdbsent683.prefix         = ''
tempdbsent683.suffix         = ''
tempdbsent683.feeling        = 'normal'
tempdbsent683.category       = 'normal'
tempdbsent683.priority       = 50
tempdbsent683.all_ohne_muell = 'Die Prignitz ist Landschaft im Nordwesten Landes Brandenburg'
db.append(tempdbsent683)


tempdbsent684 = DBSentence()
tempdbsent684.subject        = 'Brandenburg'
tempdbsent684.verb           = 'ist'
tempdbsent684.object         = 'ein Bundesland im Nordosten Deutschlands.'
tempdbsent684.prefix         = ''
tempdbsent684.suffix         = ''
tempdbsent684.feeling        = 'normal'
tempdbsent684.category       = 'normal'
tempdbsent684.priority       = 50
tempdbsent684.all_ohne_muell = 'Brandenburg ist Bundesland im Nordosten Deutschlands'
db.append(tempdbsent684)


tempdbsent685 = DBSentence()
tempdbsent685.subject        = 'Albrecht'
tempdbsent685.verb           = 'ist'
tempdbsent685.object         = 'eine Kurzform des maennlichen Vornamens Adalbert.'
tempdbsent685.prefix         = ''
tempdbsent685.suffix         = ''
tempdbsent685.feeling        = 'normal'
tempdbsent685.category       = 'normal'
tempdbsent685.priority       = 50
tempdbsent685.all_ohne_muell = 'Albrecht ist Kurzform maennlichen Vornamens Adalbert'
db.append(tempdbsent685)


tempdbsent686 = DBSentence()
tempdbsent686.subject        = 'Gifhorn'
tempdbsent686.verb           = 'ist'
tempdbsent686.object         = 'die Kreisstadt des gleichnamigen Landkreises im Osten des Landes Niedersachsen.'
tempdbsent686.prefix         = ''
tempdbsent686.suffix         = ''
tempdbsent686.feeling        = 'normal'
tempdbsent686.category       = 'normal'
tempdbsent686.priority       = 50
tempdbsent686.all_ohne_muell = 'Gifhorn ist Kreisstadt gleichnamigen Landkreises im Osten Landes Niedersachsen'
db.append(tempdbsent686)


tempdbsent687 = DBSentence()
tempdbsent687.subject        = 'die den Rahmen fuer die wirtschaftlichen Taetigkeiten innerhalb'
tempdbsent687.verb           = 'eines'
tempdbsent687.object         = 'Wirtschaftsraumes vorgibt.'
tempdbsent687.prefix         = 'Wirtschaftsordnung bezeichnet die politische und rechtliche Form'
tempdbsent687.suffix         = ''
tempdbsent687.feeling        = 'normal'
tempdbsent687.category       = 'normal'
tempdbsent687.priority       = 50
tempdbsent687.all_ohne_muell = 'Wirtschaftsordnung bezeichnet politische rechtliche Form den Rahmen wirtschaftlichen Taetigkeiten innerhalb Wirtschaftsraumes vorgibt'
db.append(tempdbsent687)


tempdbsent688 = DBSentence()
tempdbsent688.subject        = 'Der Begriff Elfenbeinturm bezeichnet einen'
tempdbsent688.verb           = 'geistigen'
tempdbsent688.object         = 'Ort der Abgeschiedenheit und Unberuehrtheit von der Welt.'
tempdbsent688.prefix         = ''
tempdbsent688.suffix         = ''
tempdbsent688.feeling        = 'normal'
tempdbsent688.category       = 'normal'
tempdbsent688.priority       = 50
tempdbsent688.all_ohne_muell = 'Der Begriff Elfenbeinturm bezeichnet einen geistigen Ort Abgeschiedenheit Unberuehrtheit Welt'
db.append(tempdbsent688)


tempdbsent689 = DBSentence()
tempdbsent689.subject        = ''
tempdbsent689.verb           = ''
tempdbsent689.object         = ''
tempdbsent689.prefix         = 'Der Begriff Antike bezeichnet eine Epoche des Altertums im Mittelmeerraum.'
tempdbsent689.suffix         = ''
tempdbsent689.feeling        = 'normal'
tempdbsent689.category       = 'normal'
tempdbsent689.priority       = 50
tempdbsent689.all_ohne_muell = 'Der Begriff Antike bezeichnet Epoche Altertums im Mittelmeerraum'
db.append(tempdbsent689)


tempdbsent690 = DBSentence()
tempdbsent690.subject        = 'Jugendmagazine'
tempdbsent690.verb           = 'sind'
tempdbsent690.object         = 'Zeitschriften fuer die Zielgruppe der 11 bis 25Jaehrigen'
tempdbsent690.prefix         = ''
tempdbsent690.suffix         = 'die sich teilweise mit voellig unterschiedlichen Themen befassen.'
tempdbsent690.feeling        = 'normal'
tempdbsent690.category       = 'normal'
tempdbsent690.priority       = 50
tempdbsent690.all_ohne_muell = 'Jugendmagazine sind Zeitschriften Zielgruppe 11 bis 25Jaehrigen sich teilweise mit voellig unterschiedlichen Themen befassen'
db.append(tempdbsent690)


tempdbsent691 = DBSentence()
tempdbsent691.subject        = ''
tempdbsent691.verb           = ''
tempdbsent691.object         = ''
tempdbsent691.prefix         = 'Das Kuerzel INC oder Inc steht fuer .'
tempdbsent691.suffix         = ''
tempdbsent691.feeling        = 'normal'
tempdbsent691.category       = 'normal'
tempdbsent691.priority       = 50
tempdbsent691.all_ohne_muell = 'Das Kuerzel INC Inc steht'
db.append(tempdbsent691)


tempdbsent692 = DBSentence()
tempdbsent692.subject        = 'Moenche uebernahmen die grammatische Tradition'
tempdbsent692.verb           = 'der'
tempdbsent692.object         = 'Antike .'
tempdbsent692.prefix         = ''
tempdbsent692.suffix         = ''
tempdbsent692.feeling        = 'normal'
tempdbsent692.category       = 'normal'
tempdbsent692.priority       = 50
tempdbsent692.all_ohne_muell = 'Moenche uebernahmen grammatische Tradition Antike'
db.append(tempdbsent692)


tempdbsent693 = DBSentence()
tempdbsent693.subject        = 'Kritik'
tempdbsent693.verb           = 'kam'
tempdbsent693.object         = 'ueber das franzoesische critique ins Deutsche.'
tempdbsent693.prefix         = ''
tempdbsent693.suffix         = ''
tempdbsent693.feeling        = 'normal'
tempdbsent693.category       = 'normal'
tempdbsent693.priority       = 50
tempdbsent693.all_ohne_muell = 'Kritik kam ueber franzoesische critique ins Deutsche'
db.append(tempdbsent693)


tempdbsent694 = DBSentence()
tempdbsent694.subject        = 'Eine Zeremonie'
tempdbsent694.verb           = 'ist'
tempdbsent694.object         = 'eine Bezeichnung fuer feierliche Handlungen im kirchlichen Bereich und auch im weltlichen Bereich'
tempdbsent694.prefix         = ''
tempdbsent694.suffix         = 'bei staatlichen Veranstaltungen auch Protokoll .'
tempdbsent694.feeling        = 'normal'
tempdbsent694.category       = 'normal'
tempdbsent694.priority       = 50
tempdbsent694.all_ohne_muell = 'Eine Zeremonie ist Bezeichnung feierliche Handlungen im kirchlichen Bereich auch im weltlichen Bereich bei staatlichen Veranstaltungen auch Protokoll'
db.append(tempdbsent694)


tempdbsent695 = DBSentence()
tempdbsent695.subject        = 'Das Gesetz ueber die Eingetragene Lebenspartnerschaft oder kurz Lebenspartnerschaftsgesetz ermoeglicht zwei Menschen des'
tempdbsent695.verb           = 'gleichen'
tempdbsent695.object         = 'Geschlechts in der Bundesrepublik Deutschland die Begruendung einer Lebenspartnerschaft.'
tempdbsent695.prefix         = ''
tempdbsent695.suffix         = ''
tempdbsent695.feeling        = 'normal'
tempdbsent695.category       = 'normal'
tempdbsent695.priority       = 50
tempdbsent695.all_ohne_muell = 'Das Gesetz ueber Eingetragene Lebenspartnerschaft kurz Lebenspartnerschaftsgesetz ermoeglicht zwei Menschen gleichen Geschlechts Bundesrepublik Deutschland Begruendung Lebenspartnerschaft'
db.append(tempdbsent695)


tempdbsent696 = DBSentence()
tempdbsent696.subject        = 'Zweifel'
tempdbsent696.verb           = 'ist'
tempdbsent696.object         = 'ein emotionaler Zustand und wird als Unsicherheit in Bezug auf Vertrauen'
tempdbsent696.prefix         = ''
tempdbsent696.suffix         = 'Taten, Entscheidungen, Glauben oder Behauptung bzw. Vermutung von Tatsachen bezeichnet.'
tempdbsent696.feeling        = 'normal'
tempdbsent696.category       = 'normal'
tempdbsent696.priority       = 50
tempdbsent696.all_ohne_muell = 'Zweifel ist emotionaler Zustand wird als Unsicherheit Bezug Vertrauen Taten Entscheidungen Glauben Behauptung bzw Vermutung Tatsachen bezeichnet'
db.append(tempdbsent696)


tempdbsent697 = DBSentence()
tempdbsent697.subject        = 'an die keine denotative Bedeutung gekoppelt'
tempdbsent697.verb           = 'ist'
tempdbsent697.object         = ''
tempdbsent697.prefix         = 'Namen sind Bezeichnungen'
tempdbsent697.suffix         = ''
tempdbsent697.feeling        = 'normal'
tempdbsent697.category       = 'normal'
tempdbsent697.priority       = 50
tempdbsent697.all_ohne_muell = 'Namen sind Bezeichnungen an keine denotative Bedeutung gekoppelt ist'
db.append(tempdbsent697)


tempdbsent698 = DBSentence()
tempdbsent698.subject        = 'ich'
tempdbsent698.verb           = 'bin'
tempdbsent698.object         = 'total doof'
tempdbsent698.prefix         = ''
tempdbsent698.suffix         = ''
tempdbsent698.feeling        = 'normal'
tempdbsent698.category       = 'normal'
tempdbsent698.priority       = 50
tempdbsent698.all_ohne_muell = 'ich bin total doof'
db.append(tempdbsent698)


tempdbsent699 = DBSentence()
tempdbsent699.subject        = 'Bush ist'
tempdbsent699.verb           = 'siehe'
tempdbsent699.object         = 'dort Etymologie und bekannte Namenstraeger'
tempdbsent699.prefix         = ''
tempdbsent699.suffix         = 'englische Rockband der Richtung Alternative-Rock'
tempdbsent699.feeling        = 'normal'
tempdbsent699.category       = 'normal'
tempdbsent699.priority       = 50
tempdbsent699.all_ohne_muell = 'Bush ist siehe dort Etymologie bekannte Namenstraeger englische Rockband Richtung Alternative-Rock'
db.append(tempdbsent699)


tempdbsent700 = DBSentence()
tempdbsent700.subject        = 'George'
tempdbsent700.verb           = 'ist'
tempdbsent700.object         = 'die englische Variante des maennlichen Vornamens Georg.'
tempdbsent700.prefix         = ''
tempdbsent700.suffix         = ''
tempdbsent700.feeling        = 'normal'
tempdbsent700.category       = 'normal'
tempdbsent700.priority       = 50
tempdbsent700.all_ohne_muell = 'George ist englische Variante maennlichen Vornamens Georg'
db.append(tempdbsent700)


tempdbsent701 = DBSentence()
tempdbsent701.subject        = 'Nach anfaenglichen Erfolgen mit einem BASICInterpreter Ende der 70er Jahre'
tempdbsent701.verb           = 'hat'
tempdbsent701.object         = 'die Firma erstmals 1981 das Betriebssystem MSDOS vorgestellt.'
tempdbsent701.prefix         = ''
tempdbsent701.suffix         = ''
tempdbsent701.feeling        = 'normal'
tempdbsent701.category       = 'normal'
tempdbsent701.priority       = 50
tempdbsent701.all_ohne_muell = 'Nach anfaenglichen Erfolgen mit BASICInterpreter Ende 70er Jahre hat Firma erstmals 1981 Betriebssystem MSDOS vorgestellt'
db.append(tempdbsent701)


tempdbsent702 = DBSentence()
tempdbsent702.subject        = ''
tempdbsent702.verb           = ''
tempdbsent702.object         = ''
tempdbsent702.prefix         = 'Busen steht fuer:'
tempdbsent702.suffix         = 'der Bereich zwischen Hals und Bruesten und die Vertiefung zwischen denselben'
tempdbsent702.feeling        = 'normal'
tempdbsent702.category       = 'normal'
tempdbsent702.priority       = 50
tempdbsent702.all_ohne_muell = 'Busen steht fuer: Bereich Hals Bruesten Vertiefung denselben'
db.append(tempdbsent702)


tempdbsent703 = DBSentence()
tempdbsent703.subject        = 'so'
tempdbsent703.verb           = 'ist'
tempdbsent703.object         = 'es'
tempdbsent703.prefix         = ''
tempdbsent703.suffix         = ''
tempdbsent703.feeling        = 'normal'
tempdbsent703.category       = 'normal'
tempdbsent703.priority       = 50
tempdbsent703.all_ohne_muell = 'so ist es'
db.append(tempdbsent703)


tempdbsent704 = DBSentence()
tempdbsent704.subject        = 'ich'
tempdbsent704.verb           = 'bin'
tempdbsent704.object         = 'dumm'
tempdbsent704.prefix         = ''
tempdbsent704.suffix         = ''
tempdbsent704.feeling        = 'normal'
tempdbsent704.category       = 'normal'
tempdbsent704.priority       = 50
tempdbsent704.all_ohne_muell = 'ich bin dumm'
db.append(tempdbsent704)




