/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef GTKGUI_PRIVATE_H
#define GTKGUI_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"0.1.1.53"
#define VER_MAJOR	0
#define VER_MINOR	1
#define VER_RELEASE	1
#define VER_BUILD	53
#define COMPANY_NAME	"Tobias Schulz & Marcel Kunzmann"
#define FILE_VERSION	"2.1"
#define FILE_DESCRIPTION	"JEliza"
#define INTERNAL_NAME	"JEliza"
#define LEGAL_COPYRIGHT	"Tobias Schulz & Marcel Kunzmann"
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	"JEliza"
#define PRODUCT_VERSION	"2.1"

#endif /*GTKGUI_PRIVATE_H*/
