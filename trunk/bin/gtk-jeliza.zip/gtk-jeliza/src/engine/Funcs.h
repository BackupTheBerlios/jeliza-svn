#ifndef __FUNCS_
#define __FUNCS_

#include <vector>
#include <fstream>
#include <string>
#include <time.h>
#include <math.h>
using namespace std;
#include "Defs.h"

class Funcs {

public:

static int wordcmp(const string &word1, const string &word2) {
	size_t bound=MIN(word1.size(),word2.size());
	for( size_t i = 0; i < bound; ++i ) {
		if( toupper(word1[i]) != toupper(word2[i]) ) {
			return((int)( toupper(word1[i]) - toupper(word2[i]) ) );
		}
	}
	if( word1.size() < word2.size() ) return( -1 );
	if( word1.size() > word2.size() ) return( 1 );
	return(0);
};

static void upper(string &theWord) {
	for( size_t i = 0; i < theWord.size(); ++i ) {
		theWord[i] = toupper(theWord[i]);
	}
}

static void middle(string &theWord) {
	bool newSentence = true;
	for( size_t i = 0; i < theWord.size(); ++i ) {
		/*
		if( isalpha(theWord[i]) ) {
			if( newSentence ) {
				theWord[i] = toupper(theWord[i]);
				newSentence = false;
			}
			else {
				theWord[i] = tolower(theWord[i]);
			}
		}
		*/
		switch( theWord[i] ) {
			case '!' :
			case '?' :
			case '.' :
				newSentence = i > 0 && isspace(theWord[i+1]);
				break;
			default:
				if( isalpha(theWord[i]) ) {
					if( newSentence ) {
						theWord[i] = toupper(theWord[i]);
						newSentence = false;
					}
					else {
						theWord[i] = tolower(theWord[i]);
					}
				}
				break;
		}
	}
}

/*
 *		Function:	Boundary
 *
 *		Purpose:		Return whether or not a word boundary exists in a string
 *						at the specified location.
 */
static bool boundary(const string &phrase, size_t pos) {
	if( pos==0 ) {
		return( false );
	}
	if( pos == phrase.size() ) {
		return( true );
	}
	bool aposm2, aposm1, apos, aposp1;
	aposm2 = pos > 1 ? isalpha(phrase[pos-2]) != 0 : false;
	aposm1 = isalpha(phrase[pos-1]) != 0;
	apos = isalpha(phrase[pos]) != 0;
	aposp1 = isalpha(phrase[pos+1]) != 0;
	if( ( phrase[pos] == '\'' ) && aposm1 && aposp1 ) {
		return( false );
	}
	if( ( phrase[pos-1] == '\'' ) && aposm2 && apos ) {
		return( false );
	}
	if( apos != aposm1 ) {
		return( true );
	}
	if( isdigit(phrase[pos]) != isdigit(phrase[pos-1]) ) {
		return( true );
	}
	return( false );
};

/*
 *		Function:	Rnd
 *
 *		Purpose:		Return a random integer between 0 and range-1.
 */
static size_t rnd(size_t range)
{
	static bool flag=false;

	if(flag==false) {
#if defined(__mac_os) || defined(DOS)
		
		#ifdef DEBUG_UNTIMED_REPLY
			srand(17777);
		#else
			srand((unsigned int)time(NULL));
		#endif
#else
		#ifdef DEBUG_UNTIMED_REPLY
			srand48(17777);
		#else
			srand48((unsigned int)time(NULL));
		#endif
#endif
	}
	flag=true;
#if defined(__mac_os) || defined(DOS)
	unsigned int rando = rand();
	return(rando%range);
#else
	return(floor(drand48()*(double)(range)));
#endif
};

static string cookie() {
	return( string("MegaHALv8") );
};

}; 

#endif 
